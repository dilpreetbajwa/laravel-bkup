<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="csrf-token" content="{{ csrf_token() }}">

  <title>ReserveAndRent</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="{{url('plugins/fontawesome-free/css/all.min.css')}}">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bbootstrap 4 -->
  <link rel="stylesheet" href="{{url('plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css')}}">
  <!-- iCheck -->
  <link rel="stylesheet" href="{{url('plugins/icheck-bootstrap/icheck-bootstrap.min.css')}}">
  <!-- JQVMap -->
  <link rel="stylesheet" href="{{url('plugins/jqvmap/jqvmap.min.css')}}">
  <!-- Theme style -->
  <link rel="stylesheet" href="{{url('dist/css/adminlte.min.css')}}">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="{{url('plugins/overlayScrollbars/css/OverlayScrollbars.min.css')}}">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="{{url('plugins/daterangepicker/daterangepicker.css')}}">
  <!-- summernote -->
  <link rel="stylesheet" href="{{url('plugins/summernote/summernote-bs4.css')}}">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
  
   <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-bars"></i></a>
      </li>
      
    </ul>

    <!-- Right navbar links -->
<ul class="navbar-nav ml-auto">
                   <li class="nav-item dropdown">
                       <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                      
                           {{ Auth::user()->name }} <span class="caret"></span>
                           
                       </a>

                       <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                           <a class="dropdown-item" href="{{url('my_profile/')}}" >
                               {{ __('Profile') }}
                           </a>
                           <a class="dropdown-item" href="{{ route('logout') }}">
                               {{ __('Logout') }}
                           </a>

                           <form id="logout-form" action="" method="POST" style="display: none;">
                               @csrf
                           </form>
                       </div>
                   </li>
               </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="/home" class="brand-link">
      <img src="{{url('dist/img/AdminLTELogo.jpg')}}" alt="AdminLTE Logo" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">ReserveAndRent</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
    

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item has-treeview @if(Route::currentRouteName() == 'home') {{ 'menu-open' }} @endif">
            <a href="{{url('/home')}}" class="nav-link @if(Route::currentRouteName() == 'home') {{ 'active' }} @endif">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard             
              </p>
            </a>
          </li>

             <li class="nav-item has-treeview @if(Route::currentRouteName() == 'addsubadmin' ||  Route::currentRouteName() == 'subadminlist' ) {{ 'active menu-open' }} @endif"  >
            <a href="#" class="nav-link @if(Route::currentRouteName() == 'addsubadmin' ||  Route::currentRouteName() == 'subadminlist' ) {{ 'active' }} @endif" <?php if(in_array('Sub Admins', $menu)){?> style="display: block;" <?php }else{ ?> style="display: none;" <?php } ?> >
              <i class="nav-icon fa fa-user"></i>
              <p>
                Sub Admins
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="{{url('/subadminlist')}}"  class="nav-link @if(Route::currentRouteName() == 'users') {{ 'active' }} @endif">
                  <i class="far fa-circle nav-icon"></i>
                  <p>List View</p>
                </a>
              </li>
               <li class="nav-item">
                <a href="{{url('/addsubadmin')}}"  class="nav-link @if(Route::currentRouteName() == 'addsubadmin') {{ 'active' }} @endif">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Add SubAdmins</p>
                </a>
              </li>
            </ul>
          </li>


            <li class="nav-item has-treeview @if(Route::currentRouteName() == 'users'  ) {{ 'active menu-open' }} @endif" <?php if(in_array('Users', $menu)){?> style="display: block;" <?php }else{ ?> style="display: none;" <?php } ?>  >
            <a href="#" class="nav-link @if(Route::currentRouteName() == 'users') {{ 'active' }} @endif">
              <i class="nav-icon fa fa-user"></i>
              <p>
                Users
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="{{url('/users')}}"  class="nav-link @if(Route::currentRouteName() == 'users') {{ 'active' }} @endif">
                  <i class="far fa-circle nav-icon"></i>
                  <p>List View</p>
                </a>
              </li>
            </ul>
          </li>

            <li class="nav-item has-treeview @if(Route::currentRouteName() == 'place' || Route::currentRouteName() == 'place_provider_list'|| Route::currentRouteName() == 'place_subcat'  ) {{ 'active menu-open' }} @endif">
            <a href="#" class="nav-link @if(Route::currentRouteName() == 'place' || Route::currentRouteName() == 'place_provider_list' || Route::currentRouteName() == 'place_subcat') {{ 'active' }} @endif" <?php if(in_array('Places', $menu)){?> style="display: block;" <?php }else{ ?> style="display: none;" <?php } ?> >
              <i class="nav-icon fa fa-university"></i>
              <p>
                Places 
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="{{route('place')}}"  class="nav-link @if(Route::currentRouteName() == 'place') {{ 'active' }} @endif">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Add Places Categories</p>
                </a>
              </li>

              <li class="nav-item">
                <a href="{{route('place_subcat')}}"  class="nav-link @if(Route::currentRouteName() == 'place_subcat') {{ 'active' }} @endif">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Add Places Subcategory</p>
                </a>
              </li>
                  <li class="nav-item">
                <a href="{{route('place_provider_list')}}"  class="nav-link @if(Route::currentRouteName() == 'place_provider_list') {{ 'active' }} @endif">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Places Provider</p>
                </a>
              </li>
            </ul>
          </li>


              <li class="nav-item has-treeview @if(Route::currentRouteName() == 'thing' || Route::currentRouteName() == 'thing_subcat' || Route::currentRouteName() == 'thing_provider_list' ) {{ 'active menu-open' }} @endif">
            <a href="#" class="nav-link @if(Route::currentRouteName() == 'thing' || Route::currentRouteName() == 'thing_subcat' || Route::currentRouteName() == 'thing_provider_list' ) {{ 'active' }} @endif" <?php if(in_array('Things', $menu)){?> style="display: block;" <?php }else{ ?> style="display: none;" <?php } ?> >
              <i class="nav-icon fa fa-cubes"></i>
              <p>
                Things
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="{{route('thing')}}"  class="nav-link @if(Route::currentRouteName() == 'thing') {{ 'active' }} @endif">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Add Things Categories</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="{{route('thing_subcat')}}"  class="nav-link @if(Route::currentRouteName() == 'thing_subcat') {{ 'active' }} @endif">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Add Things Subcategory</p>
                </a>
              </li>
               <li class="nav-item">
                <a href="{{route('thing_provider_list')}}"  class="nav-link @if(Route::currentRouteName() == 'thing_provider_list') {{ 'active' }} @endif">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Things Provider</p>
                </a>
              </li>
            </ul>
          </li>


              <li class="nav-item has-treeview @if(Route::currentRouteName() == 'people' || Route::currentRouteName() == 'provider_list' ||Route::currentRouteName() == 'people_subcat' ) {{ 'active menu-open' }} @endif">
            <a href="#" class="nav-link @if(Route::currentRouteName() == 'people'|| Route::currentRouteName() == 'provider_list' ||Route::currentRouteName() == 'people_subcat') {{ 'active' }} @endif" <?php if(in_array('People', $menu)){?> style="display: block;" <?php }else{ ?> style="display: none;" <?php } ?> >
              <i class="nav-icon fa fa-users"></i>
              <p>
                People
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="{{route('people')}}"  class="nav-link @if(Route::currentRouteName() == 'people') {{ 'active' }} @endif">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Add Peoples Categories</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="{{route('people_subcat')}}"  class="nav-link @if(Route::currentRouteName() == 'people_subcat') {{ 'active' }} @endif">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Add People Subcategory</p>
                </a>
              </li>
                 <li class="nav-item">
                <a href="{{route('provider_list')}}"  class="nav-link @if(Route::currentRouteName() == 'provider_list') {{ 'active' }} @endif">
                  <i class="far fa-circle nav-icon"></i>
                  <p>ServiceProvider</p>
                </a>
              </li>
            </ul>
          </li>


              <li class="nav-item has-treeview @if(Route::currentRouteName() == 'coupon'  ) {{ 'active menu-open' }} @endif" <?php if(in_array('Coupons', $menu)){?> style="display: block;" <?php }else{ ?> style="display: none;" <?php } ?>  >
            <a href="#" class="nav-link @if(Route::currentRouteName() == 'coupon') {{ 'active' }} @endif">
              <i class="nav-icon fas fa-copy"></i>
              <p>
                Coupons
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="{{route('coupon')}}"  class="nav-link @if(Route::currentRouteName() == 'people') {{ 'active' }} @endif">
                  <i class="far fa-circle nav-icon"></i>
                  <p>List Coupons</p>
                </a>
              </li>                          
            </ul>
          </li>

              <li class="nav-item has-treeview @if(Route::currentRouteName() == 'booking_list'  ) {{ 'active menu-open' }} @endif"  <?php if(in_array('Bookings', $menu)){?> style="display: block;" <?php }else{ ?> style="display: none;" <?php } ?>  >
            <a href="#" class="nav-link @if(Route::currentRouteName() == 'booking_list') {{ 'active' }} @endif">
              <i class="nav-icon fa fa-bookmark"></i>
              <p>
                Bookings
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="{{url('booking_list/all')}}"  class="nav-link @if(Route::currentRouteName() == 'booking_list') {{ 'active' }} @endif">
                  <i class="far fa-circle nav-icon"></i>
                  <p>List Bookings</p>
                </a>
              </li>                          
            </ul>
          </li>

         <li class="nav-item has-treeview @if(Route::currentRouteName() == 'transaction_history' || Route::currentRouteName() == 'vault_transactions'  ) {{ 'active menu-open' }} @endif">
            <a href="#" class="nav-link @if(Route::currentRouteName() == 'transaction_history' || Route::currentRouteName() == 'vault_transactions') {{ 'active' }} @endif"  <?php if(in_array('Transactions', $menu)){?> style="display: block;" <?php }else{ ?> style="display: none;" <?php } ?>  >
              <i class="nav-icon fa fa-bookmark"></i>
              <p>
                Transactions
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="{{route('transaction_history')}}"  class="nav-link @if(Route::currentRouteName() == 'transaction_history') {{ 'active' }} @endif">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Transaction History</p>
                </a>
              </li>                          
            </ul>
             <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="{{route('vault_transactions')}}"  class="nav-link @if(Route::currentRouteName() == 'vault_transactions') {{ 'active' }} @endif">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Vault Transactions</p>
                </a>
              </li>                          
            </ul>
          </li>

          <li class="nav-item has-treeview @if(Route::currentRouteName() == 'supportIssue_type' || Route::currentRouteName() == 'issue_listview'  ) {{ 'active menu-open' }} @endif">
            <a href="#" class="nav-link @if(Route::currentRouteName() == 'supportIssue_type' || Route::currentRouteName() == 'issue_listview') {{ 'active' }} @endif" <?php if(in_array('Support', $menu)){?> style="display: block;" <?php }else{ ?> style="display: none;" <?php } ?>   >
              <i class="nav-icon fa fa-bookmark"></i>
              <p>
                Support
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="{{route('supportIssue_type')}}"  class="nav-link @if(Route::currentRouteName() == 'supportIssue_type') {{ 'active' }} @endif">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Add Support IssueTypes</p>
                </a>
              </li>                          
            </ul>
             <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="{{route('issue_listview')}}"  class="nav-link @if(Route::currentRouteName() == 'issue_listview') {{ 'active' }} @endif">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Support Issues</p>
                </a>
              </li>                          
            </ul>
          </li>

          <li class="nav-item has-treeview @if(Route::currentRouteName() == 'faq' || Route::currentRouteName() == 'faq_list'  ) {{ 'active menu-open' }} @endif">
            <a href="#" class="nav-link @if(Route::currentRouteName() == 'faq' || Route::currentRouteName() == 'faq_list') {{ 'active' }} @endif"  <?php if(in_array('FAQ', $menu)){?> style="display: block;" <?php }else{ ?> style="display: none;" <?php } ?>    >
             <i class="fa fa-question-circle" aria-hidden="true"></i>
              <p>
                FAQ
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="{{route('faq')}}"  class="nav-link @if(Route::currentRouteName() == 'faq') {{ 'active' }} @endif">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Add FAQ</p>
                </a>
              </li>                          
            </ul>
             <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="{{route('faq_list')}}"  class="nav-link @if(Route::currentRouteName() == 'faq_list') {{ 'active' }} @endif">
                  <i class="far fa-circle nav-icon"></i>
                  <p>FAQ List</p>
                </a>
              </li>                          
            </ul>
          </li>

          <li class="nav-item has-treeview @if(Route::currentRouteName() == 'terms_and_condition') {{ 'menu-open' }} @endif"   <?php if(in_array('Terms and Condition', $menu)){?> style="display: block;" <?php }else{ ?> style="display: none;" <?php } ?>    >
            <a href="{{url('/terms_and_condition')}}" class="nav-link @if(Route::currentRouteName() == 'terms_and_condition') {{ 'active' }} @endif">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Terms and Condition             
              </p>
            </a>
          </li>

           <li class="nav-item has-treeview @if(Route::currentRouteName() == 'privacy_policy') {{ 'menu-open' }} @endif" <?php if(in_array('Privacy Policy', $menu)){?> style="display: block;" <?php }else{ ?> style="display: none;" <?php } ?>   >
            <a href="{{url('/privacy_policy')}}" class="nav-link @if(Route::currentRouteName() == 'privacy_policy') {{ 'active' }} @endif">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Privacy Policy            
              </p>
            </a>
          </li>

            <li class="nav-item has-treeview @if(Route::currentRouteName() == 'about_us') {{ 'menu-open' }} @endif">
            <a href="{{url('/about_us')}}" class="nav-link @if(Route::currentRouteName() == 'about_us') {{ 'active' }} @endif"  <?php if(in_array('About Us', $menu)){?> style="display: block;" <?php }else{ ?> style="display: none;" <?php } ?>   >
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                About Us            
              </p>
            </a>
          </li>

           <li class="nav-item has-treeview @if(Route::currentRouteName() == 'online_support') {{ 'menu-open' }} @endif"  <?php if(in_array('Payment Term Of Service', $menu)){?> style="display: block;" <?php }else{ ?> style="display: none;" <?php } ?>   > 
            <a href="{{url('/online_support')}}" class="nav-link @if(Route::currentRouteName() == 'online_support') {{ 'active' }} @endif">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Online Support            
              </p>
            </a>
          </li>
           <li class="nav-item has-treeview @if(Route::currentRouteName() == 'trust_and_safety') {{ 'menu-open' }} @endif"  <?php if(in_array('Payment Term Of Service', $menu)){?> style="display: block;" <?php }else{ ?> style="display: none;" <?php } ?>   > 
            <a href="{{url('/trust_and_safety')}}" class="nav-link @if(Route::currentRouteName() == 'trust_and_safety') {{ 'active' }} @endif">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Trust & Safety            
              </p>
            </a>
          </li>

          <li class="nav-item has-treeview @if(Route::currentRouteName() == 'nondescrimination') {{ 'menu-open' }} @endif">
            <a href="{{url('/nondescrimination')}}" class="nav-link @if(Route::currentRouteName() == 'nondescrimination') {{ 'active' }} @endif">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Help
            
              </p>
            </a>
          </li>
          <li class="nav-item has-treeview @if(Route::currentRouteName() == 'how_it_works') {{ 'menu-open' }} @endif">
            <a href="{{url('/how_it_works')}}" class="nav-link @if(Route::currentRouteName() == 'how_it_works') {{ 'active' }} @endif">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                How it works
            
              </p>
            </a>
          </li>
          

        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">


          <!-- Main content -->

          @yield('content')

          <!-- /.content -->


  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>Copyright &copy; 2014-2019 <a href="http://adminlte.io">AdminLTE.io</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 3.0.0-rc.3
    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="{{url('plugins/jquery/jquery.min.js')}}"></script>
<!-- jQuery UI 1.11.4 -->
<script src="{{url('plugins/jquery-ui/jquery-ui.min.js')}}"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>  
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<script type="text/javascript">
   $(document).ready(function() {
      $('#example').DataTable();
      $('.deletecoupon').on('click',function(){
        var delete_id = $(this).data('id');
        console.log(delete_id);
        if(confirm('Are you sure you want to delete?')){
            $.ajax({
              url : "{{ route('delete-coupon') }}",
              type: 'POST',
              data :{
                "id":delete_id,
                 " _token":'{{csrf_token()}}'
                },
          }).done(function(response){ 
            console.log(response);
            if(response.status == 1){
              swal("Success!", "FAQ deleted successfully!", "success").then((value) => {
                  location.reload(true);
                });
            }
            
          });
        
         }else{
            
        }
        

      });
  });
</script>

   <script type="text/javascript"> 
    $(document).ready(function(){
         $("#example").on("click", ".delete-faq", function(){
          var id = $(this).data('id');
            swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
              }).then((value) => {
              if(value == true){
                $.ajax({
                  url : "{{ route('delete-faq') }}",
                  type: 'POST',
                  data :{
                    "id":id,
                     " _token":'{{csrf_token()}}'
                    },
                }).done(function(response){ 
                      console.log(response);
                      if(response.status == 1){
                        swal("Success!", "Faq deleted successfully!", "success").then((value) => {
                            location.reload(true);
                          });
                      }
                      
                });

              }
            });
        });
        $("#example").on("click", ".delete-subadmin", function(){
          var id = $(this).data('id');
            swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
              }).then((value) => {
              if(value == true){
                $.ajax({
                  url : "{{ route('delete-subadmin') }}",
                  type: 'POST',
                  data :{
                    "id":id,
                     " _token":'{{csrf_token()}}'
                    },
                }).done(function(response){ 
                      console.log(response);
                      if(response.status == 1){
                        swal("Success!", "Subadmin deleted successfully!", "success").then((value) => {
                            location.reload(true);
                          });
                      }
                      
                });

              }
            });
        });

         $("#example").on("click", ".delete_peoplecategory", function(){
          var id = $(this).data('id');
      
            swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
              }).then((value) => {
              if(value == true){
                $.ajax({
                  url : "{{ route('delete-people') }}",
                  type: 'POST',
                  data :{
                    "id":id,
                     " _token":'{{csrf_token()}}'
                    },
                }).done(function(response){ 
                      console.log(response);
                      if(response.status == 1){
                        swal("Success!", response.message, "success").then((value) => {
                            location.reload(true);
                          });
                      }else{
                        swal("Danger!", response.message, "danger").then((value) => {
                            location.reload(true);
                          });
                      }
                      
                });

              }
            });
        });
         $("#example").on("click", ".delete_placescategory", function(){
          var id = $(this).data('id');
          
            swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
              }).then((value) => {
              if(value == true){
                $.ajax({
                  url : "{{ route('delete-places') }}",
                  type: 'POST',
                  data :{
                    "id":id,
                     " _token":'{{csrf_token()}}'
                    },
                }).done(function(response){ 
                      console.log(response);
                      if(response.status == 1){
                        swal("Success!", response.message, "success").then((value) => {
                            location.reload(true);
                          });
                      }else{
                        swal("Danger!", response.message, "danger").then((value) => {
                            location.reload(true);
                          });
                      }
                      
                });
              }
            });
        });
          
           $("#example").on("click", ".delete_thingscategory", function(){

          var id = $(this).data('id');
          
            swal({
                title: "Are you sure?",
                text: "Once deleted, you will not be able to recover!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
              }).then((value) => {
              if(value == true){
                $.ajax({
                  url : "{{ route('delete-things') }}",
                  type: 'POST',
                  data :{
                    "id":id,
                     " _token":'{{csrf_token()}}'
                    },
                }).done(function(response){ 
                      console.log(response);
                      if(response.status == 1){
                        swal("Success!", response.message, "success").then((value) => {
                            location.reload(true);
                          });
                      }else{
                        swal("Danger!", response.message, "danger").then((value) => {
                            location.reload(true);
                          });
                      }
                      
                });
              }
            });
        });
           $("#example").on("click", ".delete_support", function(){
             var id = $(this).data('id');
          
            swal({
                title: "Are you sure?",
                text: "Issue resolved and remove it from admin!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
              }).then((value) => {
              if(value == true){
                $.ajax({
                  url : "{{ route('delete-support') }}",
                  type: 'POST',
                  data :{
                    "id":id,
                     " _token":'{{csrf_token()}}'
                    },
                }).done(function(response){ 
                      console.log(response);
                      if(response.status == 1){
                        swal("Success!", response.message, "success").then((value) => {
                            location.reload(true);
                          });
                      }else{
                        swal("Danger!", response.message, "danger").then((value) => {
                            location.reload(true);
                          });
                      }
                      
                });
              }
            });
        });


           $("#example").on("click", ".delete_supportissue_type", function(){
             var id = $(this).data('id');
          
            swal({
                title: "Are you sure?",
                text: "Issue Type once removed can not be recovered!",
                icon: "warning",
                buttons: true,
                dangerMode: true,
              }).then((value) => {
              if(value == true){
                $.ajax({
                  url : "{{ route('delete_supportissue_type') }}",
                  type: 'POST',
                  data :{
                    "id":id,
                     " _token":'{{csrf_token()}}'
                    },
                }).done(function(response){ 
                      console.log(response);
                      if(response.status == 1){
                        swal("Success!", response.message, "success").then((value) => {
                            location.reload(true);
                          });
                      }else{
                        swal("Danger!", response.message, "danger").then((value) => {
                            location.reload(true);
                          });
                      }
                      
                });
              }
            });
        });

          


    });
  </script>  

   <script type="text/javascript"> 
    $(document).ready(function(){
        $('.approve_transaction').click(function(){
          var id = $(this).data('id');
            swal({
                title: "Are you sure?",               
                buttons: true,              
              }).then((value) => {
              if(value == true){
                $.ajax({
                  url : "{{ route('approve_transaction_complete') }}",
                  type: 'POST',
                  data :{
                    "id":id,
                     " _token":'{{csrf_token()}}'
                    },
                }).done(function(response){ 
                      console.log(response);
                      if(response.status == 1){
                        swal("Success!", "Transaction Completed successfully!", "success").then((value) => {
                            location.reload(true);
                          });
                      }
                      
                });

                console.log('jdwd');
              }
            });
        });

        $("#example").on("click", ".approve_placedata", function(){
          var id = $(this).data('id');
            swal({
                title: "Are you sure?",               
                buttons: true,              
              }).then((value) => {
              if(value == true){
                $.ajax({
                  url : "{{ route('approve_placeprovider') }}",
                  type: 'POST',
                  data :{
                    "id":id,
                     " _token":'{{csrf_token()}}'
                    },
                }).done(function(response){ 
                      console.log(response);
                      if(response.status == 1){
                        swal("Success!", "Place Provider approved successfully!", "success").then((value) => {
                            location.reload(true);
                          });
                      }else if(response.status == 2){

                        swal("Success!",response.message , "success").then((value) => {
                            location.reload(true);
                          });
                      }
                      
                });

                console.log('jdwd');
              }
            });
        });

         $("#example").on("click", ".approve_peopledata", function(){
          var id = $(this).data('id');
            swal({
                title: "Are you sure?",               
                buttons: true,              
              }).then((value) => {
              if(value == true){
                $.ajax({
                  url : "{{ route('approve_provider') }}",
                  type: 'POST',
                  data :{
                    "id":id,
                     " _token":'{{csrf_token()}}'
                    },
                }).done(function(response){ 
                      console.log(response);
                      if(response.status == 1){
                        swal("Success!", "Place Provider approved successfully!", "success").then((value) => {
                            location.reload(true);
                          });
                      }else if(response.status == 2){
                        
                        swal("Success!", response.message, "success").then((value) => {
                            location.reload(true);
                          });
                      }
                      
                });

                console.log('jdwd');
              }
            });
        });

         $("#example").on("click", ".approve_thingsdata", function(){
          var id = $(this).data('id');
            swal({
                title: "Are you sure?",               
                buttons: true,              
              }).then((value) => {
              if(value == true){
                $.ajax({
                  url : "{{ route('approve_thingprovider') }}",
                  type: 'POST',
                  data :{
                    "id":id,
                    " _token":'{{csrf_token()}}'
                    },
                }).done(function(response){ 
                      console.log(response);
                      if(response.status == 1){
                        swal("Success!", "Place Provider approved successfully!", "success").then((value) => {
                            location.reload(true);
                          });
                      }else if(response.status == 2){
                       
                        swal("Success!", response.message, "success").then((value) => {
                            location.reload(true);
                         });
                      }
                      
                });

                console.log('jdwd');
              }
            });
        });



        
    });
  </script>
@yield('scripts');
   
<script>
            CKEDITOR.replace( 'description' );
        </script>
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 4 -->
<script src="{{url('plugins/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
<!-- ChartJS -->
<script src="{{url('plugins/chart.js/Chart.min.js')}}"></script>
<!-- Sparkline -->
<script src="{{url('plugins/sparklines/sparkline.js')}}"></script>
<!-- JQVMap -->
<script src="{{url('plugins/jqvmap/jquery.vmap.min.js')}}"></script>
<script src="{{url('plugins/jqvmap/maps/jquery.vmap.usa.js')}}"></script>
<!-- jQuery Knob Chart -->
<script src="{{url('plugins/jquery-knob/jquery.knob.min.js')}}"></script>
<!-- daterangepicker -->
<script src="{{url('plugins/moment/moment.min.js')}}"></script>
<script src="{{url('plugins/daterangepicker/daterangepicker.js')}}"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="{{url('plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js')}}"></script>
<!-- Summernote -->
<script src="{{url('plugins/summernote/summernote-bs4.min.js')}}"></script>
<!-- overlayScrollbars -->
<script src="{{url('plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js')}}"></script>
<!-- AdminLTE App -->
<script src="{{url('dist/js/adminlte.js')}}"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="{{url('dist/js/pages/dashboard.js')}}"></script>
<!-- AdminLTE for demo purposes -->
<script src="{{url('dist/js/demo.js')}}"></script>
</body>
</html>
