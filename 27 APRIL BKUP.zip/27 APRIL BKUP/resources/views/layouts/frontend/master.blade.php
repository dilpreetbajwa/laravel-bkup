<!doctype>

<html lang="en">
   <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <!-- Bootstrap CSS -->
     <script
  src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
     
      <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
      <script src="{{url('web/js/bootstrap.min.js')}}"></script>
      <link rel="stylesheet" href="{{url('web/css/bootstrap.mi
n.css')}}">
      <link rel="stylesheet" href="{{url('web/css/style.css')}}">
      <link rel="stylesheet" href="{{url('web/css/responsive.css')}}">
      <link rel="stylesheet" href="{{url('web/css/animate.css')}}">
      <link rel="stylesheet" href="{{url('web/css/owl.carousel.min.css')}}">
      <link rel="stylesheet" href="{{url('web/css/owl.theme.default.min.css')}}">
      <link rel="stylesheet" href="{{url('web/css/slick.css')}}">
      <link rel="stylesheet" href="{{url('web/css/intlTelInput.css')}}">
      <link rel="icon" href="{{url('web/images/fav.png')}}" type="image/gif" sizes="16x16">
      <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,400i,500,500i,700,700i,900&display=swap" rel="stylesheet">
      <link href="https://fonts.googleapis.com/css?family=Oswald:400,500,600&display=swap" rel="stylesheet">
   <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.css"> 
   <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-160833352-1"></script>
<script>
 window.dataLayer = window.dataLayer || [];
 function gtag(){dataLayer.push(arguments);}
 gtag('js', new Date());

 gtag('config', 'UA-160833352-1');
</script>
      <title>Home</title>
      <style>
      .task-btn
      {
        color:#000;
      }
      .modal {
  overflow-y:auto;
}


     /* .fullscreen-container {
        display: none;
        position: fixed;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        background: rgba(90, 90, 90, 0.5);
        z-index: 9999;
      }*/
/*
      #reviewsmodal
      {
        height: 300px;
        width: 420px;
        background-color: #97ceaa;
        position: fixed;
        top: 50px;
        left: 50px;
      }*/
      </style>
   </head>
		  
  <div class="modal fade" id="loginmodal1" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Modal Header</h4>
        </div>
        <div class="modal-body">
          <p>This is a small modal.</p>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>

  
   <div class="modal fade" id="reviewsmodal" role="dialog">
    <div class="modal-dialog modal-md">
      <div class="modal-content reviewsbookingmodal">
        <div class="modal-header">
          <h4 class="modal-title">Add Reviews</h4>
        </div>
        <div class="modal-body">
          <p>Welcome back!! Please add reviews and rate us for your past bookings and continue enjoying our services.</p>
          <a href="{{url('/add-reviews')}}">Click here to add reviews and ratings</a>
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="booking-modal"  role="dialog">
    <div class="modal-dialog modal-md">
      <div class="modal-content switchbookingmodal">
        <div class="modal-header">
          <h4 class="modal-title">Information</h4>
            <button type="button" class="btn btn-danger loginclose" data-dismiss="modal">X</button>
        </div>
        <div class="modal-body">
          <p>Please switch to booking mode to avail booking related services</p>
        </div>
      </div>
    </div>
  </div>
  
     <div class="modal fade" id="login-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
         <div class="modal-dialog">
            <div class="loginmodal-container">
               <button type="button" class="btn btn-danger loginclose" data-dismiss="modal">X</button>
               <h1>Log In </h1>

              <div class="alert alert-success" role="alert" style="display: none;margin-top: 23px;">
                    
              </div>
              <div class="alert alert-danger" role="alert" style="display: none;margin-top: 23px;">
                   
               </div>
               <br>
               <form>
                <input type="hidden" name="placeval" id="placeval" value="home">
                </form>
               <form id="loginform1">
                   <input type="hidden" name="_token" id="csrf-token" value="{{ Session::token() }}" />
                   <input type="hidden" name="reviews" id="reviewsval" value="{{ Session::get('reviews') }}" />
                  <input type="text" id="user_name" name="user_name" placeholder="Email Address">
                  <input type="password" id="user_password" name="user_password" placeholder="Password">
                  <div class="login-help">
                     <a class="forgot_pwd" href="javascript:void(0)">Forgot Your Password</a>
                  </div>
                  <input type="submit" name="login" class="login loginmodal-submit" value="Log in">
               </form>
               <div class="social_media">
                  <a href="{{url('login/facebook')}}" class="fb btn">
                  <span class="fb_icon"><i class="fab fa-facebook-f"></i></span>Log In with Facebook
                  </a>
                  <a href="{{url('login/google')}}" class="fb btn Google">
                  <span class="fb_icon"><i class="fab fa-google"></i></span>Log In with Google
                  </a>
                  <a href="{{url('/instagram')}}" class="fb btn Instagram">
                  <span class="fb_icon"><i class="fab fa-instagram"></i></span>Log In with Instagram
                  </a>
                  <div class="login-help">
                     <a href="javascript:void(0)" class="accountnew">Don't have an existing account? <span class="Create_account sdf">Create a new account</span></a>
                  </div>
               </div>
            </div>
         </div>
      </div>

       <div class="modal fade" id="login-modal_1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
         <div class="modal-dialog">
            <div class="loginmodal-container">
               <button type="button" class="btn btn-danger btn_modalclose" data-dismiss="modal">X</button>
               <h1>Sign Up </h1>
               <br>
               <div class="login-help Sign_Up" data-toggle="modal">
                  <a href="javascript:void(0)" class="" ><span class="Create_account email_with signup_withemail">Sign Up Using Email</span></a>
               </div>
               <div class="divider"><span class="or">or</span></div>
               <div class="social_media">
                  <a href="{{url('login/facebook')}}" class="fb btn">
                  <span class="fb_icon"><i class="fab fa-facebook-f"></i></span>Sign Up with Facebook
                  </a>
                  <a href="{{url('login/google')}}" class="fb btn Google">
                  <span class="fb_icon"><i class="fab fa-google"></i></span>Sign Up with Google
                  </a>
                  <a href="{{url('instagram')}}" class="fb btn Instagram">
                  <span class="fb_icon"><i class="fab fa-instagram"></i></span>Sign Up with Instagram
                  </a>
                  <div class="login-help">
                    <a href="javascript:void(0)" class="loginnewaccount">Already have an account? <span class="Create_account">Log In</span></a>
                  </div>
               </div>
            </div>
         </div>
      </div>


        <div class="modal fade" id="login-modal_2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
         <div class="modal-dialog">
            <div class="loginmodal-container">
               <button type="button" class="btn btn-danger btn_modalclose btn_close_signup" data-dismiss="modal">X</button>
               <h1>Sign Up </h1>
               <br>
               <form method="post" id="signupform" enctype='multipart/form-data'>
                  <input type="hidden" name="_token" id="csrf-token" value="{{ Session::token() }}" /> 
             

                  <!-- <div class="custom-file" id="customFile" lang="es">
                     <input type="file" class="custom-file-input" id="exampleInputFile" aria-describedby="fileHelp">
                     <label class="custom-file-label" for="exampleInputFile">
                        Select file...
                     </label>
                     
                     </div> -->
                  <div class="avatar">
                    <img id="imguser" name="imguser" class="profile-user-img img-responsive img-circle" src="{{Session::get('userimage')?Session::get('userimage') :url('web/images/man.png')}}" style="height: 123px;margin: 20px;border-radius: 64%;width: 130px;">
                     <span class="plus" style="position: relative;
                    right: 21px;
                    font-size: 25px;
                    color: #3878BC;
                    top: 43px;">+</span>
                  </div>


                  <div class="signup_err"></div>
                  <div class="text-center"><input id="image_upload" type="file" onchange="readURL(this);" name="image" style="display: none;"></div>
                  <input type="text" name="firstname" class="firstname" placeholder="First Name">
                  <div class="fn_err"></div>
                  <input type="text" name="lastname" class="lastname" placeholder="Last Name">
                  <div class="ln_err"></div>
                  <input type="text" name="phoneno" id="phoneno" type="tel" placeholder="Mobile Number">
                 
                   <div class="phone_err"></div>
                  <!--  <a href="javascript:void(0)avascript:void(0)"><span class="verify_otp" style="float:right;">verify otp</span></a> -->
                   <input type="hidden" class="otp_value">
                  <input type="text" name="emailaddress" id="emailaddress" placeholder="Email Address" value="{{Session::get('useremail')}}" >
                  <div class="email_err"></div>
                  <input type="password" name="password" id="password" placeholder="Password">
                  <div id="pwd_err1"></div>
                  <input type="password" name="confirmpwd" id="confirmpwd" placeholder="Confirm Password">
                   <div id="pwd_err"></div>
                  <!-- <input type="date" name="bday" class="dob" placeholder="" required=""> -->
                  <input type="text" name="bday" class="dob" placeholder="Date of Birth"
                    onfocus="(this.type='date')" onload="validDate()"> <div class="bday"></div>
                  <div class="form-group">
                     <select class="form-control" name="gender" id="gender">
                        <option value="">Gender</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                     </select>
                  </div>
                  <div class="gender_err"></div>
                  <input type="submit" id= "signup" name="login" class="" value="Sign Up">
               </form>
               <div class="login-help">
                  <a href="javascript:void(0)" class="loginnewaccount">Already have an account? <span class="Create_account">Click here to Login</span></a>
               </div>
            </div>
         </div>
      </div>

      <input type="hidden" id="otp">
          
        </div>
      <div class="modal fade fade_popup" id="login-modal_3" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
        <div class="modal-dialog">
           <div class="loginmodal-container otp_model">
              <button type="button" class="btn btn-danger" data-dismiss="modal">X</button>
              <h1>Sign Up </h1>
              <br>
              <div id="wrapper">
                 <div id="dialog">
                    <h4>Please enter the 4-digit verification code we sent via SMS:</h4>
                    <span>(we want to make sure it's you before we contact our movers)</span>
                    <div id="form">
                       <input type="text" name="txtverify1"  id="txtverify1" maxLength="1" size="1" min="0" max="9" pattern="[0-9]{1}" />
                       
                       <input type="text" name="txtverify2"  id="txtverify2" maxLength="1" size="1" min="0" max="9" pattern="[0-9]{1}" />

                       <input type="text" name="txtverify3"  id="txtverify3" maxLength="1" size="1" min="0" max="9" pattern="[0-9]{1}" />

                       <input type="text" name="txtverify4"  id="txtverify4" maxLength="1" size="1" min="0" max="9" pattern="[0-9]{1}" />
                       <button class="btn btn-primary btn-embossed verify_btn">Verify</button>
                    </div>
                    <div>
                       Didn't receive the code?<br />
                       <a class="resend_otp" href="javascript:void(0)">Send code again</a><br />
                    </div>
                 </div>
              </div>
           </div>
        </div>
     </div>

    <div id="forgot_modal" class="modal fade" role="dialog">
      <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header" style="display:block">
            <button type="button" class="close forgot_close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Forgot Password</h4>
          </div>
          <div class="modal-body">
            <form name="form_password" id="form_password" method="post">
               <div id="pwd_errforgot" style="text-align: center;color: #721c24;
                background-color: #f8d7da;border-color: #f5c6cb;"></div>
               <div id="pwd_successforgot" style="text-align: center;color:#237509 ;
                background-color: #ace89b;border-color: #237509;"></div>
              <input type="text" placeholder = "Enter your email address" class="form-control" name="pwd_forgot" id="pwd_forgot">
              <p class="forgottext">Enter the email you registered with  and we will send you new password on your email</p>
             
              <input type="submit" name="forgot" class="pwd-submit btn btn-primary" value="Submit">
            </form>
          </div>
        </div>
      </div>
    </div>

 
    @if(Route::currentRouteName() == 'home1')
      <body  class="homepage">
      @elseif (Route::currentRouteName() == 'addplacesdetails'|| Route::currentRouteName() == 'bookingplaceavailability'|| Route::currentRouteName() == 'paymentplaces'|| Route::currentRouteName() == 'editplaceprovider')
        <body class="index-places-page">
        @elseif (Route::currentRouteName() == 'addservicedetails'|| Route::currentRouteName() == 'bookingpeopleavailability'||Route::currentRouteName() == 'paymentservices'||Route::currentRouteName() == 'editpeopleprovider')
        <body class="index-service-page">
         @elseif (Route::currentRouteName() == 'addthingdetails' || Route::currentRouteName() == 'bookingthingavailability'||Route::currentRouteName() == 'paymentthings'||Route::currentRouteName() == 'editthingprovider')
        <body class="index-things-page">
      @elseif (Route::currentRouteName() == 'placelisting' ||Route::currentRouteName() == 'thingslisting'||Route::currentRouteName() == 'peoplelisting' || Route::currentRouteName() == 'search-data')
      <body id="booking_page">
      @else
      <body>
    @endif
      <!-- Header -->  
      <header class="wow bounceInDown">
         <div class="header-top  @if(Route::currentRouteName() == 'addplacesdetails' || Route::currentRouteName() == 'addservicedetails') places-header @endif" >
            <div class="container">
               <div class="row">
                  <div class="col-lg-6 col-md-6">
                     <ul class="header-info">
                        <li class="mr-lg-3">
                           <i class="fa fa-phone-alt"></i>
                          <!--  <p class="d-inline">24/7 Support  1800 123 1234</p> -->
                        </li>
                     </ul>
                  </div>
                  <div class="col-lg-6 col-md-6">
                     <ul class="header-info-2">
                       <!--  <li>
                           <a href="javascript:void(0)" class="">Language</a>
                        </li> -->
                        <li>
                           <a href="javascript:void(0)" class="">Help and Support</a>
                        </li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
          
         <div class="header_bg">
        
         <div class="container">
            <div class="row">
               @if(Route::currentRouteName() != 'home1' && Route::currentRouteName() != 'placelisting' && Route::currentRouteName() != 'thingslisting' && Route::currentRouteName() != 'peoplelisting'&& Route::currentRouteName() != 'search-data')
               <div class="col-lg-3 col-md-3 col-sm-3 col-3">
               @elseif(Route::currentRouteName() == 'placelisting' || Route::currentRouteName() == 'thingslisting' || Route::currentRouteName() == 'peoplelisting'||Route::currentRouteName() == 'search-data')
                <div class="col-lg-2 col-md-2">
               

               @else
               <div class="col-lg-3 col-md-3 col-sm-3 col-3">
               @endif
                  <a href="{{url('/')}}"><img class="img-fluid logo" src="{{url('/web/images/logo.png')}}" alt="logo" /></a>
               </div>
               @if(Route::currentRouteName() != 'home1' && Route::currentRouteName() != 'addthingdetails' && Route::currentRouteName() != 'addplacesdetails' && Route::currentRouteName() != 'addservicedetails' && Route::currentRouteName() != 'placelisting' 
               && Route::currentRouteName() != 'thingslisting' && Route::currentRouteName() !='peoplelisting'&& Route::currentRouteName() != 'search-data')
              
                     <div class="search-bar"><input type="text" placeholder="Location" class="main_search">
                        <button type="button"><i class="fa fa-search"></i></button>
                     </div>
              
                @elseif(Route::currentRouteName() == 'placelisting' || Route::currentRouteName() == 'thingslisting' || Route::currentRouteName() == 'peoplelisting'|| Route::currentRouteName() == 'search-data')
                <div class="col-lg-4 col-md-4">
                     <div class="search-bar"><input type="text" placeholder="Location" name="address" id="address" class="main_search">
                        <button type="button"><i class="fa fa-search"></i></button>
                     </div>
                </div>

                @endif
                @if(Route::currentRouteName() == 'placelisting' || Route::currentRouteName() == 'thingslisting' || Route::currentRouteName() == 'peoplelisting'||Route::currentRouteName() == 'search-data')
                <div class="col-lg-6 col-md-6 dm-none">                
               
               @else
               <div class="col-lg-9 col-md-9 col-sm-9 col-9 dm-none">
               @endif
                @if(Route::currentRouteName() == 'home1' && !Auth::check())
                <div class="right-info">
                @elseif((Route::currentRouteName() == 'home1') && Auth::check())
                <div class="right-info main-header">
                @else
                  <div class="right-info main-header">
                  @endif
                   <ul>
                    @if (Session::get('loginval')==1)
                    <li>
                    <div class="list-service-outer">
                    @if(Auth::user()->userheaderstatus==0)  
                        <label>              
                          <span class="switchprovider task-btn" href="javascript:void(0)">Switch to service provider</span>
                       </label>
                       @else
                       <label>
                        <span class="switchbookings task-btn" href="javascript:void(0)">Switch to Bookings</span>
                        </label>
                      @endif
                         <label for="list-service"><span class="task-btn" href="#">Become a Host</span>
                       </label>
                       <input type="checkbox" id="list-service">
                       <div class="list-service-overly">
                          <ul class="list-providers">
                             <li><a href="{{url('/addplacesdetails')}}">List Your Places</a><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p></li>
                             <li><a href="{{url('/addthingdetails')}}">List Your Things</a><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p></li>
                             <li><a href="{{url('/addservicedetails')}}">List Your Services</a><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. </p></li>
                             <li><a href="{{url('/serviceproviderinformation')}}">Service Provider Information</a><p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p></li>
                          </ul>
                       </div>
                    </div>
                  </li>
                       <li class="menu">
                       <a href="#mySidenav" onclick="openNav()">
                          <div class="menu_icon"><img src="{{Auth::user()->image!=''?asset('/profile/'.Auth::user()->image) :url('web/images/man.png')}}" alt="icon"/><!-- <i class="fa fa-bars"></i> --></div>
                       <div id="mySidenav" class="sidenav">
                       <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
                      <!--  <div class="profile_picture"><img src="{{url('web/images/man.png')}}"> -->
                       <div class="profile_picture"><img src="{{Auth::user()->image!=''?asset('/profile/'.Auth::user()->image) :url('web/images/man.png')}}">
                        <p>{{Session::get('fname')}}  {{Session::get('lname')}}</p>
                       <div class="star">
                       <i class="fas fa-star"></i>
                       <i class="fas fa-star"></i>
                       <i class="fas fa-star"></i>
                       <i class="fas fa-star"></i>
                       <i class="fas fa-star"></i>
                       </div>
                       </div>
                       @if(Auth::user()->userheaderstatus==0)  
                       <span class="bookingsdata">
                       
                       <a href="{{url('/bookings-history')}}">My Bookings</a>
                       <a href="{{url('/notifications')}}">Notifications</a>
                       <a href="{{url('/invite-share')}}">Invite Friends</a>
                       <a href="{{url('/allfavourites')}}">My Favourites</a>
                       <a href="{{url('contact-us')}}">Support</a>
                       </span>
                       @else

                      <span class="serviceprovider">
                       <a href="{{url('/request_bookinglist')}}">My Requests</a>
                      <!-- <a href="{{url('/transaction-history')}}">My Transactions</a> -->
                       <a href="{{url('/check-balance')}}">My Wallet</a>
                       <a href="{{url('/my-progress')}}">My Progress</a>
                       <a href="{{url('/mylistings')}}">My Listings</a>
                       <a href="{{url('/notifications')}}">Notifications</a>

                       <a href="{{url('/invite-share')}}">Invite Friends</a>
                       <a href="{{url('contact-us')}}">Support</a>
                       </span>
                       @endif
                       <a href="{{url('/logout1')}}">Logout</a>
                       </div>
                       </a>
                    </li>
                     @else
                        <li><a href="javascript:void(0)" class="loign" data-toggle="modal">Login</a></li>
                        <li><a href="javascript:void(0)" class="sign_btn" data-toggle="modal" data-target="#login-modal_1">Sign up</a></li>
                     @endif
                     </ul>





                  </div>
               </div>
            </div>
         </div>
        @if(\Request::is('bookings'))  
         </div>
        @endif
      </header>

    @yield('content')
    @if(Route::currentRouteName() == 'home1')
       <footer class="footer pt-5 home_footer">
      @else
      <footer class="footer pt-5  booking_footer">
      @endif

         <div class="container">
            <div class="row main_footer">
               <div class="col-lg-3 col-md-3  bottom-links wow bounceInUp">
                  <h3>LINKS</h3>
                  <ul class="q-links">
                     <li><a href="{{url('about-us')}}"> About</a></li>
                     <li><a href="{{url('faqs')}}"> FAQ</a></li>
                     
                  </ul>
               </div>
               <div class="col-lg-3 col-md-3  bottom-links wow bounceInUp">
                  <h3>SUPPORT</h3>
                  <ul class="q-links">
                     <li><a href="{{url('/howitworks')}}"> How it works</a></li>
                     <!-- <li><a href="javascript:void(0)"> Online Support</a></li> -->
                     <li><a href="{{url('/trustandsafety')}}"> Trust & Safety </a></li>
                     <li><a href="{{url('contact-us')}}"> Contact Us</a></li>
                     <li><a href="{{url('/onlinesupport')}}"> Online Support</a></li>

                  </ul>
               </div>
               <div class="col-lg-3 col-md-3  bottom-links wow bounceInUp">
                  <h3>RESOURCES</h3>
                  <ul class="q-links">
                     <li><a href="{{url('/help')}}"> Help and Support</a></li>
                     <li><a href="{{url('terms-and-conditions')}}"> Terms & Conditions</a></li>
                    <!--  <li><a href="javascript:void(0)"> Cookie Policy</a></li> -->
                     <li><a href="{{url('privacy-policy')}}"> Privacy Policy</a></li>
                  </ul>
               </div>
               <div class="col-lg-3  col-md-3 wow bounceInRight">
                  <div class="contact">
                     <h3>Subscribe</h3>
                     <input type="text" name="firstname" placeholder="Email Address" class="email"> 
                     <div class="Subscribe_btn">
                        <img src="{{url('/web/images/btn_1.png')}}" class="google_play_1">
                        <img src="{{url('/web/images/btn_2.png')}}">
                     </div>
                  </div>
               </div>
            </div>
             <div id="wait" style="display:none;width:69px;height:89px;position:absolute;top:50%;left:50%;padding:2px;z-index:999999"><img src="{{url('/web/images/loader.png')}}" width="64" height="64" /><br>Loading..</div>

         </div>
        

         <div class="bottom-footer">
            <div class="container">
               <div class="row">
                  <div class="col-lg-6 col-md-6">
                     <p>Copyright,  © {{ now()->year }}, all rights reserved.</p>
                  </div>
                  <div class="col-lg-6 col-md-6">
                     <ul class="s-links">
                        
                        <li><a href="https://www.facebook.com/TimeRNR/"><i class="fab fa-facebook-f"></i></a></li>
                        <li><a href="https://twitter.com/Timernr1"><i class="fab fa-twitter"></i></a></li>
                        <li><a href="https://www.instagram.com/timernr/ "><i class="fab fa-instagram"></i></a></li>
                        <li><a href= "https://www.linkedin.com/company/time-rnr"><i class="fab fa-linkedin-in"></i></a></li>
                        <li><a href="https://www.youtube.com/channel/UC4SWfz5EOFMrkJquTLBxweg/"><i class="fab fa-youtube"></i></a></li>
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </footer>

       <script src="{{url('web/js/intlTelInput.js')}}"></script>
       <script>
       $(document).ready(function(){
		  $(document).ajaxStart(function(){
		    $("#wait").css("display", "block");
		  });
		  $(document).ajaxComplete(function(){
		    $("#wait").css("display", "none");
		  });
		 
		});
     $(".Sign_Up").on('click',function(e){  
     	$("#login-modal_1").modal('hide'); 
     	$("#login-modal_2").modal('show');

     	$("#signup").prop('disabled',false) ;
       	   $(".signup_err").html("");
           $(".fn_err").html("");   
			$(".ln_err").html("");	
			$(".phone_err").html("");
			$(".email_err").html("");
			$("#pwd_err1").html("");
			$("#pwd_err").html("");
			$(".bday").html("");
			$(".gender_err").html(""); 
			$('#signupform')[0].reset();
         
    	});

     $(".loign").click(function(){
     	$("#login-modal").modal('show');
     	$('#loginform1')[0].reset();

     })

       </script>

        <script>

  function validDate(){ 
            var today = new Date().toISOString().split('T')[0];  
             document.getElementsByName("bday")[0].setAttribute('max', today); 
            }


        $(".signup_withemail").on('click',function(){ 
                
          $("#login-modal_1").modal('hide');
        })

          $(".accountnew").on('click',function(e){
            e.preventDefault();
            $("#login-modal_1").modal('show');
             $("#login-modal").modal('hide');  
          });

       
          $(".loginnewaccount").on('click',function(e){
            e.preventDefault();
            $("#login-modal_1").modal('hide');
            $("#login-modal_2").modal('hide'); 
            $("#login-modal").modal('show');  
          });


       $(document).ready(function(e){

       	$(".profile_picture").on('click',function(){
        window.location = "{{url('/user-profile')}}"
      });

      $(".profile_picture").on('mouseover',function(){

        $(this).css("cursor","pointer");
      });
     
     $(".btn_close_signup").on('click',function(){
        location.reload();

     })

      /*  $(".btn_modalclose").on('click',function(e){
          window.location.reload();          
        });*/
       

        window.onload = validDate;


          $(".accountnew").on('click',function(e){
            e.preventDefault();
            $("#login-modal_1").modal('show');
             $("#login-modal").modal('hide');  
          })

          var url = $(location).attr('href'),
          parts = url.split("/"),
          last_part = parts[parts.length-1];
          if(last_part =="#signup")
          $("#login-modal_1").modal('show');

        
          $(".switchprovider").on('click',function(){
         /* $(".serviceprovider").show();
          $(".bookingsdata").hide();
          $(".switchbookings").show();
          $(".switchprovider").hide(); */ 
           $.ajax({
             url: "{{url('/updateuserstatus')}}",
             type: 'POST', 
             data:   {    
               "_token": token,
               "status":1              
             },
            success: function(response){
              window.location.href="{{url('/request_bookinglist')}}";
            }, 
         });         
        });

        $(".switchbookings").on('click',function(){
          /*$(".serviceprovider").hide();
          $(".bookingsdata").show();
          $(".switchprovider").show();
          $(".switchbookings").hide();*/
           $.ajax({
             url: "{{url('/updateuserstatus')}}",
             type: 'POST', 
             data:   {    
               "_token": token,
               "status":0               
             },
            success: function(response){
              window.location.href="{{url('/getplacelistings')}}";
            }, 
         });
          
        });
         <?php $id = Session::get('loginid11');
        if($id==11) {
        ?>
        swal("Oops!", "Please Login for booking process.", "error");
        <?php }?>
        var user = "{{Auth::user()}}";


        if(user!="" && ($("#reviewsval").val()==1) )
        {
          <?php if (Route::currentRouteName() !='add-reviews') {?>
          $('#reviewsmodal').modal({
              backdrop: 'static',
              keyboard: false
           });
          $("#reviewsmodal").modal('show');
       <?php  } ?>
     }

            var token = "{{ csrf_token() }}";
           

              $(".tab-pane.container").hasClass('active')
              {

                var typeval = $(".tab-content .tab-pane.container.active").attr('id');
                $("#typeofbooking").val(typeval); 
                $(".typecat").val(typeval);
              }
          

            $(".form_tabs .nav-item").on('click',function(){ 

              $(".tab-pane.container").hasClass('active')
              {
                setTimeout(function(){ var typeval = ($(".tab-content .tab-pane.container.active").attr('id')); 
                  $("#typeofbooking").val(typeval); 
                   $(".typecat").val(typeval);
                if($("#typeofbooking").val()=="home"){
                  $(".Places").html("Places Explore");
                  $("h2 span.typeresource") .html("Places");  
                  $("h2 span.rated") .html("Rated Places"); 
                  $(".package.comman-padding").addClass("placeimage");
                  $(".package.comman-padding").removeClass("peopleimage");
                  $(".package.comman-padding").removeClass("thingimage");
                                  
                }
                if($("#typeofbooking").val()=="menu2"){
                  $(".Places").html("People Explore");
                  $("h2 span.typeresource") .html("People");  
                  $("h2 span.rated") .html("Rated People");
                  $(".package.comman-padding").addClass("peopleimage");
                  $(".package.comman-padding").removeClass("placeimage");
                  $(".package.comman-padding").removeClass("thingimage");
                }
                if($("#typeofbooking").val()=="menu1"){
                  $(".Places").html("Things Explore");
                  $("h2 span.typeresource") .html("Things");  
                  $("h2 span.rated") .html("Rated Things");
                  $(".package.comman-padding").addClass("thingimage");
                  $(".package.comman-padding").removeClass("placeimage");
                  $(".package.comman-padding").removeClass("peopleimage");
                }
              }, 500); 
                 $('html, body').animate({
                  scrollTop: $("#allcategories1").offset().top-300
              }, 1000);
                 setTimeout(function(){
                  var booking = $("#typeofbooking").val();
                  $.ajax({
                   url: "{{url('/show-categories')}}",
                   type: 'POST', 
                   data:   {    
                     "_token": token,
                     'booking':booking              
                   },
                  success: function(response){
                    $('#allcategories1').html('<div id="testing" class="owl-carousel owl-theme wow bounceInLeft homecarousel"></div>');

                    $('#allrateddata').html('<div id="ratingdata" class="owl-carousel owl-theme wow bounceInLeft ratedcarousel"></div>');
                
                    $(".owl-carousel.homecarousel").append(response.html);
                    $(".owl-carousel.ratedcarousel").append(response.htmlrated);

                    if(booking=="home")
                      $(".owl-carousel.homecarousel").addClass("placecarousel");
                    else if(booking=="menu1") 
                      $(".owl-carousel.homecarousel").addClass("thingcarousel");
                    else if(booking=="menu2") 
                      $(".owl-carousel.homecarousel").addClass("peoplecarousel");  
                    var owl = $("#testing");
                       $(".owl-carousel.homecarousel,.owl-carousel.ratedcarousel").owlCarousel({
                        loop:true,
                         margin:10,
                         rtl: false,
                         autoplay:true,
                         autoplayTimeout:4000,
                         autoplayHoverPause:true,
                         responsiveClass:true,
                         responsive:{
                           300:{
                             items:1,
                             nav:true
                           },
                           767:{
                             items:2,
                             nav:true
                           },
                           1000:{
                             items:4,
                             nav:true,
                             loop:false
                           }
                         }
                     });
                     
                   },    
                 });

                 },500);
              }
            });

            $(".loginmodal-submit").on('click',function(e){
            e.preventDefault();
            var uname = $("#user_name").val();
            var upwd = $("#user_password").val();
            $.ajax({
             url: "{{url('/user-login')}}",
             type: 'POST', 
             data:   {    
               "_token": token,
               'email':uname,
               'password':upwd
             },
            success: function(response){
               if(response.success == 1)
               {
             	   var img = (response.image_src);
                 jQuery('.alert-success').show();
                 jQuery('.alert-danger').hide();
                 if($("#reviewsval").val()==1)
                 {
                  $("#login-modal").modal('hide');
                                      
                  // $('.loginclose').prop('disabled', true);
                   $('#reviewsmodal').modal({
                      backdrop: 'static',
                      keyboard: false
                  });
                   $("#reviewsmodal").modal('show');
                               
                 }
                 else{
                   jQuery('.alert-success').html("Login successful");
                   setTimeout(function(){ location.reload(); }, 200); 
                  }                   
                }
               else{
                  jQuery('.alert-danger').html("");
                  jQuery('.alert-success').hide();
                  jQuery.each(response.errors, function(key, value){
                     jQuery('.alert-danger').show();

                     jQuery('.alert-danger').append('<p>'+value+'</p>');
                  });
               }
             },    
           });
         })
         })
        </script>
       <script>
        var input = document.querySelector("#phoneno");
        window.intlTelInput(input, {
         
          utilsScript: "{{url('web/js/utils.js')}}",
        });

        var input = document.querySelector("#phoneno1");
        window.intlTelInput(input, {
          utilsScript: "{{url('web/js/utils.js')}}",
        });
  
  </script>
      <script>
       var token = "{{ csrf_token() }}";
       $(".profile-user-img,.plus").click(function() {
            $("input[id='image_upload']").click();
        });

        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#imguser').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }

    function ValidateEmail(email) {
      var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
      return expr.test(email);
    };
	    $(".firstname").on('change',function(){ 
	  	 	$(".fn_err").html(""); 
	    });
	    $(".lastname").on('change',function(){
	  	 	$(".ln_err").html("");
	    }); 
	    $(".dob").on('change',function(){
	  	 	$(".bday").html("");
	    });

	    $("#gender").on('change',function(){
	  	 	$(".gender_err").html("");
	    });     


        $("#emailaddress,#txtemail").on('keyup',function(){
         
         var email = $("#emailaddress").val();
         if(email=="") var email = $("#txtemail").val();
         $.ajax({
             url: "{{url('/check-email')}}",
             type: 'POST', 
             data:   {    
               "_token": token,
               'email':email
             },
            success: function(response){
              
               if(response==0){
                  $(".email_err").html("Email already exists");
                  $("#signup").prop('disabled',true)  ;
                  }
                  else
                  { 
                    if(!ValidateEmail(email))
                    {
                      $(".email_err").html("Please enter valid email address.");
                    }  
                    else{
                      $(".email_err").html("");
                      $("#signup").prop('disabled',false);
                    }
                  }
            }, 
         });
      })

        $("#phoneno,#phoneno1").on('keyup',function(e){
        var code = (e.which) ? e.which : e.keyCode;
        if ((e.keyCode >= 48 && e.keyCode <= 57) || (e.keyCode >= 96 && e.keyCode <= 105)){
            
        }else{
          e.preventDefault();
           $("#phoneno").val("");
        }

         var phone = $("#phoneno").val();
          if(phone=="") var phone = $("#phoneno1").val();

         $.ajax({
             url: "{{url('/check-phoneno')}}",
             type: 'POST', 
             data:   {    
               "_token": token,
               'phone':phone
             },
            success: function(response){
               if(response==0){
                  $(".phone_err").html("Phone no. already exists");
                  $("#signup").prop('disabled',true)  ;
               }               
               else{
                  $(".phone_err").html("");
                  $("#signup").prop('disabled',false)  
               }
            }, 
         });
      })

        $("#password").on('keyup',function(){
         
         var cpwd = $("#confirmpwd").val();
          var pwd = $("#password").val();
         if(cpwd!=""){
            $.ajax({
                url: "{{url('/check-password')}}",
                type: 'POST', 
                data:   {    
                  "_token": token,
                  "cpwd":cpwd,
                  "pwd":pwd
                },
               success: function(response){
                 
                  if(response==0){
                     $("#pwd_err").html("Password and Confirm Password does not match");
                     $("#signup,.button-4").prop('disabled',true)  ;
                  }               
                  else{
                     $("#pwd_err").html("");
                     $("#signup,.button-4").prop('disabled',false) ; 
                  }
               }, 
            });
         }
      });

        $("#confirmpwd").on('keyup',function(){
         var pwd = $("#password").val();
         var cpwd = $("#confirmpwd").val();
         $.ajax({
             url: "{{url('/check-password')}}",
             type: 'POST', 
             data:   {    
               "_token": token,
               "pwd":pwd,
               "cpwd":cpwd,
             },
            success: function(response){
               if(response==0){
                  $("#pwd_err").html("Password and Confirm Password does not match");
                  $("#signup,.button-4").prop('disabled',true)  ;
               }               
               else{
                  $("#pwd_err").html("");
                   $("#pwd_err1").html("");
                  $("#signup,.button-4").prop('disabled',false)  
               }
            }, 
         });
      });

 $("#signupform").on('submit',function(e){     
    e.preventDefault();  
    var phone = $("#phoneno").val(); 
     var code = $(".iti__active").data('dial-code');   
     console.log(code);  
     var img = $("#image_upload").val();
     var socialimg = $("#imguser").attr('src');
     var cpwd = $("#confirmpwd").val();
     var pwd = $("#password").val();
     var fn =  $(".firstname").val();
     var ln =  $(".lastname").val();
     var bday = $(".dob").val();
     var gender = $("#gender").val();
     var email = $("#emailaddress").val();
     if(fn==""){
      $(".fn_err").html("Please enter your first name");
      return false;
  	 }
  	 else
  	 { 
  	 	$(".fn_err").html("");        
  	 }
    if(ln==""){
	    $(".ln_err").html("Please enter your last name");
	    return false;
  	 }
  	else{
	    $(".ln_err").html("");	   
  	}
    if(phone==""){
     $(".phone_err").html("Please enter phone no");
     return false;
    }
    else{
     $(".phone_err").html("");     	
    }
    if(email==""){
     $(".email_err").html("Please enter email");
     return false;
    }
    else{
     $(".email_err").html("");     	
    }


    if(pwd.length<6)
    {
      $("#pwd_err1").html("Password must be 6 characters in length");
     return false;
    }
    else
    {
      $("#pwd_err1").html("");
    }
    if(cpwd.length<6){
       $("#pwd_err").html("Confirm Password must be 6 characters in length");
     	return false;     	
     }
     else
     {
     	$("#pwd_err").html("");
     }
     if(pwd==""){
     	$("#pwd_err1").html("Please enter password");
     	return false;
     }
     else
     {
     	$("#pwd_err1").html("");
     }
    if(cpwd == ""){
     	$("#pwd_err").html("Please enter confirm password");
     	return false;     	
     }
     else
     {
     	$("#pwd_err").html("");
     }
    if(bday == ""){
     	$(".bday").html("Please enter Date of birth");
     	return false;     	
     }
     else
     {
     	$(".bday").html("");
     }
    if(gender == ""){
     	$(".gender_err").html("Please select gender");
     	return false;     	
     }
     else
     {
     	$(".gender_err").html("");
     }

    
     if(img ==  ''  &&  socialimg !=""){
        var img = $("#imguser").val();
     }else{
        var img = $("#image_upload").val();
            if(img =="")
         {
          swal("","Please upload profile image","error");
          return false;
         }
     }
     $("#login-modal_2").modal('hide');
     if(phone!=""){
        $.ajax({
            url: "{{url('/send-otp')}}",
            type: 'POST', 
            data:   {    
              "_token": token,
              "phone":phone,
              "code":code                  
            },
           success: function(response){
            if(response.success==1){
          		$("#otp").val(response.otp);
              swal("OTP sent!", "Please verify OTP sent on your phone no.", "success")   	
              .then((showmodal) => {
    			    if (showmodal) {			    				    
      			$("#login-modal_2").modal('hide');                      
                  $("#login-modal_3").modal('show'); 
      			    } 
      				});                     
              }               
            else{
              $("#login-modal_1").modal('hide'); 
              $("#login-modal_3").modal('show'); 
            }
          },
        })       
      }           
    });  

     $(".resend_otp").on('click',function(e){
       e.preventDefault();
        var phone = $("#phoneno").val();
        var code = $(".iti__active").data('dial-code');                
         if(phone!=""){
            $.ajax({
                url: "{{url('/send-otp')}}",
                type: 'POST', 
                data:   {    
                  "_token": token,
                  "phone":phone,  
                  "code":code                
                },
               success: function(response){
                  	if(response.success==1){
                  		$("#otp").val(response.otp);
		                swal("OTP sent!", "Please verify OTP sent on your phone no.", "success")   	
		                  .then((showmodal) => {
						    if (showmodal) {			    				    
							    $("#login-modal_1").modal('hide'); 
			                   
			                    $("#login-modal_3").modal('show'); 
						    } 
		  				});                     
                	}               
              else{
                   swal({
                    title: "OTP not sent!!",
                    text: "Please check your phone no. is valid or try to send OTP again.",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                  })
                   .then((showmodal) => {
					    if (showmodal) {			    				    
						    $("#login-modal_1").modal('hide'); 
		            $("#login-modal_3").modal('show'); 
					    } 
	  				});                  
                  }
               },
            })
        }  
     })

  $(".verify_btn") .on('click',function(){
    var otp = $("#otp").val();
    var otp_enter = $("#txtverify1").val()+$("#txtverify2").val()+$("#txtverify3").val()+$("#txtverify4").val();    
     var text1 = $("#txtverify1").val();
     var text2 = $("#txtverify2").val();
     var text3 = $("#txtverify3").val();
     var text4 = $("#txtverify4").val();

    if(text1=="" || text2==""||text3=="" ||text4=="")
    {
      swal("Oops!", "Please fill all the numbers", "error");
      return false;
    }  
    var form = $("#signupform")[0];
    var form_data = new FormData(form);
    form_data.append('otp', otp_enter);
    form_data.append('otp_original', otp);
    form_data.append('_token', token);
    var code = $(".iti__active").data('dial-code');
    form_data.append('cc_code', code);
    $.ajax({
       url: "{{url('/sign-up')}}",
       data: form_data,
       type: 'POST',
       processData: false,
       contentType: false,
      success: function(data){
        if(data==1)
        { 
          swal("Good job!", "OTP Verified!! Registration successful", "success") ;
          $("#login-modal_2").modal('hide'); 
          $("#login-modal_3").modal('hide'); 
           $("#login-modal").modal('show');
        }
        else if(data==2)
        {
          swal("Oops!", "Something went wrong!! Registration unsuccessful.Please register again", "error");
          $("#login-modal_2").modal('hide'); 
          $("#login-modal_3").modal('hide');
        }
        else if(data ==0)
        {
          swal("Oops!", "OTP verification failed. Please register again", "error")
          .then((showmodal) => {
            if (showmodal) { 
            $("#login-modal_2").modal('hide');   
            $("#login-modal_3").modal('hide'); 
            } 
        });  
        }
      }
    });
  })

 function openNav() {
    document.getElementById("mySidenav").classList.add('reveal');
  }
     
  function closeNav() {
    document.getElementById("mySidenav").classList.remove('reveal');
  }


</script>
  <?php $id = Session::get('signup_id');
      if($id==1) {
     ?>
    <script>
        $(function() {
           swal("More Information Needed", "Please Complete your Profile for successful Registration.", "success")     
            .then((showmodal) => {
                if (showmodal) {   
                $("#login-modal_2").modal('show'); 
                } 
            });  
        });
    </script>
    <?php }?>
    <script>
      $(".forgot_pwd").on('click',function(){
        $("#forgot_modal").modal('show');
        $("#login-modal").modal('hide');
       
        
        //$("#login-modal").css('display','none');
      })

      $("#form_password").on('submit',function(e){

        e.preventDefault();
        var emailval = $("#pwd_forgot").val();
        if(emailval=="")
        {
          $("#pwd_errforgot").html("please enter email address");
        }
        else
        {
          $.ajax({
            url: "{{url('/forgot-password')}}",
            type: 'POST', 
            data:   {    
              "_token": token,
              "email":emailval                  
            },
          success: function(response){
            $("#pwd_successforgot").html(response);
            $("#pwd_errforgot").html("");
          },
        })       
        }
      })

     /* $(".forgot_close").on('click',function(){
        window.location = "https://timernr.in/";
      });*/

     
    </script>

  <script>
    new WOW().init();
    $(function() {
    'use strict';
   
    var body = $('.otp_model');
   
    function goToNextInput(e) {
    var key = e.which,
    t = $(e.target),
    sib = t.next('input');
   
    if (key != 9 && (key < 48 || (key > 57 && key<96) || key > 105)) {
    e.preventDefault();
    return false;
    }
   
    if (key === 9) {
    return true;
    }
   
    if (!sib || !sib.length) {
    sib = body.find('input').eq(0);
    }
    sib.select().focus();
    }
   
    function onKeyDown(e) {
    var key = e.which;
   
    if (key === 9 || ((key >= 48 &&  key <= 57) || (key >= 96 && key <= 105))) {
    return true;
    }
   
    e.preventDefault();
    return false;
    }
   
    function onFocus(e) {
    $(e.target).select();
    }
   
    body.on('keyup', 'input', goToNextInput);
    body.on('keydown', 'input', onKeyDown);
    body.on('click', 'input', onFocus);
   
    })  


    

      

  </script>
 <script>
$( "#list-service" ).on('click', function() {
  $(".list-service-overly" ).addClass('active');
     $('body').append($('<div/>', {
          id: 'holdy' 
      }));
  });

$(document).on("click","#holdy",function() {
    $(".list-service-overly").removeClass('active');
    $('#holdy').remove();
   });
 </script>

   
