<input type="hidden" id="filterval" value="{{@$filter}}">
<input type="hidden" id="catval" value="{{@$id}}">
<input type="hidden" id="latitude" value="{{@$latitude}}">
<input type="hidden" id="longitude" value="{{@$longitude}}">

@if(count(@$result['data'])>0)
  @foreach(@$result['data'] as $key=>$value)
  <div class="container lis_bg">
     <a href="{{url('/booking-peopleavailability/').'/'.$value['encodedid']}}">
     <div class="row under_bg">
        <div class="col-lg-4">
        	@if($value['image'])	
           <img src="{{$value['image']}}" class="m1">
           @else
           <img src="{{url('/attachments'.'/'.'noimage.jpeg')}}" class="m1">
           @endif
        </div>
        <div class="col-lg-8">
           <div class="main_box">
              <h5 class="heading_main">{{$value['title']}}</h5>
              <p class="contant_main"><?php 
              if(str_word_count($value['description'])>10)
              {
                echo implode(' ', array_slice(explode(' ', $value['description']), 0, 10)).'  ......';
              }
              else
              {                                 
                echo $value['description'];
              }  ?></p>
           </div>
           <div class="row">
              <div class="col-lg-6">                                   
              <p class="price">${{$value['price_per_night']}}</p>
               
              </div>
             <!--  <div class="col-lg-6">
                 <a href="{{url('/booking-peopleavailability/').'/'.$value['id']}}"><button type="button" class="category_btn_1">Book</button></a>
              </div> -->
           </div>
        </div>
     </div>
     </a>
  </div>
  @endforeach
  {{$provider->links()}}
  @else
  <input type="hidden" id="notfound" value=1>
  <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
@endif

<script>
       $('.pagination li a,.nav-item a,.pagination li.page-item:nth-child(2)').on('click', function(e){  
         
        e.preventDefault();
        $(".pagination li").removeClass("active");
        if ($(this).is(':nth-child(2)'))
          $(this).addClass("active");
        else
        $(this).parent().addClass("active");
        var filter= $("#filterval").val();
        var lat = $("#latitude").val();
        var lng = $("#longitude").val();
        var cat = $("#catval").val();
      
        var url = $(this).attr('href');
        
         $.ajax({
         type:'POST',
         url:url,
          data: {"_token": "{{ csrf_token() }}","filter":filter,"catval":cat,'latitude':lat,'longitude':lng},
         success:function(data){
          $(".filterresult").html(data.html);
         
         }
        });
      });

      </script>