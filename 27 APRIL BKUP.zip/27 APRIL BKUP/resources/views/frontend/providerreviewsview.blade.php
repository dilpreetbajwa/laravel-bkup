
@if($type=="#all")
   @if(count($review)>0)
      @foreach($review as $place)
         <li>
            <div class="review-icon"><img src="{{$place['image']}}" alt="icon" width="100" height=100></div>
            <div class="review-content">
               <h3>{{$place['user']}}</h3>
               <span class="m-re">{{$place['ratings']}}.0<span> ★</span></span>
               <p class="review-date">{{$place['datemonth']}} {{$place['dateyear']}}</p>
               <p>{{$place['reviews']}} </p>
            </div>
         </li>
      @endforeach
     @else
      <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
   @endif 


@elseif($type=="#home")
   @if(count($review_place)>0)
    @foreach($review_place as $place)
      <li>
         <div class="review-icon"><img src="{{$place['image']}}" alt="icon" width="100" height=100></div>
         <div class="review-content">
            <h3>{{$place['user']}}</h3>
            <span class="m-re">{{$place['ratings']}}.0<span> ★</span></span>
            <p class="review-date">{{$place['datemonth']}} {{$place['dateyear']}}</p>
            <p>{{$place['reviews']}} </p>
         </div>
      </li>
   @endforeach
    @else
      <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
   @endif 


 @elseif($type=="#menu1")
 @if(count($review_things)>0)
   @foreach($review_things as $things)
      <li>
         <div class="review-icon"><img src="{{$things['image']}}" alt="icon" width="100" height=100></div>
         <div class="review-content">
            <h3>{{$things['user']}}</h3>
            <span class="m-re">{{$things['ratings']}}.0<span> ★</span></span>
            <p class="review-date">{{$things['datemonth']}} {{$things['dateyear']}}</p>
            <p>{{$things['reviews']}}</p>
         </div>
      </li>
   @endforeach
   @else
      <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
   @endif 


@elseif($type=="#menu2")
   @if(count($review_people)>0)
      @foreach($review_people as $people)
         <li>
            <div class="review-icon"><img src="{{$people['image']}}" alt="icon" width="100" height=100></div>
            <div class="review-content">
               <h3>{{$people['user']}}</h3>
               <span class="m-re">{{$people['ratings']}}.0<span> ★</span></span>
               <p class="review-date">{{$people['datemonth']}} {{$people['dateyear']}}</p>
               <p>{{$people['reviews']}}</p>
            </div>
         </li>
      @endforeach 
    @else
      <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
   @endif 
@endif
  






