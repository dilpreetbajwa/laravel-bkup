@extends('layouts.frontend.master')
@section('content')
<style>
.search-bar
{
  display:none;
}
.bottom-cntnt {
    
    flex-wrap: unset;     
}
.booking-list {
    justify-content: left;
}
.booking-tabs-cntnt .form_tabs {
    display: flex;
}
.booking-inner{
    margin-right: 20px!important;
    
}
</style>

<div class="modal fade" id="hostmodal" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Host Details</h4>
        </div>
        <div class="modal-body hostdata">
      
        </div>
       
      </div>
    </div>
  </div>
  <input type="hidden" id="typeofbooking1" value="">
   <input type="hidden" id="filterval" value="">
      <section class="Popular-task_1 comman-padding booking-c-main">
         <div class="container task-contain">
            <div class="places-form">
              <h2 class="border-bottom-content title-transact" style="margin-bottom: 20px">All Bookings</h2>
               <div class="Tabs booking-tabs-cntnt">
               <!-- Nav pills -->
                  <ul class="nav nav-pills form_tabs">
                     <li class="nav-item">
                     <a class="nav-link active  tab_menu" data-toggle="pill" href="javascript:void(0)" data-id="1">Upcoming</a>
                     </li>
                     <li class="nav-item">
                     <a class="nav-link tab_menu Cancelled" data-toggle="pill" href="javascript:void(0)" data-id="2">Cancelled </a>
                     </li>
                     <li class="nav-item"> 
                     <a class="nav-link tab_menu completed" data-toggle="pill" href="javascript:void(0)" data-id="3">Completed</a>
                     </li>
                     <li class="nav-item">
                     <select name="filterprovider" id="filterprovider">
                        <option value="0">All</option>
                        <option value="1">Places</option>
                        <option value="2">Things</option>
                        <option value="3">People</option>
                     </select>
                     </li>
                  </ul>
               <!-- Tab panes -->
                  <div class="tab-content">
                     <div class="tab-pane container active" id="home1">
                        <div class="booking-list filterresult_up">
                        @if($filter==0)
                          @if(count($data)>0)
                       
                          @foreach($data as $value)
                            
                             <div class="booking-inner">
                             
                            
                                <div class="booking-details-cntnt">
                                   <div class="top-content">
                                      <h3>Booking Id : {{$value['id']}}</h3>
                                      <h3>Booking Date : {{$value['date']}}</h3>

                                   </div>
                                   <div class="bottom-cntnt">
                                      <div class="imge-book">
                                         <img src="{{$value['image']}}" alt="image">
                                      </div>
                                     
                                      <div class="booking-opop">
                                      <a href="{{url('/booking-historydetail').'/'.base64_encode($value['id'])}}">

                                       
                                         <h3 class="booking-title">Name : {{$value['title']}}</h3>
                                         <div class="guest-pricee">
                                            <p>Price : $ {{$value['amount']}}</p>
                                            <p>Category : {{$value['category']}}</p>
                                         </div>
                                         <p>Location : {{$value['location']}}</p>
                                         @if($value['place']==1)
                                           <div class="btn-contactt">
                                               <a class="contacthost" href="javascript:void(0)" data-name="{{$value['hname']}}" data-phone="{{$value['hphone']}}">Contact Host</a>
                                         </div>
                                         @endif
                                         </a>

                                      </div>
                                     
                                   </div>
                                </div>
                               
                             </div>
                            
                             @endforeach
                             @else
                              <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
                              @endif
                          @endif

                      @if($filter==1)
                       @if(count($data)>0)
                        @foreach($data_place as $value)
                           <div class="booking-inner">
                              <div class="booking-details-cntnt">
                                 <div class="top-content">
                                    <h3>Booking Id : {{$value['id']}}</h3>
                                    <h3>Booking Date : {{$value['date']}}</h3>

                                 </div>
                                 <div class="bottom-cntnt">
                                    <div class="imge-book">
                                       <img src="{{$value['image']}}" alt="image">
                                    </div>
                                    <div class="booking-opop">
                                       <a href="{{url('/booking-historydetail').'/'.base64_encode($value['id'])}}">
                                       <h3 class="booking-title">Name : {{$value['title']}}</h3>
                                       <div class="guest-pricee">
                                          <p>Price : $ {{$value['amount']}}</p>
                                          <p>Category : {{$value['category']}}</p>
                                       </div>
                                       <p>Location : {{$value['location']}}</p>
                                        <div class="btn-contactt">
                                          <a class="contacthost" href="javascript:void(0)" data-name="{{$value['hname']}}" data-phone="{{$value['hphone']}}">Contact Host</a>
                                       </div>
                                    </div>
                                  </a>   
                                 </div>
                              </div>
                           </div>
                           @endforeach
                            @else
                              <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
                              @endif
                          @endif
                           
                          
                        </div>
                     </div>
                     <div class="tab-pane container fade" id="menu11">
                        <div class="booking-list filterresult_can">
                        @if($filter==2)
                           @if(count($data)>0)
                          @foreach($data_things as $value)
                           <div class="booking-inner">
                                 <div class="booking-details-cntnt">
                                    <div class="top-content">
                                       <h3>Booking Id : {{$value['id']}}</h3>
                                       <h3>Booking Date : {{$value['date']}}</h3>

                                    </div>
                                    <div class="bottom-cntnt">
                                       <div class="imge-book">
                                          <img src="images/booking.jpg" alt="image">
                                       </div>
                                       <div class="booking-opop">
                                        <a href="{{url('/booking-historydetail').'/'.base64_encode($value['id'])}}">
                                          <h3 class="booking-title">Name : {{$value['title']}}</h3>
                                          <div class="guest-pricee">
                                             <p>Price : $ {{$value['amount']}}</p>
                                             <p>Category : {{$value['category']}}</p>
                                          </div>
                                          <p>Location :  {{$value['location']}}</p>
                                       </div>
                                       </a>
                                    </div>
                                 </div>
                              </div>
                              @endforeach
                               @else
                              <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
                              @endif
                              @endif
                            
                           </div>
                     </div>
                     <div class="tab-pane container fade" id="menu21">
                        <div class="booking-list filterresult_comp">
                        @if($filter==3)
                           @if(count($data)>0)
                          @foreach($data_people as $value)
                           <div class="booking-inner">
                              <div class="booking-details-cntnt">
                                 <div class="top-content">
                                    <h3>Booking Id :{{$value['id']}}</h3>
                                    <h3>Booking Date : {{$value['date']}}</h3>

                                 </div>
                                 <div class="bottom-cntnt">
                                    <div class="imge-book">
                                       <img src="images/booking.jpg" alt="image">
                                    </div>
                                    <div class="booking-opop">
                                     <a href="{{url('/booking-historydetail').'/'.base64_encode($value['id'])}}">
                                       <h3 class="booking-title">Name : {{$value['title']}}</h3>
                                       <div class="rating-result" title="99%">
                                       <span style="width: 67%;">
                                       </span>
                                       </div>
                                       <div class="guest-pricee">
                                          <p>Price : $ {{$value['amount']}}</p>
                                          <p>Category : {{$value['category']}}</p>
                                       </div>
                                       <p>Location : {{$value['location']}}</p>
                                    </div>
                                    </a>
                                 </div>
                              </div>
                           </div>
                           @endforeach
                            @else
                              <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
                              @endif
                           @endif
                           
                        </div>
                     </div>
                     </div>
                  </div>
               </div>
          </div>
      </section>  
      
       <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script> 
      <script src="{{url('web/js/wow.js')}}"></script>

   <script>
      var base_url = "<?php echo url('/'); ?>";
      var token = "{{ csrf_token() }}";  

      $("#filterprovider").on('change',function(){ 

        $('li.nav-item a').each(function(i){
          if($(this).hasClass('active'))  tab = i+1;         
       });        
          var filter = $("#filterprovider").val();
           $.ajax({
                type: "POST",
                url: base_url+'/bookings-history',
                data: {
                  "_token": token,
                  'filter':filter,
                  'type':tab               
                },
                success: function(data) {   
                             
                 if(data.typebooking == 1)                
                  $(".filterresult_up").html(data.html);
                  if(data.typebooking == 2)                
                  $(".filterresult_can").html(data.html);
                  if(data.typebooking == 3)                
                  $(".filterresult_comp").html(data.html);
                            
                }
              });
            });
         

$(".booking-c-main .nav-item a").on('click',function(){           
  var type =  $(this).attr('data-id');
  var filter = $("#filterprovider").val();
  if(type==2)
    $(this).attr('href','#menu11');
  if(type==3)
    $(this).attr('href','#menu21');
  if(type==1)
    $(this).attr('href','#home1');
  $("#typeofbooking1").val(type);
   $.ajax({
    type: "POST",
    url: base_url+'/bookings-history',
    data: {
      "_token": token,
      'filter':filter,
      'type':type               
    },
    success: function(data) { 
      
      if(data.typebooking == 1)                
      $(".filterresult_up").html(data.html);      
      if(data.typebooking == 2)                
      $(".filterresult_can").html(data.html);
      if(data.typebooking == 3)                
      $(".filterresult_comp").html(data.html);
    }
  });
})
$(".contacthost").on('click',function(e){
   e.preventDefault();
   var hname = $(this).attr('data-name');
   var hphone = $(this).attr('data-phone');
   $("#hostmodal").modal('show');
   if(hname !="" && hphone!="")
   $(".hostdata").html('<p><b>Host Name :</b>'+hname+'</p><p><b>Host Phone No.:</b>'+hphone+'</p>');
  else
    $(".hostdata").html('<p>No Host available</p>');

})
</script>


@endsection
     