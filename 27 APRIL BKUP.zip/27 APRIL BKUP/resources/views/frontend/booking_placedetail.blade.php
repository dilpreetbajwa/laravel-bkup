@extends('layouts.frontend.master')
@section('content')
<style>
#map_canvas
{
  position: relative!important;
  width:100%!important;
  height:20vw!important;
}
button.owl-prev {
float: left;
left: 0;
position: absolute;
top: 50%;
}
button.owl-next {
float: right;
right: 0;
top: 50%;
position: absolute;
}
</style>

<div class="modal fade" id="hostmodal" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Host Details</h4>
        </div>
        <div class="modal-body">
          <p><b>Host Name :</b>{{$userdet->name}}</p>
          <p><b>Host Phone No.:</b>{{$userdet->phone_number}}</p>
        </div>
       
      </div>
    </div>
  </div>
</div>
      <!-- About place -->
      <section class="Popular-task_1 comman-padding more-about-place">
         <div class="container task-contain">
            <div class="places-form">
               <!-- <div class="row bx-banner-images">
                  <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                    <div class="innerpage-box-left">
                                   
                    </div>
                  </div>
                  <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                     <div class="innerpage-box-left owl-carousel">
                      @foreach($attachments as $pic)
                      <img src="{{url('/attachments').'/'.$pic->filenames}}" width="100px" height="100px">
                     @endforeach             
                    </div>
                  </div>
               </div> -->
                <div class="row bx-banner-images">
                  <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                    <div class="innerpage-box-left">
                      <img src="{{url('/web/images/img-silder-1.jpg')}}" class="width-FUll">              
                    </div>
                  </div>
                  <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                     <div class="innerpage-box-right">
                       <div class="image-box"><img src="{{url('/web/images/img-silder-2.jpg')}}"></div>
                       <div class="image-box"><img src="{{url('/web/images/img-silder-3.jpg')}}"></div>
                       <div class="image-box"><img src="{{url('/web/images/img-silder-4.jpg')}}"></div>
                       <div class="image-box"><img src="{{url('/web/images/img-silder-5.jpg')}}"></div>
                     </div>
                  </div>
               </div>
               <div class="full-width-text content-info border-bottom-content">
                  <div class="content-left-info">
                  <h3>{{$placedetails->title}}</h3>
                  <!-- <p>{{$placedetails->description}}</p> -->
                  <p>
                  Polar Cabin is a perfect place for outdoor activities, observing Northern Lights in winter or just relaxing, reading books, listening to birds singing and enjoying nature. Suitable for couples, families, group of friends or small groups searching for something extraordinary.
                  </p>
               <input type="hidden"  id = "latval" value="{{$placedetails->latitude}}"">
                <input type="hidden"  id = "lngval" value="{{$placedetails->longitude}}"">
                <form method="post">
                 <input type="hidden"  id = "providerid" value="{{$placedetails->id}}">
                 <input type="hidden" name="_token" id="csrf-token" value="{{ Session::token() }}" />
                 </form>
         <h4 class="heaindg-auth">Owned by - <span>{{$userdet->name}}</span></h4>
                  </div>
                  <div class="content-right-info">
                     <ul>
                        <li>
                           <a href="#">
                           <span class="icon-info"><svg viewBox="0 0 24 24" fill="currentColor" fill-opacity="0" stroke="currentColor" stroke-width="2.25" focusable="false" aria-hidden="true" role="presentation" stroke-linecap="round" stroke-linejoin="round" style="height: 15px; width: 15px; display: block; overflow: visible;"><g fill-rule="evenodd"><path d="m11.5 16v-15"></path><path d="m7.5 4 4-3 4 3"></path><path d="m5.4 9.5h-3.9v14h20v-14h-3.1"></path></g></svg>
                           </span>
                           <span class="title-info">Share</span></a>
                        </li>
                        <li>
                           <a href="#">
                           <span class="icon-info"><svg viewBox="0 0 24 24" fill="currentColor" fill-opacity="0" stroke="#484848" stroke-width="2.25" focusable="false" aria-label="Save this listing." role="img" stroke-linecap="round" stroke-linejoin="round" style="height: 15px; width: 15px; display: block; overflow: visible;"><path d="m17.5 2.9c-2.1 0-4.1 1.3-5.4 2.8-1.6-1.6-3.8-3.2-6.2-2.7-1.5.2-2.9 1.2-3.6 2.6-2.3 4.1 1 8.3 3.9 11.1 1.4 1.3 2.8 2.5 4.3 3.6.4.3 1.1.9 1.6.9s1.2-.6 1.6-.9c3.2-2.3 6.6-5.1 8.2-8.8 1.5-3.4 0-8.6-4.4-8.6" stroke-linejoin="round"></path></svg>
                           </span>
                           <span class="title-info">Save</span></a>
                        </li>
                     </ul>
                     <div class="info-img">
                        <img src="images/info-au.png" alt=""/>
                        <p>{{$userdet->phone_number}}</p>
                     </div>
                  </div>
               </div>
            <!--    <div class="full-width-text border-bottom-content">
                  <h3>Entire Cabin</h3>
                  <p>We offers our guests with luxurious Suite Cottages which are beautifully designed, spacious, well-illuminated and have comfortable beds. These rooms are enabled with all the comfortable beds. These rooms are enabled with... </p>
               </div>
               <div class="full-width-text border-bottom-content">
                  <h3>Great Location</h3>
                  <p>We offers our guests with luxurious Suite Cottages which are beautifully designed, spacious, well-illuminated and have comfortable beds. These rooms are enabled with a spacious, well-illuminated and have comfortable beds. These rooms are enabled with...  </p>
               </div>
                <div class="full-width-text border-bottom-content">
                  <h3>Galye is a Host</h3>
                  <p>We offers our guests with luxurious Suite Cottages which are beautifully designed, spacious, well-illuminated and have comfortable beds. These rooms are enabled with a spacious, well-illuminated and have comfortable beds. These rooms are enabled with beautifully designed, spacious, well-illuminated and have comfortable beds. These rooms are enabled with a spacious beautifully designed, spacious, well-illuminated and have comfortable beds. These rooms are enabled with a spacious... </p>
               </div> -->
              
               <div class="full-width-text border-bottom-content Amenities-content">
                  <h3>Amenities</h3>
                  <!-- <img src="images/amitit.png" alt="amenities" class="full-img"> -->
                  <div class="amittites">
                   <?php 
                  $arr = explode(",", $placedetails->amenities_offered);
                  ?>
                     <ul>
                        <ul class="showtwoamenties">
                        <li>
                          <span class="icon-title">{{$arr[0]}}</span>
                        </li>
                        @if(count($arr)>1)
                          <li>
                            <span class="icon-title">{{$arr[1]}}</span>
                          </li>
                        @endif
                     </ul>
                   
                      <ul class="showallamenties" style="display:none">
                          @foreach($arr as $amt)
                            <li>
                              <span class="icon-title">{{$amt}}</span>
                            </li>
                          @endforeach
                       
                     </ul>
                  </div>
                   @if(count($arr)>2)
                  <button type="submit" class="btnn btn-show-all" value="next">Show all amenities</button>
                  @endif
                  <button type="submit" class="btnn btn-connt-host" value="Contact to Host" data-toggle="modal" data-target="#hostmodal">Contact to Host</button>
               </div>
               <div class="pick-up-time full-width-text border-bottom-content">
                  <div class="place-info">
                     <div class="innr-info-content">Check in Time - <span class="info-value">{{$placedetails->time_in}}</span></div>
                     <div class="innr-info-content">Check out Time - <span class="info-value">{{$placedetails->time_out}}</span></div>
                     <div class="innr-info-content">Rate - <span class="info-value">${{$placedetails->price_per_night}}</span></div>
                     <div class="innr-info-content">Guests - <span class="info-value">{{$placedetails->total_guests}}</span></div>
                  </div>
                  <!-- <div class="row">
                     <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                        <div class="heading-content">
                           <h4>Check in Time</h4>
                           <p>2:00PM</p>
                        </div>
                        <div class="heading-content">
                           <h4>Rate</h4>
                           <p>$200</p>
                        </div>
                     </div>
                     <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                        <div class="heading-content-right">
                           <h4>Check Out Time </h4>
                           <p>11:00AM</p>
                        </div>
                        <div class="heading-content-right">
                           <h4>Max.Number of Guests</h4>
                           <p>4</p>
                        </div>
                     </div>
                  </div> -->
               </div>
               <div class="full-width-text border-bottom-content">
                  <h3>Location</h3>
                 <!--  <p>We offers our guests with luxurious Suite Cottages which are beautifully designed, spacious, well-illuminated and have comfortable beds. These rooms are enabled with all the modern... </p> -->
                  <div id="map_canvas"></div>
               </div>
                <div class="full-width-text">
                  <h3>Reviews</h3>
                  <p>We offers our guests with luxurious Suite Cottages which are beautifully designed, spacious, well-illuminated and have comfortable beds. These rooms are enabled with all the modern... </p>
                  <ul class="reviews-list">
                     <li>
                        <div class="review-icon"><img src="{{url('/web/images/').'/review-1.png'}}" alt="icon"></div>
                        <div class="review-content">
                           <h3>Naina Holloway</h3>
                           <p class="review-date">September 2019</p>
                           <p>We offers our guests with luxurious Suite Cottages which are beautifully designed, spacious, well-illuminated and have comfortable beds. These rooms are enabled with a spacious, well-illuminated and have comfortable beds. These rooms are enabled with... </p>
                        </div>
                     </li>
                     <li>
                        <div class="review-icon"><img src="{{url('/web/images/').'/review-2.png'}}" alt="icon"></div>
                        <div class="review-content">
                           <h3>Steve Fletcher</h3>
                           <p class="review-date">September 2019</p>
                           <p>We offers our guests with luxurious Suite Cottages which are beautifully designed, spacious, well-illuminated and have comfortable beds. These rooms are enabled with a spacious, well-illuminated and have comfortable beds. These rooms are enabled with... </p>
                        </div>
                     </li>
                     <li>
                        <div class="review-icon"><img src="{{url('/web/images/').'/review-3.png'}}" alt="icon"></div>
                        <div class="review-content">
                           <h3> Oscar Rogers</h3>
                           <p class="review-date">September 2019</p>
                           <p>We offers our guests with luxurious Suite Cottages which are beautifully designed, spacious, well-illuminated and have comfortable beds. These rooms are enabled with a spacious, well-illuminated and have comfortable beds. These rooms are enabled with... </p>
                        </div>
                     </li>
                  </ul>
               </div>
               <div class="form-action-button">
                  <button type="cancel" class="btnn btn-next" value="Cancel" style="width: auto">${{$placedetails->price_per_night}}/night</button>
                 <a href="{{url('/booking-placeavailability'.'/'.$id)}}"> <button type="submit" class="btnn  btn-cancel" value="next" style="width: auto">Check Availability</button></a>
                </div>
            </div>
          </div>
      </section>  

      <!-- Footer Start -->
   
      <!--------------------- Login Form Start --------------------------------->
      <div class="modal fade" id="login-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
         <div class="modal-dialog">
            <div class="loginmodal-container">
               <button type="button" class="btn btn-danger" data-dismiss="modal">X</button>
               <h1>Log In </h1>
               <br>
               <form>
                  <input type="text" name="user" placeholder="Email Address">
                  <input type="password" name="pass" placeholder="Password">
                  <div class="login-help">
                     <a href="#">Forgot Your Password</a>
                  </div>
                  <input type="submit" name="login" class="login loginmodal-submit" value="Log in">
               </form>
               <div class="social_media">
                  <a href="#" class="fb btn">
                  <span class="fb_icon"><i class="fab fa-facebook-f"></i></span>Log In with Facebook
                  </a>
                  <a href="#" class="fb btn Google">
                  <span class="fb_icon"><i class="fab fa-google"></i></span>Log In with Google
                  </a>
                  <a href="#" class="fb btn Instagram">
                  <span class="fb_icon"><i class="fab fa-instagram"></i></span>Log In with Instagram
                  </a>
                  <div class="login-help">
                     <a href="#"><a href="#">Don't have an existing account? <span class="Create_account">Create a new account</span></a>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!--------------------- Login Form End --------------------------------->
      <!--------------------- SignUp Form Start --------------------------------->
      <div class="modal fade" id="login-modal_1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
         <div class="modal-dialog">
            <div class="loginmodal-container">
               <button type="button" class="btn btn-danger" data-dismiss="modal">X</button>
               <h1>Sign Up </h1>
               <br>
               <div class="login-help Sign_Up" data-toggle="modal" data-target="#login-modal_2">
                  <a href="#" class="" ><span class="Create_account email_with">Sign Up Using Email</span></a>
               </div>
               <div class="divider"><span class="or">or</span></div>
               <div class="social_media">
                  <a href="#" class="fb btn">
                  <span class="fb_icon"><i class="fab fa-facebook-f"></i></span>Sign Up with Facebook
                  </a>
                  <a href="#" class="fb btn Google">
                  <span class="fb_icon"><i class="fab fa-google"></i></span>Sign Up with Google
                  </a>
                  <a href="#" class="fb btn Instagram">
                  <span class="fb_icon"><i class="fab fa-instagram"></i></span>Sign Up with Instagram
                  </a>
                  <div class="login-help">
                     <a href="#"><a href="#">Already have an account? <span class="Create_account">Log In</span></a>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!--------------------- SignUp Form End --------------------------------->
      <!--------------------- SignUp Form_2 Start --------------------------------->
      <div class="modal fade" id="login-modal_2" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
         <div class="modal-dialog">
            <div class="loginmodal-container">
               <button type="button" class="btn btn-danger" data-dismiss="modal">X</button>
               <h1>Sign Up </h1>
               <br>
               <form>
                  <!-- <div class="custom-file" id="customFile" lang="es">
                     <input type="file" class="custom-file-input" id="exampleInputFile" aria-describedby="fileHelp">
                     <label class="custom-file-label" for="exampleInputFile">
                        Select file...
                     </label>
                     
                     </div> -->
                  
                  <div class="avatar"><img src="images/man.png"></div>
                  <input type="text" name="user" placeholder="First Name">
                  <input type="text" name="user" placeholder="Last Name">
                  <input type="text" name="user" placeholder="Mobile Number">
                  <input type="text" name="user" placeholder="Email Address">
                  <input type="password" name="pass" placeholder="Password">
                  <input type="password" name="pass" placeholder="Confirm Password">
                  <input type="date" name="bday" class="dob" placeholder="">
                  <div class="form-group">
                     <select class="form-control" id="sel1">
                        <option>Gender</option>
                        <option>Male</option>
                        <option>Female</option>
                     </select>
                  </div>
                  <input type="submit" name="login" class="login loginmodal-submit" value="Sign Up" data-toggle="modal" data-target="#login-modal_3">
               </form>
               <div class="login-help">
                  <a href="#"><a href="#">Already have an account? <span class="Create_account">Click here to Login</span></a>
               </div>
            </div>
         </div>
      </div>
      <!--------------------- SignUp Form_2 End --------------------------------->
      <!--------------------- OTP Form Start --------------------------------->
      <div class="modal fade" id="login-modal_3" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
         <div class="modal-dialog">
            <div class="loginmodal-container">
               <button type="button" class="btn btn-danger" data-dismiss="modal">X</button>
               <!-- <h1>Sign Up </h1> -->
               <br>
               <div id="wrapper">
                  <div id="dialog">
                     <h4>Please enter the 4-digit verification code we sent via SMS:</h4>
                     <span>(we want to make sure it's you before we contact our movers)</span>
                     <div id="form">
                        <input type="text" maxLength="1" size="1" min="0" max="9" pattern="[0-9]{1}" />
                        <input type="text" maxLength="1" size="1" min="0" max="9" pattern="[0-9]{1}" /><input type="text" maxLength="1" size="1" min="0" max="9" pattern="[0-9]{1}" /><input type="text" maxLength="1" size="1" min="0" max="9" pattern="[0-9]{1}" />
                        <button class="btn btn-primary btn-embossed">Verify</button>
                     </div>
                     <div>
                        Didn't receive the code?<br />
                        <a href="#">Send code again</a><br />
                        <a href="#">Change phone number</a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
      <!--------------------- OTP Form End --------------------------------->
      <!-- Bootstrap JS -->
      
      <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
       <script src="https://timernr.com/web/js/owl.carousel.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
      <script src="js/bootstrap.min.js"></script>
    
       
      <script>
      (function($) {
       $(document).ready(function(){
        $(".owl-carousel").owlCarousel({
            loop:true,
             margin:10,
             autoplay:true,
             autoplayTimeout:4000,
             autoplayHoverPause:true,
             responsiveClass:true,
             responsive:{
               300:{
                 items:1,
                 nav:true
               },
               767:{
                 items:2,
                 nav:true
               },
               1000:{
                 items:1,
                 nav:true,
                 loop:false
               }
             }
         });
       });
      }) (jQuery);

      $(".btn-show-all").on('click',function(){
        $(".showallamenties").show();
       $(".showtwoamenties").hide();

      })

      

     

    function addMarker(latlng,title,map) {
      var marker = new google.maps.Marker({
      position: latlng,
      map: map,
      title: title,
      draggable:false
      });
    }


    function initialise() {
      var latitude = $("#latval").val();
      var longitude = $("#lngval").val();    
      var myLatlng = new google.maps.LatLng(latitude,longitude);
      var myOptions = {
        zoom: 8,
        center: myLatlng,
        mapTypeId: google.maps.MapTypeId.ROADMAP
      }
      var map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
      addMarker(myLatlng, 'Default Marker', map);

  }
      </script>
  <script type="text/javascript" src="https://maps.google.com/maps/api/js?key=AIzaSyC29SOMdVFnuCgpVR9VFbeARVJqDJ7tJ-w&callback=initialise"></script> 
    @endsection