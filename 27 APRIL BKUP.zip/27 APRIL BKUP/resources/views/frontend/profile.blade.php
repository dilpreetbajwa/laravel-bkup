@extends('layouts.frontend.master')

@section('content')
 
<style>
.search-bar
{
  display:none;
}
</style>

 <section class="Personal_Information">
         <div class="container">
            <div class="row">
               <div class="main_heading_top col-md-12">
                    <h2 class="border-bottom-content title-transact userprofile" style="margin-bottom: 20px">Profile</h2>
               </div>
               <div class="col-md-12">
                  <div class="Information_bg">
                     <div class="container">
                        <div class="profile_inner p_120">
                           <div class="row viewprofile">
                          
                              <div class="col-lg-5">
                                 <!-- <img class="img-fluid" src="{{url('web/images/personal-2.jpg')}}" alt=""> -->
                                  <!--  <img class="img-fluid" src="{{Session::get('image_src')?Session::get('image_src') :url('web/images/personal-2.jpg')}}" alt="">  -->
                                    <img class="img-fluid" src="{{Auth::user()->image!=''?asset('/profile/'.Auth::user()->image) :url('web/images/personal-2.jpg')}}" alt=""> 

                                  
                              </div>
                              <div class="col-lg-7">
                                 <div class="personal_text">
                                    <h3>{{$userdata->name}}  {{$userdata->lastname}}</h3>
                                    <h4>{{$userdata->email}}</h4>

                                    <!-- <p>You will begin to realise why this exercise is called the Dickens Pattern (with reference to the ghost showing Scrooge some different futures)</p> -->
                                    <ul class="list basic_info">
                                    <?php
                                    $time=strtotime($userdata->dob);
                                    $month=date("F",$time);
                                    $year=date("Y",$time);
                                    $day=date("d",$time);
                                    ?>
                                 <li><a href="#"><?php echo $day.' ' .$month.' '.','.' ' .$year; ?> </a></li>
                                       <li><a href="#">{{$userdata->phone_number}}</a></li>
                                    </ul>
                                 </div>
                                 <div class="button-4 btn_edit">
                                    <div class="eff-4"></div>
                                     <a href="javascript:void(0)" class="btn_editprofile"> Edit Profile </a>
                                 </div>
                              </div>
                              </div>
                             


                              <div class="row editprofile">
                                 <div class="col-lg-5">
                                   <!--  <img class="img-fluid" id="imguser1"  src="{{url('web/images/personal-2.jpg')}}" alt=""> -->
                                     <img class="img-fluid profile" id="imguser1"  src="{{Auth::user()->image!=''?asset('/profile/'.Auth::user()->image)  :url('web/images/personal-2.jpg')}}" alt="">

                                 </div>
                                 <div class="col-lg-7">
                                 <form id="updateprofileform">
                                 <input type="hidden" name="_token" id="csrf-token" value="{{ Session::token() }}" />
                                 <input type="hidden" name="userid" id="userid" value="{{Auth::id()}}">
                                    <div class="personal_text">
                                       <input id="image_upload1" type="file" onchange="readURL1(this);" name="image" style="display: none;" > 
                                    <ul class="list basic_info">
                                      <label>FirstName</label>
                                       <li>
                                          <div class="form-group">
                                             <input class="form-control" type="text" name="txtfn" id="txtfn" value="{{@$userdata->name}}">
                                          </div>
                                       </li>   

                                       <label>LastName</label>
                                       <li>
                                       <div class="form-group">                
                                          <input class="form-control" type="text" name="txtln" id="txtln" value="{{@$userdata->lastname}}">
                                       </div>
                                       </li>    

                                       <label>Phone Number</label>
                                       <li>
                                         <div class="form-group">
                                             <input class="form-control" type="tel" name="phoneno1" id="phoneno1" value="{{@$userdata->phone_number}}"> 
                                             <div class="phone_err"></div>
                                          </div>
                                       </li>

                                          <label>Email</label>
                                         <li>
                                             <div class="form-group">
                                                <input type="text" class="form-control" name="txtemail" id="txtemail" value="{{@$userdata->email}}">
                                                 <div class="email_err"></div>
                                             </div>
                                          </li>

                                        <label>Gender</label>
                                       <li>
                                          <div class="form-group">
                                             <select class="form-control" name="gender" id="gender" required="">
                                                <option value="">Gender</option>
                                                <option value="Male">Male</option>
                                                <option value="Female">Female</option>
                                             </select>
                                          </div>
                                       </li>

                                      
                                        <label>Date of Birth</label>
                                       <li>
                                          <div class="form-group">
                                             <input type="date" class="form-control" name="bday" id="bday" value="{{@$userdata->dob}}">
                                          </div> 
                                       </li>
                                    </ul>
                                    </div>
                                    <div class="button-4 btn_update">
                                       <div class="eff-4"></div>
                                       <a href="javascript:void(0)" class="btn_updateprofile"> Update Profile </a>
                                    </div>
                                    </form>
                                 </div>
                             
                              </div>
                          


                          
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
       <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script> 
      <script src="{{url('web/js/wow.js')}}"></script>

      
      <script>
      $(document).ready(function(){
       $('.editprofile').hide();
      });

      $('.btn_edit').on('click',function(e){
         e.preventDefault();
         $('.viewprofile').hide();
         $('.editprofile').show();
         $(".userprofile").html("Edit Profile");

      })
      $("#imguser1").click(function() {          
         $("input[id='image_upload1']").click();
        });

        $('.btn_update').on('click',function(e){
            e.preventDefault();
          
            if(($(".phone_err").html()=="") &&($(".email_err").html()==""))
            {              
                var form = $("#updateprofileform")[0];
                var form_data = new FormData(form); 
              var code = $(".iti__country.iti__standard.iti__highlight.iti__active").attr('data-dial-code');
                
                form_data.append('cc_code', code);
                form_data.append('userid', $("#userid").val());
                $.ajax({
                   url: "{{url('/update-profile')}}",
                   data: form_data,
                   type: 'POST',
                   processData: false,
                   contentType: false,
                  success: function(data){
                     if(data==1)
                        swal("Good Job!", "Profile Updated successfully.",'success');
                     else
                         alert("Profile not Updated");
                       setTimeout(function(){ window.location.href="{{url('/user-profile')}}"; }, 1000);
                     
                  }
               })
            }
            else
            {
                swal("Some Errors!", "Please Fill in correct Details.", "error") 
            }
         });

        function readURL1(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function (e) {
                    $('#imguser1').attr('src', e.target.result);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
      
     </script>
     <script>
     /*$(".iti__country.iti__standard.iti__highlight.iti__active").attr('data-dial-code',"+91");
        $("#phoneno1").intlTelInput({ 

         
       
        });*/
  </script>  


@endsection