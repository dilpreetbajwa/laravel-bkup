 
 <div class="modal fade" id="hostmodal" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Host Details</h4>
        </div>
        <div class="modal-body hostdata">
        
        </div>       
      </div>
    </div>
  </div>
 @if($filter==0)
   @if(count($data)>0)
    @foreach($data as $value)
      <div class="booking-inner">
         <div class="booking-details-cntnt">
            <div class="top-content">
               <h3>Booking Id : {{$value['id']}}</h3>
               <h3>Booking Date : {{$value['date']}}</h3>

            </div>
            <div class="bottom-cntnt">
               <div class="imge-book">
                  <img src="{{$value['image']}}" alt="image">
               </div>
               <div class="booking-opop">
                 <a href="{{url('/booking-historydetail').'/'.base64_encode($value['id'])}}">
                  <h3 class="booking-title">Name : {{$value['title']}}</h3>
                  <div class="guest-pricee">
                     <p>Price : $ {{$value['amount']}}</p>
                     <p>Category : {{$value['category']}}</p>
                  </div>
                  <p>Location : {{$value['location']}}</p>
                  @if($value['place']==1)
                <div class="btn-contactt">
                  <a class="contacthost" href="javascript:void(0)" data-name="{{$value['hname']}}" data-phone="{{$value['hphone']}}">Contact Host</a>
               </div>

               
                  @endif
               </div>
               </a>

            </div>
         </div>
      </div>
   @endforeach
   {{$bookings->links()}}
   @else
     <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
    @endif
     
@endif
@if($filter==1)
  @if(count($data_place)>0)
    @foreach($data_place as $value)
      <div class="booking-inner">
         <div class="booking-details-cntnt">
            <div class="top-content">
               <h3>Booking Id : {{$value['id']}}</h3>
               <h3>Booking Date : {{$value['date']}}</h3>

            </div>
            <div class="bottom-cntnt">
               <div class="imge-book">
                  <img src="{{$value['image']}}" alt="image">
               </div>
               <div class="booking-opop">
                 <a href="{{url('/booking-historydetail').'/'.base64_encode($value['id'])}}">
                  <h3 class="booking-title">Name : {{$value['title']}}</h3>
                  <div class="guest-pricee">
                     <p>Price : $ {{$value['amount']}}</p>
                     <p>Category : {{$value['category']}}</p>
                  </div>
                  <p>Location : {{$value['location']}}</p>
                    <div class="btn-contactt">
                  </div>
                 
                     <a class="contacthost" href="javascript:void(0)" data-name="{{$value['hname']}}" data-phone="{{$value['hphone']}}">Contact Host</a>
               </a>
               </div>
            </div>
         </div>
      </div>
   @endforeach
   {{$bookings->links()}}
   @else
     <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
    @endif
     
@endif


@if($filter==2)

  @if(count($data_things)>0)
    @foreach($data_things as $value)
      <div class="booking-inner">
         <div class="booking-details-cntnt">
            <div class="top-content">
               <h3>Booking Id : {{$value['id']}}</h3>
               <h3>Booking Date : {{$value['date']}}</h3>

            </div>
            <div class="bottom-cntnt">
               <div class="imge-book">
                  <img src="{{$value['image']}}" alt="image">
               </div>
               <div class="booking-opop">
                <a href="{{url('/booking-historydetail').'/'.base64_encode($value['id'])}}">
                  <h3 class="booking-title">Name : {{$value['title']}}</h3>
                  <div class="guest-pricee">
                     <p>Price : $ {{$value['amount']}}</p>
                     <p>Category : {{$value['category']}}</p>
                  </div>
                  <p>Location :  {{$value['location']}}</p>
               </a>
               </div>
            </div>
         </div>
         </div>
   @endforeach
   {{$bookings->links()}}
   @else
     <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
    @endif
     
@endif
@if($filter==3)
  @if(count($data_people)>0)
    @foreach($data_people as $value)
      <div class="booking-inner">
         <div class="booking-details-cntnt">
            <div class="top-content">
               <h3>Booking Id :{{$value['id']}}</h3>
               <h3>Booking Date : {{$value['date']}}</h3>

            </div>
            <div class="bottom-cntnt">
               <div class="imge-book">
                  <img src="{{$value['image']}}" alt="image">
               </div>
               <div class="booking-opop">
                 <a href="{{url('/booking-historydetail').'/'.base64_encode($value['id'])}}">
                  <h3 class="booking-title">Name : {{$value['title']}}</h3>
                  <div class="rating-result" title="99%">
                  <span style="width: 67%;">
                  </span>
                  </div>
                  <div class="guest-pricee">
                     <p>Price : $ {{$value['amount']}}</p>
                     <p>Category : {{$value['category']}}</p>
                  </div>
                  <p>Location : {{$value['location']}}</p>
               </a>
               </div>

            </div>
         </div>
         </div>
    @endforeach
    {{$bookings->links()}}
   @else
     <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
    @endif
     
@endif
  <script>
  $(".contacthost").on('click',function(e){
    e.preventDefault();
   var hname = $(this).attr('data-name');
   var hphone = $(this).attr('data-phone');
   $("#hostmodal").modal('show');
    if(hname !="" && hphone!="")
   $(".hostdata").html('<p><b>Host Name :</b>'+hname+'</p><p><b>Host Phone No.:</b>'+hphone+'</p>');
   else
   $(".hostdata").html('<p>No Host available</p>');
})
</script>
<script>
       $('.pagination li a,.pagination li.page-item:nth-child(2)').on('click', function(e){  
         
        e.preventDefault();
        $(".pagination li").removeClass("active");
        if ($(this).is(':nth-child(2)'))
          $(this).addClass("active");
        else
        $(this).parent().addClass("active");
        var typebooking1= $("#typeofbooking1").val();
        var filter = $("#filterval").val();
       
        var url = $(this).attr('href');

        
         $.ajax({
         type:'POST',
         url:url,
          data: {"_token": "{{ csrf_token() }}","filter":filter,"type":typebooking1},
         success:function(data){
           if(typebooking1 == 1)                
        $(".filterresult_up").html(data.html);      
        if(typebooking1 == 2)                
        $(".filterresult_can").html(data.html);
        if(typebooking1 == 3)                
        $(".filterresult_comp").html(data.html);
         
         }
        });
      });

      </script>


                           