@extends('layouts.frontend.master')
@section('content')
<style>
.search-bar
{
  display: none;
}
#map_canvas
{
  position: relative!important;
  width:100%!important;
  height:69%!important;
}
.imgecontainer img {
    height: 63px;
}

input#datesdata {
   display: flex;
   align-items: center;
   border: 1px solid #e1e1ed;
   background: #fafaff;
   justify-content: space-between;
   padding: 10px 15px;
   margin: 5px 0;
   height: 50px;
   border-radius: 0;
}

div#datepicker2 span.input-group-addon {
   background: #fafaff;
   height: 45px;
   display: flex;
   flex-wrap: wrap;
   align-items: center;
   justify-content: center;
   position: absolute;
   right: 3px;
   top: 32px;
   padding: 0;
   width: 40px;
   z-index: 9;
   border: 0;
}

  .datepicker-days table.table-condensed {
     width: 25vw !important;
     font-size: 1.6rem !important;
     background: #fafaff !important;
  }

  select#subcatlist {
     margin: 0 0 5px 0;
  }
  span.othersubcat {
     display: flex;
     flex-wrap: wrap;
  }
  .title-inner-form {
  margin-top: 0;
  }
   .datepicker-days td.disabled
  {
    background: grey !important;
    color:red !important;
  }
  .search-bar
  {
    display:none;
  }
</style>
      <!-- Our Packages -->  
      <section class="package comman-padding">
         <div class="container task-contain">
            <div class="row card-section wow bounceInRight">
               <div class="col-lg-12 col-md-12">
                  <div class="card">
                     <div class="main-heading-overlay wow bounceUp">
                        <h2>Edit Your <b>Things</b></h2>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Top Rated-->
      <form  method="post" action = "{{url('/editthingprovider')}}" id="place-form-main" name="places" enctype="multipart/form-data">
     <input type="hidden" name="_token" id="csrf-token" value="{{ Session::token() }}" />
     <input type="hidden" name="providerid" id="providerid" value="{{@$provider_id}}" />
     <input type="hidden" name="datesbooked" id="datesbooked" value="{{@$original_dates}}" />
      <input type="hidden"  id = "unavldates" value="{{@$unavailable_dates}}">
      <section class="Popular-task_1">
         <div class="container task-contain">
             <span class="placesitem" hidden></span>
         </div>
      </section>
      <!-- About place -->
      <section class="Popular-task_1 comman-padding more-about-thing">
         <div class="container task-contain">
           
         <div class="places-form">
               <form action="" method="post" id="place-form-main" name="">
               <div class="row">
                  <div class="col-lg-6">
                      <input type="hidden" name="catdata" id="catdata">
                      <input type="hidden" name="amentiesid" id="amentiesid" value="1">
                      <input type="hidden" name="picsid" id="picsid" value="1">
                  </div>
               </div>
               <div class="row">
                  <div class="main-heading more-about-heading wow bounceInUp">
                     <h2>Edit Thing <b class="Services">Details</b></h2>
                  </div>
                  <div class="col-lg-6">
                     <div class="">
                        
                        <!-- <div class="add-offer-values">
                           <label for="value-add-off"><img src="images/arrow-down-new.png" alt="icon"></label>
                           <input type="checkbox" id="value-add-off">
                           <div class="overly-content-ofer thing-off"> -->
                                 <select name="condition" id="condition" class="form-input">
                                    <option value="-1" selected>Condition of the item</option>
                                    <option value="New" {{@$condition=="New"?'selected':''}}>New</option>
                                    <option value="Average" {{@$condition=="Average"?'selected':''}}>Average</option>
                                    <option value="Old" {{@$condition=="Old"?'selected':''}}>Old</option>
                                 </select>
                          <!--  </div>
                        </div> -->
                     </div>
                     <div class="file-upload-in">
                        <div class="upload-button">Add Photos</div>
                        <input class="file-upload" type="file" name="uploadfile[]" accept="image/*" multiple/  required hidden>
                        <div id="dvPreview"></div>
                     </div>
                                         
               </div>
                  <div class="col-lg-6">
                     <div id="datepicker2" class="input-group date" data-date-format="mm-dd-yyyy">
                     <label for = "dates">Please block the dates that are unavailable</label>
                       <input class="form-control" type="text"  readonly name = "dates" id="datesdata" required placeholder="Select the dates">
                       <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                     </div>
                     <label for="pricingpernight" style="margin-top: 6px;">Pricing per night($)</label>
                     <input type="text" name="pricingpernight" id="pricingpernight" class="form-input" placeholder="Pricing per night" required="" value="{{@$pricing_per_night}}">
                  </div>

               </div>
               <div class="row">
                  <div class="col-lg-6">
                     <!-- <div class="pet-allow"><input type="checkbox" name="" id="pet-allow"><label for="pet-allow">Pet Allowance</label></div>
                     <div class="host-fac"><input type="checkbox" name="" id="host-facility"><label for="host-facility">Host Facility</label> </div> -->
                     <div class="clockpicker">
                        <label>Pick-up Time  </label>
                         <input type="text" class="timepicker-in form-control" name="timepicker_in" data-id="{{@$checkin_time}}">
                     </div>
                      <div class="input-group clockpicker">
                        <label>Drop-off Time  </label>
                         <input type="text" class="timepicker-out form-control" name="timepicker_out" data-id="{{@$checkout_time}}">
                     </div>
                  </div>
               </div>
               <div class="form-action-button">
               <button type="cancel" class="btnn btn-cancel" value="Cancel">Cancel</button>
               <button type="submit" class="btnn btn-next" value="next">@if(@$providercompletion_status!=4) Next @else Submit @endif</button>
            </div>
               </form>
         </div>
      </div>
      </section> 
      <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
      <script src="{{url('/web/js/wow.js')}}"></script>  
      <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
      <link rel="stylesheet" href="{{url('web/css/wickedpicker.css')}}">
      <link rel="stylesheet" href="{{url('web/css/wickedpicker.min.css')}}">
      <script src="{{url('web/js/wickedpicker.min.js')}}"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js"></script>
     
      <script>
         var token = "{{ csrf_token() }}";
         var att = (<?php echo json_encode($attachments)?>);
         var datesForDisable = $("#unavldates").val();
    var arr = datesForDisable.split(',');
    var unavailableDates = arr;
    var base_url = "<?php echo url('/'); ?>";
    $("#datepicker2").datepicker({ 
      format: 'yyyy-mm-dd', 
      multidate: true,
     
      beforeShowDay: function (currentDate) { var dayNr = currentDate.getDay(); var dateNr = moment(currentDate.getDate()).format("YYYY-MM-DD");
      
          if (unavailableDates.length > 0) { 
            for (var i = 0; i < unavailableDates.length; i++) { 
              if (moment(currentDate).unix()==moment(unavailableDates[i],'YYYY-MM-DD').unix()){ 
                return false; 
              } 
            } 
          } 
          return true; 
        } 

  });

 $('.timepicker-in').wickedpicker().val(($(".timepicker-in").attr('data-id'))); 
 $('.timepicker-out').wickedpicker().val(($(".timepicker-out").attr('data-id')));

        
        
    $(document).ready(function () {

    $input = $("#datepicker2");

    $input.datepicker({
      multidate: true,
      inline: true,
      format: 'yyyy-mm-dd'
    }); 
    var status = $(".placesitem").html(); 
    if(status.length!=0)  
    $input.datepicker('show');
    $('.timepicker-in').wickedpicker(); 
    $('.timepicker-out').wickedpicker(); 

  });
   $(".file-upload").change(function () {

        if (typeof (FileReader) != "undefined") {
            var dvPreview = $("#dvPreview");
            var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.jpg|.jpeg|.gif|.png|.bmp)$/;
            $($(this)[0].files).each(function () {
                var file = $(this);
                                
                  var reader = new FileReader();
                  reader.onload = function (e) {
                      var id = $("#picsid").val();
                      var img = $("<img id="+id+" class=delpics-"+id+"><span data-id="+id+"  class=delpics id=delpics-"+id+">X</span>");
                      //img.attr("style", "height:100px;width: 100px");
                      img.attr("src", e.target.result);
                      var imgouter=$("<div data-id="+id+" class='delpics imgecontainer'></div>");
                      imgouter.html(img);
                      dvPreview.append(imgouter);
                      var i = parseInt(id)+1;
                      $("#picsid").val(i);
                    }
                    reader.readAsDataURL(file[0]);
               
            });
        } else {
            alert("This browser does not support HTML5 FileReader.");
        }
    });

    for(j=0;j<att.length;j++){
            var id = $("#picsid").val();
            var imgsrc= att[j]['url'];
            var attid = att[j]['id'];
            var imgouter = $("#dvPreview").append("<div data-imgid="+attid + " data-id="+id+" class='delpics imgecontainer'><img src="+imgsrc+" id="+id+" class=delpics-"+id+"><span data-id="+id+"class=delpics id=delpics-"+id+">X</span></div>");
            $("#dvPreview").append(imgouter);
            var i = parseInt(id)+1;
            $("#picsid").val(i);
          }

    $(document).on('click','.delpics',function(){
      var id = ($(this).attr('data-id'));
       var imgid = $(this).attr('data-imgid');
      $(".delpics-"+id).remove();
      $(this).remove();
       $.ajax({
          url: "{{url('/deleteattachment')}}",
          type: 'POST',
          data: {
            attachid:imgid,
            _token: token
          },
          success: function (response) {
            
          }
      });
    })

      </script>

  <script>

  $(".btn-next").on('click',function(event){

    event.preventDefault();
    var dates= ($("#datesdata").val());
    var condition = $("#condition").val();
   
    var pricingpernight = $("#pricingpernight").val();
  
     if(condition=="-1"){
        swal({
          title: "Error!!",
          text: "Please Select condition of thing",
          icon: "warning",
          buttons: true,
          dangerMode: true,
        })
      }
      else if($("#dvPreview").html()=="")
    {
      swal({
        title: "Error!!",
        text: "Please add photos",
        icon: "warning",
        buttons: true,
        dangerMode: true,
      })
    }
     
   
  /*  else if(dates.length==0 && $("#datesbooked").val()=="")
    {
     swal({
          title: "Error!!",
          text: "Please select the dates",
          icon: "warning",
          buttons: true,
          dangerMode: true,
        })
    }*/
     else if(pricingpernight==""){
        swal({
          title: "Error!!",
          text: "Please enter value for pricing/night",
          icon: "warning",
          buttons: true,
          dangerMode: true,
        })
      }
     
   else{
      $("#place-form-main").submit();
   }
  })
  $(".btn-cancel").on('click',function(event){
    event.preventDefault();
    location.reload();
  })
  $(".upload-button").click(function(){
    $(".file-upload").click();
  });
</script>
@endsection