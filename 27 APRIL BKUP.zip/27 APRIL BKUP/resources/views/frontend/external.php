  
               <div class="item">
                  <a class="hover-thumb" href="#">
                     <div class="thumb">
                        <img src="https://timernr.com/web/images/t1.png" alt="icon"/>
                        <h5>Home</h5>
                     </div>
                  </a>
               </div>
               <div class="item">
                  <a class="hover-thumb" href="#">
                     <div class="thumb">
                        <img src="https://timernr.com/web/images/t2.png" alt="icon"/>
                        <h5>Kitchen</h5>
                     </div>
                  </a>
               </div>
               <div class="item">
                  <a class="hover-thumb" href="#">
                     <div class="thumb">
                        <img src="https://timernr.com/web/images/t3.png" alt="icon"/>
                        <h5>Bathroom</h5>
                     </div>
                  </a>
               </div>
               <div class="item">
                  <a class="hover-thumb" href="#">
                     <div class="thumb">
                        <img src="https://timernr.com/web/images/t4.png" alt="icon"/>
                        <h5>Hall</h5>
                     </div>
                  </a>
               </div>
               <div class="item">
                  <a class="hover-thumb" href="#">
                     <div class="thumb">
                        <img src="https://timernr.com/web/images/t3.png" alt="icon"/>
                        <h5>Bathroom</h5>
                     </div>
                  </a>
               </div>
               <div class="item">
                  <a class="hover-thumb" href="#">
                     <div class="thumb">
                        <img src="https://timernr.com/web/images/t4.png" alt="icon"/>
                        <h5>Hall</h5>
                     </div>
                  </a>
               </div>
               