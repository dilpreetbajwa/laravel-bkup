@extends('layouts.frontend.master')
@section('content')
<style>
.search-bar
{
  display:none;
}
</style>
      
      <!-- About place -->
      <section class="Popular-task_1 comman-padding booking-c-main">
         <div class="container task-contain">
            <div class="places-form wallet-form">
             <h2 class="border-bottom-content title-transact" style="margin-bottom: 20px">My Wallet</h2>
              <div class="wallet-content"> 
                  <img src="{{url('web/images/wallet.svg')}}">
                  <h3>Wallet Balance <span class="w-balnce">${{@$user_vault_total}}</span></h3>
               </div>
               <div class="wallet-btns">
                  <a href="{{url('/addbankdetails')}}" class="withh-btn">Withdraw</a>
                  <a href="{{url('/transaction-history')}}" class="hist-btn">History</a>
               </div>
            </div>
          </div>
      </section>  
       <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script> 
      <script src="{{url('web/js/wow.js')}}"></script>

      @endsection
   