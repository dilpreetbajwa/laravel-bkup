
<style>
.datepicker-days table .disabled-date.day {
  background-color: #663399;
  color: #fff;
}

.datepicker table tr td.disabled, 
.datepicker table tr td.disabled:hover {
  background: #8447c2;
  color: #fff;
}
</style>
<input/>
      <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
      <script src="{{url('/web/js/wow.js')}}"></script>  

     
     
      <link rel="stylesheet" href="{{url('web/css/wickedpicker.css')}}">
      <link rel="stylesheet" href="{{url('web/css/wickedpicker.min.css')}}">
      
      
      <script src="{{url('web/js/wickedpicker.min.js')}}"></script>
     
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js"></script>
<script>


var datesForDisable = ["2020-02-12","2020-02-15"];
$("input").datepicker({ 
  format: 'dd/mm/yyyy', 
  autoclose: true,
  multidate: true,
   
   
   todayHighlight: true, 
   //datesDisabled: datesForDisable, daysOfWeekDisabled: [0, 6], 

  beforeShowDay: function (currentDate) { var dayNr = currentDate.getDay(); var dateNr = moment(currentDate.getDate()).format("YYYY-MM-DD");
  
      if (datesForDisable.length > 0) { 
        for (var i = 0; i < datesForDisable.length; i++) { 
          if (moment(currentDate).unix()==moment(datesForDisable[i],'YYYY-MM-DD').unix()){ 
            return false; 
          } 
        } 
      } 
      return true; 
    } 
  });

</script>