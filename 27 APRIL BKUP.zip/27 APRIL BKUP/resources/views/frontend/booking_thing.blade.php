@extends('layouts.frontend.master')
@section('content')
<style>

#map_location
{
  position: relative;!important;
  width:100%!important;
  height:75%!important;
  min-width: 515px;
}
.switch {
  position: relative;
  display: inline-block;
  width: 60px;
  height: 34px;
}

/* Hide default HTML checkbox */
.switch input {
  opacity: 0;
  width: 0;
  height: 0;
}

/* The slider */
.slider {
  position: absolute;
  cursor: pointer;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background-color: #ccc;
  -webkit-transition: .4s;
  transition: .4s;
}

.slider:before {
  position: absolute;
  content: "";
  height: 26px;
  width: 26px;
  left: 4px;
  bottom: 4px;
  background-color: white;
  -webkit-transition: .4s;
  transition: .4s;
}

input:checked + .slider {
  background-color: #2196F3;
}

input:focus + .slider {
  box-shadow: 0 0 1px #2196F3;
}

input:checked + .slider:before {
  -webkit-transform: translateX(26px);
  -ms-transform: translateX(26px);
  transform: translateX(26px);
}

/* Rounded sliders */
.slider.round {
  border-radius: 34px;
}

.slider.round:before {
  border-radius: 50%;
}
</style>
      <!-- Category -->
  <form method="post"  id="placelocation1" method="post" action="{{url('/getthingslistings')}}">
   <section class="Category">
      <div class="container">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12">
             <h2 class="border-bottom-content title-transact" style="margin-bottom: 10px;margin-top: 10px;">Things listing</h2>
         <div class="bg-color">
            <div class="col-lg-6 col-md-6">
               <div class="all_category">             
                  <input type="hidden" name="placeval" id="placeval" value="home">
                  <input type="hidden" name="catid" id="catid" value="{{@$id}}">
                  <input type="hidden" name="homepagecat" id="homepagecat" value="{{@$thing_id}}">
                  <?php $i =1;?>
                  @if(count(@$result['categories'])>0)
                  @foreach(@$result['categories'] as $key=>$value)
                  <button type="button" class="category_btn" data-id="{{$value['id']}}">{{ucfirst($value['name'])}}</button>
                  <?php if($i==count(@$result['categories'])){ ?>
                  <button type="button" class="category_btn" data-id="All">All</button>
                  <?php  } ?>
                  <?php $i++;?>
                  @endforeach
                  @else 
                  <button type="button" class="category_btn">No categories</button>                   
                  @endif 
               </div>
            </div>
            <div class="col-lg-6 col-md-6">
               <div class="price_class">
                  <select name="filter" id="filter">
                  <option value="0" @if($filter==0)selected @endif>Sort By</option>
                  <option value="1" @if($filter==1) selected @endif>Highest price</option>
                  <option value="2" @if($filter==2) selected @endif>Lowest price</option>
                  <option value="3" @if($filter==3) selected @endif>Highest rating</option>
                  <option value="4" @if($filter==4) selected @endif>Lowest rating</option>
                  </select>
                  <div class="filter_btn filterbtn_price">
                     <!--  <button type="" class="filter"><i class="fa fa-filter"></i></button> -->
                     <span class="showbtn">Show Map</span>
                     <label class="switch">
                     <input type="checkbox" checked>
                     <span class="slider round"></span>
                     </label>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </section>
   <!-- Listing Section -->
   <input type="hidden"  name="catval" id="catval1" value="All">
   <section class="list_map">
      <div class="container category_bg">
        <div class="row place_coupnmargin">
         <div class="col-lg-6 col-md-6 col-sm-6 filterresult">
            @if(count(@$result['data'])>0)
            @foreach(@$result['data'] as $key=>$value)
            <div class="container lis_bg">
               <a href="{{url('/booking-thingavailability'.'/'.$value['encodedid'])}}">
                  <div class="row under_bg">
                     <div class="col-lg-4">
                        @if(count($value['attachments'])>0)
                        <img src="{{$value['attachments'][0]}}" class="m1">
                        @else
                        <img src="{{url('/attachments'.'/'.'noimage.jpeg')}}" class="m1">
                        @endif
                     </div>
                     <div class="col-lg-8">
                        <div class="main_box">
                           <h5 class="heading_main">{{$value['name']}}</h5>
                           <p class="contant_main">{{$value['owned_by']}}</p>
                           <p class="contant_main"><?php 
                              if(str_word_count($value['description'])>10)
                              {
                                echo implode(' ', array_slice(explode(' ', $value['description']), 0, 10)).'  ......';
                              }
                              else
                              {                                 
                                echo $value['description'];
                              } ?></p>
                        </div>
                        <div class="row">
                           <div class="col-lg-6">
                              <p class="price">$ {{$value['price_per_night']}} / night</p>
                           </div>
                           <div class="col-lg-6">
                              <!--  <a href="{{url('/booking-thingavailability'.'/'.$value['id'])}}"><button type="button" class="category_btn_1">Book</button></a> -->
                           </div>
                        </div>
                     </div>
                  </div>
                  </a>
            </div>
            
            @endforeach
            <div class="pagination custom-pagination">
            </div>
            @else
            <input type="hidden" id="notfound" value=1>
            <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
            @endif
            {{$provider->links()}}
         </div>
         <input type="hidden" name="_token" id="csrf-token" value="{{ Session::token() }}" />
         <input type="hidden" class="form-control" id="lat"  name="latitude">
         <input type="hidden" class="form-control" id="lng"  name="longitude">
         <div class="col-lg-6 col-md-6 col-sm-6">
                  <div class="location  <?php  if(count($result['data'])==0) 
                  echo 'nodata'; ?>" id="map_location">
            </div>
         </div>
      </div>
       <div class="owl-carousel owl-theme coupn-codes wow bounceInLeft place_coupncarousal">
            @foreach($result['coupons']  as $coupon)
               <div class="item" style=" background-color: white;background-size: cover;background-position: 100%;background-repeat: no-repeat;background-image:url({{$coupon['background_image']}})">
                  <a class="hover-thumb" href="#">
                     <div class="thumb">
                         <p class="coupon_discount">{{$coupon['discount']}}%  OFF  </p ><p class="coupon_code">Apply coupon code {{$coupon['coupon_code']}} on  amount
                         @if($coupon['rules']=="greater than equal to")
                          above or equal 
                         @elseif($coupon['rules']=="less than equal to")
                           less or equal 
                         @elseif($coupon['rules']=="greater than")
                           above 
                         @elseif($coupon['rules']=="less than")
                           less 
                         @endif                         
                       ${{$coupon['amount']}} </p>
                        <p class="coupon_validity">Valid till {{$coupon['valid_till']}}</p>
                     </div>
                  </a>
               </div>
               @endforeach  
               </div>             
           </div>
   </section>
   
</form>
      <!-- Footer Start -->
     
      <!-- Bootstrap JS -->
       <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
      
      <script src="{{url('web/js/bootstrap.min.js')}}"></script>
      <script src="{{url('web/js/slick.js')}}"></script>
    <script>
         jQuery(document).ready(function($) {

           var data = $("#homepagecat").val();
          if(data !=""){
            $("#catval1").val(data);
            $(".category_btn").css('background',"#f4f4f4");
            $(".category_btn").css('color',"#333333");
            $(this).css('background',"#0478bc");
            $(this).css('color',"#fff");
            $(this).css('border',"#1px solid #0478bc");
           // $(this).css('background',"#0478bc");
          }
          
          var catname = $("#catid").val();
          
           var token = "{{ csrf_token() }}";
          var base_url = "<?php echo url('/'); ?>";
          var catname = $("#catval1").val();
          $(".category_btn").each(function () {
            var id = $(this).attr('data-id');
            if(catname==id){
              $(".category_btn").css('color',"#333333");
              $(this).css('background',"#0478bc");
              $(this).css('color',"#fff");
              $(this).css('border',"#1px solid #0478bc");
              return false;
            }
          });

           
            $('.slick.marquee').slick({
              speed: 23000,
              autoplay: true,
              autoplaySpeed: 0,
              centerMode: true,
              cssEase: 'linear',
              slidesToShow: 1,
              slidesToScroll: 1,
              variableWidth: true,
              infinite: true,
              initialSlide: 1,
              arrows: false,
              focusOnSelect: true,
              pauseOnHover:true,
              buttons: false
            });
          });
      </script>
      <script type="text/javascript">
         $(document).ready(function(){
           $('.mymultiplediv').mouseover(function() {
           myvar = this.id;
             $("div.mydiv").hide();
             $('#div'+myvar).show();
           });
           $("#two").hover(function(){
             $(".firstt").hide();
           });
           });
      </script>
      <script src="{{url('web/js/owl.carousel.js')}}"></script>
      <script>
         $(document).ready(function(){
          var owl = $('.owl-carousel');
           owl.owlCarousel({       
             loop:true,
             margin:10,
             rtl: false,
             autoplay:true,
             autoplayTimeout:4000,
             autoplayHoverPause:true,
             responsiveClass:true,
             responsive:{
               300:{
                 items:1,
                 nav:true
               },
               767:{
                 items:2,
                 nav:true
               },
               1000:{
                 items:5,
                 nav:true,
                 loop:false
               }
             }
           });
         });
      </script>
      <script src="{{url('web/js/wow.js')}}"></script>
      <script>
         new WOW().init();
      </script>
      <script>
      $(document).on('click','.category_btn',function(){
              var base_url = "<?php echo url('/'); ?>";
              var token = "{{ csrf_token() }}";
              var id = $(this).attr('data-id');  
              var filter = $("#filter").val();
              var latitude = $("#lat").val();
              var longitude = $("#lng").val();
              $("#catval1").val(id);
              $(".category_btn").css('background',"#f4f4f4");
              $(".category_btn").css('color',"#333333");
              $(this).css('background',"#0478bc");
              $(this).css('color',"#fff");
              $(this).css('border',"#1px solid #0478bc");
              $.ajax({
                type: "POST",
                url: base_url+'/getthingslistings',
                data: {
                  "_token": token,
                  'catval': id,
                  'filter':filter,
                  'longitude':longitude,
                  'latitude':latitude,
                },
                success: function(data) {
                 
                    $(".filterresult").html(data.html);
                    $("#map_location").show();
                    if($("#notfound").val()==1)
                    {
                      $(".category_bg").addClass("noresult");
                      $(".location").css('display','none');
                    }
                    else
                    {
                      $(".category_bg").removeClass("noresult");
                      $(".location").css('display','block');
                    }
                    
                    }
                  });
                })

       $(document).on('change','#filter',function(){
              var base_url = "<?php echo url('/'); ?>";
              var token = "{{ csrf_token() }}";
              var id = $("#catval1").val();  

              var filter = $("#filter").val();
              var latitude = $("#lat").val();
              var longitude = $("#lng").val();
              var catname = $("#catval1").val();
              $(".category_btn").each(function () {
              var id = $(this).attr('data-id');
              if(catname==id){
                $(this).css('background',"#0478bc");
                $(".category_btn").css('color',"#333333");
                $(this).css('background',"#0478bc");
                $(this).css('color',"#fff");
                $(this).css('border',"#1px solid #0478bc");
                return false;
              }
            });
              $.ajax({
                type: "POST",
                url: base_url+'/getthingslistings',
                data: {
                  "_token": token,
                  'catval': id,
                  'filter':filter,
                  'longitude':longitude,
                  'latitude':latitude,
                },
                success: function(data) {
                 
                    $(".filterresult").html(data.html);
                    $("#map_location").show();
                    if($("#notfound").val()==1)
                    {
                      $(".category_bg").addClass("noresult");
                    }
                    else
                    {
                      $(".category_bg").removeClass("noresult");
                    }
                    
                    }
                  });
                })
                
            
      </script>
      <script>

  var ids = <?php echo json_encode ($placeids); ?>;
  function initialise() {
    var map;
    var bounds = new google.maps.LatLngBounds();
    var mapOptions = {
        mapTypeId: 'roadmap'
    };
                    
    // Display a map on the page
    map = new google.maps.Map(document.getElementById("map_location"), mapOptions);
    map.setTilt(45);
     var infoWindow = new google.maps.InfoWindow(), marker, i;
        var icon = {
        url: "{{url('/web/images/ic_marker_red.png')}}", // url
        scaledSize: new google.maps.Size(60, 60), // scaled size
       origin: new google.maps.Point(0,0), // origin
       
        anchor: new google.maps.Point(25, 32)
    };
        
     var markers = <?php echo json_encode($location); ?>;
     var ids = <?php echo json_encode ($placeids); ?>;
     console.log(markers);
   
    // Display multiple markers on a map
    var infoWindow = new google.maps.InfoWindow(), marker, i;
    
    // Loop through our array of markers & place each one on the map  
    for( i = 0; i < markers.length; i++ ) {
        var position = new google.maps.LatLng(markers[i][1], markers[i][2]);
        bounds.extend(position);
        marker = new google.maps.Marker({
            position: position,
            map: map,
            icon: icon,
            title: markers[i][0],
            id1:ids[i]
        });
         marker.addListener('click', function() {

          var baseurl = "{{url('/booking-thingavailability/')}}";
          var url = baseurl+'/';
          window.location.href= url+this.id1;
        });
        
        // Allow each marker to have an info window    
        google.maps.event.addListener(marker, 'click', (function(marker, i) {
            return function() {
                infoWindow.setContent(infoWindowContent[i][0]);
                infoWindow.open(map, marker);
            }
        })(marker, i));

        // Automatically center the map fitting all markers on the screen
        map.fitBounds(bounds);
    }

    // Override our map zoom level once our fitBounds function runs (Make sure it only runs once)
    var boundsListener = google.maps.event.addListener((map), 'bounds_changed', function(event) {
        this.setZoom(3);
        google.maps.event.removeListener(boundsListener);
    });
    
}
</script>

<script type="text/javascript" src="https://maps.google.com/maps/api/js?libraries=places&language=en-AU&key=AIzaSyC29SOMdVFnuCgpVR9VFbeARVJqDJ7tJ-w&callback=initialise">
</script>

<script>

          var autocomplete = new google.maps.places.Autocomplete($("#address")[0], {});
                $("#address").on('keyup',function(){

                var place = $("#address").val();
                  if(place=="")
                  {
                    $("#lat").val("");
                    $("#lng").val("");
                  }
                var base_url = "<?php echo url('/'); ?>";
                var token = "{{ csrf_token() }}";
                var id = $("#catval1").val();  
                var filter = $("#filter").val();
                var latitude = $("#lat").val();
                var longitude = $("#lng").val();
                var catname = $("#catval1").val();
                $(".category_btn").each(function () {
                var id = $(this).attr('data-id');
                if(catname==id){
                  $(this).css('background',"#0478bc");
                  $(".category_btn").css('color',"#333333");
                  $(this).css('background',"#0478bc");
                  $(this).css('color',"#fff");
                  $(this).css('border',"#1px solid #0478bc");
                  return false;
                }
              });
                $.ajax({
                  type: "POST",
                  url: base_url+'/getthingslistings',
                  data: {
                    "_token": token,
                    'catval': id,
                    'filter':filter,
                    'longitude':longitude,
                    'latitude':latitude,
                  },
                  success: function(data) {
                   
                      $(".filterresult").html(data.html);
                      $("#map_location").show();
                      
                      }
                    });
                  });
                
            var autocomplete = new google.maps.places.Autocomplete($("#address")[0], {});

            google.maps.event.addListener(autocomplete, 'place_changed', function() {
                var place = autocomplete.getPlace();
                console.log(place.address_components);
                var latitude = place.geometry.location.lat();
                var longitude = place.geometry.location.lng(); 
                $("#lat").val(latitude);
                $("#lng").val(longitude);

              var base_url = "<?php echo url('/'); ?>";
              var token = "{{ csrf_token() }}";
              var id = $("#catval1").val();  
              var filter = $("#filter").val();
              var latitude = $("#lat").val();
              var longitude = $("#lng").val();
              var catname = $("#catval1").val();
              $(".category_btn").each(function () {
              var id = $(this).attr('data-id');
              if(catname==id){
                $(this).css('background',"#0478bc");
                $(".category_btn").css('color',"#333333");
                $(this).css('background',"#0478bc");
                $(this).css('color',"#fff");
                $(this).css('border',"#1px solid #0478bc");
                return false;
              }
            });
              $.ajax({
                type: "POST",
                url: base_url+'/getthingslistings',
                data: {
                  "_token": token,
                  'catval': id,
                  'filter':filter,
                  'longitude':longitude,
                  'latitude':latitude,
                },
                success: function(data) {                 
                  $(".filterresult").html(data.html);
                  $("#map_location").show();
                  if($("#notfound").val()==1)
                  {
                    $(".category_bg").addClass("noresult");
                  }
                  else
                  {
                    $(".category_bg").removeClass("noresult");
                  }
                
                }
              });
            });
        </script>
      
        <script>
        $(".fa-search").on('click',function(e){
          e.preventDefault();
          $("#placelocation1").submit();

        })
         $(".fa-filter").on('click',function(e){
          e.preventDefault();
          $("#placelocation1").submit();

        })
        $('input[type="checkbox"]').on('click', function(){
          if ($(this). prop("checked") == false) {
            $('.category_bg').addClass('filter_data');
               
              } else { 
                $('.category_bg').removeClass('filter_data');
            }   
          });

        </script>

 
@endsection