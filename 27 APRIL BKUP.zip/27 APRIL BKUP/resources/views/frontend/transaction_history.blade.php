@extends('layouts.frontend.master')
@section('content')
<style>
.search-bar
{
  display: none;
}
</style>
      <!-- About place -->
      <section class="Popular-task_1 comman-padding traans-histrory">
      <input type="hidden" name="typedata" id="typedata" value="0">
         <div class="container task-contain">
            <div class="places-form">
               <div class="Tabs history">
                   <form action="{{url('/transaction-history')}}" method="post" id="historyform">
                   <input type="hidden" name="_token" id="csrf-token" value="{{ Session::token() }}" />
                  <div class="all-reviews-c">
                    <h2 class="title-transact">Transactions Histroy </h2>
                    <div class="imgee-title">
                      <img src="https://timernr.com/web/images/history.gif" alt="icon">
                    </div>
                     <div class="inner-c-review">
                        <div class="left-c">
                              <p>$ {{@$overall_earnings}}</p>
                              <p>Overall Earning</p>
                        </div>
                        <select name="filterprovider-history" id="filterprovider-history">
                        <option value="0" {{(@$filter==0?'selected':'')}}>All</option>
                        <option value="1" {{(@$filter==1?'selected':'')}}>Recevied</option>
                        <option value="2" {{(@$filter==2?'selected':'')}}>In progress</option>
                        <option value="3" {{(@$filter==3?'selected':'')}}>Withdrawn</option>
                     </select>
                     </div>
                     <div class="transaction-history">
                        <div class="date-transaction">
                              <div class="date-title">
                              </div>
                              <div class="list-transaction">
                                <ul class="title-ul">
                                  <li>
                                       <span class="tran-name"><span class="t-name">Title</span> <span class="t-cate">Category</span></span>
                                       <span class="amount-tran">Price</span>
                                    </li>
                                </ul>
                                <div class="results-wrapper"> 
                                @if($type==0) 
                                  @if(count($data)>0)
                                     @foreach($data as $value)
                                     <ul class="trans-detail">
                                        <li>
                                           <span class="tran-name"><span class="t-name">{{$value['provider_title']}}</span> <span class="t-cate">{{$value['category']}}</span><span class="t-time">{{$value['date']}}</span></span>
                                           <span class="amount-tran">${{$value['amount']}}</span>
                                        </li>
                                     </ul>
                                  @endforeach
                                
                             @else
                              <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">

                            @endif
                            @elseif($type==1) 
                                  @if(count($data_rcd)>0)
                                     @foreach($data_rcd as $value)
                                     <ul class="trans-detail">
                                        <li>
                                           <span class="tran-name"><span class="t-name">{{$value['provider_title']}}</span> <span class="t-cate">{{$value['category']}}</span><span class="t-time">{{$value['date']}}</span></span>
                                           <span class="amount-tran">${{$value['amount']}}</span>
                                        </li>
                                     </ul>
                                  @endforeach
                                
                             @else
                              <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
                            @endif
                             @elseif($type==2) 

                                  @if(count($data_progress)>0)
                                     @foreach($data_progress as $value)
                                     <ul class="trans-detail">
                                        <li>
                                           <span class="tran-name"><span class="t-name">{{$value['provider_title']}}</span> <span class="t-cate">{{$value['category']}}</span><span class="t-time">{{$value['date']}}</span></span>
                                           <span class="amount-tran">${{$value['amount']}}</span>
                                        </li>
                                     </ul>
                                  @endforeach
                                
                             @else
                              <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
                            @endif
                             @elseif($type==3) 
                                  @if(count($data_withdraw)>0)
                                     @foreach($data_withdraw as $value)
                                     <ul class="trans-detail">
                                        <li>
                                           <span class="tran-name"><span class="t-name">{{$value['provider_title']}}</span> <span class="t-cate">{{$value['category']}}</span><span class="t-time">{{$value['date']}}</span></span>
                                           <span class="amount-tran">${{$value['amount']}}</span>
                                        </li>
                                     </ul>
                                  @endforeach
                                
                             @else
                              <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
                            @endif
                            @endif
                                
                        </div>
                         </div>
                        </div>
                     </div>
                     @if($type==1) 
                    
                     {{$transactionsrcd->links()}}  
                      @elseif($type==2) 
                     
                     {{$transactionsprogress->links()}} 
                      @elseif($type==3) 
                     
                     {{$transactionswithdraw->links()}} 
                    
                     @else
                    
                     {{$transactions->links()}}  
                     @endif                  
                  </div>
                  </form>
                  </div>
               </div>
          </div>
      </section>  
       <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script> 
      <script src="{{url('web/js/wow.js')}}"></script>

      <script>
      $("#filterprovider-history").on('change',function(e) {
        e.preventDefault();
        $("#typedata").val($("#filterprovider-history").val());
         $("#historyform").submit();         
      });

     

      $('.pagination li a,.nav-item a,.pagination li.page-item:nth-child(2)').on('click', function(e){       
          e.preventDefault();
         
          $(".pagination li").removeClass("active");
          if ($(this).is(':nth-child(2)'))
            $(this).addClass("active");
          else
          $(this).parent().addClass("active");
          var type = $("#typedata").val();
          var url = $(this).attr('href');
         
           $.ajax({
           type:'POST',
           url:url,
            data: {"_token": "{{ csrf_token() }}","type":type},
           success:function(data){
              $(".results-wrapper").html(data);
           }
        });
      });

      $('.pagination li.page-item:nth-last-child(2)').on('click', function(e){
  
      });

      $('.pagination li.page-item:nth-child(2)').on('mouseover', function(e){
        $(this).css('cursor','pointer');
        $(".pagination li").removeClass("active");
        $(this).addClass("active");                
      });

      </script>
@endsection
    