@extends('layouts.frontend.master')
@section('content')
<style>
.search-bar
{
   display:none;

}
</style>


      <section class="Popular-task_1 comman-padding booking-c-main">
         <input type="hidden" name="typedata" id="typedata" value="#home">
         <div class="container task-contain">
            <div class="places-form">
             <h2 class="border-bottom-content title-transact" style="margin-bottom: 20px">My Listings</h2>
               <div class="Tabs booking-tabs-cntnt">
               <!-- Nav pills -->
        @if(Session::has('success'))
        <div class="alert alert-success"><span class="glyphicon glyphicon-ok"></span><em> {!! session('success') !!}</em></div>
        @endif
                  <ul class="nav nav-pills form_tabs">
                     <li class="nav-item">
                     <a class="nav-link active  tab_menu" data-toggle="pill" href="#home">Places</a>
                     </li>
                     <li class="nav-item">
                     <a class="nav-link tab_menu Cancelled" data-toggle="pill" href="#menu1">Things</a>
                     </li>
                     <li class="nav-item">
                     <a class="nav-link tab_menu Cancelled" data-toggle="pill" href="#menu2">People</a>
                     </li>
                  </ul>
               <!-- Tab panes -->
                  <div class="tab-content">
                     <div class="tab-pane container active" id="home">
                        
                        <div class="request-list">
                          @if(count($places_data)>0)
                           @foreach($places_data as $place)
                           <div class="request-inner">
                              <div class="request-details-cntnt">
                                 <div class="req-img">
                                    @if($place['image']!="")
                                       <img src="{{$place['image']}}" alt="image"/>
                                    @else
                                 	  <img src="{{url('/web/images/service-profile-img.png')}}" alt="image"/>
                                     @endif
                                 </div>
                                 <div class="inner-content-req">
                                 	<h3>{{$place['title']}}</h3>
                                 	<p>Category: {{$place['Category']}}</p>
                                 	<p>{{$place['date']}}</p>
                                 </div>
                                 <div class="stauts-req">
                                 @if($place['percent_status']==75)  
                                 	<img src="{{url('web/images/wall-clock.png')}}" alt="icon"/>
                                 	<p>Upcoming</p>
                                  @else
                                 <div class="stauts-req complete">
                                  <img src="{{url('web/images/check.png')}}" alt="icon"/>
                                  <p>Completed</p>
                                 </div>
                                   @endif
                                    <p> <a href="{{url('/editplaceprovider').'/'.$place['encodedid']}}"><i title="edit" class="fa fa-edit" style="position: relative; margin-left:7px;color:#3c8dbc !important"></i></a></p>
                                 </div>
                              </div>
                               @if($place['percent_status']==75)  
                              <div class="progress-data">
                                 <p>Finish Your Listing</p>
                                 <div class="progress-result" title="99%">
                               <span style="width: {{$place['percent_status']}}%;">
                               </span></div>
                               <p>You're  {{$place['percent_status']}}% of the way there</p>
                              </div>
                           @endif
                        </div>
                         @endforeach
                         @else
                          <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
                         @endif
                        </div>
                       
                     </div>
                     <div class="tab-pane container" id="menu1">
                        <div class="request-list">
                     @if(count($things_data)>0)
                        @foreach($things_data as $things)
                           <div class="request-inner">
                              <div class="request-details-cntnt">
                                 <div class="req-img">
                                    <img src="{{url('/web/images/service-profile-img.png')}}" alt="image"/>
                                 </div>
                                 <div class="inner-content-req">
                                    <h3>{{$things['title']}}</h3>
                                   <p>Category: {{$things['Category']}}</p>
                                    <p>{{$things['date']}}</p>
                                 </div>
                                 <div class="stauts-req">
                                 @if($things['percent_status']==75)  
                                  <img src="{{url('web/images/wall-clock.png')}}" alt="icon"/>
                                  <p>Upcoming</p>
                                  @else
                                 <div class="stauts-req complete">
                                  <img src="{{url('web/images/check.png')}}" alt="icon"/>
                                  <p>Completed</p>
                                 </div>
                                   @endif
                                    <p> <a href="{{url('/editthingprovider').'/'.$things['encodedid']}}"><i title="edit" class="fa fa-edit" style="position: relative; margin-left:7px;color:#3c8dbc !important"></i></a></p>
                                 </div>
                              </div>
                               @if($things['percent_status']==75)  
                              <div class="progress-data">
                                 <p>Finish Your Listing</p>
                                 <div class="progress-result" title="99%">
                               <span style="width: {{$things['percent_status']}}%;">
                               </span></div>
                               <p>You're  {{$things['percent_status']}}% of the way there</p>
                              </div>
                           @endif
                        </div>                          
                        @endforeach
                        @else
                         <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
                        @endif
                        </div>
                       
                     </div>
                     <div class="tab-pane container" id="menu2">
                        <div class="request-list">
                     @if(count($people_data)>0)
                        @foreach($people_data as $people)
                           <div class="request-inner">
                              <div class="request-details-cntnt">
                                 <div class="req-img">
                                    <img src="{{url('/web/images/service-profile-img.png')}}" alt="image"/>
                                 </div>
                                 <div class="inner-content-req">
                                    <h3>{{$people['title']}}</h3>
                                   <p>Category: {{$people['Category']}}</p>
                                    <p>{{$people['date']}}</p>
                                 </div>
                                  <div class="stauts-req">
                                 @if($people['percent_status']==75)  
                                  <img src="{{url('web/images/wall-clock.png')}}" alt="icon"/>
                                  <p>Upcoming</p>
                                  @else
                                 <div class="stauts-req complete">
                                  <img src="{{url('web/images/check.png')}}" alt="icon"/>
                                  <p>Completed</p>
                                 </div>
                                   @endif
                                    <p><a href="{{url('/editpeopleprovider').'/'.$people['encodedid']}}"><i title="edit" class="fa fa-edit" style="position: relative; margin-left:7px;color:#3c8dbc !important"></i></a></p>
                                 </div>
                              </div>
                               @if($people['percent_status']==75)  
                              <div class="progress-data">
                                 <p>Finish Your Listing</p>
                                 <div class="progress-result" title="99%">
                               <span style="width: {{$people['percent_status']}}%;">
                               </span></div>
                               <p>You're  {{$people['percent_status']}}% of the way there</p>
                              </div>
                           @endif
                        </div>                          
                        @endforeach
                      
                        @else
                         <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
                        @endif
                        </div>
                       
                     </div>
                     </div>
                  </div>
               </div>
          </div>
      </section>  

   @endsection
   <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script> 
      
   <script>
   $(document).on('ready',function(e){
     $(".nav-item a").on('click',function(e){
      alert();
      e.preventDefault();
      $("#typedata").val($(this).attr('href'));

    });

   })

  

    $('.pagination li a,.nav-item a,.pagination li.page-item:nth-child(2)').on('click', function(e){       
        e.preventDefault();
        $(".pagination li").removeClass("active");
        if ($(this).is(':nth-child(2)'))
          $(this).addClass("active");
        else
        $(this).parent().addClass("active");
        var type = $("#typedata").val();
        var url = $(this).attr('href');
         $.ajax({
         type:'POST',
         url:url,
          data: {"_token": "{{ csrf_token() }}","type":type},
         success:function(data){

          if(type=="#all")
            $(".one").html(data);
          else if(type=="#home")
            $(".two").html(data);
          else if(type=="#menu1")
            $(".three").html(data);
          else if(type=="#menu2")
            $(".four").html(data);
         }
        });
      });
      </script>