@extends('layouts.frontend.master')
@section('content')
<style>
.search-bar
{
  display: none;
}
</style>
      <section class="Popular-task_1 comman-padding booking-c-main">
         <input type="hidden" name="typedata" id="typedata" value="#all">
         <div class="container task-contain">
            <div class="places-form">
               <div class="Tabs booking-tabs-cntnt service-revices">
                <h2 class="border-bottom-content title-transact" style="margin-bottom: 20px">Reviews</h2>
               <!-- Nav pills -->
                  <ul class="nav nav-pills form_tabs">
                      <li class="nav-item">
                     <a class="nav-link active  tab_menu" data-toggle="pill" href="#all">All</a>
                     </li>
                     <li class="nav-item">
                     <a class="nav-link tab_menu" data-toggle="pill" href="#home">Places</a>
                     </li>
                     <li class="nav-item">
                     <a class="nav-link tab_menu Cancelled" data-toggle="pill" href="#menu1">Things</a>
                     </li>
                     <li class="nav-item"> 
                     <a class="nav-link tab_menu completed" data-toggle="pill" href="#menu2">People</a>
                     </li>
                  </ul>
                  <div class="all-reviews-c">
                        <div class="inner-c-review">
                           <div class="left-c">
                                 <p>{{@$aveage_rating}} <span>★</span></p>
                                 <p>Overall Rating</p>
                           </div>
                           <div class="right-c">
                                 <p>{{@$reviews}}</p>
                                 <p>Reviews</p>
                           </div>
                     </div>
                  </div>
               <!-- Tab panes -->
                  <div class="tab-content">
                      <div class="tab-pane container active" id="all">
                        <ul class="reviews-list one">

                        @if(count($review)>0)
                        @foreach($review as $place)
                          <li>
                             <div class="review-icon"><img src="{{$place['image']}}" alt="icon" width="100" height=100></div>
                             <div class="review-content">
                                <h3>{{$place['user']}}</h3>
                                <span class="m-re">{{$place['ratings']}}.0<span> ★</span></span>
                                <p class="review-date">{{$place['datemonth']}} {{$place['dateyear']}}</p>
                                <p>{{$place['reviews']}} </p>
                             </div>
                          </li>
                       @endforeach
                        @else
                              <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
                        @endif 
                     </ul>
                     {{$reviewsall->links()}}
                        
                     </div>
                     <div class="tab-pane container" id="home">
                        <ul class="reviews-list two">
                        @if(count($review_place)>0)
                          @foreach($review_place as $place)
                          <li>
                             <div class="review-icon"><img src="{{$place['image']}}" alt="icon" width="100" height=100></div>
                             <div class="review-content">
                                <h3>{{$place['user']}}</h3>
                                <span class="m-re">{{$place['ratings']}}.0<span> ★</span></span>
                                <p class="review-date">{{$place['datemonth']}} {{$place['dateyear']}}</p>
                                <p>{{$place['reviews']}} </p>
                             </div>
                          </li>
                          @endforeach
                         @else
                          <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
                        @endif

                     </ul>
                        {{$reviews3->links()}}
                     </div>
                     <div class="tab-pane container fade" id="menu1">
                        <ul class="reviews-list three">
                         @if(count($review_things)>0)
                         @foreach($review_things as $things)
                        <li>
                           <div class="review-icon"><img src="{{$things['image']}}" alt="icon" width="100" height=100></div>
                           <div class="review-content">
                              <h3>{{$things['user']}}</h3>
                              <span class="m-re">{{$things['ratings']}}.0<span> ★</span></span>
                              <p class="review-date">{{$things['datemonth']}} {{$things['dateyear']}}</p>
                              <p>{{$things['reviews']}}</p>
                           </div>
                        </li>
                        @endforeach 
                         @else
                          <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
                        @endif 
                     </ul>
                        {{$reviews2->links()}}                     
                     </div>
                     <div class="tab-pane container fade" id="menu2">
                        <ul class="reviews-list four">
                        @if(count($review_people)>0)
                         @foreach($review_people as $people)
                        <li>
                           <div class="review-icon"><img src="{{$people['image']}}" alt="icon" width="100" height=100></div>
                           <div class="review-content">
                              <h3>{{$people['user']}}</h3>
                              <span class="m-re">{{$people['ratings']}}.0<span> ★</span></span>
                              <p class="review-date">{{$people['datemonth']}} {{$people['dateyear']}}</p>
                              <p>{{$people['reviews']}}</p>
                           </div>
                        </li>
                         @endforeach    
                          @else
                          <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
                        @endif 
                     </ul>
                         {{$reviews1->links()}}                        
                     </div>
                     </div>
                  </div>
               </div>
          </div>
      </section>  

     <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script> 
      <script src="{{url('web/js/wow.js')}}"></script>
      <script>
       $(".nav-item a").on('click',function(e){
          e.preventDefault();
          $("#typedata").val($(this).attr('href'));

        });

      $('.pagination li a,.nav-item a,.pagination li.page-item:nth-child(2)').on('click', function(e){       
        e.preventDefault();
        $(".pagination li").removeClass("active");
        if ($(this).is(':nth-child(2)'))
          $(this).addClass("active");
        else
        $(this).parent().addClass("active");
        var type = $("#typedata").val();
        var url = $(this).attr('href');
         $.ajax({
         type:'POST',
         url:url,
          data: {"_token": "{{ csrf_token() }}","type":type},
         success:function(data){

          if(type=="#all")
            $(".one").html(data);
          else if(type=="#home")
            $(".two").html(data);
          else if(type=="#menu1")
            $(".three").html(data);
          else if(type=="#menu2")
            $(".four").html(data);
         }
        });
      });

      $('.pagination li.page-item:nth-last-child(2)').on('click', function(e){

  
      });

      $('.pagination li.page-item:nth-child(2)').on('mouseover', function(e){
        $(this).css('cursor','pointer');
        $(".pagination li").removeClass("active");
        $(this).addClass("active");                
      });
</script>
@endsection
     