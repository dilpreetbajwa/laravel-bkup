      @extends('layouts.frontend.master')
      <!-- Slider -->  
      @section('content')

      <?php 
      $loginval = Session::get('show_modal');
      $bookingval = Session::get('booking_modal');
      if($loginval):?>
      <script>       
        $('#login-modal').modal('show');</script>
      <?php endif;?>
      <?php  if($bookingval):?>
        <script>       
        $('#booking-modal').modal('show');</script>
      <?php endif;?>

      <div class="bd-example">
         <div id="carouselExampleCaptions" class="carousel slide homepagecat_carousal" data-ride="carousel">
            <div class="carousel-inner">
               <div class="carousel-item active">
                  <img src="https://timernr.in/web/images/ban1.jpg" class="d-block " alt="...">
                  <div class="carousel-text">
                     <h3 class="wow bounceInLeft">Find Tourist Local Places</h3>
                     <h1 class="wow bounceInLeft">Welcome to <b>Reserve and Rent</b></h1>
                     <div class="search-area wow bounceInUp">
                        <div class="Tabs">
                           <!-- Nav pills -->
                           <ul class="nav nav-pills form_tabs">
                              <li class="nav-item">
                                 <a class="nav-link active  tab_menu" data-toggle="pill" href="#home">Places</a>
                              </li>
                              <li class="nav-item">
                                 <a class="nav-link tab_menu things" data-toggle="pill" href="#menu1">Things</a>
                              </li>
                              <li class="nav-item"> 
                                 <a class="nav-link tab_menu people" data-toggle="pill" href="#menu2">People</a>
                              </li>
                           </ul>
                           <input type="hidden" id="calvalall">
                           <!-- Tab panes -->
                           <div class="tab-content">
                              <div class="tab-pane container active" id="home">
                                <form action="{{url('/search-data')}}" method="post" name="searchformhome"  id="searchformhome">
                                  <div class="input-group">
                                  <input type="hidden" name="_token" id="csrf-token" value="{{ Session::token() }}" />
                                <input type="hidden" class="form-control" id="lat1"  name="latitude1">
                                <input type="hidden" class="form-control" id="lng1"  name="longitude1">
                              <input type="hidden" class="form-control typecat"   name="typecat1">                                 
                                  <select class="form-control" name="catdropdown" id="validationDefaultUsername" placeholder="Category" aria-describedby="inputGroupPrepend2">
                                  <option value="all" style="font-weight:700; display:none" selected >Select categories</option>
                                  <option value="all" style="font-weight:700">All place categories</option>

                                    @foreach(@$allplacecat as $key=>$place)
                                     
                                      <option value="{{$place['id']}}-place">
                                      {{ucfirst($place['name'])}}</option>
                                    
                                    @endforeach
                                  
                                  </select>
                                  <input type="text" class="form-control address1"  placeholder="Location" aria-describedby="inputGroupPrepend2">
                                  <div class="input-group-prepend">
                                    <button class="input-group-text searchbtnhome" type="submit">Search</button>
                                 </div>
                                  </div>
                                </form>
                              </div>
                              <div class="tab-pane container fade" id="menu1">
                                  <form action="{{url('/search-data')}}" method="post" name="searchformenu1" id="searchformenu1">
                                  <div class="input-group">
                                  <input type="hidden" name="_token" id="csrf-token" value="{{ Session::token() }}" />
                                <input type="hidden" class="form-control" id="lat2"  name="latitude1">
                                <input type="hidden" class="form-control" id="lng2"  name="longitude1">
                              <input type="hidden" class="form-control typecat"  name="typecat2">                                 
                                  <select class="form-control" name="catdropdown" id="validationDefaultUsername" placeholder="Category" aria-describedby="inputGroupPrepend2">
                                  <option value="all" style="font-weight:700; display:none" selected >Select categories</option>
                                 
                                    <option value="all" style="font-weight:700">All things categories</oppeopletion>
                                    @foreach(@$allthingscat as $key=>$thing)
                                        <option value="{{$thing['id']}}-thing">{{ucfirst($thing['name'])}}</option>
                                      
                                    @endforeach
                                   
                                  </select>
                                  <input type="text" class="form-control address2"  placeholder="Location" aria-describedby="inputGroupPrepend2">
                                  <div class="input-group-prepend">
                                    <button class="input-group-text searchbtnmenu1" type="submit">Search</button>
                                 </div>
                                  </div>
                                </form>
                              </div>
                              <div class="tab-pane container fade" id="menu2">
                                <form action="{{url('/search-data')}}" method="post" id="searchformenu2">
                                  <div class="input-group">
                                  <input type="hidden" name="_token" id="csrf-token" value="{{ Session::token() }}" />
                                <input type="hidden" class="form-control" id="lat3"  name="latitude1">
                                <input type="hidden" class="form-control" id="lng3"  name="longitude1">
                              <input type="hidden" class="form-control typecat"  name="typecat3">                                 
                                  <select class="form-control" name="catdropdown" id="validationDefaultUsername" placeholder="Category" aria-describedby="inputGroupPrepend2">
                                  <option value="all" style="font-weight:700; display:none" selected >Select categories</option>
                                  
                                    <option value="all" style="font-weight:700">All people categories</option>
                                    @foreach(@$allpeoplecat as $key=>$people)
                                        <option value="{{$people['id']}}-people"">{{ucfirst($people['name'])}}</option>
                                    @endforeach
                                  </select>
                                  <input type="text" class="form-control address3"  placeholder="Location" aria-describedby="inputGroupPrepend2">
                                  <div class="input-group-prepend">
                                    <button class="input-group-text searchbtnmenu2" type="submit">Search</button>
                                 </div>
                                  </div>
                                </form>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <!--                <div class="carousel-item">
                  <img src="images/ban2.jpg" class="d-block w-100" alt="...">
                  <div class="carousel-text">
                     <h3 class="wow bounceInLeft">Find Trusted Local Pros </h3>
                     <h1 class="wow bounceInLeft">For any <b>Home Project</b></h1>
                     <div class="search-area wow bounceInUp">
                        <div class="input-group">
                           <input type="text" class="form-control" id="validationDefaultUsername" placeholder="Search Tasker..." aria-describedby="inputGroupPrepend2" required>
                           <div class="input-group-prepend">
                              <span class="loc">
                              <i class="fas fa-map-marker-alt"></i> <input type="button" value="Location" onclick="">
                              </span>
                              <button class="input-group-text" type="submit">Get Quote</button>
                           </div>
                        </div>
                        <div class="search-jobs">
                           <span>OR</span>
                           <a href="#">Search Open Jobs</a>
                        </div>
                     </div>
                  </div>
                  </div> -->
            </div>
         </div>
      </div>
      <!-- Popular Tasks -->  
      <section class="Popular-task comman-padding">
         <div class="container task-contain">
            <div class="main-heading wow bounceInUp">
               <h2><span class="typeresource">Places</span> <b class="Services">Categories</b></h2>
            </div>
            <div id="demo"></div>
            <div class="owl-carousel owl-theme wow bounceInLeft" id="allcategories1">
                @foreach($allcategories as $cat)
                  <div class="item">
                     <a class="hover-thumb" href="{{url('getplacelistings').'/'.base64_encode($cat['id'])}}">
                        <div class="thumb allplacecategories" style="background: #{{$cat['color']}}">
                          <img src="{{url('/places').'/'.$cat['image']}}" alt="icon"/>
                           <h5>{{ucfirst($cat['name'])}}</h5>
                        </div>
                     </a>
                  </div>
                  @endforeach

               </div>           
         </div>
      </section>
      <!-- Our Packages -->  
      <section class="package comman-padding">
         <div class="container task-contain">
            <div class="main-heading2 wow bounceInUp">
            </div>
            <div class="row card-section wow bounceInRight">
               <div class="col-lg-12 col-md-12">
                  <div class="card">
                     <div class="main-heading_1 wow bounceInUp">
                        <h2  class="Places">Places <b class="Explore">Explore</b></h2>
                     </div>
                  </div>
                  <p class="contant">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore<br>et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra<br> 
                     maecenas accumsan lacus vel facilisis.
                  </p>
               </div>
            </div>
             <div class="row view-row wow bounceInUp">
               <form method="post" action= "{{url('/bookings')}}"> 
                  <input type="hidden" name="_token" id="csrf-token" value="{{ Session::token() }}" />
                  <input type="hidden" name="typeofbooking" id="typeofbooking">
                  <button type="submit" value="Explore" class="view explorebooking">Explore</button>
               </form>
            </div>
         </div>
      </section>
      <!-- Top Rated-->
      <section class="Popular-task_1 comman-padding">
         <div class="container task-contain">
            <div class="main-heading wow bounceInUp">
               <h2>Top <b class="Services"><span class="rated">Rated Places</span></b></h2>
            </div>
            <div class="owl-carousel owl-theme wow bounceInLeft" id="allrateddata">
              @foreach(@$alltopratedplaces  as $place)
               <div class="item">
                  <a class="hover-thumb silder_2" href="{{url('/getplacelistings')}}">
                     <div class="thumb">
                      
                      @if($place['getimage']['filenames']!="")
                      <img src="{{url('/attachments').'/'.$place['getimage']['filenames']}}"" alt="icon"/ width="100px" height="289px">
                      @else
                        <img src="https://timernr.in/web/images/img_1.png" alt="icon"/>
                        @endif
                     
                     </div>
                     <div class="overlay-text-image">
                        <h3>{{$place['title']}}</h3>
                        <p>$ {{$place['price_per_night']}}/night average</p>
                        <span>
                         <?php for($i=1;$i<=$place['ratings'];$i++){?>
                        <i class="fas fa-star"></i>
                        <?php }?>
                        </span>
                     </div>
                  </a>
               </div>
               @endforeach
             
            </div>
         </div>
      </section>
      <!-- Top Rated-->
      <!-- works -->  
      <section class="app">
         <div class="container">
            <div class="row">
               <div class="col-lg-12 col-md-12 right-content wow bounceInLeft">
                  <div class="main-heading_1 wow bounceInUp">
                     <h2  class="Download"><span class="Download_1">Download</span><b class="Our_App"> Our App</b></h2>
                  </div>
                  <p class="app_contant">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rem quis necessitatibus velit<br>
                     asperiores.Lorem ipsum dolor sit amet, consectetur adipisicing elit<br>
                     Rem quis necess itat ibus velit asperiores...
                  </p>
                  <div class="app-btns">
                     <img src="https://timernr.in/web/images/Apple_store.png" class="app-btns_1">
                     <img src="https://timernr.in/web/images/Google_store.png">
                  </div>
               </div>
               <div class="phone_img">
                  <figure class="mob-img wow bounceInRight">
                     <img class="img-fluid mobile" src="https://timernr.in/web/images/mobile.png" alt="image" />
                  </figure>
               </div>
            </div>
         </div>
         </div>
      </section>
      <!-- works -->  
      <!-- Footer Start -->
      <!-- Bootstrap JS -->

       

      <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>     
      <script src="https://timernr.in/web/js/slick.js"></script>
      <script type="text/javascript" src="https://maps.google.com/maps/api/js?libraries=places&language=en-AU&key=AIzaSyC29SOMdVFnuCgpVR9VFbeARVJqDJ7tJ-w"></script>

   
      <script type="text/javascript">
         jQuery(document).ready(function($) {
            $('.slick.marquee').slick({
              speed: 23000,
              autoplay: true,
              autoplaySpeed: 0,
              centerMode: true,
              cssEase: 'linear',
              slidesToShow: 1,
              slidesToScroll: 1,
              variableWidth: true,
              infinite: true,
              initialSlide: 1,
              arrows: false,
              focusOnSelect: true,
              pauseOnHover:true,
              buttons: false
            });
          });
      </script>
      <script type="text/javascript">
         $(document).ready(function(){
           $('.mymultiplediv').mouseover(function() {
           myvar = this.id;
             $("div.mydiv").hide();
             $('#div'+myvar).show();
           });
           $("#two").hover(function(){
             $(".firstt").hide();
           });
           });
      </script>
      <script src="https://timernr.in/web/js/owl.carousel.js"></script>
      <script>
      (function($) {
       $(document).ready(function(){
        $(".owl-carousel").owlCarousel({
            loop:true,
             margin:10,
             autoplay:true,
             autoplayTimeout:4000,
             autoplayHoverPause:true,
             responsiveClass:true,
             responsive:{
               300:{
                 items:1,
                 nav:true
               },
               767:{
                 items:2,
                 nav:true
               },
               1000:{
                 items:4,
                 nav:true,
                 loop:false
               }
             }
         });
       });
      }) (jQuery);

      
      $('select[name^="catdropdown"]').on('change',function(){
        var a = $(this).val();
        $("#calvalall").val(a);

        //$('select[name^="catdropdown"] option[value=a]').attr("selected","selected");
      });

       $(".searchbtnhome").on('click',function(e){
        e.preventDefault();      
        var dropdown = $("#calvalall").val();  
        var lat1 = $("#lat1").val();
        var lng1 = $("#lng1").val();

        if(dropdown =="")  
          dropdown ="all";        
        var typecat = $(".typecat").val();      
         if(typeof lat1 === "undefined" && typeof lng1 === "undefined") 
          var url = "{{url('search-data')}}"+'/'+dropdown+'/'+typecat;     
        else
          var url = "{{url('search-data')}}"+'/'+dropdown+'/'+typecat+'/'+lat1+'/'+lng1;    
        $("#searchformhome").attr('action',url);
        $("#searchformhome").submit();
       });

      $(".searchbtnmenu1").on('click',function(e){
        e.preventDefault();
        var dropdown = $("#calvalall").val();
        var lat2 = $("#lat2").val();
        var lng2= $("#lng2").val();
        if(dropdown =="")  
        dropdown ="all";         
        var typecat = $(".typecat").val();
        if(typeof lat2 === "undefined" && typeof lng2 === "undefined") 
         var url = "{{url('search-data')}}"+'/'+dropdown+'/'+typecat;
        else 
         var url = "{{url('search-data')}}"+'/'+dropdown+'/'+typecat+'/'+lat2+'/'+lng2;  
        $("#searchformenu1").attr('action',url);
        $("#searchformenu1").submit();

       });

      $(".searchbtnmenu2").on('click',function(e){

        e.preventDefault();
        var dropdown = $("#calvalall").val();
        var lat3 = $("#lat3").val();
        var lng3= $("#lng3").val();
        if(dropdown =="")  
        dropdown ="all";    
         ;
        var typecat = $(".typecat").val();
        if(typeof lat3 === "undefined" && typeof lng3 === "undefined") 
          var url = "{{url('search-data')}}"+'/'+dropdown+'/'+typecat;
         else 
          var url = "{{url('search-data')}}"+'/'+dropdown+'/'+typecat+'/'+lat3+'/'+lng3;          
       
        $("#searchformenu2").attr('action',url);
        $("#searchformenu2").submit();

       });


      
      </script>

      <script src="{{url('web/js/wow.js')}}"></script>
      <script>
         new WOW().init();
      </script>
      <script>
          var autocomplete1 = new google.maps.places.Autocomplete($(".address1")[0], {});
          var autocomplete2 = new google.maps.places.Autocomplete($(".address2")[0], {});
          var autocomplete3 = new google.maps.places.Autocomplete($(".address3")[0], {});

        google.maps.event.addListener(autocomplete1, 'place_changed', function() {
        var place = autocomplete1.getPlace();       
        var latitude = place.geometry.location.lat();
        var longitude = place.geometry.location.lng(); 
        $("#lat1").val(latitude);
        $("#lng1").val(longitude);
      });

        google.maps.event.addListener(autocomplete2, 'place_changed', function() {
        var place = autocomplete2.getPlace();
        //console.log(place.address_components);
        var latitude = place.geometry.location.lat();
        var longitude = place.geometry.location.lng(); 
        $("#lat2").val(latitude);
        $("#lng2").val(longitude);
      });
        google.maps.event.addListener(autocomplete3, 'place_changed', function() {
        var place = autocomplete3.getPlace();
        //console.log(place.address_components);
        var latitude = place.geometry.location.lat();
        var longitude = place.geometry.location.lng(); 
        $("#lat3").val(latitude);
        $("#lng3").val(longitude);
      });

    </script>
   </body>
</html>
@endsection