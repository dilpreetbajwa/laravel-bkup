@extends('layouts.frontend.master')

@section('content')

<style>
.search-bar
{
  display:none;
}
</style>

<section class="Popular-task_1 comman-padding booking-c-main">
         <div class="container task-contain">
            <div class="places-form-1">
              <h2 class="border-bottom-content title-transact" style="margin-bottom: 20px">Invite Share</h2>
               <div class="Tabs booking-tabs-cntnt">
                   <div class="row">
                     <div class="col-sm-6">
                        <h1 class="earn">Invite your friend to avail booking services</h1>
                         <p class=invite-text>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
                         <form>   
                            <input type="hidden" name="_token" id="csrf-token" value="{{ Session::token() }}" />
                           <div class="send-invite"> 
                           <input type="text" class="_f0iods" autocomplete="none" placeholder="Enter email addresses" id="emailvalue">
                           <button class="Send-Invites">Send Invites</button>
                           </div>                    
                        
                           <div class="Invite-link"> 
                            <p class=" invite-link">Share your invite link</p>
                           <input type="text" class="_f0iods copytext" autocomplete="none" value="https://timernr.com/#signup" readonly >
                          <span class="copydata" style="display: none">https://timernr.com/#signup</span>
                           <span class="right copybtn"><i class="far fa-copy"></i></span>
                           </div> 
                         </form>
                        </div>
                      <div class="col-sm-6">
                        <div class="share-img">
                           <img src="https://timernr.com/web/images/1111.jpg">
                        </div>
                      </div>
               </div>
          </div>
        </div>
</section>

<script>

   function ValidateEmail(email) {
        var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
        return expr.test(email);
    };


  $(document).ready(function(){
    $(".Send-Invites").on('click',function(e){
      e.preventDefault();
      var email = $("#emailvalue").val();
      if(email=="")
      {
        swal("OOPs!!","please fill in the email",'error');
      }
      else if(!ValidateEmail($("#emailvalue").val()))
      {
        swal("OOPs!!","Invalid email address",'error');

      }
      else{     
        $.ajax({
          url: "{{url('share_email')}}",
          type: 'POST',
          data: {
            _token: token,emailval:email
          },
          success: function (response) {
            if(response.status==0)
            {
              swal("OOps!!","Sorry!!could not send to this email",'error');
            }
            else if(response.status==1)
            {
              swal("Good job!!","Sent invitation to this email",'success');
            }
            $("#emailvalue").val("");      
          }
        });
      }
    });
  });

  $(".copybtn").on('click',function(){  

    copyToClipboard($(".copydata"));
    swal("", "Copied to clipboard",'success');
  })


  function copyToClipboard(element) {
    var $temp = $("<input>");
    $("body").append($temp);
    $temp.val($(element).text()).select();
    document.execCommand("copy");
    $temp.remove();
  }



</script>
@endsection