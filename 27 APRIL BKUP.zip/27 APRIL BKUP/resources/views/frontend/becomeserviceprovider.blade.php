@extends('layouts.frontend.master')
@section('content')
<style>
.imgecontainer img {
    height: 63px;
}

#map_canvas
{
  position: relative!important;
  width:100%!important;
  height:69%!important;
}

input#datesdata {
   display: flex;
   align-items: center;
   border: 1px solid #e1e1ed;
   background: #fafaff;
   justify-content: space-between;
   padding: 10px 15px;
   margin: 5px 0;
   height: 50px;
   border-radius: 0;
}

div#datepicker2 span.input-group-addon {
   background: #fafaff;
   height: 45px;
   display: flex;
   flex-wrap: wrap;
   align-items: center;
   justify-content: center;
   position: absolute;
   right: 3px;
   top: 32px;
   padding: 0;
   width: 40px;
   z-index: 9;
   border: 0;
}

  .datepicker-days table.table-condensed {
     width: 25vw !important;
     font-size: 1.6rem !important;
     background: #fafaff !important;
  }

  select#subcatlist {
     margin: 0 0 5px 0;
  }
  span.othersubcat {
     display: flex;
     flex-wrap: wrap;
  }
  .title-inner-form {
  margin-top: 0;
  }
</style>
      <!-- Our Packages -->  
      <section class="package comman-padding">
         <div class="container task-contain">
            <div class="row card-section wow bounceInRight">
               <div class="col-lg-12 col-md-12">
                  <div class="card">
                     <div class="main-heading-overlay wow bounceUp">
                        <h2>List Your <b>SERVICES</b></h2>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Top Rated-->
    
      <!-- Top Rated-->
      <form  method="post" action = "{{url('/addservicedetails')}}" id="place-form-main" name="places" enctype="multipart/form-data">
     <input type="hidden" name="_token" id="csrf-token" value="{{ Session::token() }}" />
      <section class="Popular-task_1 comman-padding">
         <div class="container task-contain">
            <div class="main-heading wow bounceInUp">
               <h2>Choose a <b class="Services">Category</b></h2>
            </div>
           <p class="app_contant">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod <br>tempor incididunt ut labore et dolore magna aliqua.</p>
            
            <ul class="services-category-items">
                 @foreach($people as $key=>$peoples)
                  <li class="service-item service-item-{{$key+1}}" data-catid="{{$peoples->id}}"><a href="javascript:void(0)" style="background: #{{$peoples['color']}};border-radius:50%">
                     <span class="place-item-icon">
                      @if($peoples->image!="")

                     <img src="{{url('/peoples/').'/'.$peoples->image}}" alt="icon" width=100px height=100px >
                     @endif

                     </span>
                     <span class="place-item-title">{{$peoples->name}}</span></a>
                  </li>
               @endforeach
                <span class="placesitem" hidden></span>
              
            </ul>
         </div>
      </section>
      <!-- About place -->
      <section class="Popular-task_1 comman-padding more-about-service" style="display:none">
         <div class="container task-contain">
            <div class="main-heading more-about-heading-service wow bounceInUp">
               <h2>Tell us more about item</h2>
            </div>
         <div class="places-form">
               <form action="" method="post" id="place-form-main" name="">
               <div class="row">
                  <div class="col-lg-6">
                       <input type="hidden" name="catdata" id="catdata">
                      
                      <input type="hidden" name="picsid" id="picsid" value="1">
                     
                     <select name="subcatlist" id="subcatlist" class="form-input">

                     </select>
                     <!-- <a href="javascript:void(0)" class="subcat">Subcategory not in List? Add Subcategory</a> -->
                     <span class="othersubcat"  style="display:none">
                      <label for="add-Subcategory"></label>
                       <input type="text" name="subcatname" id="subcatname" class="form-input" placeholder = "Add Subcategory Name">
                     </span>
                    <input type="text" id="title" name="title" class="form-input" placeholder="Title" required>
                     <textarea name="description" id="description" class="form-textarea" placeholder="Description" required></textarea>
                  </div>
                  <div class="col-lg-6">
                     <h3 class="title-inner-form">Location of the Pickup</h3>
                      <input type="text" name="address" id="address" class="form-control">
                      <input type="hidden" class="form-control" id="lat"  name="latitude">
                      <input type="hidden" class="form-control" id="lng"  name="longitude">
                      <div id="map_canvas" style="position: initial!important;"></div>
                  </div>
               </div>
               <div class="row">
                  <div class="main-heading more-about-heading wow bounceInUp">
                     <h2>Details and <b class="Services">Specifications</b></h2>
                  </div>
                  <div class="col-lg-6">
                     
                     <div class="file-upload-in">
                        <div class="upload-button">Add Photos</div>
                        <input class="file-upload" type="file" name="uploadfile[]" accept="image/*" multiple/  required hidden>
                        <div id="dvPreview"></div>
                        <p class="hint-text">Please upload your driving license, certificate of service 
                        qualification, etc. documents</p>
                     </div>
                     <div class="clockpicker">
                        <label>Pick-up Time  </label>
                         <input type="text" class="timepicker-in form-control" name="timepicker_in">
                          <span class="time-icon checkouttimeclock">
                             <img src="{{url('/web/images/date-pick-icon.png')}}">
                         </span>
                     </div>
                      <div class="input-group clockpicker">
                        <label>Drop-off Time  </label>
                         <input type="text" class="timepicker-out form-control" name="timepicker_out">
                          <span class="time-icon">
                             <img src="{{url('/web/images/date-pick-icon.png')}}">
                         </span>
                     </div>
               </div>
                  <div class="col-lg-6">
                         <div id="datepicker2" class="input-group date" data-date-format="mm-dd-yyyy">
                     <label for = "dates">Please block the dates that are unavailable</label>
                       <input class="form-control" type="text"  readonly name = "dates" id="datesdata" required placeholder="Select the dates">
                       <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                     </div>
                     <label for="pricingpernight" style="margin-top: 6px;">Pricing per night($)</label>
                     <input type="number" name="pricingpernight" id="pricingpernight" class="form-input" placeholder="Pricing per night" required="">
                  </div>
               </div>
               
               <div class="form-action-button">
               <button type="cancel" class="btnn btn-cancel" value="Cancel">Cancel</button>
               <button type="submit" class="btnn btn-next" value="next">Next</button>
            </div>
               </form>
         </div>
      </div>
      </section>  
      <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
      <script src="{{url('/web/js/wow.js')}}"></script>  
      <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
      <link rel="stylesheet" href="{{url('web/css/wickedpicker.css')}}">
      <link rel="stylesheet" href="{{url('web/css/wickedpicker.min.css')}}">
      <script src="{{url('web/js/wickedpicker.min.js')}}"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>
     
      <script>


         var token = "{{ csrf_token() }}";
         $(".othersubcat").hide();
         $(".service-item").on('click',function(){
          $(".placesitem").html("category selected");
          //document.places.dates.focus()﻿;
          $(".more-about-service").show();
          var target = $(".places-form");

          $('html,body').animate({
            scrollTop: target.offset().top
          }, 1000);

          ($("#catdata").val($(this).attr('data-catid')));

          var i = 0;
          var id = $("#catdata").val();
           $.ajax({
           url: "{{url('/get-subcatpeople')}}",
           type: 'POST', 
           data:   {  
             "_token": token,
             id: id,
             userid:"{{Auth::id()}}"
           },
          success: function(response){
          
            var subcatlist = $("#subcatlist");
            subcatlist.empty();
            var option = $("<option />"); 
            option.html("Select the Sub category"); 
            option.val("-1");
            subcatlist.get(0).selectedIndex = -1;
            subcatlist.append(option);
            $(response).each(function () {
            i++;
            var option = $("<option />");   
            option.html(this.name); 
            option.val(this.id);
            subcatlist.append(option);
          })
             if(i==response.length)  
            {              
              subcatlist.append("<option value=other>other</option>");
            }  
          }
         })
        })

        $(".subcat").on('click',function(){
          $(".othersubcat").toggle();
        });

        $("#address").on('keypress',function(event){
           if (event.keyCode == 13) {
           return false;
          }
        });

        $("#subcatlist").on('change',function()
        {
          var catval = $(this).val();
          if(catval=="other")
          {
            $(".othersubcat").show();
          }
          else{
             $(".othersubcat").hide();
          }
        });

        
    $(document).ready(function () {
      var date = new Date();
    date.setDate(date.getDate());

    $input = $("#datepicker2");

    $input.datepicker({
      multidate: true,
      inline: true,
      startDate: date,
      format: 'yyyy-mm-dd'
    }); 
    var status = $(".placesitem").html(); 
    if(status.length!=0)  
    $input.datepicker('show');
    $('.timepicker-in').wickedpicker(); 
    $('.timepicker-out').wickedpicker(); 

  });
   $(".file-upload").change(function () {

        if (typeof (FileReader) != "undefined") {
            var dvPreview = $("#dvPreview");
            var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.jpg|.jpeg|.gif|.png|.bmp)$/;
            $($(this)[0].files).each(function () {
                var file = $(this);
              /*  if (regex.test(file[0].name.toLowerCase())) {  */                 
                  var reader = new FileReader();
                  reader.onload = function (e) {
                      var id = $("#picsid").val();
                      var img = $("<img id="+id+" class=delpics-"+id+"><span data-id="+id+"  class=delpics id=delpics-"+id+">X</span>");
                      //img.attr("style", "height:100px;width: 100px");
                      img.attr("src", e.target.result);
                      var imgouter=$("<div data-id="+id+" class='delpics imgecontainer'></div>");
                      imgouter.html(img);
                    
                      dvPreview.append(imgouter);
                      var i = parseInt(id)+1;
                      $("#picsid").val(i);
                    }
                    reader.readAsDataURL(file[0]);
                /*} else {
                  alert(file[0].name + " is not a valid image file.");
                  dvPreview.html("");
                  return false;
                }*/
            });
        } else {
            alert("This browser does not support HTML5 FileReader.");
        }
    });

    $(document).on('click','.delpics',function(){
      var id = ($(this).attr('data-id'));
      $(".delpics-"+id).remove();
      $(this).remove();
      if( $('#dvPreview').is(':empty') ) 
      {
        $("#dvPreview").css("height","0px");
      }
    })

      </script>

   <script>
   
   function initialise() {
    var latitude = $("#lat") .val();
   var longitude = $("#lng") .val();
   if(latitude =="" || longitude=="")
   {
     var latitude = 46.8182;
     var longitude = 8.2275;
    } 
    var myLatlng = new google.maps.LatLng(latitude,longitude);
    var myOptions = {
      zoom: 8,
      center: myLatlng,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    }

    var map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
    addMarker(myLatlng, 'Default Marker', map);
    /*map.addListener('click',function(event) {
    addMarker(event.latLng, 'Click Generated Marker', map);
  });*/
  }
  //google.maps.event.addDomListener(window, "load", initialise);

  function handleEvent(event) {
      document.getElementById('lat').value = event.latLng.lat();
      document.getElementById('lng').value = event.latLng.lng();
      var lat = event.latLng.lat();
      var lng = event.latLng.lng();
      var latlng = new google.maps.LatLng(lat,lng);
      var geocoder = geocoder = new google.maps.Geocoder();
      geocoder.geocode({ 'latLng': latlng }, function (results, status) {
                    if (status == google.maps.GeocoderStatus.OK) {
                        if (results[1]) {
                          $("#address").val(results[1].formatted_address);




                            /*alert("Location: " + results[1].formatted_address + "\r\nLatitude: " + lat + "\r\nLongitude: " + lng);*/
                        }
                    }
                });
      
  }

  function addMarker(latlng,title,map) {
    var marker = new google.maps.Marker({
    position: latlng,
    map: map,
    title: title,
    draggable:true
    });

    marker.addListener('drag', handleEvent);
    //marker.addListener('dragend', handleEvent);
  }

  $(".btn-next").on('click',function(event){

    event.preventDefault();
    //var dates= ($("#datesdata").val());
    
    var catval = $(".placesitem").html();
    var address = $("#address").val();
    var pricingpernight = $("#pricingpernight").val();
   
    if(catval.length==0)
    {
      swal({
        title: "Error!!",
        text: "Please select category",
        icon: "warning",
        buttons: true,
        dangerMode: true,
      })
    }
    else if($("#subcatlist").val()==-1)
    {
      swal({
        title: "Error!!",
        text: "Please Select Sub category",
        icon: "warning",
        buttons: true,
        dangerMode: true,
      })
    }

    else if(($("#subcatname").val()=="")&& $("#subcatlist").val()=="other")
    {
      swal({
        title: "Error!!",
        text: "Please enter sub category name",
        icon: "warning",
        buttons: true,
        dangerMode: true,
      })
    }
     else if($("#title").val()=="")
    {
      swal({
        title: "Error!!",
        text: "Please enter title",
        icon: "warning",
        buttons: true,
        dangerMode: true,
      })
    }
     else if($("#description").val()=="")
    {
      swal({
        title: "Error!!",
        text: "Please enter description",
        icon: "warning",
        buttons: true,
        dangerMode: true,
      })
    }
   
     
      else if($("#dvPreview").html()=="")
    {
      swal({
        title: "Error!!",
        text: "Please add photos",
        icon: "warning",
        buttons: true,
        dangerMode: true,
      })
    }
     
     else if(address.length==""){
      swal({
        title: "Error!!",
        text: "Please add place address",
        icon: "warning",
        buttons: true,
        dangerMode: true,
      })
    }
    /*else if(dates.length==0)
    {
     swal({
          title: "Error!!",
          text: "Please select the dates",
          icon: "warning",
          buttons: true,
          dangerMode: true,
        })
    }*/
     else if(pricingpernight==""){
        swal({
          title: "Error!!",
          text: "Please enter value for pricing/night",
          icon: "warning",
          buttons: true,
          dangerMode: true,
        })
      }
     
   else{
      $("#place-form-main").submit();
   }
  })
  $(".btn-cancel").on('click',function(event){
    event.preventDefault();
    location.reload();
  })
  $(".upload-button").click(function(){
    $(".file-upload").click();
  })


</script>
<script type="text/javascript" src="https://maps.google.com/maps/api/js?sensor=false&libraries=places&language=en-AU&key=AIzaSyC29SOMdVFnuCgpVR9VFbeARVJqDJ7tJ-w&callback=initialise"></script>

<script>
   var autocomplete = new google.maps.places.Autocomplete($("#address")[0], {});

   google.maps.event.addListener(autocomplete, 'place_changed', function() {
       var place = autocomplete.getPlace();
       console.log(place.address_components);
       var latitude = place.geometry.location.lat();
       var longitude = place.geometry.location.lng(); 
       $("#lat").val(latitude);
       $("#lng").val(longitude);
       initialise();

   });
</script>
@endsection
     