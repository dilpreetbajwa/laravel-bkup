@extends('layouts.frontend.master')
@section('content')
 
 <style>
 	.search-bar
 	{
 		display: none;
 	}
  form{
    padding-top:20px;
  }
  #issue_type
  {
    margin-bottom: 20px;
  }
  button
  {
    background: #7abade;
    margin: 0 10px;
    padding: 8px 10px;
    width: 110px;
    border: 0;
    color: #fff;
    border-radius: 5px;
    font-size: 16px;
    font-weight: 500;
    letter-spacing: .5px;
    float:right;
  }
 </style>

<section class="Popular-task_1 comman-padding more-about-place">
 <div class="container task-contain">
    <div class="things-innerpage-content">
       <div class="row">
          <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
             <div class="full-width-text showamount">
            @if(Session::has('success'))
    	<div class="alert alert-success"><span class="glyphicon glyphicon-ok"></span><em> {!! session('success') !!}</em></div>
	   @endif
               <h2 class="border-bottom-content title-transact" style="margin-bottom: 20px">Contact Us</h2>

                <form method="post" id="issueform" name="issueform" action="{{url('/contact-us')}}">
                  <input type="hidden" name="_token" id="csrf-token" value="{{ Session::token() }}" />

                  <select name="issue_type" id="issue_type" class="form-control" required>
                  <option value="0">Select issue type</option> 
                  @foreach($issue_types as $key=>$issue)
                    <option value="{{$issue['issue_type']}}">{{$issue['issue_type']}}</option>
                  @endforeach
                  </select>
                  <p><span class="errmsg" style="color:red"></span></p>
                  <textarea style="height: 200px;line-height: normal;"  name="description"   id="description" placeholder="Description" class="form-control contactdescription" required  /></textarea>
                  </form>
                  <button  class="btnn btn-next" name="btnissue" id="btnissue">Submit</button>
                </form>
             </div>
             </div>
            </div>
        </div>
    </div>
  </div>       
</section>  

<script>
 
  $("#btnissue").on('click',function(e){
  	e.preventDefault();
    
  	var description = $("#description").val();
     if($("#issue_type").val()==0)
    {
      $(".errmsg").html("Please select the issue type");
      return false;
    }
    else if(description=="")
    {
      $(".errmsg").html("Please fill in the description");
      return false;
    }
  	else
    {
      $("#issueform").submit();
    }
  });
</script>
@endsection