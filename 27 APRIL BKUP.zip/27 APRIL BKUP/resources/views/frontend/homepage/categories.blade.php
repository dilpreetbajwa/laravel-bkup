
@if($cattype=="home")

   @foreach($allcategories as $cat)
   <div class="item">
      <a class="hover-thumb" href="{{url('getplacelistings').'/'.base64_encode($cat['id'])}}">
         <div class="thumb place" style="background: #{{$cat['color']}}">
            
            @if($cat['image']!="")

               <img src="{{url('/places').'/'.$cat['image']}}" alt="icon"/>
            @else
               <img src="{{url('/places/1580386713.png')}}" alt="icon"/>
            @endif
            
            <h5>{{ucfirst($cat['name'])}}</h5>
         </div>
      </a>
   </div>
   @endforeach

   @elseif($cattype=="menu1")

   @foreach($allcategories as $cat)
   <div class="item">
      <a class="hover-thumb" href="{{url('getthingslistings').'/'.base64_encode($cat['id'])}}">
         <div class="thumb thing" style="background: #{{$cat['color']}}">
            
            @if($cat['image']!="")
                <img src="{{url('/things').'/'.$cat['image']}}" alt="icon"/>
            @else
               <img src="{{url('/things/1580389045.png')}}" alt="icon"/>
            @endif
           
            <h5>{{ucfirst($cat['name'])}}</h5>
         </div>
      </a>
   </div>
   @endforeach

   @elseif($cattype=="menu2")
      @foreach($allcategories as $cat)
      <div class="item">
         <a class="hover-thumb" href="{{url('getpeoplelistings').'/'.base64_encode($cat['id'])}}">
            <div class="thumb people" style="background: #{{$cat['color']}}">
             
            @if($cat['image']!="")

               <img src="{{url('/peoples').'/'.$cat['image']}}" alt="icon"/>
            @else
               <img src="{{url('/peoples/1580389045.png')}}" alt="icon"/>
            @endif
           
               <h5>{{ucfirst($cat['name'])}}</h5>
            </div>
         </a>
      </div>
      @endforeach
@endif





