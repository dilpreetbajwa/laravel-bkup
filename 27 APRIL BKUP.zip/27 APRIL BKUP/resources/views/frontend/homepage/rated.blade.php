
@if($cattype=="home")
   @foreach($alltoprated as $place)   
     <div class="item">
      <a class="hover-thumb silder_2" href="{{url('/getplacelistings')}}">
         <div class="thumb">
          
          @if($place['getimage']['filenames']!="")
          <img src="{{url('/attachments').'/'.$place['getimage']['filenames']}}"" alt="icon"/ width="100px" height="289px">
          @else
            <img src="https://timernr.com/web/images/img_1.png" alt="icon"/>
            @endif
         
         </div>
         <div class="overlay-text-image">
            <h3>{{$place['title']}}</h3>
            <p>$ {{$place['price_per_night']}}/night average</p>
            <span>
             <?php for($i=1;$i<=$place['ratings'];$i++){?>
            <i class="fas fa-star"></i>
            <?php }?>
            </span>
         </div>
      </a>
   </div>         
  
   @endforeach

   @elseif($cattype=="menu1")
   @foreach($alltoprated as $thing)

   <div class="item">
      <a class="hover-thumb silder_2" href="{{url('/getthingslistings')}}">
         <div class="thumb">
          
          @if($thing['getimage']['filenames']!="")
          <img src="{{url('/attachments').'/'.$thing['getimage']['filenames']}}"" alt="icon"/ width="100px" height="289px">
          @else
            <img src="https://timernr.com/attachments/dummy_things.png" alt="icon"/>
            @endif
         
         </div>
         <div class="overlay-text-image">
            <h3>{{$thing['title']}}</h3>
            <p>$ {{$thing['price_per_night']}}/night average</p>
            <span>
             <?php for($i=1;$i<=$thing['ratings'];$i++){?>
            <i class="fas fa-star"></i>
            <?php }?>
            </span>
         </div>
      </a>
   </div>         
  
   @endforeach

   @elseif($cattype=="menu2")
   @foreach($alltoprated as $people)   
   <div class="item">
      <a class="hover-thumb silder_2" href="{{url('/getpeoplelistings')}}">
         <div class="thumb">
          
          @if($people['getimage']['filenames']!="")
          <img src="{{url('/attachments').'/'.$people['getimage']['filenames']}}"" alt="icon"/ width="100px" height="289px">
          @else
            <img src="https://timernr.com/attachments/dummy_people.png" alt="icon"/ height="290px">
            @endif
         
         </div>
         <div class="overlay-text-image">
            <h3>{{$people['title']}}</h3>
            <p>$ {{$people['price_per_night']}}/night average</p>
            <span>
             <?php for($i=1;$i<=$people['ratings'];$i++){?>
            <i class="fas fa-star"></i>
            <?php }?>
            </span>
         </div>
      </a>
   </div> 
      @endforeach   
@endif


  