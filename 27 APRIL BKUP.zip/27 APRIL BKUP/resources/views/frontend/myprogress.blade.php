  @extends('layouts.frontend.master')
@section('content')
<style>
.search-bar
{
  display:none;
}
</style>

  <section class="Popular-task_1 comman-padding booking-c-main">
         <div class="container task-contain">
            <div class="places-form progress-page">
             <h2 class="border-bottom-content title-transact" style="margin-bottom: 20px">My progress</h2>
              <div class="progress-content"> 
                 <div class="rating-progress">
                     <div class="inner-c-progress">
                           <div class="left-c">
                                 <p>{{@$aveage_rating}} <span>★</span></p>
                                 <p>Overall Rating</p>
                           </div>
                           <div class="right-c">
                                 <a href="{{url('/provider-reviews')}}"><p>{{@$review_count}}</p>
                                 <p>Reviews</p></a>
                           </div>
                     </div>
                     <div class="inner-c-progress">
                           <div class="left-c">
                                 <p>${{@$overall_earnings}}</p>
                                 <p>Overall Earning</p>
                           </div>
                           <div class="right-c">
                                <a href="{{url('/request_bookinglist')}}"> <p>{{@$total_bookings}}</p>
                                 <p>All Booking</p></a>
                           </div>
                     </div>

                 </div>
               </div>
               <div class="progress-img">
                <img src="https://timernr.com/web/images/progress.gif" alt="icon">
              </div>
               <!-- <div class="progress-btn">
                  <a href="#" class="withh-btn">View Transaction History</a>
               </div> -->
            </div>
          </div>
      </section>  
       <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script> 
      <script src="{{url('web/js/wow.js')}}"></script>

      @endsection