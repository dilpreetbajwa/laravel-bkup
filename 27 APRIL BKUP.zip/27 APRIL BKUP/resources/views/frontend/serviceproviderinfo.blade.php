@extends('layouts.frontend.master')
@section('content')
<style type="text/css">
  .search-bar
  {
    display: none;
  }

</style>
<?php 
$loginval = Session::get('show_modal');
if($loginval):?>
<script> 
  $('#login-modal').modal('show');</script>
<?php endif;?>


   
    <section class="Popular-task_1 comman-padding more-about-service">
         <div class="container task-contain">
         @if($type==1)
            <div class="things-innerpage-content services_provider">
                  <div class="service_provider-profile-info profile-img">
                    <div class="service_provider-img">
                      @if($image!="")
                        <img src="{{$image}}" >  
                      @else                      
                        <img src="{{url('/web/images/service-profile-img.png')}}" >   
                      @endif         
                   
               </div>
               </div>
                     <div class="service-proviDer-name client-name">
                        <h3>{{$user_name}}</h3>
                      <div class="service-proviDer-info">
                        
                      </div>
                     </div>
               <!-- <button type="submit" class="btnn btn-Message " value="Message ">Message </button> -->
               <div class="full-width-text">
              
              <div class="skills_section">
                <div class="all_document-heading-flex"> 
                <h3>Skills</h3>
                <span><a style="color:#fff" href="{{url('addservicedetails')}}">+</a></span>
                </div>
              
                <ul class="reviews-list multipul-skills" style="white-space:nowrap">
                    @if(count($data)>0)
                        <div class="row">
                      @foreach($data as $data1)
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-6 main-skillbox">    
                    
                      <li> 
                              <div class="review-icon skill">
                                @if($data1['category_image']!="")
                                  <img src="{{$data1['category_image']}}" alt="icon" width=100px height=100px style="background: #6F276C !important;">
                                @else
                                 <img src="{{url('/peoples/').'/1580389298.png'}}" alt="icon" style="background: #6F276C !important;">
                                @endif 

                              </div>
                              <div class="review-content data">
                                <h2>{{$data1['title']}}</h2> 
                                <h3>{{$data1['category']}}: <span class="host_details">{{$data1['subcategory']}}</span></h3> 
                                 <p>$ {{$data1['price_per_night']}} per night</p>
                              </div>
                           </li>
                   
                          </div>
                       @endforeach
                     @else
                      Please become service provider to add your skills and services.
                    
                     </div>
                    @endif
                     
                  </ul>
                </div>
                <div class="all_document-sec main-documents">
                 <div class="all_document-heading-flex down-area">
                    <h3>All Documents</h3>
                      <span><a style="color:#fff" href="{{url('addservicedetails')}}">+</a></span>
                    
                 </div>
                 <div class="all_document-img-flex documents-img">
                 @if(count($attachment)>0)
                    @foreach($attachment as $att)
                      <span><img src="{{@$att}}"></span>                     
                    @endforeach
                    @else
                    No Attachment added yet
                @endif
                 </div>
              </div>
               </div>
            </div>
           
            @else
              {{$type}}
            @endif
            
          </div>
      </section>  
      <!-- Bootstrap JS -->
       <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
       <link rel="stylesheet" href="/resources/demos/style.css">
      <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
       <script src="https://timernr.com/web/js/owl.carousel.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
     
@endsection