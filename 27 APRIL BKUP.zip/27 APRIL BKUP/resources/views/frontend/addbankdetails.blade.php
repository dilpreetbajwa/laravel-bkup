@extends('layouts.frontend.master')
@section('content')
 
 <style>
 	.search-bar
 	{
 		display: none;
 	}

 </style>

 <section class="Popular-task_1 comman-padding more-about-place">
         <div class="container task-contain">
            <div class="things-innerpage-content">
               <div class="row">
                  
                  <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                     <div class="full-width-text showamount">
                    @if(Session::has('success'))
				    	<div class="alert alert-success"><span class="glyphicon glyphicon-ok"></span><em> {!! session('success') !!}</em></div>
				      	@endif
                        <h2 class="border-bottom-content title-transact">Withdraw</h2>

                        <form method="post" action="">
                        <input type="hidden" name="_token" id="csrf-token" value="{{ Session::token() }}" />
                   <div class="wallet">       
                    <label for="amount" style="margin-top: 6px; margin-top: 10px;
                      font-size: 20px;
                      font-weight: 500;
                      margin-bottom: 10px; ">Amount($)</label>
                     <p> Wallet Balance: $ {{@$amt}}</p>
                    </div>
                        <p><span class="errmsg" style="color:red"></span></p>
                        <input type="number" name="amount" id="amount" class="form-input" placeholder="amount" required /><p>
                        <label for="taxes" style="margin-top: 6px;margin-top: 12px;
                    margin-bottom: 17px;"><b><span class="info" style="font-size:20px">Note:</span> Taxes ( 10% of the requested amount will be deducted from your wallet )</b></label>
                      </p>
                        <button  name="btnamount" id="btnamount">Submit</button>

                        </form>
                     </div>
                     <div class="showbankdetails" style="display:none">
                        <h2 class="border-bottom-content title-transact">Add Bank Information</h2>
                        @if(Session::has('error'))
                         <input type="hidden" name="errval" id="errval" value="1">
				   		 <div class="alert alert-danger"><span class="glyphicon glyphicon-ok"></span><em> {!! session('error') !!}</em></div>
						@endif
                        <form method="post" action="{{url('/addbankdetails')}}">
                        	<input type="hidden" name="_token" id="csrf-token" value="{{ Session::token() }}" />

                        	<input type="hidden" name="user_vault_total" id="user_vault_total">

	                        <label for="accout_holder_name" style="margin-top: 6px; font-size: 18px;font-weight: 500;margin: 15px 0 3px 0;">Account Holder Name</label>
	                        <input type="text" name="accout_holder_name" id="accout_holder_name" class="form-input" placeholder="Account holder name">
	                        <label for="account_number" style="margin-top: 6px; font-size: 18px;font-weight: 500;margin: 15px 0 3px 0;">Account Number</label>
	                        <input type="text" name="account_number" id="account_number" class="form-input" placeholder="Account Number">
	                         <label for="bank_name" style="margin-top: 6px; font-size: 18px;font-weight: 500;margin: 15px 0 3px 0;">Bank Name</label>
	                        <input type="text" name="bank_name" id="bank_name" class="form-input" placeholder="Bank Name">
	                         <label for="iban" style="margin-top: 6px; font-size: 18px;font-weight: 500;margin: 15px 0 3px 0;">IBAN</label>
	                        <input type="text" name="iban" id="iban" class="form-input" placeholder="IBAN">
	                         <label for="sort_code" style="margin-top: 6px; font-size: 18px;font-weight: 500;margin: 15px 0 3px 0;">Sort code</label>
	                        <input type="text" name="sort_code" id="sort_code" class="form-input" placeholder="Sort code">
	                        
	                        <input type="submit" name="btntransaction" id="btntransaction" class="transactionamount">
                        </form>
                     </div>

                     
                    </div>
                </div>
               
             
            </div>
        </div>       
      </section>  

      <script>
      $(document).ready(function(){
      	var errval = $("#errval").val();
      
      	if(errval==1)
      	{
      		$(".showamount").hide();
            $(".showbankdetails").fadeIn(2000);
      	}
      	else
      	{
      		
      	}

      })
      $("#btnamount").on('click',function(e){
      	e.preventDefault();
      	var amount = $("#amount").val();
      	if(amount=="")
      	{
      		$(".errmsg").html("Please fill in the amount");
      		return false;
      	}
      	$.ajax({
           url: "{{url('/balance-check')}}",
           type: 'POST', 
           data:   {  
             "_token": token,             
             amount: amount
            },
          success: function(response){
            if(response.success==1)
            {
            	$("#user_vault_total").val(response.amountreq);
            	$(".showamount").hide();
            	$(".showbankdetails").fadeIn(2000);
            }
            else
            {
            	swal("OOps!","Insufficeient balance in your wallet",'error');
            }
            
          }
         });
       })

    
      </script>


@endsection