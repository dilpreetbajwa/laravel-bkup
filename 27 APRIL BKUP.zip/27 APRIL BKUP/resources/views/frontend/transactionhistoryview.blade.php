@if($type==0)
  @if(count($data_all)>0)
      @foreach($data_all as $value)
            <ul class="trans-detail">
               <li>
                  <span class="tran-name"><span class="t-name">{{$value['provider_title']}}</span> <span class="t-cate">{{$value['category']}}</span><span class="t-time">{{$value['date']}}</span></span>
                  <span class="amount-tran">${{$value['amount']}}</span>
               </li>
               
            </ul>
        
         @endforeach
      @else
       <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
   @endif

@elseif($type==1)
    @if(count($data_rcd)>0)
      @foreach($data_rcd as $value)
            <ul class="trans-detail">
               <li>
                  <span class="tran-name"><span class="t-name">{{$value['provider_title']}}</span> <span class="t-cate">{{$value['category']}}</span><span class="t-time">{{$value['date']}}</span></span>
                  <span class="amount-tran">${{$value['amount']}}</span>
               </li>
               
            </ul>
        
         @endforeach
      @else
       <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
   @endif
 

 @elseif($type==2)
   @if(count($data_progress)>0)
      @foreach($data_progress as $value)
            <ul class="trans-detail">
               <li>
                  <span class="tran-name"><span class="t-name">{{$value['provider_title']}}</span> <span class="t-cate">{{$value['category']}}</span><span class="t-time">{{$value['date']}}</span></span>
                  <span class="amount-tran">${{$value['amount']}}</span>
               </li>
               
            </ul>
        
         @endforeach
      @else
       <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
   @endif

   @elseif($type==3)

    @if(count($data_withdraw)>0)
      @foreach($data_withdraw as $value)
            <ul class="trans-detail">
               <li>
                  <span class="tran-name"><span class="t-name">{{$value['provider_title']}}</span> <span class="t-cate">{{$value['category']}}</span><span class="t-time">{{$value['date']}}</span></span>
                  <span class="amount-tran">${{$value['amount']}}</span>
               </li>
               
            </ul>
        
         @endforeach
      @else
       <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
   @endif
@endif






