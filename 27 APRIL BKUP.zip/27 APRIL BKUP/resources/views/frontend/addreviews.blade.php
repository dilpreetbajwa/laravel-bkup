@extends('layouts.frontend.master')
@section('content')
<style>
.list-service-outer span.task-btn, .menu .menu_icon
{
  display:none;
}
.swal-overlay {
    position: absolute;
    z-index: 999999;
    top:5%;
  }


.search-bar
{
  display: none;
}
a {
  color: tomato;
  text-decoration: none;
}

a:hover {
  color: #2196f3;
}

.rating-stars ul {
  list-style-type:none;
  padding:0;
  
  -moz-user-select:none;
  -webkit-user-select:none;
}
.rating-stars ul > li.star {
  display:inline-block;
  
}

/* Idle State of the stars */
.rating-stars ul > li.star > i.fa {
  font-size:2.5em; /* Change the size of the stars */
  color:#ccc; /* Color on idle state */
}

/* Hover state of the stars */
.rating-stars ul > li.star.hover > i.fa {
  color:#FFCC36;
}

/* Selected state of the stars */
.rating-stars ul > li.star.selected > i.fa {
  color:#FF912C;
}


</style>

 <div class="modal fade" id="reviewrating" role="dialog">
    <div class="modal-dialog modal-md">
      <div class="modal-content reviewratingfinal">
      <div class="modal-header">
          <h4 class="modal-title">Add Reviews and ratings</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
          <form method="post" action="{{url('/add-reviews')}}">
            <label for="reviewdata">Reviews</label>
            <textarea name="reviewdata" id="reviewdata" rows="10" cols="45"></textarea>
            <input type="hidden" name="providerid" id="providerid">
            <input type="hidden" name="servicetype" id="servicetype">
            <input type="hidden" name="bookingid" id="bookingid">
            <input type="hidden" name="provideruserid" id="provideruserid">
            <input type="hidden" name="rating" id="rating">
            <input type="hidden" name="_token" id="csrf-token" value="{{ Session::token() }}" />
          
            <section class='rating-widget'>
                <p>Ratings</p>
              <div class='rating-stars text-center'>
                <ul id='stars'>
                  <li class='star' title='Poor' data-value='1'>
                    <i class='fa fa-star fa-fw'></i>
                  </li>
                  <li class='star' title='Fair' data-value='2'>
                    <i class='fa fa-star fa-fw'></i>
                  </li>
                  <li class='star' title='Good' data-value='3'>
                    <i class='fa fa-star fa-fw'></i>
                  </li>
                  <li class='star' title='Excellent' data-value='4'>
                    <i class='fa fa-star fa-fw'></i>
                  </li>
                  <li class='star' title='WOW!!!' data-value='5'>
                    <i class='fa fa-star fa-fw'></i>
                  </li>
                </ul>
              </div>
            </section>
            </p>
            <button type="submit" class="btn-rating" value="submit">Submit</button>
          </form>
        </div>
      </div>
    </div>
  </div>

<section class="Popular-task_1 comman-padding booking-c-main">
   <input type="hidden" name="typedata" id="typedata" value="#all">
    <input type="hidden" name="bookingscount" id="bookingscount" value="{{@$bookingscount}}">
   
   <div class="container task-contain">
      <div class="places-form">
         <div class="Tabs booking-tabs-cntnt service-revices">
       
    <div class="tab-content">
        <div class="tab-pane container active" id="all">
          <ul class="reviews-list one">
          @foreach($data as $data1)
            <li>
               <div class="review-icon"><img src="{{$data1['attachment']}}" alt="icon" width="100" height=100></div>
               <div class="review-content">

                  <h3>Title:{{$data1['title']}}</h3>
                  <h3>Booking id:{{$data1['booking_id']}}</h3>
                  <h3>Service provider type:@if($data1['provider_type']==1) People
                  @elseif($data1['provider_type']==2) Thing
                  @elseif($data1['provider_type']==3) Place
                  @endif</h3>
                  <span class="m-re"><button class = "add-review reviewsadddata" data-bookingid="{{$data1['booking_id']}}"  data-providerid="{{$data1['provider_id']}}" data-servicetype= "{{$data1['provider_type']}}" data-provideruserid= "{{$data1['provider_user_id']}}" > Add Review</button></span>
                  
               </div>
            </li>
        @endforeach
       </ul>
      
          
       </div>
       <div class="tab-pane container" id="home">
          <ul class="reviews-list two">
         
       </ul>
          
       </div>
       <div class="tab-pane container fade" id="menu1">
          <ul class="reviews-list three">
          
       </ul>            
       </div>
       <div class="tab-pane container fade" id="menu2">
          <ul class="reviews-list four">
          
       </ul>             
       </div>
       </div>
   </div>
  </div>
  </div>
</section>  

  <script>
  if($("#bookingscount").val()==0)
  {
    $("#reviewsval").val(0);
    swal("All Done", "Thanks for your feedback", "success")     
        .then((showmodal) => {
        if (showmodal) {                      
           window.location.href="{{url('/')}}" ;
        } 
    });    
  }

  $(".add-review").on('click',function(e){
    e.preventDefault();
    var bookid = $(this).attr('data-bookingid');
    var providerid = $(this).attr('data-providerid');
    var servicetypeid = $(this).attr('data-servicetype');
    var provideruserid = $(this).attr('data-provideruserid');
    $("#reviewrating").modal('show');
    $("#providerid").val(providerid);
    $("#bookingid").val(bookid);
    $("#servicetype").val(servicetypeid);
    $("#servicetype").val(servicetypeid);
    $("#provideruserid").val(provideruserid);
  });

  $(document).ready(function(){
  
  $('#stars li').on('mouseover', function(){
    var onStar = parseInt($(this).data('value'), 10);
    $(this).parent().children('li.star').each(function(e){
      if (e < onStar) {
        $(this).addClass('hover');
      }
      else {
        $(this).removeClass('hover');
      }
    });
    
  }).on('mouseout', function(){
    $(this).parent().children('li.star').each(function(e){
      $(this).removeClass('hover');
    });
  });
 
  $('#stars li').on('click', function(){
    var onStar = parseInt($(this).data('value'), 10); // The star currently selected
    var stars = $(this).parent().children('li.star');
    
    for (i = 0; i < stars.length; i++) {
      $(stars[i]).removeClass('selected');
    }
    
    for (i = 0; i < onStar; i++) {
      $(stars[i]).addClass('selected');
    }   
    var ratingValue = parseInt($('#stars li.selected').last().data('value'), 10);
    $("#rating").val(ratingValue);
    
  });
});



function responseMessage(msg) {
  $('.success-box').fadeIn(200);  
  $('.success-box div.text-message').html("<span>" + msg + "</span>");
}

$(".btn-rating").on('click',function(){
  if($("#rating").val()=="")
  {
    swal("OOPs!!",'Please give the rating','error');
    return false;
  }
})
  </script>
     
@endsection
     