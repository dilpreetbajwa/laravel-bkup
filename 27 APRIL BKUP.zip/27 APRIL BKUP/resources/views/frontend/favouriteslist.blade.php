@extends('layouts.frontend.master')
@section('content')
<style>
.search-bar
{
  display:none;
}
.bottom-cntnt {
    
    flex-wrap: unset;     
}
</style>
 
    
      <section class="Popular-task_1 comman-padding booking-c-main">
         <div class="container task-contain">
            <div class="places-form">
              <h2 class="border-bottom-content title-transact" style="margin-bottom: 20px">Favourites</h2>
               <div class="Tabs booking-tabs-cntnt">
               <!-- Nav pills -->
                  <ul class="nav nav-pills form_tabs">
                     <li class="nav-item">
                     <a class="nav-link active  tab_menu" data-toggle="pill" href="#home">Places</a>
                     </li>
                     <li class="nav-item">
                     <a class="nav-link tab_menu Cancelled" data-toggle="pill" href="#menu1">Things </a>
                     </li>
                     <li class="nav-item"> 
                     <a class="nav-link tab_menu completed" data-toggle="pill" href="#menu2">People</a>
                     </li>
                  </ul>
               <!-- Tab panes -->
                  <div class="tab-content">
                     <div class="tab-pane container active" id="home">
                        <div class="booking-list">
                          @if(count($data_place)>0)
                           @foreach($data_place as $value)
                           <div class="booking-inner">
                     <div class="booking-details-cntnt">
                        <div class="top-content">
                         
                        </div>
                        <div class="bottom-cntnt">
                           <div class="imge-book">
                              <img src="{{$value['image']}}" alt="image">
                           </div>
                           <div class="booking-opop">
                              <a>
                                 <h3 class="booking-title">Name : {{$value['title']}}</h3>
                                 <div class="guest-pricee">
                                    <p>Price : $ {{$value['price_per_night']}}</p>
                                    <p>Category : {{$value['category']}}</p>
                                 </div>
                                 <p>Location : {{$value['address']}}</p>
                              </a>
                              <div class="btn-contactt"><a href="{{url('/booking-historydetail').'/'.$value['encodedid']}}">
                                 </a><a class="contacthost" href="{{url('/booking-placeavailability').'/'.$value['encodedid']}}">Book</a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                           @endforeach
                             @else
                          <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
                          @endif

                        </div>
                     </div>
                     <div class="tab-pane container fade" id="menu1">
                        <div class="booking-list">
                         @if(count($data_thing)>0)
                          @foreach($data_thing as $value2)
                          <div class="booking-inner">
                         <div class="booking-details-cntnt">
                            <div class="top-content">
                              
                            </div>
                            <div class="bottom-cntnt">
                               <div class="imge-book">
                                  <img src="{{$value2['image']}}" alt="image">
                               </div>
                               <div class="booking-opop">
                                  <a>
                                     <h3 class="booking-title">Name : {{$value2['title']}}</h3>
                                     <div class="guest-pricee">
                                        <p>Price : $ {{$value2['price_per_night']}}</p>
                                        <p>Category : {{$value2['category']}}</p>
                                     </div>
                                     <p>Location : {{$value2['address']}}</p>
                                  </a>
                                  <div class="btn-contactt"><a href="javascript:void(0)">
                                     </a><a class="contacthost" href="{{url('/booking-thingavailability').'/'.$value2['encodedid']}}">Book</a>
                                  </div>
                               </div>
                            </div>
                         </div>
                      </div>
                          @endforeach
                         @else
                          <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
                          @endif
                             
                           </div>
                     </div>
                     <div class="tab-pane container fade" id="menu2">
                        <div class="booking-list">
                        @if(count($data_people)>0)
                          @foreach($data_people as $value1)
                          <div class="booking-inner">
                           <div class="booking-details-cntnt">
                              <div class="top-content">
                                
                              </div>
                              <div class="bottom-cntnt">
                                 <div class="imge-book">
                                   <img src="{{$value1['image']}}" alt="image">
                                 </div>
                                 <div class="booking-opop">
                                    <a>
                                       <h3 class="booking-title">Name : {{$value1['title']}}</h3>
                                       <div class="guest-pricee">
                                          <p>Price : $ {{$value1['price_per_night']}}</p>
                                          <p>Category : {{$value1['category']}}</p>
                                       </div>
                                       <p>Location :  {{$value1['address']}}</p>
                                    </a>
                                    <div class="btn-contactt"><a href="javascript:void(0)">
                                       </a><a class="contacthost" href="{{url('/booking-peopleavailability').'/'.$value1['encodedid']}}">Book</a>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                           @endforeach
                           @else
                              <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
                              @endif
                        </div>
                     </div>
                     </div>
                  </div>
               </div>
          </div>
      </section> 

      @endsection

   