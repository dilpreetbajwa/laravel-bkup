@extends('layouts.frontend.master')
@section('content')
<style>
.search-bar
{
  display: none;
}
.couponapply
{
  color: darkgreen;
  font-weight: 500;
}
</style>
      <!-- About place -->
        <script type="text/javascript" src="https://js.stripe.com/v2/"></script>
      <section class="Popular-task_1 comman-padding more-about-thing">
         <div class="container task-contain">
            <div class="places-form">
               <div class="fixed-content">
               <div class="col-main-left">
               <div class="full-width-text content-info m-none border-bottom-content">
                  <div class="content-info-inner">
                  <h2>{{@$provider_data['title']}}</h2>
                    <div class="star-review">
                     <ul>                     
                    <?php  
                    for($i=0;$i<$provider_data['ratings'];$i++) {?>
                        <li><img src="{{url('/web/images/').'/star.png'}}" alt="icon"></li> 
                      <?php } ?> 
                       <?php  for($i=1;$i<=5-$provider_data['ratings'];$i++) {?>
                       <li><img src="{{url('/web/images/').'/greystar.png'}}" alt="icon"></li> 
                    <?php } ?> 
                     </ul><span class="review-count">
                     {{@$allreviewscount}}
                     @if(@$allreviewscount>1)Reviews
                      @else
                      Review
                     @endif
                     </span>
                  </div>
                  <div class="dec-content">
                     <h4>{{@$no_of_days}} nights</h4>
                     <div class="dates-travel">
                        <div class="date-check check-in">
                           <div class="date-c">
                              <span>{{$datemonthin}}<br>{{$datedayin}}</span>
                           </div>
                           <div class="date-content">
                              <p>check-in</p>
                              <p id="check_in">{{@$time_in}}</p>
                               <input type="hidden" id="checkindate" value="{{@$checkindate}}">
                           </div>
                        </div>
                        <div class="date-check check-out">
                           <div class="date-c">
                              <span>{{$datemonthout}}<br>{{$datedayout}}</span>
                           </div>
                           <div class="date-content">
                              <p>check-out</p>
                             <p id="check_out">{{@$time_out}}</p>
                              <input type="hidden" id="checkoutdate" value="{{@$checkoutdate}}">
                           </div>
                        </div>
                     </div>
                  </div>
                  </div>
               </div>
               <!-- <div class="full-width-text border-bottom-content">
                  <h3>Collections Policy</h3>
                  <p>We offers our guests with luxurious Suite Cottages which are beautifully designed, spacious, well-illuminated and have comfortable beds...</p>
               </div> -->
               <div class="full-width-text border-bottom-content">
                  <h3>Rules of Conduct</h3>
                  <p>{{@$provider_data['rules']}}</p>
               </div>
               <!-- <div class="full-width-text content-info border-bottom-content">
                  <div class="content-left-info">
                  <h3>Say hello to your host</h3>
                  <p>Let Ashish Know a little about yourself and why you're coming...</p>
                  </div>
                  <div class="content-right-info">
                     <div class="info-img">
                        <img src="images/info-au.png" alt=""/>
                        <p>2542-4150-40</p>
                     </div>
                  </div>
               </div> -->
            </div>
            <div class="side-bar">
               <form action="" method="">
                  <div class="side-bar-form">
                     <div class="heading-desc">
                         <div class="cntnt-left-h">
                          <input type="hidden" name="type" id="type" value="2">
                            <input type="hidden" name="provider_id" id="provider_id" value="{{@$provider_data['id']}}">
                            <input type="hidden" name="coupon_id" id="coupon_id" value="">
                           <h4>{{@$provider_data['title']}}</h4>
                           <span><?php 
                                if(str_word_count(@$provider_data['description'])>10)
                                {
                                 
                                  echo implode(' ', array_slice(explode(' ', @$provider_data['description']), 0, 10)).'  ......';
                                }
                                else
                                {                                 
                                  echo @$provider_data['description'];
                                } ?></span>
                        </div>
                        <div class="cntnt-right-h">
                           <img src="{{url('web/images/h-img.png')}}" alt="">
                        </div>
                     </div>
                     <input type="hidden" name="providerid" id="providerid" value="{{@$providerid}}"> 
                     <input type="hidden" name="type" id="type" value="2"> 
                     <div class="guets-cunt">
                     
                     </div>

                     <div class="date-cunt">
                        <svg viewBox="0 0 24 24" role="presentation" aria-hidden="true" focusable="false" style="height:20px;width:20px;display:block;fill:currentColor"><path d="m22 9.5v-1.5-5h-4.75v-2c0-.41-.34-.75-.75-.75s-.75.34-.75.75v2h-7.5v-2c0-.41-.34-.75-.75-.75s-.75.34-.75.75v2h-4.75v5 1.5 12.51c0 .54.44.99.99.99h18.02c.54 0 .99-.44.99-.99zm-18.5-5h3.25v.5c0 .41.34.75.75.75s.75-.34.75-.75v-.5h7.5v.5c0 .41.34.75.75.75s.75-.34.75-.75v-.5h3.25v3.5h-17zm0 17v-12h17v12z" fill-rule="evenodd"></path></svg><span>{{$datedaydatein}}</span>
                        <svg viewBox="0 0 24 24" role="presentation" aria-hidden="true" focusable="false" style="width:15px;display:block;fill:currentColor"><path d="m0 12.5a.5.5 0 0 0 .5.5h21.79l-6.15 6.15a.5.5 0 1 0 .71.71l7-7v-.01a.5.5 0 0 0 .14-.35.5.5 0 0 0 -.14-.35v-.01l-7-7a .5.5 0 0 0 -.71.71l6.15 6.15h-21.79a.5.5 0 0 0 -.5.5z" fill-rule="evenodd"></path></svg>
                        <span>{{$datedaydateout}}</span>
                     </div>
                     <div class="pay-with">
                       <h2>PAY WITH</h2>
                       <div class="pay-method">
                          <label for="card" id="payment_open" class="c-pay">
                          <input type="radio" name="pay" value="card" id="card" class="radio_button1">
                          <span>Credit/Debit Card</span>
                          <div class="pay-options">
                             
                                <div class="card-info">
                                       <?php if(!empty($successMessage)) { ?>
<div id="success-message"><?php echo $successMessage; ?></div>
<?php  } ?>
<div id="error-message"></div>

<form id="frmStripePayment" action="" method="post">
    <div class="field-row">
        <label>Card Holder Name</label> <span id="card-holder-name-info"
            class="info"></span><br> <input type="text" id="name"
            name="name" class="demoInputBox">
    </div>
    <div class="field-row">
        <label>Email</label> <span id="email-info" class="info"></span><br>
        <input type="text" id="email" name="email" class="demoInputBox">
    </div>
    <div class="field-row">
        <label>Card Number</label> <span id="card-number-info"
            class="info"></span><br> <input type="text" id="card-number"
            name="card-number" class="demoInputBox">
    </div>
    <div class="field-row">
        <div class="contact-row column-right">
            <label>Expiry Month / Year</label> <span id="userEmail-info"
                class="info"></span><br> <select name="month" id="month"
                class="demoSelectBox" style="width:45%">
                <option value="01">01</option>
                <option value="02">02</option>
                <option value="03">03</option>
                <option value="04">04</option>
                <option value="05">05</option>
                <option value="06">06</option>
                <option value="07">07</option>
                <option value="08">08</option>
                <option value="09">09</option>
                <option value="10">10</option>
                <option value="11">11</option>
                <option value="12">12</option>
            </select> <select name="year" id="year"
                class="demoSelectBox" style="width:45%">
               <?php for($i=2020; $i<=2070;$i++){
               $y = substr( $i, -2);?>
                <option value="{{$y}}">{{$i}}</option>
              <?php }?>
               
            </select>
        </div>
        <div class="contact-row cvv-box">
            <label>CVC</label> <span id="cvv-info" class="info"></span><br>
            <input type="text" name="cvc" id="cvc"
                class="demoInputBox cvv-input">
        </div>
    </div>
    <div class="pay-submit">
     
        <input type="submit" name="pay_now" value="Pay Now"
            id="submit-btn" class="btnAction paynow-btn"
            onClick="stripePay(event);">

        <!-- <div id="loader">
            <img alt="loader" src="LoaderIcon.gif">
        </div> -->
    </div>
    <input type='hidden' name='amount' value='0.5'> <input type='hidden'
        name='currency_code' value='USD'> <input type='hidden'
        name='item_name' value='Test Product'> <input type='hidden'
        name='item_number' value='PHPPOTEG#1'>
</form>
                                     <!--  <p>Card Info</p> -->
                                      <!-- <div id="dropin-container"></div> -->
                                      <!-- <input class="cc-number" maxlength="19" name="credit-number" pattern="\d*" placeholder="Card Number" type="tel">
                                      <input class="cc-expires" maxlength="7" name="credit-expires" pattern="\d*" placeholder="MM / YY" type="tel">
                                      <input class="cc-cvc" maxlength="4" name="credit-cvc" pattern="\d*" placeholder="CVC" type="tel"> -->
                                </div>
                                <!-- <div class="other-info">
                                      <div class="billing-info">
                                            <p>Billing info</p>
                                            <input type="text" name="zcode" placeholder="ZIP Code">
                                      </div>
                                      <div class="billing-info">
                                            <p>Country/region</p>
                                            <select class="cuntry">
                                               <option>United Kingdom</option>
                                            </select>
                                      </div>
                                </div> -->
                          </div>
                          </label>
                         <!--  <label for="paypal"   id="paypal_option" class="pp-pay">
                           <input type="radio" name="pay" value="paypal" class="radio_button1"> 
                           <span>PayPal</span>
                           <div class="pay-options">
                                 <h3>Pay with</h3>
                                 
                                 <input type="text" class="pp-id" placeholder="PayPal Id"/>
                              </div>
                           </label>
                           <div id="paypal-button"></div> -->
                       </div>
                    </div>
                    <div class="border-bottom-content price-total">
                        <div class="side-bar-lt-cntnt">$
                         <span class="payplaces">  {{@$provider_data['price_per_night']}} X {{@$no_of_days}} nights</span>
                        <!--  <div class="discount">Discount Value</div> -->
                        </div>
                        <div class="side-bar-rt-cntnt original_amount">$
                       <span>  <?php echo $provider_data['price_per_night']* $no_of_days?></span>
                       <!--  <div>$ <?php ?></div> -->
                     </div>
                     </div>
                     <div class="border-bottom-content price-total price-discount" style="display:none">
                        <div class="side-bar-lt-cntnt">
                         <span class="payplaces">  Discount</span>
                        <!--  <div class="discount">Discount Value</div> -->
                        </div>
                        <div class="side-bar-rt-cntnt">- $
                       <span class="discounted-value"> </span>
                       <!--  <div>$ <?php ?></div> -->
                     </div>
                     </div>

                     

                      <div class="border-bottom-content coupon-add">
                        <div class="side-bar-cp-add">
                         <img src="{{url('web/images/add-cupn-img.png')}}" alt="icon">
                       <a href="javascript:void(0)"><span class="addcoupon">Add Coupon</span></a>
                       <span class="showcode" style="display:none">
                         <input type="text" name="couponcode" id="couponcode" class="form-control" placeholder="Enter coupon code">
                         <div class="coupontext" style="display:block">
                           <a name="applycouponcode" id="applycouponcode" href="javascript:void(0)">apply</a>
                            <span class="couponapply"></span>
                           <a name="removecouponcode" id="removecouponcode" href="javascript:void(0)" style="float:right">remove</a>
                         </div>
                         <div class="errmsgcoupon" style="color:red;text-align: center"></div>
                       </span>
                     </div>
                     </div>
                     <!-- <div class="border-bottom-content coupon-add">
                        <div class="side-bar-cp-add">
                         <img src="{{url('web/images/add-cupn-img-thing.png')}}" alt="icon">
                       <span>Add Coupon</span>
                     </div>
                     </div> -->
                     <div class="price-total">
                        <div class="side-bar-lt-cntnt">
                         <span>Total(Dollars)</span>
                        </div>
                        <div class="side-bar-rt-cntnt final" id="final_amt">$
                       <span> <?php echo $provider_data['price_per_night']* $no_of_days?></span>
                     </div>
                     </div>
                  </div>
               </form>
             <!--  <a href="javascript:void(0)" id="paynow" class="paynow-btn">Pay Now</a> -->
            </div>
         </div>
            </div>
          </div>
      </section>  

   
       <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
       <link rel="stylesheet" href="/resources/demos/style.css">
      <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
      <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
       <script src="https://timernr.com/web/js/owl.carousel.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
      
      

       
      <script>
      (function($) {
       $(document).ready(function(){


    $('.paynow-btn').click(function(e) {
      e.preventDefault();
       if($('.radio_button1').is(':checked')){} else{ swal("","Please select the payment method",'error'); }
    });  
        $(".owl-carousel").owlCarousel({
            loop:true,
             margin:10,
             autoplay:true,
             autoplayTimeout:4000,
             autoplayHoverPause:true,
             responsiveClass:true,
             responsive:{
               300:{
                 items:1,
                 nav:true
               },
               767:{
                 items:1,
                 nav:true
               },
               1000:{
                 items:1,
                 nav:true,
                 loop:false
               }
             }
         });
       });
      }) (jQuery);

      $(".btn-show-all").on('click',function(){
        $(".showallamenties").show();
       $(".showtwoamenties").hide();

      })

      

     

    function addMarker(latlng,title,map) {
      var marker = new google.maps.Marker({
      position: latlng,
      map: map,
      title: title,
      draggable:false
      });
    }


    function initialise() {
      var latitude = $("#latval").val();
      var longitude = $("#lngval").val();    
      var myLatlng = new google.maps.LatLng(latitude,longitude);
      var myOptions = {
        zoom: 8,
        center: myLatlng,
        mapTypeId: google.maps.MapTypeId.ROADMAP
      }
      var map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
      addMarker(myLatlng, 'Default Marker', map);

  }
      </script>
  <script type="text/javascript" src="https://maps.google.com/maps/api/js?key=AIzaSyC29SOMdVFnuCgpVR9VFbeARVJqDJ7tJ-w&callback=initialise"></script> 

  <script type="text/javascript">
    var a = $("#unavldates").val();

    var arr = a.split(',');
    var unavailableDates = arr;
    function unavailable(date) {
      dmy = date.getFullYear()+ "-" + (date.getMonth() + 1) + "-" +date.getDate() ;
          if ($.inArray(dmy, unavailableDates) == -1) {
              return [true, ""];
          } else {
              return [false, "", "Unavailable"];
          }
      }

    $(function() {
        $("#iDate").datepicker({
            dateFormat: 'yy-mm-dd',
            beforeShowDay: unavailable
        });
         $("#oDate").datepicker({
            dateFormat: 'yy-mm-dd',
            beforeShowDay: unavailable
        });

    });
</script>
<!-- Load Hosted Fields component. -->
<script src="https://js.braintreegateway.com/web/3.56.0/js/hosted-fields.min.js"></script>

<!-- Load PayPal's checkout.js Library. -->
<script src="https://www.paypalobjects.com/api/checkout.js" data-version-4 log-level="warn"></script>

<!-- Load the client component. -->
<script src="https://js.braintreegateway.com/web/3.56.0/js/client.min.js"></script>

<!-- Load the PayPal Checkout component. -->
<script src="https://js.braintreegateway.com/web/3.56.0/js/paypal-checkout.min.js"></script>
<script>
 var base_url = "<?php echo url('/'); ?>";
   $(function() {
    $('#payment_open').on('click',function(e){
       $(".card-info").show();
      /*var data1 = '_token= {{csrf_token()}}';
      var type = $("#type").val();
      var timein = $("#check_in").html();
      var timeout = $("#check_out").html();
      var checkin = $("#checkindate").val();
      var checkout = $("#checkoutdate").val();

      var providerid = $("#provider_id").val();
      var couponid = $("#coupon_id").val();
          $.ajax({
                 type: "POST",
                 url: "{{route('token')}}", 
                 data: data1,
                    success: function(response){
                     console.log(response);
                     if(response.status == true){

                        var button = document.querySelector('#submit-button');
                        var form = document.querySelector('#my-payment-form');
                       

                      var button = document.querySelector('#submit-button');
                      braintree.dropin.create({
                              authorization: response.data,
                              container: '#dropin-container',
                               
                      
                        }, function (createErr, instance) {

                           var submit = document.querySelector('#paynow');

                           submit.addEventListener('click', function () {
                          instance.requestPaymentMethod(function (err, payload) {
                           console.log(payload);

                           /****************************/
                           /*var amount = $('#final_amt').find('span').html();
                           var provider_id = $("#providerid").val();
                           
                          var data = 'amount='+ amount +'&nonce='+ payload.nonce + '&_token= {{csrf_token()}}'+'&type='+type+'&check_in='+checkin+'&check_out='+checkout+'&provider_id='+providerid+'&coupon_id='+couponid+'&time_in='+timein+'&time_out='+timeout;
                                   $.ajax({
                                     type: 'POST',
                                     url: "{{route('payment')}}", 
                                     data: data,                                   
                                  }).done(function(result) {
                                     swal("Good job!", "Payment done successfully", "success") ;
                                        window.location.href = "{{url('/bookings-history')}}";
                              });*/
                                 

                           /****************************/


                        /*  });
                       });
                        });

                     }
                  }

           });*/
       });
    });




</script>

<script>
   function cardValidation () {
    var valid = true;
    var name = $('#name').val();
    var email = $('#email').val();
    var cardNumber = $('#card-number').val();
    var month = $('#month').val();
    var year = $('#year').val();
    var cvc = $('#cvc').val();

    $("#error-message").html("").hide();

    if (name.trim() == "") {
        valid = false;
    }
    if (email.trim() == "") {
         valid = false;
    }
    if (cardNumber.trim() == "") {
         valid = false;
    }

    if (month.trim() == "") {
          valid = false;
    }
    if (year.trim() == "") {
        valid = false;
    }
    if (cvc.trim() == "") {
        valid = false;
    }

    if(valid == false) {
        $("#error-message").html("All Fields are required").show();
    }

    return valid;
}
//set your publishable key
Stripe.setPublishableKey("pk_test_TvnKsuyonC0Uze3UkqnJkYcw00lQ92HYiV");

//callback to handle the response from stripe
function stripeResponseHandler(status, response) {
    if (response.error) {
        //enable the submit button
        $("#submit-btn").show();
        $( "#loader" ).css("display", "none");
        //display the errors on the form
        $("#error-message").html(response.error.message).show();
    } else {

        //get token id
        var token = response['id'];
        
        //insert the token into the form
        $("#frmStripePayment").append("<input type='hidden' name='stripetoken' value='" + token + "' />");
        var data1 = '_token= {{csrf_token()}}';
        var type = $("#type").val();
        var timein = $("#check_in").html();
        var timeout = $("#check_out").html();
        var providerid = $("#provider_id").val();
        var couponid = $("#coupon_id").val();
        var checkin = $("#checkindate").val();
        var checkout = $("#checkoutdate").val();
        //submit form to the server
        var amount = $('#final_amt').find('span').html();
                         
                           var data = 'amount='+ amount + '&_token= {{csrf_token()}}'+'&type='+type+'&check_in='+checkin+'&check_out='+checkout+'&provider_id='+providerid+'&coupon_id='+couponid+'&time_in='+timein+'&time_out='+timeout+'&stripetoken='+token;
                                 $.ajax({
                                   type: 'POST',
                                   url: "{{route('payment')}}", 
                                   data: data,                                   
                                }).done(function(result) {
                                  $(".payplaces").html("O Nights");
                                   $(".finalplaceamt").html("0");
                                   swal("Good job!", "Payment done successfully", "success") ;
                                   
                                   window.location.href = "{{url('/bookings-history')}}";
                              });
    }
}
function stripePay(e) {
    e.preventDefault();
    var valid = cardValidation();

    if(valid == true) {
        $("#submit-btn").hide();
        $( "#loader" ).css("display", "inline-block");
        Stripe.createToken({
            number: $('#card-number').val(),
            cvc: $('#cvc').val(),
            exp_month: $('#month').val(),
            exp_year: $('#year').val()
        }, stripeResponseHandler);

        //submit from callback
        return false;
    }
}

 
    $(".addcoupon").on('click',function(){
      $(".showcode").toggle();
   })

   var initial_amount = $('#final_amt').find('span').html();
   $("#applycouponcode").on('click',function(){
      var txtcoupon = $("#couponcode").val();
      var type = $("#type").val();
      var amount = $('#final_amt').find('span').html();
      if(txtcoupon=="")
      {
        $(".errmsgcoupon").html("Please fill in the coupon");
      }
      else
      {
         $.ajax({
            type: "POST",
            url: base_url+'/applycoupon',
            data: {
              "_token": token,
              'amount': amount,
              'couponcode':txtcoupon,
              'type':type
            },
            success: function(data) {
              if(data.status ==0){
                $(".errmsgcoupon").html(data.message);
              }
              if(data.status ==2){
                $(".errmsgcoupon").html(data.message);
              }
              else if(data.status ==1){
                $(".price-discount").show();
               
               
                $('#final_amt').find('span').html(data.amount);
                $(".side-bar-rt-cntnt").find('span').html(data.amount);
                $("#coupon_id").val(data.coupon_id);
                $(".couponapply").show();
                $(".couponapply").html('Coupon applied successfully');
                 $(".discounted-value").html(data.discount);
                 $(".original_amount").html("$ "+data.original_amount);
                 $("#applycouponcode").hide();
                 $(".errmsgcoupon").html("");

              }
            }
        });
      }
   });


    $("#removecouponcode").on('click',function(){

       var txtcoupon = $("#couponcode").val();
       $("#applycouponcode").show();
        $("#applycouponcode").text('apply');
        $(".couponapply").hide();
      if(txtcoupon=="")
      {
        $(".errmsgcoupon").html("Please fill in the coupon");
      }
      else{
      $("#couponcode").val("");
      $(".price-discount").hide();
      $('#final_amt').find('span').html(initial_amount);
      $(".side-bar-rt-cntnt").find('span').html(initial_amount);

    }
   })







</script>
    @endsection