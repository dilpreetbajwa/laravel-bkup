@extends('layouts.frontend.master')
@section('content')
<style>
.search-bar
{
  display: none;
}
</style>

      <!-- About place -->
       <input type="hidden"  id = "latval" value="{{$data['data']['latitude']}}">
      <input type="hidden"  id = "lngval" value="{{$data['data']['longitude']}}">

      <section class="Popular-task_1 comman-padding booking-c-main">
         <div class="container task-contain">
            <div class="places-form">
               <div class="fixed-content">
               <div class="col-main-left">
               <div class="full-width-text content-info m-none border-bottom-content">
                  <div class="content-info-inner">

                  <h2>{{$data['data']['title']}}</h2>
                  <div class="star-review">
                     <div class="rating-result" title="99%">
                        <span style="width: 87%;"></span>
                     </div>
                     <p class="review-count">{{$data['data']['reviews_count']}}Reviews</p>
                  </div>
              
                  <div class="dec-content">
                  <?php 

                $timeDiff = abs(strtotime($data['data']['check_out']) - strtotime($data['data']['check_in']));
                $no_of_days = $timeDiff/86400;
                $datemonthin = date('M', strtotime($data['data']['check_in'])); 
                $datedayin = date('d', strtotime($data['data']['check_in'])); 
                $datedaydatein = date('M d, Y', strtotime($data['data']['check_in']));
                $nameOfDaydatein = date('l', strtotime($data['data']['check_in']));

                $datemonthout = date('M', strtotime($data['data']['check_out'])); 
                $datedayout = date('d', strtotime($data['data']['check_out'])); 
                $datedaydateout = date('M d, Y', strtotime($data['data']['check_out']));
                $nameOfDaydateout = date('l', strtotime($data['data']['check_out']));
                ?>
                     <h4><?= $no_of_days ?> nights in {{$data['data']['title']}}</h4>
                     <div class="dates-travel">
                        <div class="date-check check-in">
                           <div class="date-c">
                              <span><?=$datemonthin?><br>{{$datedayin}}</span>
                           </div>
                           <div class="date-content">
                              <p><?= $nameOfDaydatein?> check-in</p>
                              <p>{{$data['data']['time_in']}}</p>
                           </div>
                        </div>
                        <div class="date-check check-out">
                           <div class="date-c">
                              <span>{{$datemonthout}}<br>{{$datedayout}}</span>
                           </div>
                           <div class="date-content">
                              <p><?= $nameOfDaydateout ?> check-out</p>
                              <p>{{$data['data']['time_out']}}</p>
                           </div>
                        </div>
                     </div>
                  </div>
                  </div>
               </div>
               @if($data['provider_type']==3)
               <div class="full-width-text content-info border-bottom-content">
                  <div class="content-left-info">
                 <!--  <h3>Say hello to your host</h3>
                  <p>Let {{$data['data']['hostname']}} Know a little about yourself and why you're coming...</p> -->

                @if($data['data']['status']==2  &&    $data['data']['bookings_cancelled_by_me']=="true") 
                    Booking Cancelled by me
                  @elseif($data['data']['status']==2)    
                     Booking Cancelled by {{$data['data']['cancelled_by']}}
                @endif
                  </div>
                  <div class="content-right-info">

                     <div class="info-img">
                        <img src="images/info-au.png" alt=""/>
                        @if($data['data']['hostphone'] !="")
                        <p>+<?= substr($data['data']['hostphone'],0,2);?>-<?= substr($data['data']['hostphone'],2);?></p>
                        @endif
                     </div>
                  </div>
               </div>
               @endif
               <div class="showcancel" name="showcancel" style="background:#E04F60;padding: 7px;color: #fff;font-weight: bold;text-align: center; display: none">
               </div>
               <div class="book-cancl-buttons">
                  <a href="{{url('/request_bookinglist')}}" class="b-btn">Back</a>
              @if($data['data']['status']==1)    
               <a href="javascript:void(0)" data-id="{{$data['data']['booking_id']}}" data-userid ="{{Auth::id()}}" class="c-btn">Cancel Booking</a>
               @else
               <a href="{{url('/contact-us')}}" data-userid ="{{Auth::id()}}" style="background: #ff6e71" class="">Support</a>
              @endif
               </div>
            </div>
            <div class="side-bar-bokking">
               <div class="book-location">
                  <h3>Location</h3>
                  <div id="map_canvas"></div>
               </div>
               <h2 class="price-list-form border-bottom-content">${{$data['data']['price_per_night']}}<span>per night</span></h2>
               <div class="border-bottom-content price-total">
                  <div class="side-bar-lt-cntnt">

            <?php 
              if($data['provider_type']==1){

                $timeDiff = abs(strtotime($data['data']['check_out']) - strtotime($data['data']['check_in']));
                if($timeDiff == 0)
                  $no_of_days = 1; 
                else
                 $no_of_days = $timeDiff/86400; 
              }
                else{

                $timeDiff = abs(strtotime($data['data']['check_out']) - strtotime($data['data']['check_in']));
                $no_of_days = $timeDiff/86400;
              }
                $datemonthin = date('M', strtotime($data['data']['check_in'])); 
                $datedayin = date('d', strtotime($data['data']['check_in'])); 
                $datedaydatein = date('M d, Y', strtotime($data['data']['check_in']));
                $datemonthout = date('M', strtotime($data['data']['check_out'])); 
                $datedayout = date('d', strtotime($data['data']['check_out'])); 
                $datedaydateout = date('M d, Y', strtotime($data['data']['check_out']));
            ?>
               <span>  $ {{$data['data']['price_per_night']}} X <?= $no_of_days ?> nights</span>


               
                  </div>

                  <div class="side-bar-rt-cntnt">
                 <span> $ <?php echo $data['data']['price_per_night'] * $no_of_days ?> </span>
               </div>
                 
                

               </div>
                @if(@$data['data']['discount'])
                <div class="price-total">
                  <div class="side-bar-lt-cntnt">
                   <span>Discount</span>
                  </div>
                  <div class="side-bar-rt-cntnt">
                     <span> 
                     - $ <span>  {{@$data['data']['discount']}}</span>
                    </span>
                  </div>
               </div>
               @endif
               <div class="price-total">
                  <div class="side-bar-lt-cntnt">
                   <span>Total(GBP)</span>
                  </div>
                  <div class="side-bar-rt-cntnt">
                 <span> $ {{$data['data']['total_amount']}}</span>
               </div>
               </div>
               
            </div>
         </div>
            </div>
          </div>
      </section>  

      <script>
      var token = "{{ csrf_token() }}";   

      function addMarker(latlng,title,map) {
      var marker = new google.maps.Marker({
      position: latlng,
      map: map,
      title: title,
      draggable:false
      });
    }

    function initialise() {
      var latitude = $("#latval").val();
      var longitude = $("#lngval").val();    
      var myLatlng = new google.maps.LatLng(latitude,longitude);
      var myOptions = {
        zoom: 8,
        center: myLatlng,
        mapTypeId: google.maps.MapTypeId.ROADMAP
      }
      var map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
      addMarker(myLatlng, 'Default Marker', map);

  }

  $(".c-btn").on('click',function(e){
    e.preventDefault();
    var bookingid = $(this).attr('data-id');
    var userid = $(this).attr('data-userid');    
    swal({
      title: "Are you sure to cancel booking?",
      text: "",
      icon: "warning",
      buttons: true,
      dangerMode: true,
    })
    .then((willDelete) => {
      if (willDelete) {
        $.ajax({
        type: "POST",
        url: "{{url('/cancel-booking')}}",
        data: {
          "_token": token,
          'bookingid':bookingid,
          'userid':userid
        },
        success: function(data) {
          e.preventDefault();
          $(".showcancel").fadeIn(2000);
          $(".showcancel").html(data.msg);  
          swal("Booking Cancel","Booking has been cancelled","error");
          $(".c-btn").remove();

        }
        });
      } 
    });
  })


  </script>
  <script type="text/javascript" src="https://maps.google.com/maps/api/js?key=AIzaSyC29SOMdVFnuCgpVR9VFbeARVJqDJ7tJ-w&callback=initialise"></script> 
@endsection