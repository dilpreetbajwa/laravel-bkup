@extends('layouts.frontend.master')
@section('content')

<style>
.search-bar
{
  display:none;
}
</style>


<section class="Popular-task_1 comman-padding booking-c-main notificationdata">
         <div class="container task-contain">
            <div class="places-form">
               <h2 class="border-bottom-content title-transact">Notifications</h2>
               <div class="Tabs booking-tabs-cntnt service-revices">
                  <div class="tab-content">
                     <div class="tab-pane container active" id="home">
                        <ul class="reviews-list notification-cmt">
                        @if(count($data)>0)
                          @foreach($data as $d)   
                           @if($d['type']==1 || $d['type']==2)                     
                            <a  class = "notify-data" data-notifyid = "{{$d['notifyid']}}" data-url="{{url('booking-historydetail/').'/'.$d['id']}}" href="javascript:void(0)">@endif                      
                          <li <?php if($d['readstatus']==0) echo "style=color:darkslategray";?>>
                             <div class="review-icon notification">
                              @if($d['image']!="")
                               <img src="{{$d['image']}}" alt="icon">
                              @else
                                <img src="https://timernr.com/profile/1576826696.png" alt="icon">
                                @endif
                             </div>
                             <div class="review-content">
                                <h3>{{@$d['name']}}</h3>
                               
                                <p class="review-date">{{@$d['time']}}</p>
                                <p>{{@$d['message']}}</p>
                             </div>
                          </li>
                          @if($d['type']==1 || $d['type']==2 )
                            </a>
                          @endif
                          @endforeach 
                        @else
                        <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
                        @endif

                     </ul>
                     {{$notification->links()}}
                    <!--  -->
                     </div>
                    
                     </div>
                  </div>
               </div>
          </div>
      </section> 



<script>
  $(document).ready(function (){
    $(".notify-data").on('click',function(e){

      e.preventDefault();
      var id = $(this).attr('data-notifyid');
      var url =$(this).attr('data-url');
     
        $.ajax({
             url: "{{url('/updatenotifystatus')}}",
             type: 'POST', 
             data:   {
                "_token":token,
               "id":id              
             },
            success: function(response){
             window.location.href= url;
            }, 
         }); 

     
    })
  });

</script>


@endsection