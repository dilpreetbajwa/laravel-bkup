@extends('layouts.frontend.master')
@section('content')

<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/taras-d/images-grid/src/images-grid.min.css">
<style>
.search-bar
{
  display: none;
}

.imgs-grid {
  max-width: 100% !important;   
}
  #map_canvas
  {
    position: relative!important;
    width:100%!important;
    height:20vw!important;
  }
  button.owl-prev {
  float: left;
  left: 0;
  position: absolute;
  top: 50%;
  }
  button.owl-next {
  float: right;
  right: 0;
  top: 50%;
  position: absolute;
  }
</style>

 <section class="Popular-task_1 comman-padding more-about-thing">
         <div class="container task-contain">
            <div class="things-innerpage-content">
                <div class="row bx-banner-images">
                  <div id="gallery"></div>
               </div>
               <div class="full-width-text border-bottom-content">

                   <h3>{{$thingsdetails->title}}</h3>
                  <p>{{$thingsdetails->description}}</p>
               </div>
               <input type="hidden"  id = "latval" value="{{$thingsdetails->latitude}}"">
                <input type="hidden"  id = "lngval" value="{{$thingsdetails->longitude}}"">
                <form method="post">
                 <input type="hidden"  id = "providerid" value="{{$thingsdetails->id}}">
                 <input type="hidden" name="_token" id="csrf-token" value="{{ Session::token() }}" />
                 </form>
               <!-- <div class="full-width-text border-bottom-content">
                  <h3>Collection Policy</h3>
                  <p>We offers our guests with luxurious Suite Cottages which are beautifully designed, spacious, well-illuminated and have comfortable beds. These rooms are enabled with all the modern... </p>
               </div> -->
               <div class="pick-up-time full-width-text border-bottom-content">
                  <div class="row">
                     <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                        <div class="heading-content">
                           <h4>Pick Up Time</h4>
                           <p>{{$thingsdetails->time_in}}</p>
                        </div>
                        <div class="heading-content">
                           <h4>Rate</h4>
                           <p>$200</p>
                        </div>
                     </div>
                     <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12">
                        <div class="heading-content-right">
                           <h4>Drop off Time</h4>
                           <p>{{$thingsdetails->time_out}}</p>
                        </div>
                     </div>
                  </div>
               </div>
               <div class="full-width-text">
                  <h3>Pick Up Location</h3>
                   <div id="map_canvas"></div>
               </div>
               <div class="form-action-button">
                  <button type="cancel" class="btnn btn-cancel" value="Cancel">Confirm</button>
                  <button type="submit" class="btnn btn-next" value="next">Cancel</button>
                </div>
            </div>
          </div>
      </section>  
       <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
       <script src="https://timernr.com/web/js/owl.carousel.js"></script>
        <script src="https://cdn.jsdelivr.net/gh/taras-d/images-grid/src/images-grid.min.js"></script>
       
      <script>
      (function($) {
       $(document).ready(function(){
        $(".owl-carousel").owlCarousel({
            loop:true,
             margin:10,
             autoplay:true,
             autoplayTimeout:4000,
             autoplayHoverPause:true,
             responsiveClass:true,
             responsive:{
               300:{
                 items:1,
                 nav:true
               },
               767:{
                 items:2,
                 nav:true
               },
               1000:{
                 items:2,
                 nav:true,
                 loop:false
               }
             }
         });
       });
      }) (jQuery);

      $(".btn-show-all").on('click',function(){
        $(".showallamenties").show();
       $(".showtwoamenties").hide();

      })

      $(".btn-cancel").click(function(event){
        event.preventDefault();
        var id = $("#providerid").val();
        
        swal({
          title: "Confirm Details",
          text: "Are you sure to confirm the details?",
           icon: "warning",
           buttons: true
        }).then((willConfirm) => {
          if (willConfirm) {
           $.ajax({
             url: "{{url('/confirmthings')}}",
             type: 'POST', 
             data:   {    
               "_token": token,
               'id':id,
               'type':1
             },
            success: function(response){
               if(response == 1)
               {
                swal("Good job!", "Details saved successfully", "success").then((willDelete) => {
                if (willDelete)
                window.location.href="{{url('/')}}";
            });
               }
               else{
                 
               }
             },    
           });
         }
        });       
      })

      $(".btn-next").click(function(event){
        event.preventDefault();
        var id = $("#providerid").val();
        swal({
          title: "Details not confirmed!!!",
          text: "Are you sure you want to cancel posting place?",
          icon: "warning",
          buttons: true,
          dangerMode: true
        }).then((willDelete) => {
          if (willDelete) {         
          $.ajax({
          url: "{{url('/confirmthings')}}",
          type: 'POST', 
          data:   {    
            "_token": token,
            'id':id,
            'type':2
           },
          success: function(response){
           if(response == 1)
            {
              swal({
                title: "Details deleted!!!",
                text: "Details not saved",
                icon: "info",
                buttons: true,
                dangerMode: true
              }).then((willDelete) => {
                if (willDelete)
                window.location.href="{{url('/')}}";

              });
            }
            else{
              
            }
           },    
         });
        }
        });
      })
     

    function addMarker(latlng,title,map) {
      var marker = new google.maps.Marker({
      position: latlng,
      map: map,
      title: title,
      draggable:false
      });
    }


    function initialise() {
      var latitude = $("#latval").val();
      var longitude = $("#lngval").val();    
      var myLatlng = new google.maps.LatLng(latitude,longitude);
      var myOptions = {
        zoom: 8,
        center: myLatlng,
        mapTypeId: google.maps.MapTypeId.ROADMAP
      }
      var map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
      addMarker(myLatlng, 'Default Marker', map);

  }
      </script>

      <script>
  $('#gallery').imagesGrid({
    images: <?php echo json_encode($allimages1) ?>,
    align: true
  });
</script>
  <script type="text/javascript" src="https://maps.google.com/maps/api/js?key=AIzaSyC29SOMdVFnuCgpVR9VFbeARVJqDJ7tJ-w&callback=initialise"></script> 
    @endsection





