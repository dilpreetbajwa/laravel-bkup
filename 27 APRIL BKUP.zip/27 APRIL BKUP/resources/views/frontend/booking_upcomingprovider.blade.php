 @if($filter==0)
   @if(count($data)>0)
    @foreach($data as $value)
      <div class="booking-inner">
         <div class="booking-details-cntnt">
            <div class="top-content">
               <h3>Booking Id : {{$value['id']}}</h3>
               <h3>Booking Date : {{$value['date']}}</h3>

            </div>
            <div class="bottom-cntnt">
               <div class="imge-book">
                  <img src="{{$value['image']}}" alt="image">
               </div>
               <div class="booking-opop">
                <a href="{{url('/booking-historydetail').'/'.base64_encode($value['id'])}}">
                  <h3 class="booking-title">Name : {{$value['title']}}</h3>
                  <div class="guest-pricee">
                     <p>Price : $ {{$value['amount']}}</p>
                     <p>Category : {{$value['category']}}</p>
                  </div>
                  <p>Location : {{$value['location']}}</p>
                 
                  </a>
               </div>
            </div>
         </div>
      </div>
   @endforeach
   @else
   <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
   @endif
@endif


@if($filter==1)
    @if(count($data_place)>0)
    @foreach($data_place as $value)
      <div class="booking-inner">
         <div class="booking-details-cntnt">
            <div class="top-content">
               <h3>Booking Id : {{$value['id']}}</h3>
               <h3>Booking Date : {{$value['date']}}</h3>

            </div>
            <div class="bottom-cntnt">
               <div class="imge-book">
                  <img src="{{$value['image']}}" alt="image" class="shsdhh">
               </div>
               <div class="booking-opop">
                <a href="{{url('/booking-historydetail').'/'.base64_encode($value['id'])}}">
                  <h3 class="booking-title">Name : {{$value['title']}}</h3>
                  <div class="guest-pricee">
                     <p>Price : $ {{$value['amount']}}</p>
                     <p>Category : {{$value['category']}}</p>
                  </div>
                  <p>Location : {{$value['location']}}</p>
                   
               </a>
               </div>
            </div>
         </div>
      </div>
   @endforeach
   @else
     <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
    @endif
     
@endif


@if($filter==2)
    @if(count($data_things)>0)
    @foreach($data_things as $value)
      <div class="booking-inner">
         <div class="booking-details-cntnt">
            <div class="top-content">
               <h3>Booking Id : {{$value['id']}}</h3>
               <h3>Booking Date : {{$value['date']}}</h3>

            </div>
            <div class="bottom-cntnt">
               <div class="imge-book" class="shsdhh">
                  <img src="{{$value['image']}}" alt="image">
               </div>
               <div class="booking-opop">
                  <a href="{{url('/booking-historydetail').'/'.base64_encode($value['id'])}}">
                  <h3 class="booking-title">Name : {{$value['title']}}</h3>
                  <div class="guest-pricee">
                     <p>Price : $ {{$value['amount']}}</p>
                     <p>Category : {{$value['category']}}</p>
                  </div>
                  <p>Location :  {{$value['location']}}</p>
               </a>
               </div>
            </div>
         </div>
         </div>
    @endforeach
   @else
     <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
    @endif
     
@endif

@if($filter==3)
    @if(count($data_people)>0)
    @foreach($data_people as $value)
      <div class="booking-inner">
         <div class="booking-details-cntnt">
            <div class="top-content">
               <h3>Booking Id :{{$value['id']}}</h3>
               <h3>Booking Date : {{$value['date']}}</h3>

            </div>
            <div class="bottom-cntnt">
               <div class="imge-book" class="shsdhh">
                  <img src="{{$value['image']}}" alt="image">
               </div>
               <div class="booking-opop">
                   <a href="{{url('/booking-historydetail').'/'.base64_encode($value['id'])}}">
                  <h3 class="booking-title">Name : {{$value['title']}}</h3>
                  <div class="rating-result" title="99%">
                  <span style="width: 67%;">
                  </span>
                  </div>
                  <div class="guest-pricee">
                     <p>Price : $ {{$value['amount']}}</p>
                     <p>Category : {{$value['category']}}</p>
                  </div>
                  <p>Location : {{$value['location']}}</p>
               </a>
               </div>
            </div>
         </div>
         </div>
    @endforeach
   @else
     <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">
    @endif     
@endif