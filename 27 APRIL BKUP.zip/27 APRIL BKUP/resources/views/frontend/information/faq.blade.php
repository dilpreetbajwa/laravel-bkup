 @extends('layouts.frontend.master')
@section('content')
<style>
.row.border-bottom-content
{
	margin-bottom: 20px;
}
.search-bar
{
	display: none;
}
.card-header
{
	background-color: rgba(122, 186, 221, 0.22);	
}
a .card-header
{
	color:#000;
	font-weight:500;
	font-size: 17px;
}


</style>


<section class="Popular-task_1 comman-padding more-about-place">
    <div class="container task-contain">
        <div class="things-innerpage-content">
            <div class="row border-bottom-content">                  
              <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                 <div class="full-width-text">
                  <h2 class="border-bottom-content title-transact" style="margin-bottom: 20px">Frequently asked Questions</h2>
                </div>                 
                </div>
            </div>
      
  	 <div id="accordion">
        @if(count($data)>0)
          @foreach($data as $key=>$value)
            <div class="card">
                <a class="card-link" data-toggle="collapse" href="#collapseOne">
              <div class="card-header">
                  {{$value['question']}}
              </div>
                </a>
              <div id="collapseOne" class="collapse show" data-parent="#accordion">
                <div class="card-body">
                 {{$value['answer']}}
                </div>
              </div>
            </div>
          @endforeach
          @endif
      </div>
		</div>
	</div>
</section>
@endsection