@extends('layouts.frontend.master')
@section('content')
<style>
.row.border-bottom-content
{
	margin-bottom: 20px;
}
.search-bar
{
	display: none;
}
</style>


 <section class="Popular-task_1 comman-padding more-about-place">
         <div class="container task-contain">
            <div class="things-innerpage-content">
               <div class="row border-bottom-content">
                  
                  <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                     <div class="full-width-text">
                      <h2 class="border-bottom-content title-transact" style="margin-bottom: 20px">Trust and Safety</h2>
                     </div>
                     
                    </div>
                </div>
               <?php echo html_entity_decode($desc); ?>

           
            </div>
        </div>       
      </section>  

@endsection