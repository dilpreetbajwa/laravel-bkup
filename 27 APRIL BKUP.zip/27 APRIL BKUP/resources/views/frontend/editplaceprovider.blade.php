@extends('layouts.frontend.master')
@section('content')

<style>

.imgecontainer img {
    height: 63px;
}

#map_canvas
{
  position: relative!important;
  width:100%!important;
  height:69%!important;
}


input#datesdata {
   display: flex;
   align-items: center;
   border: 1px solid #e1e1ed;
   background: #fafaff;
   justify-content: space-between;
   padding: 10px 15px;
   margin: 5px 0;
   height: 50px;
   border-radius: 0;
}

div#datepicker2 span.input-group-addon {
   background: #fafaff;
   height: 45px;
   display: flex;
   flex-wrap: wrap;
   align-items: center;
   justify-content: center;
   position: absolute;
   right: 3px;
   top: 32px;
   padding: 0;
   width: 40px;
   z-index: 9;
   border: 0;
}

  .datepicker-days table.table-condensed {
     width: 25vw !important;
     font-size: 1.6rem !important;
     background: #fafaff !important;
  }

  select#subcatlist {
     margin: 0 0 5px 0;
  }
  span.othersubcat {
     display: flex;
     flex-wrap: wrap;
  }
  .title-inner-form {
  margin-top: 0;
  }
  .datepicker-days td.disabled
  {
    background: grey !important;
    color:red !important;
  }
  .search-bar
  {
    display:none;
  }
</style>
      <!-- Our Packages -->  
      <section class="package comman-padding">
         <div class="container task-contain">
            <div class="row card-section wow bounceInRight">
               <div class="col-lg-12 col-md-12">
                  <div class="card">
                     <div class="main-heading-overlay wow bounceUp">
                        <h2>Edit Your <b>Places</b></h2>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- Top Rated-->
    <form  method="post" action = "{{url('/editplaceprovider')}}" id="place-form-main" name="places" enctype="multipart/form-data">
      <div class="container task-contain">
            
            <span class="placesitem" hidden></span>

         </div>
     <input type="hidden" name="_token" id="csrf-token" value="{{ Session::token() }}" />
     <input type="hidden" name="providerid" id="providerid" value="{{@$provider_id}}" />
     <input type="hidden" name="datesbooked" id="datesbooked" value="{{@$original_dates}}" />
      
      <!-- About place -->
      <section class="Popular-task_1 comman-padding more-about-place">
         <div class="container task-contain">
         <div class="places-form">         
               <div class="row">
                  <div class="col-lg-6">
                     <input type="hidden" name="catdata" id="catdata">
                      <input type="hidden" name="amentiesid" id="amentiesid" value="1">
                      <input type="hidden" name="picsid" id="picsid" value="1">
          
                  </div>
                
               </div>
               <div class="row">
                  <div class="main-heading more-about-heading wow bounceInUp">
                     <h2>Edit Place<b class="Services"> Details</b></h2>
                  </div>
                  <div class="col-lg-6">
                     <div class="offred-content">
                        <span>Amenities Offered</span>
                        <div class="add-offer-values">
                           <label for="value-add-off">+</label>
                           <input type="checkbox" id="value-add-off">
                           <div class="overly-content-ofer">
                             
                          <input type="text" class="amentiestext" name="amentiestext" id="mainoffervalue">
                          <input type="button" value="OK" class="amenties-btn" id="amenties-btn">
                              
                           </div> 
                        </div>
                     </div>
                     <div class="amenties"></div>
                      <input type="hidden"  id = "unavldates" value="{{@$unavailable_dates}}">

                     <div class="file-upload-in">
                        <div class="upload-button">Add Photos</div>
                        <input class="file-upload" type="file" name="uploadfile[]" accept="image/*" multiple/  required hidden>
                        <div id="dvPreview"></div>
                     </div>
                      <div class="clockpicker">
                        <label>Check-In Time  </label>
                         <input type="text" class="timepicker-in form-control" name="timepicker_in" data-id="{{@$checkin_time}}">
                         <span class="time-icon checkouttimeclock">
                             <img src="{{url('/web/images/date-pick-icon.png')}}">
                         </span>
                     </div>
                    
                      <div class="input-group clockpicker">
                        <label>Check-Out Time  </label>
                        
                         <input type="text" class="timepicker-out form-control" name="timepicker_out" data-id="{{@$checkout_time}}">
                         <span class="time-icon">
                             <img src="{{url('/web/images/date-pick-icon.png')}}">
                         </span>
                     </div>

                     <div class="host-fac"><input type="checkbox" name="host_facility" id="host_facility" value="1" {{@$host_facility=='true'?'checked':''}}><label for="host_facility">Host Facility</label> </div>
                     <div id="host_details">
                        <input type="text" id="host_name" name="host_name" class="form-input" placeholder="Host Name" required value="{{@$host_name}}">
                         <input type="text" id="host_phone" name="host_phone" class="form-input" placeholder="Host Phone No." required value="{{@$host_phone}}">
                     </div>
                     <div class="pet-allow"><input type="checkbox" name="pet_allow" id="pet_allow" value="1" {{@$pet_allowance=='true'?'checked':''}} ><label for="pet_allow">Pet Allowance</label></div>
                   

               </div>
              
                <div class="col-lg-6">

                  <div id="datepicker2" class="input-group date" data-date-format="yyyy-mm-dd">                 
                  <label for = "dates">Please block the dates that are unavailable</label>
                    <input class="form-control" type="text"  readonly name = "dates" id="datesdata" required placeholder="Select the dates">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                  </div>
                   <!-- <div class="pricing-per-night"> -->
                        <label for="pricingpernight" style="margin-top: 6px;">Pricing per night($)</label>
                        <input type="text" name="pricingpernight" id="pricingpernight" class="form-input" placeholder="Pricing per night" required=""  value="{{@$pricing_per_night}}">

                        <!-- 
                        <input type="number"  id="pricingpernight" min="0"> -->
                        <!-- <div class="input-number">
                            <button  class="arrow-up" type="button" onclick="this.parentNode.querySelector('[type=number]').stepDown();"><img src="{{url('/web/images/arrow-up.png')}}"></button>
                              <input type="number" name="pricingpernight" min="1" max="100" value="1">
                           <button class="arrow-down" type="button" onclick="this.parentNode.querySelector('[type=number]').stepUp();"><img src="{{url('/web/images/arrow-down.png')}}"></button>
                         </div> -->
                    <!--  </div>    -->
                     <!-- <div class="date-selct">
                        <p class="date-select-text">Please block the dates that are unavailable</p>
                         <input type="text" id="datepicker2" class="form-control">
                       
                     </div> --> 
                  </div> 
               </div>
              
               <div class="form-action-button">
               <button  class="btnn btn-cancel" value="Cancel">Cancel</button>
               
               <button  class="btnn btn-next" value="next">
               @if(@$providercompletion_status!=4) Next @else Submit @endif</button>
              
            </div>
               
         </div>
      </div>
      </section>
      </form> 
      <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
      <script src="{{url('/web/js/wow.js')}}"></script>  
      <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js"></script>

     
     
      <link rel="stylesheet" href="{{url('web/css/wickedpicker.css')}}">
      <link rel="stylesheet" href="{{url('web/css/wickedpicker.min.css')}}">
      
      
      <script src="{{url('web/js/wickedpicker.min.js')}}"></script>
     
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>
     
      

      <script>
         new WOW().init();
      </script>
<script>
    var token = "{{ csrf_token() }}";
    var amnts = (<?php echo json_encode($amenitiesall)?>);
    var att = (<?php echo json_encode($attachments)?>);

    var datesForDisable = $("#unavldates").val();
    var arr = datesForDisable.split(',');
    var unavailableDates = arr;
    var base_url = "<?php echo url('/'); ?>";
    $("#datepicker2").datepicker({ 
      format: 'yyyy-mm-dd', 
      multidate: true,
     
      beforeShowDay: function (currentDate) { var dayNr = currentDate.getDay(); var dateNr = moment(currentDate.getDate()).format("YYYY-MM-DD");
      
          if (unavailableDates.length > 0) { 
            for (var i = 0; i < unavailableDates.length; i++) { 
              if (moment(currentDate).unix()==moment(unavailableDates[i],'YYYY-MM-DD').unix()){ 
                return false; 
              } 
            } 
          } 
          return true; 
        } 

  });

 $('.timepicker-in').wickedpicker().val(($(".timepicker-in").attr('data-id'))); 
 $('.timepicker-out').wickedpicker().val(($(".timepicker-out").attr('data-id')));

  var token = "{{ csrf_token() }}";
         $(".othersubcat").hide();
         $(document).ready(function(){
          for(j=0;j<amnts.length;j++){

            var id = $("#amentiesid").val();
            var one ="jdfgjd";       
            $(".amenties").append("<div data-id="+id+" class='delamenity amenitie-innr'><span class=amenities-"+id+">"+amnts[j]+"</span><span class=delamenity data-id="+id+">X</span><input type=hidden name=amenities[] class=amenities"+id+" value="+amnts[j]+"></div>");
             var i = parseInt(id)+1;
            $("#amentiesid").val(i);
          }
         })

           
          for(j=0;j<att.length;j++){
            var id = $("#picsid").val();
            var imgsrc= att[j]['url'];
            var attid = att[j]['id'];
            var imgouter = $("#dvPreview").append("<div data-imgid="+attid + " data-id="+id+" class='delpics imgecontainer'><img src="+imgsrc+" id="+id+" class=delpics-"+id+"><span data-id="+id+"class=delpics id=delpics-"+id+">X</span></div>");
            $("#dvPreview").append(imgouter);
            var i = parseInt(id)+1;
            $("#picsid").val(i);
          }

        $(".subcat").on('click',function(){
          $(".othersubcat").toggle();
        })

        $("#subcatlist").on('change',function()
        {
          var catval = $(this).val();
          if(catval=="other")
          {
            $(".othersubcat").show();
          }
          else{
             $(".othersubcat").hide();
          }

        });

        $(".amenties-btn").on('click',function(){

          var amentiesval = $(".amentiestext").val();
         
          if(amentiesval==""){
          swal({
            title: "Error!!",
            text: "Please fill in the value",
            icon: "warning",
            buttons: true,
            dangerMode: true,
          }) }
          else{
            var id = $("#amentiesid").val();
            $(".amenties").append("<div data-id="+id+" class='delamenity amenitie-innr'><span class=amenities-"+id+">"+amentiesval+"</span><span class=delamenity data-id="+id+">X</span><input type=hidden name=amenities[] class=amenities"+id+" value='"+ amentiesval+"'></div>");
            var i = parseInt(id)+1;
            $("#amentiesid").val(i);
            $(".amentiestext").val("");
            //$(".add-offer-values").trigger('click');
            $("#value-add-off").prop("checked", false);
          }
        })

        $(document).on( "click",  ".delamenity" , function() {
          var id = $(this).attr('data-id');
          $(".amenities-"+id).remove();
          $(".amenities"+id).remove();  
          $(this).remove();
        });



        $(document).on( "click",  ".delamenity" , function() {
          var id = $(this).attr('data-id');
          $(".amenities-"+id).remove();
          $(".amenities"+id).remove();  
          $(this).remove();
        });

   /*   $('#datepicker2').datepicker({
         $input.datepicker('show');
        multidate: true

      });
*/
  

   $(".file-upload").change(function () {

        if (typeof (FileReader) != "undefined") {
            var dvPreview = $("#dvPreview");
            var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.jpg|.jpeg|.gif|.png|.bmp)$/;
            $($(this)[0].files).each(function () {
                var file = $(this);
                                 
                  var reader = new FileReader();
                  reader.onload = function (e) {
                      var id = $("#picsid").val();
                      var img = $("<img id="+id+" class=delpics-"+id+"><span data-id="+id+"  class=delpics id=delpics-"+id+">X</span>");
                      //img.attr("style", "height:100px;width: 100px");
                      img.attr("src", e.target.result);
                      var imgouter=$("<div data-id="+id+" class='delpics imgecontainer'></div>");
                      imgouter.html(img);
                      dvPreview.append(imgouter);
                      var i = parseInt(id)+1;
                      $("#picsid").val(i);
                    }
                    reader.readAsDataURL(file[0]);
                
            });
        } else {
            alert("This browser does not support HTML5 FileReader.");
        }
    });

    $(document).on('click','.delpics',function(){
      var id = ($(this).attr('data-id'));
      var imgid = $(this).attr('data-imgid');
      $(".delpics-"+id).remove();
      $(this).remove();
      $.ajax({
          url: "{{url('/deleteattachment')}}",
          type: 'POST',
          data: {
            attachid:imgid,
            _token: token
          },
          success: function (response) {
            
          }
      });

    })


      </script>
      <script>
      $("#host_facility").on('click', function(){
        if ($(this). prop("checked") == true) { 
           $("#host_details").show();
          } else { 
            $("#host_details").hide();
        }         
      })
      </script>
   
<script>

  $(".btn-next").on('click',function(event){

    event.preventDefault();
    var dates= ($("#datesdata").val());
    var amentiesval = $(".amenties").html();
    var pricingpernight = $("#pricingpernight").val();
      if(amentiesval.length==""){
        swal({
          title: "Error!!",
          text: "Please enter values for amenities",
          icon: "warning",
          buttons: true,
          dangerMode: true,
        })
      }
      else if($("#dvPreview").html()=="")
    {
      swal({
        title: "Error!!",
        text: "Please add photos",
        icon: "warning",
        buttons: true,
        dangerMode: true,
      })
    }
   /* else if(dates.length==0 && $("#datesbooked").val()=="")
    {
     swal({
          title: "Error!!",
          text: "Please select the dates",
          icon: "warning",
          buttons: true,
          dangerMode: true,
        })
    }*/
     else if(pricingpernight==""){
        swal({
          title: "Error!!",
          text: "Please enter value for pricing/night",
          icon: "warning",
          buttons: true,
          dangerMode: true,
        })
      }
      
    else{
      $("#place-form-main").submit();
    }
  })
  $(".btn-cancel").on('click',function(event){
    event.preventDefault();
    location.reload();
  })
  $(".upload-button").click(function(){

    $(".file-upload").click();
  })

</script>
@endsection