@extends('layouts.frontend.master')
@section('content')
<style>
#map_canvas
{
  position: relative!important;
  width:100%!important;
  height:20vw!important;
}
.owl-carousel
{
   display: block !important;
}
button.owl-prev {
float: left;
left: 0;
position: absolute;
top: 50%;
}
button.owl-next {
float: right;
right: 0;
top: 50%;
position: absolute;
}
.swal-text
{
  text-align: center;
  font-weight: bold;
  font-size: 20px;
}
.price-list-form{
  background: #6f276c;
  text-align: center;
  font-size: 30px !important;
  padding: 3px;
  color:#fff;
}
.search-bar
{
  display: none;
}
</style>
<?php 
$loginval = Session::get('show_modal');
if($loginval):?>
<script>
 
  $('#login-modal').modal('show');</script>
<?php endif;?>
      <!-- About place -->

      <div id="share_modal" class="modal fade" role="dialog">
      <div class="modal-dialog">
        <!-- Modal content-->
        <div class="modal-content">
          <div class="modal-header" style="display:block">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title">Share Page Link</h4>
          </div>
          <div class="modal-body">
            <form name="form_share" id="form_share" method="post">
               <div id="share_errforgot" style="text-align: center;color: #721c24;
                background-color: #f8d7da;border-color: #f5c6cb;"></div>
                <div id="share_sentforgot" style="text-align: center;color:#237509 ;
                background-color: #ace89b;border-color: #237509;"></div>
              <input type="text" placeholder = "Enter your email address" class="form-control" name="share_url" id="share_url">
               <input type="hidden" class="form-control" name="share_url_val" id="share_url_val">
              <input type="submit" name="shareurlbtn" class="btn btn-primary shareurlbtn" value="Submit">
            </form>
          </div>
        </div>
      </div>
    </div>

    <section class="Popular-task_1 comman-padding more-about-service">
         <div class="container task-contain">
            <div class="things-innerpage-content">
               <div class="row border-bottom-content">
                  <div class="col-xl-5 col-lg-5 col-md-5 col-sm-12">
                    <div class="innerpage-box-left">
                   
                   
                      @if($userdet['image']!="")
                        <img src="{{url('/profile').'/'.$userdet['image']}}" class="width-FUll">  
                      @else                      
                        <img src="{{url('/web/images/service-profile-img.png')}}" class="width-FUll">   
                      @endif         
                    </div>
                  </div>
                  <div class="col-xl-7 col-lg-7 col-md-7 col-sm-12">
                     <div class="full-width-text border-bottom-content service-profile-content p-relativ">
                        <h3>{{$userdet['name']}}</h3>
                        <div class="content-right-info">
                     <ul>
                        <li>
                           <a class= "shareurl" href="javascript:void(0)">
                           <span class="icon-info"><svg viewBox="0 0 24 24" fill="currentColor" fill-opacity="0" stroke="currentColor" stroke-width="2.25" focusable="false" aria-hidden="true" role="presentation" stroke-linecap="round" stroke-linejoin="round" style="height: 15px; width: 15px; display: block; overflow: visible;"><g fill-rule="evenodd"><path d="m11.5 16v-15"></path><path d="m7.5 4 4-3 4 3"></path><path d="m5.4 9.5h-3.9v14h20v-14h-3.1"></path></g></svg>
                           </span>
                           <span class="title-info">Share</span></a>
                        </li>
                        <li>
                           <a href="javascript:void(0)">
                           <span class="icon-info like-icon"><svg viewBox="0 0 24 24" fill="currentColor" fill-opacity="0" stroke="#484848" stroke-width="2.25" focusable="false" aria-label="Save this listing." role="img" stroke-linecap="round" stroke-linejoin="round" style="height: 15px; width: 15px; display: block; overflow: visible;"><path d="m17.5 2.9c-2.1 0-4.1 1.3-5.4 2.8-1.6-1.6-3.8-3.2-6.2-2.7-1.5.2-2.9 1.2-3.6 2.6-2.3 4.1 1 8.3 3.9 11.1 1.4 1.3 2.8 2.5 4.3 3.6.4.3 1.1.9 1.6.9s1.2-.6 1.6-.9c3.2-2.3 6.6-5.1 8.2-8.8 1.5-3.4 0-8.6-4.4-8.6" stroke-linejoin="round"></path></svg>
                           </span>
                           <span class="title-info">Save</span></a>
                        </li>
                     </ul>
                  </div>
                        <p>{{$peopledetails->description}}</p>
                        <p><b>{{$peopledetails->title}}</b></p>
                         <div class="place-info">
                     <div class="innr-info-content">Check in Time - <span class="info-value">{{$peopledetails->time_in}}</span></div>
                     <div class="innr-info-content">Check out Time - <span class="info-value">{{$peopledetails->time_out}}</span></div>
                     <div class="innr-info-content">Rate - <span class="info-value">$ {{$peopledetails->price_per_night}} Per Night</span></div>
                   
                  </div>
                        <div class="heding-contnt-service">
                        <div class="heading-content">
                           <h4>Past Services:</h4>
                           <p>{{@$pastservices}} </p>
                        </div> 
                        <div class="heading-content">
                           <h4>Reviews:</h4>
                           <p>{{@$reviewall}} </p>
                        </div> 
                     </div>
              <form method="post" name="bookingpeople" id="bookingpeople" action = "{{url('/paymentservices')}}">
                  <input type="hidden"  id = "latval" value="{{$peopledetails->latitude}}"">
                <input type="hidden"  id = "lngval" value="{{$peopledetails->longitude}}"">
                <input type="hidden"  id = "unavldates" value="{{@$unavailable_dates}}">
                 <input type="hidden"  name= "providerid" id = "providerid" value="{{$peopledetails->id}}"> 
                 <input type="hidden" name="_token" id="csrf-token" value="{{ Session::token() }}" />
                  
                      <div class="side-bar-form">
                     <h2 class="price-list-form border-bottom-content">${{$peopledetails->price_per_night}}<span>per night</span></h2>
                     <div class="date-select">
                        <label>Check In Date</label>
                        <input type="text" id ="iDate" name="iDate" required readonly>
                        <span class="errcheckin" style="color:red"></span>
                       
                     </div>
                     <div class="date-select">
                        <label>Check Out Date</label>
                        <input type="text" id ="oDate" name ="oDate"  required readonly>
                        <span class="errcheckout" style="color:red"></span>
                        
                     </div>
                     <div class="selct-guests">
                        
                        <button type="submit" class="resrve-btn" style="background-color: rgb(111, 39, 108);">Reserve</button>
                        <p class="btn-botom-text">You won't be charged yet</p>
                     </div>
                  </div>
                  </form>
                     </div>
                      
                  </div>
               </div>
               <!-- <button type="submit" class="btnn btn-Message " value="Message ">Message </button> -->
               <div class="full-width-text">
                  <h3>Recent Reviews</h3>
                <!--   <p>We offers our guests with luxurious Suite Cottages which are beautifully designed, spacious, well-illuminated and have comfortable beds. These rooms are enabled with all the modern... </p> -->
                  <ul class="reviews-list">
                    @if(count($review_people)>0)
                      @foreach($review_people as $place)
                         <li>
                            <div class="review-icon">
                              @if($place['image']!="")
                                <img src="{{$place['image']}}" alt="icon" width=100px height=100px style="border-radius: 50%">
                              @else
                               <img src="{{url('/web/images/').'/review-1.png'}}" alt="icon">
                              @endif 
                            </div>
                            <div class="review-content">
                               <h3>{{$place['user']}}</h3>
                               <p class="review-date">{{$place['datemonth'] }} {{$place['dateyear']}}</p>
                               <p>{{$place['reviews']}}</p>
                            </div>
                         </li>
                       @endforeach
                    @else
                     No Reviews Found
                    @endif
                     
                  </ul>
               </div>
            </div>
          </div>
      </section>  
      <!-- Bootstrap JS -->
        <script
  src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
      <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
       <link rel="stylesheet" href="/resources/demos/style.css">
      <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
       <script src="https://timernr.com/web/js/owl.carousel.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
      <script>
       var j = jQuery.noConflict();
       var base_url = "<?php echo url('/'); ?>";
      (function($) {
       $(document).ready(function(){
        $(".owl-carousel").owlCarousel({
            loop:true,
             margin:10,
             autoplay:true,
             autoplayTimeout:4000,
             autoplayHoverPause:true,
             responsiveClass:true,
             responsive:{
               300:{
                 items:1,
                 nav:true
               },
               767:{
                 items:1,
                 nav:true
               },
               1000:{
                 items:1,
                 nav:true,
                 loop:false
               }
             }
         });
       });
      }) (jQuery);

     

    function addMarker(latlng,title,map) {
      var marker = new google.maps.Marker({
      position: latlng,
      map: map,
      title: title,
      draggable:false
      });
    }


    function initialise() {
      var latitude = $("#latval").val();
      var longitude = $("#lngval").val();    
      var myLatlng = new google.maps.LatLng(latitude,longitude);
      var myOptions = {
        zoom: 8,
        center: myLatlng,
        mapTypeId: google.maps.MapTypeId.ROADMAP
      }
      var map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);
      addMarker(myLatlng, 'Default Marker', map);

  }
      </script>
  <script type="text/javascript" src="https://maps.google.com/maps/api/js?key=AIzaSyC29SOMdVFnuCgpVR9VFbeARVJqDJ7tJ-w&callback=initialise"></script> 

  <script type="text/javascript">
   var a = j("#unavldates").val();
    var arr = a.split(',');
    var unavailableDates = arr;
    function unavailable(date) {
      var m = date.getMonth()+1;

      if(date.getMonth()>8)
      {
        var month1 = m;
      }
      else
      {
        var month1 = "0" + m;
      }
      dmy =(date.getFullYear() + "-" + (month1) + "-" + ("0" + date.getDate()).slice(-2));
     
          if (j.inArray(dmy, unavailableDates) == -1) {

              return [true, ""];
          } else {
          
              return [false, "", "Unavailable"];
          }
      }
    
    j( function() {
      j( "#iDate" ).datepicker({
        dateFormat: 'yy-mm-dd',
        changeMonth: true,
        beforeShowDay: unavailable,
        minDate: 0, 
        onSelect: function(date){
            var selectedDate = new Date(date);
            var msecsInADay = 86400000;
            var endDate = new Date(selectedDate.getTime());
            j("#oDate").datepicker( "option", "minDate", endDate );
            j("#oDate").datepicker( "option", "maxDate", '+2y' );
        }
    });
    });
    j("#oDate").datepicker({
    dateFormat: 'yy-mm-dd',
    changeMonth: true,
    beforeShowDay: unavailable,
    onSelect: function(date){ 
    if(j("#iDate").val()==""){
      j(".errcheckout").html("Please fill in check-in date first");
      j("#oDate").val("");     
    } 
      var date1 = j( "#iDate" ).val();  
      var date2 = j( "#oDate" ).val();    
      var  startDate = new Date(date1);
      var endDate = new Date(date2);
      var aa = getDateArray(startDate,endDate);
      for(var i =0; i<aa.length;i++)
      {
        var date = new Date(aa[i]);
        dmy =(date.getFullYear() + "-" + ("0" + date.getMonth()+1).slice(-2) + "-" + ("0" + date.getDate()).slice(-2));
        if ($.inArray(dmy, unavailableDates) == -1) {            
        } else {
         
          swal("OOps!","Please choose date range that does not include unavailable dates","error");
          $("#oDate").val("");

        }
      }
    }
});

    $(".btn-connt-host").on('click',function(e){
      e.preventDefault();
    })

  function getDateArray(start, end) {
    var arr = new Array(),
      dt = new Date(start);
    while (dt <= end) {
      arr.push(formatDate(dt));
      dt.setDate(dt.getDate() + 1);
    }
    return arr;
  }

  function formatDate(date) {
    var d = new Date(date),
    month = '' + (d.getMonth() + 1),
    day = '' + d.getDate(),
    year = d.getFullYear();
    if (month.length < 2) 
      month = '0' + month;
    if (day.length < 2) 
      day = '0' + day;
    return [year, month, day].join('-');
  }

  $("#oDate").on("change", function() { 
    j(this).blur();    
    if(j("#iDate").val()==""){
      j(".errcheckout").html("Please fill in check-in date first");
      j("#oDate").val("");      
    }
  }); 

   
  j(".resrve-btn").on('click',function(e){
   
    e.preventDefault();
     var id = "{{Auth::user()}}";
    if(id){}
      else
    window.location.href= "{{url('/backtologin')}}";
    if(j("#iDate").val()=="")
      j(".errcheckin").html("Please fill in check-in date");
    else if(j("#oDate").val()=="")
      j(".errcheckout").html("Please fill in check-out date");
   
    else
    {
      j(".errcheckout").html();
      j(".errcheckin").html();
      var datein = $("#iDate").val();
      var dateout = $("#oDate").val();
      var id = $("#providerid").val();
      var address =  base_url +'/paymentservices/'+id+ '/'+datein+ '/'+dateout;
      j("#bookingpeople").attr('action',address)
      j("#bookingpeople").submit();
    }
  });
   j(".like-icon").on('click',function(e){
    e.preventDefault();
    var address =  base_url +'/favourites';
    var id = $("#providerid").val();
    var type = 1;
    var favourite = 1;
     $.ajax({
          url: address,
          type: 'POST',
          data: {
            provider_id: id,type:type,favourite:favourite,_token: token
          },
          success: function (response) {
            var msg = '';
            if(response.data == 1) {
              if(response.fav_status==1){
                j(".like-icon svg").css("fill","red");
                j(".like-icon svg").css("fill-opacity","initial");
                j(".like-icon svg").css("stroke","red");
                swal("Added to favourites");
              }
              else
              {
                j(".like-icon svg").css("fill","red");
                j(".like-icon svg").css("fill-opacity","0");
                j(".like-icon svg").css("stroke","#000");
                swal("Removed from favourites");
              }
            } 
            else {
              $("#login-modal").modal('show');
            }
          }
      });
    /*j("#bookingplace").attr('action',address)
    j("#bookingplace").submit();*/
  })
   
$(".shareurl").on('click',function(){
  $("#share_modal").modal('show');
});

$("#form_share").on('submit',function(e){
    e.preventDefault();
    var emailval = $("#share_url").val();
    var url = $(location).attr('href');
    if(emailval=="")
    {
      $("#share_errforgot").html("please enter email address");
    }
    else
    {
      $.ajax({
        url: "{{url('/share_url')}}",
        type: 'POST', 
        data:   {    
          "_token": token,
          "email":emailval,
          'url':url                  
        },
      success: function(response){        
          $("#share_errforgot").html("");
        $("#share_sentforgot").html(response.msg);
      },
    })       
}
      })
</script>
@endsection