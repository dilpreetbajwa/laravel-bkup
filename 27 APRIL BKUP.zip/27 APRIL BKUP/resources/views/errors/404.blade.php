@extends('layouts.frontend.master')

@section('content')
<style>
.search-bar
{
  display:none;
}
</style>
 <img src="{{url('/web/images').'/no-result.gif'}}" class="no-result">

@endsection

