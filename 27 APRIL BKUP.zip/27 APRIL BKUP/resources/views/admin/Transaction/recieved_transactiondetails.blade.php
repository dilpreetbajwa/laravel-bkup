@extends('layouts.master')
@section('content')
<style type="text/css">
  .imgs-grid-modal{margin-left: 250px!important;}    
</style>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/taras-d/images-grid/src/images-grid.min.css">
<section class="content"> 
    <div class="row" style="margin-left: 15px;">
        <div class="col-md-12">
            <div class="box box-danger">
                <div class="box-header"  style=" text-align: center;">
                    <h3 class="box-title" style="    text-decoration: underline;">Transaction Details</h3>

                    @if (session()->has('message'))
                    <br>
                    <div class = "alert alert-success col-md-12">
                        <ul>
                          <li>{{Session::get('message')}}</li>
                      </ul>
                  </div>
                  @endif
              </div>
              <!-- /.box-header --> 
              <div class="box-body"  >
                 <div class="row">
          <div class="col-md-4">
            <!-- Widget: user widget style 2 -->
            <h3 class="widget-user-username" style="font-size: 22px;">User Details</h3>
            <div class="card card-widget widget-user-2">
              <!-- Add the bg color to the header using any of the bg-* classes -->
              <div class="widget-user-header bg-warning">
                <div class="widget-user-image">
                  <img class="img-circle elevation-2" src="{{url('/profile/'.@$user_data->image)}}" style="height: 77px;width: 69px;object-fit: cover;" alt="User Avatar">
                </div>
                <!-- /.widget-user-image -->
                <h3 class="widget-user-username" style="font-size: 22px;color: #fff;">{{$user_data->name}}</h3>
                <h5 class="widget-user-desc" style="font-size: 1rem;color: #fff;">{{$user_data->email}}</h5>
              </div>
              <div class="card-footer p-0">
                <ul class="nav flex-column">
                  <li class="nav-item">
                    <a  class="nav-link">
                      Amount Transaction <span class="float-right badge bg-info">{{$data->transaction_amount}}</span>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link">
                      Date <span class="float-right badge bg-info">{{$data->date}}</span>
                    </a>
                  </li>                
                </ul>
              </div>
            </div>
            <!-- /.widget-user -->
          </div>
          <!-- /.col -->
          <div class="col-md-4">
            <!-- Widget: user widget style 2 -->
            <h3 class="widget-user-username" style="font-size: 22px;">Provider Owner Details</h3>
            <div class="card card-widget widget-user-2">
              <!-- Add the bg color to the header using any of the bg-* classes -->
              <div class="widget-user-header bg-info">
                <div class="widget-user-image">
                  <img class="img-circle elevation-2" src="{{url('/profile/'.@$provider_user->image)}}" style="height: 77px;width: 69px;object-fit: cover;" alt="User Avatar">
                </div>
                <!-- /.widget-user-image -->
                <h3 class="widget-user-username" style="font-size: 22px;">{{$provider_user->name}}</h3>
                <h5 class="widget-user-desc" style="font-size: 1rem;">{{$provider_user->email}}</h5>
              </div>
              <div class="card-footer p-0">
                <ul class="nav flex-column">
                  <li class="nav-item">
                    <a  class="nav-link">
                      Phone <span class="float-right badge bg-primary">{{$provider_user->phone_number}}</span>
                    </a>
                  </li>
                                 
                </ul>
              </div>
            </div>
            <!-- /.widget-user -->
          </div>
          <!-- /.col -->
          <div class="col-md-4">
            <!-- Widget: user widget style 2 -->
            <h3 class="widget-user-username" style="font-size: 22px;">Provider Category: {{$category->name}} Details</h3>
            <div class="card card-widget widget-user-2" >
              <!-- Add the bg color to the header using any of the bg-* classes -->
              <div class="widget-user-header bg-info" style="background-color: #DC3545 !important;">
                <div class="widget-user-image">
                  <img class="img-circle elevation-2" src="{{$category_image}}" style="height: 77px;width: 69px;object-fit: cover;" alt="User Avatar">
                </div>
                <!-- /.widget-user-image -->
                <h3 class="widget-user-username" style="font-size: 30px; margin-left: 100px; margin-top: 20px;">{{$provider->title}}</h3>
              </div>
              <div class="card-footer p-0">
                <ul class="nav flex-column">
                  <li class="nav-item">
                    <a  class="nav-link">
                      Price Per Night <span class="float-right badge bg-primary">$ {{$provider->price_per_night}} </span>
                    </a>
                  </li>
                                 
                </ul>
              </div>
            </div>
            <!-- /.widget-user -->
          </div>
          <!-- /.col -->
        </div>

          <div class="col-md-12">
            <div class="card card-widget widget-user-2">
              <!-- Add the bg color to the header using any of the bg-* classes -->
              <div class="widget-user-header bg-warning" style="    background-color: #cf676c!important;
">      
              <h3 class="widget-user-username" style="font-size: 22px;    color: #fff;
    font-weight: 500;">BOOKING DETAILS</h3>          
                </div>
                <!-- /.widget-user-image -->
                <ul class="nav flex-column">
                  <li class="nav-item">
                    <a  class="nav-link">
                      Booking ID <span class="float-right badge bg-primary">{{$data->booking_id}}</span>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link">
                      Booking Check In Date <span class="float-right badge bg-info">{{$booking->check_in}}</span>
                    </a>
                  </li>   
                   <li class="nav-item">
                    <a class="nav-link">
                      Booking Check Out Date <span class="float-right badge bg-info">{{$booking->check_out}}</span>
                    </a>
                  </li>               
                   <li class="nav-item">
                    <a class="nav-link">
                      Booking Amount <span class="float-right badge bg-info">$ {{$booking->total_amount}}</span>
                    </a>
                  </li>  
                   <li class="nav-item">
                    <a class="nav-link">
                      Booking Status <span class="float-right badge bg-info">{{$booking->check_in}}</span>
                    </a>
                  </li>  
                </ul>
              </div>
              
            </div>
          </div>
              <?php if(empty($attachments)){ ?>
                

                <?php


              }else{?>
                <div  class="col-md-12">
                <div  class="card" style="padding: 5px">
                  <h3 class="widget-user-username" style="font-size: 22px;">Provider Attachments Details</h3>
               <div id="gallery"></div>
             </div>
            </div>
              
          <?php } ?>

        </div>
      </div>
    </div>


        </div>
<!-- /.row -->
</section>

@endsection
@section('scripts')
       <script src="https://cdn.jsdelivr.net/gh/taras-d/images-grid/src/images-grid.min.js"></script>

<script>
  $('#gallery').imagesGrid({
    images: <?php echo json_encode($attachments) ?>,
    align: true
  });
</script>
@endsection