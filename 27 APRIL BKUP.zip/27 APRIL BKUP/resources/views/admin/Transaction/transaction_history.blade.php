@extends('layouts.master')

@section('content')

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Transaction History</h1>           
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Transaction History</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->      
      </div><!-- /.container-fluid -->
    </div>

    <!-- /.content-header -->
    <div class="container-fluid">
        <table id="example" class="table table-striped table-bordered" style="width:100%">
          <thead>
              <tr>
                  <th>Sr. No</th>
                  <th>Transaction</th>
                  <th>Amount</th> 
                  <th>Date</th>   
                  <th>Action</th>                               
              </tr>
          </thead>
          <tbody>        
           <?php $count = 0; ?>	
          @foreach($data as $key => $value)
             <?php $count++; ?>
              <tr>
               <td>{{@$count}}</td>

               <td><?php if($value['transaction_amount_status'] == '0'){ echo "Recieved"; }elseif($value['transaction_amount_status'] == '1'){ echo "In Progress"; }elseif($value['transaction_amount_status'] == '2'){ echo "Withdrawn";} ?></td>
               <td>{{$value['amount']}}</td>
               <td>{{$value['date']}}</td>
               <td>
                <?php if($value['transaction_amount_status'] == '1' || $value['transaction_amount_status'] == '2' ) {?> 
                      <a id="approve_transaction1" data-id="<?php echo $value['id']; ?>"  href="transactiondetails/{{$value['id']}}" class="lp-view-detail-btn" style="    padding: 1px 5px 0 5px;margin: 5px;border: 1px solid #95999e;color: #027aff;display: inline-block;background: #aa9f9f17;border-radius: 4px; " title="view" >
                             <i class="fa fa-eye" aria-hidden="true"></i>
                      </a> 

                  <?php }else{?> 

                    <a id="approve_transaction1" data-id="<?php echo $value['id']; ?>"  href="recieved_transactiondetails/{{$value['id']}}" class="lp-view-detail-btn" style="    padding: 1px 5px 0 5px;margin: 5px;border: 1px solid #95999e;color: #027aff;display: inline-block;background: #aa9f9f17;border-radius: 4px; " title="view" >
                         <i class="fa fa-eye" aria-hidden="true"></i>
                    </a> 


                  <?php }?>
                

                </td>
               
            
             </tr> 
          
          
            @endforeach
         
          </tbody>      
      </table>
    </div>


    
@endsection
