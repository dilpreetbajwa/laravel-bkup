@extends('layouts.master')
@section('content')
<style type="text/css">
  .imgs-grid-modal{margin-left: 250px!important;} 
  .widget-user-2 .widget-user-desc, .widget-user-2 .widget-user-username {
    margin-left: 108px;
    font-weight: 500;
}   
</style>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/taras-d/images-grid/src/images-grid.min.css">
<section class="content"> 
    <div class="row" style="margin-left: 15px;">
        <div class="col-md-12">
            <div class="box box-danger">
                <div class="box-header"  style=" text-align: center;">
                    <h3 class="box-title" style="    text-decoration: underline;">Transaction Details</h3>

                    @if (session()->has('message'))
                    <br>
                    <div class = "alert alert-success col-md-12">
                        <ul>
                          <li>{{Session::get('message')}}</li>
                      </ul>
                  </div>
                  @endif
              </div>
              <!-- /.box-header --> 
              <div class="box-body"  >
                 <div class="row">
          <div class="col-md-12">
            <!-- Widget: user widget style 2 -->
            <h3 class="widget-user-username" style="font-size: 22px;">User Details</h3>
            <div class="card card-widget widget-user-2">
              <!-- Add the bg color to the header using any of the bg-* classes -->
              <div class="widget-user-header bg-warning">
                <div class="widget-user-image">
                  <img class="img-circle elevation-2" src="{{url('/profile/'.@$provider_user->image)}}" style="height: 77px;width: 69px;object-fit: cover;" alt="User Avatar">
                </div>
                <!-- /.widget-user-image -->
                <h3 class="widget-user-username" style="font-size: 22px;color: #fff;">{{$provider_user->name}}</h3>
                <h5 class="widget-user-desc" style="font-size: 1rem;color: #fff;">{{$provider_user->email}}</h5>
              </div>
              <div class="card-footer p-0">
                <ul class="nav flex-column">
                  <li class="nav-item">
                    <a  class="nav-link">
                      Amount Transaction <span class="float-right badge bg-info">$ {{$data->transaction_amount}}</span>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link">
                      Date <span class="float-right badge bg-info">{{$data->date}}</span>
                    </a>
                  </li>                
                </ul>
              </div>
            </div>
            <!-- /.widget-user -->
          </div>
          <!-- /.col -->
         
          <!-- /.col -->
     
          <!-- /.col -->
        </div>

          <div class="col-md-12">
            <div class="card card-widget widget-user-2">
              <!-- Add the bg color to the header using any of the bg-* classes -->
              <div class="widget-user-header bg-warning" style="    background-color: #cf676c!important;">      
              <h3 class="widget-user-username" style="font-size: 22px;    color: #fff;font-weight: 500;"> BANK DETAILS</h3>          
                </div>
                <!-- /.widget-user-image -->
                <ul class="nav flex-column">
                  <li class="nav-item">
                    <a class="nav-link">
                      Bank Name <span class="float-right badge bg-info">{{$data->bank_name}}</span>
                    </a>
                  </li>  
                  <li class="nav-item">
                    <a  class="nav-link">
                      Account Holder <span class="float-right badge bg-info">{{$data->account_holder}}</span>
                    </a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link">
                      Account Number<span class="float-right badge bg-info">{{$data->account_number}}</span>
                    </a>
                  </li>   
                                
                   <li class="nav-item">
                    <a class="nav-link">
                      Iban<span class="float-right badge bg-info">{{$data->iban}}</span>
                    </a>
                  </li>  
                   <li class="nav-item">
                    <a class="nav-link">
                      Sort Code <span class="float-right badge bg-info">{{$data->sort_code}}</span>
                    </a>
                  </li>  
                </ul>
              </div>
              
            </div>
          </div>
        

        </div>
      </div>
    </div>


        </div>
<!-- /.row -->
</section>

@endsection


