@extends('layouts.master')

@section('content')

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Bookings</h1>           
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Bookings</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->      
      </div><!-- /.container-fluid -->
    </div>

    <!-- /.content-header -->
    <div class="container-fluid">
              <select id="booking_status" class="form-control" name="booking_status" style="width: 15%;color: #fff; background: #353a40; margin: 10px;">
                   <option value="{{url('/booking_list/all')}}" <?php if($status_data == 'all'){ echo 'selected="selected"';} ?> >All</option>
                <option value="{{url('/booking_list/upcoming')}}" <?php if($status_data == 'upcoming'){ echo 'selected="selected"';} ?> >Upcoming</option>
                <option value="{{url('/booking_list/cancelled')}}" <?php if($status_data == 'cancelled'){ echo 'selected="selected"';} ?> >Cancelled</option>
                <option value="{{url('/booking_list/completed')}}"  <?php if($status_data == 'completed'){ echo 'selected="selected"';} ?> >Completed</option>
              </select>
        <table id="example" class="table table-striped table-bordered" style="width:100%">
          <thead>
              <tr>
                  <th>Booking ID</th>
                  <th>Booking User</th>
                  <th> Title</th>
                  <th>Check In</th>
                  <th>Check Out</th>
                  <th>Amount</th>
                  <th>Status</th>
              </tr>
          </thead>
          <tbody>        
          @foreach($data as $key => $value)
         
            
              <tr>
               <td>{{$value['id']}}</td>
               <td>{{$value['user']}}</td>
               <td>{{$value['provider_title']}}</td>
               <td>{{$value['check_in']}}</td>
               <td>{{$value['check_out']}}</td>
               <td>{{$value['total_amount']}}</td>
                <td>{{$value['status']}}</td>
            
             </tr> 
          
          
            @endforeach
         
          </tbody>      
      </table>
    </div>


    
@endsection
@section('scripts')
<script type="text/javascript">
 var urlmenu = document.getElementById( 'booking_status' );
 urlmenu.onchange = function() {
  window.open( this.options[ this.selectedIndex ].value, '_self');
};
</script>


@endsection
