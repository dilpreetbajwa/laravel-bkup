@extends('layouts.master')

@section('content')

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">{{ @$data['page_title'] }}</h1>           
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Users</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->      
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <div class="container-fluid">
        <table id="example" class="table table-striped table-bordered" style="width:100%">
          <thead>
              <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Phone</th>
                  <th>Date Of Birth</th>
                  <th>Gender</th>
                  <!-- <th>Action</th> -->
              </tr>
          </thead>
          <tbody>
            @foreach(@$data['data'] as $key => $raw_data)
              <tr>
                  <td>{{$raw_data['name']." ".$raw_data['lastname']}}</td>
                  <td>{{$raw_data['email']}}</td>
                  <td>{{$raw_data['phone_number']}}</td>
                  <td>{{$raw_data['dob']}}</td>
                  <td>{{$raw_data['gender']}}</td>
                  <!-- <td> 
                 <a title="Delete" style="    padding:1px 5px 0px 5px; margin: 4px; border: 1px solid #95999e;display: inline-block;background: #aa9f9f17;border-radius: 4px;" title="delete" class="edit delete delete-item" href="{{ url('delete-user/'.@$raw_data['id']) }}"><i class="fa fa-trash" style="color: #b61010;"></i>
                     </a>
               </td> -->
              </tr> 
              @endforeach          
          </tbody>      
      </table>
    </div>
    
@endsection
