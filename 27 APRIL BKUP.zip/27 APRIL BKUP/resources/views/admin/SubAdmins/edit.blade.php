@extends('layouts.master')


@section('content')
 <!-- Content Header (Page header) -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css">
 <script src="{{url('js/jscolor.js')}}"></script>
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Edit  Sub-Admin</h1>           
          </div><!-- /.col -->
        </div><!-- /.row -->      
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
 @if ($errors->any())
  <div class="alert alert-danger">
      <ul>
          @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
          @endforeach
      </ul>
  </div>
@endif
<div class="flash-message">
    @foreach (['danger', 'warning', 'success', 'info'] as $msg)
      @if(Session::has('alert-' . $msg))

      <p class="alert alert-{{ $msg }}">{{ Session::get('alert-' . $msg) }} <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p> 
      @endif
    @endforeach
  </div>

<div class="container-fluid">
    <form method="POST" action="{{route('editsavesubadmin')}}" enctype="multipart/form-data" >
      {{csrf_field()}}
  <div class="form-group">
    <label for="name">Name</label>
    <input type="hidden" name="id" value="{{$users->id}}">
    <input type="text" placeholder="Name" value="{{$users->name}}" class="form-control" name="name" required>
  </div>  
  <div class="form-group">
    <label for="email">Email</label>
    <input type="text" placeholder="Email" value="{{$users->email}}" class="form-control" id='email' name="email" required>
  </div>
    <div class="form-group">
    <label for="email">Password</label>
    <input type="password" placeholder="Password" value="" class="form-control" id='password' name="password" required>
  </div>
      <div class="form-group">
    <label for="perminssions">Permissions</label><br>
    <input type="checkbox" name="permissions[]" value="Users" <?php if(in_array('Users', $menu_user)){?> checked <?php } ?>  /> Users<br />
    <input type="checkbox" name="permissions[]" value="People" <?php if(in_array('People', $menu_user)){?> checked='checked' <?php }?>   /> People<br />
    <input type="checkbox" name="permissions[]" value="Places" <?php if(in_array('Places', $menu_user)){?> checked='checked' <?php ?>  /> Places<br />
    <input type="checkbox" name="permissions[]" value="Things"  <?php if(in_array('Things', $menu_user)){?> checked='checked' <?php } ?>   /> Things<br />
    <input type="checkbox" name="permissions[]" value="Coupons" <?php if(in_array('Coupons', $menu_user)){?> checked='checked' <?php }?>  <?php } ?> /> Coupons<br />
    <input type="checkbox" name="permissions[]" value="Bookings" <?php if(in_array('Bookings', $menu_user)){?> checked <?php } ?>  /> Bookings<br />
    <input type="checkbox" name="permissions[]" value="Transactions" <?php if(in_array('Transactions', $menu_user)){?> checked='checked'  <?php } ?>  /> Transactions<br />
    <input type="checkbox" name="permissions[]" value="Support" <?php if(in_array('Support', $menu_user)){?> checked='checked' <?php } ?>  /> Support<br />
    <input type="checkbox" name="permissions[]" value="FAQ" <?php if(in_array('FAQ', $menu_user)){?> checked='checked' <?php } ?>  /> FAQ<br />
    <input type="checkbox" name="permissions[]" value="Terms and Condition" <?php if(in_array('Terms and Condition', $menu_user)){?> checked='checked' <?php } ?>  /> Terms and Condition<br />
    <input type="checkbox" name="permissions[]" value="Privacy Policy" <?php if(in_array('Privacy Policy', $menu_user)){?> checked='checked' <?php } ?>  /> Privacy Policy<br />
    <input type="checkbox" name="permissions[]" value="About Us" <?php if(in_array('About Us', $menu_user)){?> checked='checked' <?php } ?>  /> About Us<br />
  </div>
   

 
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
</br>
</br>
</br>

@endsection('content')