@extends('layouts.master')


@section('content')
 <!-- Content Header (Page header) -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css">
 <script src="{{url('js/jscolor.js')}}"></script>
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Add  Sub-Admin</h1>           
          </div><!-- /.col -->
        </div><!-- /.row -->      
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
 @if ($errors->any())
  <div class="alert alert-danger">
      <ul>
          @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
          @endforeach
      </ul>
  </div>
@endif


<div class="container-fluid">
    <form method="POST" action="{{route('addnewsubadmin')}}" enctype="multipart/form-data" >
      {{csrf_field()}}
  <div class="form-group">
    <label for="name">Name</label>
    <input type="text" placeholder="Name" value="" class="form-control" name="name" required>
  </div>  
  <div class="form-group">
    <label for="email">Email</label>
    <input type="text" placeholder="Email" value="" class="form-control" id='email' name="email" required>
  </div>
    <div class="form-group">
    <label for="password">Password</label>
    <input type="password" placeholder="Password" value="" class="form-control" id='password' name="password" required>
  </div>
      <div class="form-group">
    <label for="perminssions">Permissions</label><br>
    <input type="checkbox" name="permissions[]" value="Users" /> Users<br />
    <input type="checkbox" name="permissions[]" value="People" /> People<br />
    <input type="checkbox" name="permissions[]" value="Places" /> Places<br />
    <input type="checkbox" name="permissions[]" value="Things" /> Things<br />
    <input type="checkbox" name="permissions[]" value="Coupons" /> Coupons<br />
    <input type="checkbox" name="permissions[]" value="Bookings" /> Bookings<br />
    <input type="checkbox" name="permissions[]" value="Transactions" /> Transactions<br />
    <input type="checkbox" name="permissions[]" value="Support" /> Support<br />
    <input type="checkbox" name="permissions[]" value="FAQ" /> FAQ<br />
    <input type="checkbox" name="permissions[]" value="Terms and Condition" /> Terms and Condition<br />
    <input type="checkbox" name="permissions[]" value="Privacy Policy" /> Privacy Policy<br />
    <input type="checkbox" name="permissions[]" value="About Us" /> About Us<br />
  </div>
   

 
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
</br>
</br>
</br>

@endsection('content')