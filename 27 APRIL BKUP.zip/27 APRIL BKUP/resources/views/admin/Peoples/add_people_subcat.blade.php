@extends('layouts.master')

@section('content')
 <!-- Content Header (Page header) -->
   <script src="{{url('js/jscolor.js')}}"></script>

    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Add  People SubCategory</h1>           
          </div><!-- /.col -->
        </div><!-- /.row -->      
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
 @if ($errors->any())
  <div class="alert alert-danger">
      <ul>
          @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
          @endforeach
      </ul>
  </div>
@endif
<div class="container-fluid">
    <form method="POST" action="{{route('add_people_subcategory')}}" enctype="multipart/form-data" >
      {{csrf_field()}}

  <div class="form-group">
    <label for="people_cat">Select People Category:</label>
    <select class="form-control" name="people_cat" id="people_cat">

              @foreach ($people as $peoples)
              <option value="<?php echo $peoples->id ?>">{{$peoples->name}}</option>
          @endforeach

    </select>
  </div> 
  
  <div class="form-group">
    <label for="name">Name</label>
    <input type="text" class="form-control" id="name" name="name" placeholder="Enter SubCategory name">
  </div>   
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
@endsection('content')