@extends('layouts.master')

@section('content')
 <!-- Content Header (Page header) -->

 <script src="https://cdn.ckeditor.com/4.11.1/standard/ckeditor.js"></script>
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Terms and Condition</h1>           
          </div><!-- /.col -->
        </div><!-- /.row -->      
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
 @if ($errors->any())

  <div class="alert alert-danger" role="alert">
      <ul>
          @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
          @endforeach
      </ul>
  </div>
@endif
<div class="flash-message">
    @foreach (['danger', 'warning', 'success', 'info'] as $msg)
      @if(Session::has('alert-' . $msg))

      <p class="alert alert-{{ $msg }}">{{ Session::get('alert-' . $msg) }} <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p> 
      @endif
    @endforeach
  </div>

<div class="container-fluid">
    <form method="POST" action="{{route('add_terms_and_condition')}}" enctype="multipart/form-data" >
      {{csrf_field()}}
  <div class="form-group">
     <label for="question">Title:</label>
      @if($data)         
       <input type="text" name="title" class="form-control" value="{{$data->title}}" readonly>         
      @else
        <input type="text" name="title" class="form-control" value="Terms and Conditions" readonly>          
      @endif
      
  </div>  
  <div class="form-group">
   <label for="answer">Description:</label>
     @if($data)         
        <textarea name="description">{{$data->description}}</textarea>         
      @else
        <textarea name="description"></textarea>      
      @endif
    
  </div>      
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>

</br>
</br>
</br>

@endsection('content')