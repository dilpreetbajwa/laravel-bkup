@extends('layouts.master')

@section('content')
 <!-- Content Header (Page header) -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css">
 <script src="{{url('js/jscolor.js')}}"></script>
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Edit  Things</h1>           
          </div><!-- /.col -->
        </div><!-- /.row -->      
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
 @if ($errors->any())
  <div class="alert alert-danger">
      <ul>
          @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
          @endforeach
      </ul>
  </div>
@endif
<div class="flash-message">
    @foreach (['danger', 'warning', 'success', 'info'] as $msg)
      @if(Session::has('alert-' . $msg))

      <p class="alert alert-{{ $msg }}">{{ Session::get('alert-' . $msg) }} <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a></p> 
      @endif
    @endforeach
  </div>

<div class="container-fluid">
    <form method="POST" action="{{route('edit_things_data')}}" enctype="multipart/form-data" >
      {{csrf_field()}}
  <div class="form-group">
    <label for="name">Name</label>
    <input type="hidden" name="id" value="{{$data->id}}">
    <input type="text" class="form-control" id="name" name="name" placeholder="Enter Category name" value="{{$data->name}}">
  </div>  
  <div class="form-group">
    <label for="exampleFormControlFile1">Image</label>
    <input type="file" class="form-control-file" name="image" id="image" value="{{$data->image}}">
  </div>
   <div class="form-group">
    <label for="exampleFormControlFile1">Image Background Color:</label>
    <input class="jscolor" name="color" value="{{$data->color}}">
  </div>

 
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
</br>
</br>
</br>
<!-- <div class="container-fluid">
        <table id="example" class="table table-striped table-bordered" style="width:100%">
          <thead>
              <tr>
                  <th>ID</th>
                  <th>Category</th>
                  <th>Image</th>
                  <th>Action</th>
              </tr>
          </thead>
          <tbody>       
          
            @foreach($data as $key => $value)
            
              <tr>
               <td>{{$value['id']}}</td>
               <td>{{$value['name']}}</td>
               <td><div style="background-color: #{{$value['color']}};    width: 60px;padding: 13px; border-radius: 50%; "><img  style="width: 35px;"  src="{{url('/places/'.@$value['image'])}}"></div></td>
               <td> 
                <a title="Edit" style="    padding:1px 5px 0px 5px; margin: 4px; border: 1px solid #95999e;display: inline-block;background: #aa9f9f17;border-radius: 4px;" title="edit" class="edit edit-item" href="{{ url('edit-places') }}" id="edit"><i class="fa fa-edit" style="color: #027aff;"></i>
                </a>
              </td>
                  
             </tr> 
            @endforeach
          </tbody>      
      </table>
    </div> -->
@endsection('content')