@extends('layouts.master')

@section('content')
 <!-- Content Header (Page header) -->
   <script src="{{url('js/jscolor.js')}}"></script>

    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Add  Things SubCategory</h1>           
          </div><!-- /.col -->
        </div><!-- /.row -->      
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
 @if ($errors->any())
  <div class="alert alert-danger">
      <ul>
          @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
          @endforeach
      </ul>
  </div>
@endif
<div class="container-fluid">
    <form method="POST" action="{{route('add_things_subcategory')}}" enctype="multipart/form-data" >
      {{csrf_field()}}

  <div class="form-group">
    <label for="things_cat">Select Things Category:</label>
    <select class="form-control" name="things_cat" id="things_cat">
      @foreach ($things as $thing)
              <option value="<?php echo $thing->id ?>">{{$thing->name}}</option>
          @endforeach
    </select>
  </div>
  
  <div class="form-group">
    <label for="name">Name</label>
    <input type="text" class="form-control" id="name" name="name" placeholder="Enter SubCategory name">
  </div>   
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>
@endsection('content')