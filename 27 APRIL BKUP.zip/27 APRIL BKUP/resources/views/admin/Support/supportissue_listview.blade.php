@extends('layouts.master')

@section('content')

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Support</h1>           
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Support</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->      
      </div><!-- /.container-fluid -->
    </div>

    <!-- /.content-header -->
    <div class="container-fluid">
        <table id="example" class="table table-striped table-bordered" style="width:100%">
          <thead>
              <tr>
                  <th>Support ID</th>
                  <th>Issue Type</th>
                  <th>Description</th>
                  <th>User Name</th>
                  <th>User Contact</th>  
                  <th>Email</th>    
                  <th>Action</th>                
              </tr>
          </thead>
          <tbody>        
          @foreach($data as $key => $value)
         
            
              <tr>
               <td>{{$value['id']}}</td>
               <td>{{$value['issue_type']}}</td>
               <td>{{$value['description']}}</td>
               <td>{{$value['user_name']}}</td>
               <td>{{$value['user_contact']}}</td>
               <td>{{$value['email']}}</td>
               <td><a title="Delete" data-id="{{$value['id']}}" style="    padding:1px 5px 0px 5px; margin: 4px; border: 1px solid #95999e;display: inline-block;background: #aa9f9f17;border-radius: 4px;" title="delete" class="edit delete delete_support" ><i class="fa fa-trash" style="color: #b61010;"></i></td>
                         
             </tr> 
          
          
            @endforeach
         
          </tbody>      
      </table>
    </div>


    
@endsection
