@extends('layouts.master')

@section('content')

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark"></h1>           
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">ServiceProvider</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->      
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <div class="container-fluid">
        <table id="example" class="table table-striped table-bordered" style="width:100%">
          <thead>
              <tr>
                  <th>Name</th>
                  <th>Category</th>
                  <th>Subcategory</th>
                  <th>Title</th>
                  <th>Action</th>
              </tr>
          </thead>
          <tbody>       
          
            @foreach($data as $key => $value)
            
              <tr>
                  <td>{{$value['name']}}</td>
                  <td>{{$value['category']}}</td>
                  <td>{{$value['subcategory']}}</td>
                  <td>{{$value['title']}}</td>
                  <td>  
                    <a  id="approve_data" data-id="<?php echo $value['id']; ?>" data-user_id="<?php echo $value['user_id']; ?>" class="lp-view-detail-btn approve_placedata" style="    padding: 1px 5px 0 5px;margin: 5px;border: 1px solid #95999e;color: #242623de;display: inline-block;background: #aa9f9f17;border-radius: 4px; "><i class="fa fa-check" <?php if($value['status'] == '1'){ echo  'style="color:green"'; } ?> aria-hidden="true"></i></a>
                   </a>
               </td>
             </tr> 
            @endforeach
          </tbody>      
      </table>
    </div>
    
@endsection
