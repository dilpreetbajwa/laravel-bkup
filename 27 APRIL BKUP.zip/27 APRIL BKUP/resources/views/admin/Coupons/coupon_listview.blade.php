@extends('layouts.master')

@section('content')

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Coupons</h1>           
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">ServiceProvider</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->      
      </div><!-- /.container-fluid -->
    </div>

      <div class="content-addcoupon">
      <div class="container-fluid">
        <div class="row">
          <div class="col-sm-12">
            <h5 class="m-0 text-dark" style="    border: 1px solid #ddd;
    width: 132px;
    padding: 10px;
    background: #353a40;
    color: #ffff !important;
    font-size: 15px;
    float: right;margin:10px !important">Add Coupons <i class="fa fa-plus" aria-hidden="true" data-toggle="modal" data-target="#addcoupon_modal"></i></h5>           
          </div><!-- /.col -->
        
        </div><!-- /.row -->      
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <div class="container-fluid">
        <table id="example" class="table table-striped table-bordered" style="width:100%">
          <thead>
              <tr>
                  <th>Coupon Code</th>
                  <th>Discount(%)</th>
                  <th>Rules</th>
                  <th>Amount</th>
                  <th>Applicable On</th>
                  <th>Action</th>
              </tr>
          </thead>
          <tbody>       
          
            @foreach($coupons as $key => $value)
            
              <tr>
               <td>{{$value['coupon_code']}}</td>
                  <td>{{$value['discount']}}</td>
                  <td>{{$value['rules']}}</td>
                  <td>{{$value['amount']}}</td>
                  <td>{{$value['applicable_on']}}</td>
                  <td>  
                    <form method="post">
              {{csrf_field()}}
                    <a  data-id="<?php echo $value['id'] ?>" data-user_id=" ?>" class="lp-view-detail-btn deletecoupon"  style="    padding: 1px 5px 0 5px;margin: 5px;border: 1px solid #95999e;color: #ea0e0ede;display: inline-block;background: #aa9f9f17;border-radius:  4px; cursor: pointer; "><i class="fa fa-trash" aria-hidden="true"></i></a>
                   </form>
               </td>
             </tr> 
            @endforeach
          </tbody>      
      </table>
    </div>


    <!-- Modal -->
  <div class="modal fade" id="addcoupon_modal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header" style="background: #17a2b8;
    color: #fff;">
          <h4 class="modal-title">Add Coupon</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          
        </div>
        <div class="modal-body">
         
          <form id="model-form" role="form" action="{{route('add_coupon')}}"  method="POST"  enctype="multipart/form-data">
                    <div class="box-body">
                    {{csrf_field()}}
                              <table >
                              <tr>
                                <td><b>Coupon Code</b></td>
                              </tr>

                              <tr>
                                <td colspan="3"> 
                                  <input type="text" placeholder="Coupon Code" value="" class="form-control" name="coupon_code">


                                </td> 
                              </tr>

                              <tr>
                                <td></br><b>Backgroung Image</b></td>
                              </tr>
                              <tr>
                                <td colspan="2">
                                <input type="file" name="background_image" id="image">
                                </td>
                              </tr>

                              <tr>
                                <td style="text-align: center;"></br><b>Discount(%)</b></td>
                                <td style="text-align: center;"></br><b>Rules</b></td>
                                <td style="text-align: center;"></br><b>Amount</b></td>
                              </tr>

                              <tr>
                                <td>
                               <input type="text" placeholder="Discount(%)" value="" class="form-control" name="discount">
                                </td>
                                <td style="padding: 10px; width: 90px;">
                                  <select name="rules" class="form-control">
                                    <option value="less than"><</option>
                                    <option value="greater than">></option>
                                    <option value="less than equal to"><=</option>
                                    <option value="greater than equal to">>=</option>
                                  </select> 
                                </td>
                                 <td>
                                 <input type="text" placeholder="Amount" value="" class="form-control" name="amount">
                                </td>

                              </tr>
                              <tr>
                                <td></br><b>Applied for</b></td>
                              </tr>

                              <tr>
                                <td colspan="3"> 
                                 <select name="applicable_on" class="form-control">
                                    <option value="places">Places</option>
                                    <option value="things">Things</option>
                                    <option value="people">People</option>
                                    <option value="all">All</option>
                                  </select> 

                                </td>
                              </tr>

                              <tr>
                                <td></br><b>Valid for</b></td>
                              </tr>

                              <tr>
                                <td colspan="2"> 
                                <input type="text" placeholder="Valid for" value="" class="form-control" name="valid_for">

                                </td>
                                <td > 
                                   &nbsp;&nbsp;Days

                                </td>
                              </tr>
                          
                              <tr>
                                <td colspan="3" style="text-align: center;">
                                </br>
                                  <input type="submit" class="btn btn-info" name="submit" value="Submit">
                                </td>
                              </tr>
                              </table>


                    <div>
                            
                           </div>
                </div>

                </form>





        </div>
      
      </div>
      
    </div>
  </div>
    

@endsection
