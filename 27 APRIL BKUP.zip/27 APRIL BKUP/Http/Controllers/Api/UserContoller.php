<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\URL;
use App\User;
use Validator;
use Auth;
use Mail;
use App\Mail\ForgotPassword; 
use Hash;

class UserController extends Controller {

    public function login(Request $request) {

        try {

                $rules = [
                    'email' => 'required',
                    'password' => 'required|min:6',

                ];
      
                $validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {
                    return response()->json([
                       "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422);               
                }
            
                if(Auth::attempt(['email' => $request->get('email') , 'password' => $request->get('password'),'role'=>array(2,3) ]))
                {
                   
                    $user = Auth::user();           
                    $token = $user->createToken($user->id. ' token ')->accessToken;
                    $result['user'] = $user;
                    $result['user']['image'] = URL::to('/').'/profile/'.$user->image;
                    $result['message'] = 'Login successfully.';
                    $result['access_token'] = $token;
                    $result['success'] = 1;   
                                 
                }else{
                return response()->json([
                   "message" => 'Please enter correct username and password.',
               ], 401); 
            }
                
       }catch(Exception $e){
            $result = [
                'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $result['success'] = 0;
            
        }
        return $result;
    }

    public function update_deviceToken(Request $request){

        try {
            $user_id = Auth::id();
                $rules = [
                    'device_token' => 'required',
                    'device_type' => 'required',              
                ];
      
                $validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {
                    return response()->json([
                       "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422);               
                }

            $updateDeviceToken = User::where('id', $user_id)->update([
                    'device_token' => $request->get('device_token'),
                    'device_type' => $request->get('device_type'),

            ]);

            if($updateDeviceToken){

                return response()->json([
                                        'status' => 1,
                                        'message' => 'Successfully updated token',
                                        
                ], 200); 

            }else{
                  return response()->json([
                    'status' => 0,
                   "message" => 'Something went wrong.',
               ], 401); 
            }

        }catch(Exception $e){
            $result = [
                'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $result['success'] = 0;
            
        }
        return $result;

    }

    public function changepassword(Request $request)
    {
        $userid = Auth::id();
        try{
              $rules = [
               
               'password' =>'required',
               'new_password' =>'required',
              ];

              $validator = Validator::make($request->all(),$rules);
              if($validator->fails())
              {
                return response()->json([
                 "message" => "Something went wrong!",
                 'errors' => $validator->errors()->toArray(),
                ], 422);    
              }
             if (Hash::check($request->password, Auth::user()->password)){
              User::where('id',$userid)->update(['password'=>bcrypt($request->new_password)]);
               $result['message']   = "Password Updated successfully";
               $result['success'] = 1;         
             }
             else{

                  return response()->json([
                 "message" => "your old password is incorrect",
                 'success' => 0,
                ], 422);  
            
                }
        }
        catch(Exception $e)
        {
           $result = [
            'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
          ];

          Log::error($e->getTraceAsString());
          $result['success'] = 0;
        }
        return $result; 
    }

    //Start: functin added by yamini (upload chat image)
    public function uploadImage(Request $request){
        try{
            $rules = [
                        'image' => 'required',
                    ];

            $validator = Validator::make($request->all(), $rules);
            if($validator->fails())
            {
                return response()->json([
                   "message" => $validator->errors()->first(),
                   'errors' => $validator->errors()->toArray(),
               ], 422);               
            }

            if( $request->file('image')!= ""){
                if (!file_exists( public_path('/chat'))) {
                    mkdir(public_path('/chat'), 0777, true);
                }
                $path =public_path('/chat/');
                $image = $request->file('image');
                $Image = time().'.'.$image->getClientOriginalExtension();
                $destinationPath = public_path('/chat');
                $image->move($destinationPath, $Image);
            }else{
                $Image = "";  
            }
            $imageUrl =  url("/chat/$Image");
            //echo $Image;die;

            return response()->json([
                                        'status' => 1,
                                        'message' => 'Successfully uploaded image!',
                                        'image_url' => $imageUrl,
                                    ], 200); 

        }catch (Exception $e) {
            $result['message'] = "Some thing went wrong!";
            $result = [
                  'errors' => $e->getMessage().' Line No '. $e->getLine(). ' in File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $response['status'] = 0;
            $response['response'] = $result;
            return $response;
        }
    }
    //End: functin added by yamini

    public function signup(Request $request) {

        

        try {

            if($request->facebook_id != ""){

            $rules = [
                'facebook_id' => 'required',  
                'email' => 'required|unique:users|email',  
                'phone_number' => 'required|unique:users',                       
            ];

            $validator = Validator::make($request->all(), $rules);
            if($validator->fails())
            {
                return response()->json([
                   "message" => $validator->errors()->first(),
                   'errors' => $validator->errors()->toArray(),
               ], 422);               
            }
            
            $facebook_email =  User::where('email',$request->email)->first();        

            if($facebook_email != ""){
                
                    $update = User::where(["email" => $request->email])->update([ 
                        'facebook_id' => $request->facebook_id,
                     ]);

                    $mainUser = User::where('email', $request->email)->first();
                    $tokenResult = $facebook->createToken('Personal Access Token');
                    $token = $tokenResult->token;
                    $token->save();
                    return response()->json([
                       'status' => 1,
                       'message' => 'Successfully Logged In!',
                       'user' => $mainUser,
                       'access_token' => $tokenResult->accessToken,
                       'token_type' => 'Bearer',
                    ], 200);    

                }else{

                $mainUser = new User;
                $mainUser->name = $request->get('firstname');
                $mainUser->email = $request->get('email');
                $mainUser->password = bcrypt($request->get('password'));
                $mainUser->lastname = $request->get('lastname');
                $mainUser->facebook_id = $request->get('facebook_id');
                $mainUser->phone_number = $request->get('phone_number');
                $mainUser->country_code = $request->get('country_code');
                $mainUser->country_initials = $request->get('country_initials');
                $mainUser->dob = $request->get('dob');
                $mainUser->gender = $request->get('gender');
                $mainUser->image = $request->get('image');
                $mainUser->role = '2';
                $mainUser->save();

                }

                $tokenResult = $mainUser->createToken('Personal Access Token');
                $token = $tokenResult->token;
                $token->save();

                return response()->json([
                    'status' => 1,
                    'message' => 'Successfully created user!',
                    'data' => $mainUser,
                    'access_token' => $tokenResult->accessToken,
                    'token_type' => 'Bearer',
                 ], 200);  

            }elseif($request->google_id != ""){

            $rules = [
                'google_id' => 'required',    
                'email' => 'required|unique:users|email',   
                'phone_number' => 'required|unique:users',                    
            ];

            $validator = Validator::make($request->all(), $rules);
            if($validator->fails())
            {
                return response()->json([
                   "message" => $validator->errors()->first(),
                   'errors' => $validator->errors()->toArray(),
               ], 422);               
            }
            $google_email =  User::where('email',$request->email)->first();
            if( $request->file('image')!= ""){
                if (!file_exists( public_path('/profile'))) {
                    mkdir(public_path('/profile'), 0777, true);
                }
                $path =public_path('/profile/');
                $image = $request->file('image');
                $profileImage = time().'.'.$image->getClientOriginalExtension();
                $destinationPath = public_path('/profile');
                $image->move($destinationPath, $profileImage);
            }else{
                $profileImage = "";  
            }

            if($google_email != ""){
                    $update = User::where(["email" => $request->email])->update([
                        'google_id' => $request->google_id,
                        
                     ]);

                    $mainUser = User::where('email', $request->email)->first();
                    $tokenResult = $google->createToken('Personal Access Token');
                    $token = $tokenResult->token;
                    $token->save();
                    return response()->json([
                       'status' => 1,
                       'message' => 'Successfully Logged In!',
                       'user' => $mainUser,
                       'access_token' => $tokenResult->accessToken,
                       'token_type' => 'Bearer',
                    ], 200);    

                }else{
                  
                $mainUser = new User;
                $mainUser->name = $request->get('firstname');
                $mainUser->email = $request->get('email');
                $mainUser->password = bcrypt($request->get('password'));
                $mainUser->lastname = $request->get('lastname');
                $mainUser->google_id = $request->get('google_id');
                $mainUser->phone_number = $request->get('phone_number');
                $mainUser->country_code = $request->get('country_code');
                    $mainUser->country_initials = $request->get('country_initials');
                $mainUser->dob = $request->get('dob');
                $mainUser->gender = $request->get('gender');
                $mainUser->image = $request->get('image');
                $mainUser->role = '2';
                $mainUser->save();

                }

                $tokenResult = $mainUser->createToken('Personal Access Token');
                $token = $tokenResult->token;
                $token->save();

                return response()->json([
                    'status' => 1,
                    'message' => 'Successfully created user!',
                    'data' => $mainUser,
                    'access_token' => $tokenResult->accessToken,
                    'token_type' => 'Bearer',
                ], 200); 

            }elseif($request->instagram_id != ""){

            $rules = [
                'instagram_id' => 'required',  
                'email' => 'required|unique:users|email',  
                'phone_number' => 'required|unique:users',                       
            ];

            $validator = Validator::make($request->all(), $rules);
            if($validator->fails())
            {
                return response()->json([
                   "message" => $validator->errors()->first(),
                   'errors' => $validator->errors()->toArray(),
               ], 422);               
            }
            $instagram_email =  User::where('email',$request->email)->first();
            if( $request->file('image')!= ""){
                if (!file_exists( public_path('/profile'))) {
                    mkdir(public_path('/profile'), 0777, true);
                }
                $path =public_path('/profile/');
                $image = $request->file('image');
                $profileImage = time().'.'.$image->getClientOriginalExtension();
                $destinationPath = public_path('/profile');
                $image->move($destinationPath, $profileImage);
            }else{
                $profileImage = "";  
            }
            if($instagram_email != ""){
                    $update = User::where(["email" => $request->email])->update([
                        'instagram_id' => $request->instagram_id,
                        
                     ]);

                    $mainUser = User::where('email', $request->email)->first();
                    $tokenResult = $instagram->createToken('Personal Access Token');
                    $token = $tokenResult->token;
                    $token->save();
                    return response()->json([
                       'status' => 1,
                       'message' => 'Successfully Logged In!',
                       'user' => $mainUser,
                       'access_token' => $tokenResult->accessToken,
                       'token_type' => 'Bearer',
                    ], 200);    

                }else{
                    $rules = [
                        'phone_number' => 'required|unique:users',           
                    ];

                    $validator = Validator::make($request->all(), $rules);
                    if($validator->fails())
                    {
                        return response()->json([
                           "message" => $validator->errors()->first(),
                           'errors' => $validator->errors()->toArray(),
                       ], 422);               
                    }

                $mainUser = new User;
                $mainUser->name = $request->get('firstname');
                $mainUser->email = $request->get('email');
                $mainUser->password = bcrypt($request->get('password'));
                $mainUser->lastname = $request->get('lastname');
                $mainUser->instagram_id = $request->get('instagram_id');
                $mainUser->phone_number = $request->get('phone_number');
                $mainUser->country_code = $request->get('country_code');
               $mainUser->country_initials = $request->get('country_initials');
                $mainUser->dob = $request->get('dob');
                $mainUser->gender = $request->get('gender');
                $mainUser->image = $request->get('image');
                $mainUser->role = '2';
                $mainUser->save();

                }

                $tokenResult = $mainUser->createToken('Personal Access Token');
                $token = $tokenResult->token;
                $token->save(); 

                return response()->json([
                    'status' => 1,
                    'message' => 'Successfully created user!',
                    'data' => $mainUser,
                    'access_token' => $tokenResult->accessToken,
                    'token_type' => 'Bearer',
                ], 200); 
 
            }else{

            $rules = [
                'email' => 'required|unique:users|email',
                'phone_number' => 'required|unique:users',                 
            ];
            $validator = Validator::make($request->all(), $rules);
            if($validator->fails())
            {
                return response()->json([
                   "message" => $validator->errors()->first(),
                   'errors' => $validator->errors()->toArray(),
               ], 422);               
            }

            if( $request->file('image')!= ""){
                if (!file_exists( public_path('/profile'))) {
                    mkdir(public_path('/profile'), 0777, true);
                }
                $path =public_path('/profile/');
                $image = $request->file('image');
                $profileImage = time().'.'.$image->getClientOriginalExtension();
                $destinationPath = public_path('/profile');
                $image->move($destinationPath, $profileImage);
            }else{
                $profileImage ="";  
            }
            $check = User::where('email', $request->email)->first();
            if($check){
            
            $update = User::where('email', $request->email)->update([
                'name' => $request->firstname,
                'lastname' => $request->lastname,
                'phone_number' => $request->phone_number,
                'country_code' => $request->country_code,
                'country_initials' => $request->country_initials,
                'image' => $profileImage,
                'email' => $request->email,
                'dob' => $request->dob,
                'gender' => $request->gender,
                'password' => bcrypt($request->password),
                ]);
            $mainUser = User::where('email', $request->email)->first();
                
            }else{
                 $mainUser = new User;
                $mainUser->name = $request->get('firstname');
                $mainUser->email = $request->get('email');
                $mainUser->password = bcrypt($request->get('password'));
                $mainUser->lastname = $request->get('lastname');
                $mainUser->phone_number = $request->get('phone_number');
                $mainUser->country_code = $request->get('country_code');
                 $mainUser->country_initials = $request->get('country_initials');
                $mainUser->dob = $request->get('dob');
                $mainUser->gender = $request->get('gender');
                $mainUser->image = $profileImage;
                $mainUser->role = '2';
                $mainUser->save();
               
            }
            $tokenResult = $mainUser->createToken('Personal Access Token');
            $token = $tokenResult->token;
            $token->save();

                $result['data'] = $mainUser;
                $result['status'] = 1;
                $result['access_token'] = $tokenResult->accessToken;
                $result['token_type'] = 'Bearer';
                $result['data']['image'] = URL::to('/').'/profile/'.$mainUser->image;
                
                return $result; 
            

            }

         } catch (Exception $e) {
            $status = false;
            $result['message'] = "Some thing went wrong!";
            $result = [
                  'errors' => $e->getMessage().' Line No '. $e->getLine(). ' in File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $response['status'] = 0;
            $response['response'] = $result;
            return $response;
        }     
       
    }

    public function SoialLogin(Request $request){

         if($request->facebook_id != ""){

            $rules = [
                'facebook_id' => 'required',  
                'email' => 'required|email',            
            ];

            $validator = Validator::make($request->all(), $rules);
            if($validator->fails())
            {
                return response()->json([
                   "message" => $validator->errors()->first(),
                   'errors' => $validator->errors()->toArray(),
               ], 422);               
            }else{

            $result =  User::where('email',$request->email)->first();
                
                if($result){            
                        
                     $update = User::where(["email" => $request->email])->update([
                        'facebook_id' => $request->facebook_id,
                        
                     ]);      
                    $mainUser = User::where('email', $request->email)->first();
                    $tokenResult = $result->createToken('Personal Access Token');
                    $token = $tokenResult->token;
                    $token->save();
                    return response()->json([
                       'status' => 1,
                       'message' => 'Successfully Logged In!',
                       'user' => $mainUser,
                       'access_token' => $tokenResult->accessToken,
                       'token_type' => 'Bearer',
                    ], 200);   
                }else{
                     return response()->json([
                       'status' => 0,
                       'message' => 'Please Signup First!',
                    ], 200); 
                }
            }
            
   
     }elseif($request->google_id != ""){
        $rules = [
                'google_id' => 'required',     
                'email' => 'required|email',        
            ];

            $validator = Validator::make($request->all(), $rules);
            if($validator->fails())
            {
                return response()->json([
                   "message" => $validator->errors()->first(),
                   'errors' => $validator->errors()->toArray(),
               ], 422);               
            }else{

            $result =  User::where('email',$request->email)->first();
                
                if($result){            
                        
                     $update = User::where(["email" => $request->email])->update([
                        'google_id' => $request->google_id,
                        
                     ]);      
                    $mainUser = User::where('email', $request->email)->first();
                    $tokenResult = $result->createToken('Personal Access Token');
                    $token = $tokenResult->token;
                    $token->save();
                    return response()->json([
                       'status' => 1,
                       'message' => 'Successfully Logged In!',
                       'user' => $mainUser,
                       'access_token' => $tokenResult->accessToken,
                       'token_type' => 'Bearer',
                    ], 200);   
                }else{
                     return response()->json([
                       'status' => 0,
                       'message' => 'Please Signup First!',
                    ], 200); 
                }

     }

 }elseif($request->instagram_id != ""){

        $rules = [
                'instagram_id' => 'required',          
            ];

            $validator = Validator::make($request->all(), $rules);
            if($validator->fails())
            {
                return response()->json([
                   "message" => $validator->errors()->first(),
                   'errors' => $validator->errors()->toArray(),
               ], 422);               
            }else{

            $result =  User::where('instagram_id',$request->instagram_id)->first();
                
                if($result){            
                        
                     $update = User::where(["email" => $result->email])->update([
                        'instagram_id' => $request->instagram_id,
                        
                     ]);    
                    $mainUser = User::where('email', $result->email)->first();
                    $tokenResult = $result->createToken('Personal Access Token');
                    $token = $tokenResult->token;
                    $token->save();
                    return response()->json([
                       'status' => 1,
                       'message' => 'Successfully Logged In!',
                       'user' => $mainUser,
                       'access_token' => $tokenResult->accessToken,
                       'token_type' => 'Bearer',
                    ], 200);   
                }else{
                     return response()->json([
                       'status' => 0,
                       'message' => 'Please Signup First!',
                    ], 200); 
                }
     }
 }
}
    public function forgotPassword(Request $request){
        $validator = Validator::make($request->all(), [
                                   'email' => 'required|string|email'
                               ]);
        if ($validator->fails()) {
            $errors = $validator->errors()->toArray();

            return response()->json([
                'status' => 0,
                'message' => "Incorrect details",
                'errors' => $errors
            ], 400);
        }else{
                $email = $request->email;
                $user = User::where('email', $request->get('email'))->first();
                if($user){
                    $dummy_pass =  str_random(8);
                    $password = bcrypt($dummy_pass);
                    $user->password = $password;
                    $user->save();
                    Mail::to($email)->send(new ForgotPassword($user->name,$dummy_pass));
                    $result['message'] = 'Please check your email for new password';
                    return response()->json([
                        'status' => 1,
                        'message' => "Please check your email for new password"
                    ], 200);
                }else{
                    return response()->json([
                        'status' => 0,
                        'message' => "This Email Is not Register With Us"
                    ], 400);
                }
                
        }
    }

    public function updateProfile(Request $request){
        
        try{
            $rules = [
                'email' => 'required|email|max:255',
  
            ];

            
            $url = URL::to("/");

            $validator = Validator::make($request->all(), $rules);
            if($validator->fails())
            {
                return response()->json([
                   "message" => $validator->errors()->first(),
                   'errors' => $validator->errors()->toArray(),
               ], 422);               
            }

            $logedInuser = Auth::user(); 
            if( $request->file('image')){
                if (!file_exists( public_path('/profile'))) {
                    mkdir(public_path('/profile'), 0777, true);
                }
                $path =public_path('/profile/');
                $image = $request->file('image');
                $profileImage = time().'.'.$image->getClientOriginalExtension();
                $destinationPath = public_path('/profile');
                $image->move($destinationPath, $profileImage);
            
            }else{
                 $profileImage1 = User::where("id", $logedInuser->id)->first(); 
                $profileImage = $profileImage1->image; 
            }

              if( $request->file('goverment_id_image')!= ""){
                if (!file_exists( public_path('/documents'))) {
                    mkdir(public_path('/documents'), 0777, true);
                }
                $path =public_path('/documents/');
                $image = $request->file('goverment_id_image');
                $govermentIDImage = time().'.'.$image->getClientOriginalExtension();
                $destinationPath = public_path('/profile');
                $image->move($destinationPath, $govermentIDImage);

            }else{
                $govermentIDImage1 = User::where("id", $logedInuser->id)->first(); 
                $govermentIDImage =  $govermentIDImage1->image; 
            }

            $updateUser = User::where("id", $logedInuser->id)->update([
                'name' => $request->get('firstname'),
                'lastname' => $request->get('lastname'),
                'image' => $profileImage,
               /* 'dob' => $request->get('dob'),
                'image' => $profileImage,
                'goverment_id' => $request->get('goverment_id'),
                'goverment_id_image' => $govermentIDImage,
                'emergency_contact' => $request->get('emergency_contact'),
                'emergency_contact_name' => $request->get('emergency_contact_name'),*/

            ]);
            $User = User::where("id", $logedInuser->id)->first();

            if($updateUser){
                return response()->json([
                        'message' => "User updated successfully.",
                        'status' => 1,
                        'user' => $User,
                    ], 200);
            }else{
                return response()->json([
                        'message' => "Some thing went wrong.",
                        'status' => '0',
                    ], 404);
            }
        }catch (Exception $e) {
            $status = 0;
            $result['message'] = "Something went wrong!";
            $result = [
                  'errors' => $e->getMessage().' Line No '. $e->getLine(). ' in File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $response['status'] = 0;
            $response['response'] = $result;
            return $response;
        }
    }

    public function getProfile(Request $request){
        try{          
            $logedInuser = Auth::user(); 
            $User = User::where("id", $logedInuser->id)->first();
             
           if($User){
            $result['user'] = $User; 
           if((substr_compare($User->image,"http",0,4)) === 0){
            $result['user']['image'] = $User->image;
             }else{
            $result['user']['image'] = URL::to('/').'/profile/'.$User->image;
             } 
                $result['message'] = "User Profile data.";
                
                
                return $result;
                
            }else{
                return response()->json([
                        'message' => "Some thing went wrong.",
                        'status' => '0',
                    ], 404);
            }
        }catch (Exception $e) {
            $status = 0;
            $result['message'] = "Something went wrong!";
            $result = [
                  'errors' => $e->getMessage().' Line No '. $e->getLine(). ' in File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $response['status'] = 0;
            $response['response'] = $result;
            return $response;
        }
    }

        public function VerifyPhone_no(Request $request){
        try{
            
            $rules = [
                'phone_number' => 'required',
  
            ];

            $validator = Validator::make($request->all(), $rules);
            if($validator->fails())
            {
                return response()->json([
                   "message" => $validator->errors()->first(),
                   'errors' => $validator->errors()->toArray(),
               ], 422);               
            }

            $User = User::where("phone_number", $request->phone_number)->first();
             
           if($User){

                return response()->json([
                        'message' => "Phone Number already exists.",
                        'status' => '0',
                    ], 404);
                
                
                return $result;
                
            }else{
                return response()->json([
                        'message' => "Phone Number is available.",
                        'status' => '1',
                    ], 200);
            }
        }catch (Exception $e) {
            $status = 0;
            $result['message'] = "Something went wrong!";
            $result = [
                  'errors' => $e->getMessage().' Line No '. $e->getLine(). ' in File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $response['status'] = 0;
            $response['response'] = $result;
            return $response;
        }
    }

        

}