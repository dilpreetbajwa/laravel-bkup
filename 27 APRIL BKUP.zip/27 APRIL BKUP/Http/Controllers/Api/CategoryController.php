<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use Validator;
use Auth;
use Mail;
use App\Category;
use App\Subcategory;

class CategoryController extends Controller
{
    public function getCategories(Request $request) {

        try {
			        $categories = Category::all();
			        foreach ($categories as $key => $category) {
			        	$categor[$key]['subcategory'] = Subcategory::where('cat_id' , $category->id)->get();
			        	$categor[$key]['name'] =  $category->name;
			        }
                    $result['categories'] = $categor; 
                    $result['status'] = 1;                   
       }catch(Exception $e){

             return response()->json([
             			"status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }
        return $result;
    }

}
