<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Validator;
use Redirect;
use App\Support_IssueType;
use App\Support;
use Auth;

class SupportController extends Controller
{
    public function GetIssueTypes(Request $request){

    try{

       $loggedInUser = Auth::user();

               $issue_types = Support_IssueType::all();
                $data = array();

               if($issue_types){

               	foreach ($issue_types as $key => $value) {

               		$data[$key] = $value->issue_type;
               		               		# code...
               	}
               
               
                   return response()->json([
                            "status" => 1,
                            'data' => $data,
                                                 
                             ], 200);
               }else{

                    return response()->json([
                                  "status" => 0,
                                  "message" => "Something went wrong!",
                                       
                                   ], 422);

               }        

    }
        catch(Exception $e){
            $result = [
              'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $result['status'] = 0;
             return $result;
        }

  }
  public function AddSupportIssues(Request $request){

    try{

       $loggedInUser = Auth::user();

        $rules = [                            
              'issue_type' => 'required',
              'description' => 'required',
            ];

            $validator = Validator::make($request->all(), $rules);

                  if($validator->fails())
                {
                    return response()->json([
                       "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422);               
                }

             $Support = new Support;
             $Support->issue_type = $request->get('issue_type');   
             $Support->description = $request->get('description');
             $Support->user_name = $loggedInUser->name;          
             $Support->user_contact = $loggedInUser->phone_number;
             $Support->email = $loggedInUser->email;
             $Support->status = '0';
             $Support->save();

               if($Support){

               	$data = Support::where('id',$Support->id)->first();
               
               
                   return response()->json([
                            "status" => 1,
                            "message" => "Issue Added Sucessfully!",
                            'data' => $data,
                                                 
                             ], 200);
               }else{

                    return response()->json([
                                  "status" => 0,
                                  "message" => "Something went wrong!",
                                       
                                   ], 422);

               }       

    }
        catch(Exception $e){
            $result = [
              'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $result['status'] = 0;
             return $result;
        }

  }
}
