<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Place;
use App\People;
use App\Thing;
use App\Coupon;
use App\People_Subcat;
use App\Place_Subcat;
use App\Thing_Subcat;
use App\PeopleProvider;
use App\PlaceProvider;
use App\ThingProvider;
use App\Favourite;
use Auth;
use App\User;
use App\Attachment;
use App\WalletTransaction;
use URL;
use Validator;
use DB;
use App\Review;
use Braintree_Transaction;
use Braintree_Customer;
use Braintree_WebhookNotification;
use Braintree_Subscription;
use Braintree_PaymentMethod;
use Braintree_CreditCard;
use Braintree_ClientToken;
use DateTime;
use App\Booking;
use SplitTime;
use DateTimeZone;
use Carbon\Carbon;
use Carbon\CarbonInterval;
use DatePeriod;
use App\Booking_Slot;
use App\Slot;
use App\Chat;
use App\Chat_head;
use App\Notification;
use DateInterval; 
class PlacesController extends Controller
{
    public function getPlaces(Request $request) {
    $user =   Auth::user();
        try {

              $today =  date('Y-m-d');
              $data = array();
              $place = Place::all();
              $thing = Thing::all();
              $people = People::all();
              Booking::where('user_id',$user->id)->where('status','1')->whereDate('check_out', '<', $today)->update([
                      'status' => '3',
                     ]);
              $reviews =  Review::pluck('booking_id');
              $ratings_average =  Review::where('provider_user_id',$user->id)->avg('ratings');
              if($ratings_average == ''){
                $ratings_average = 0;
              }

              
              $bookings = Booking::where('user_id',$user->id)->where('status','3')->whereNotIn('id',$reviews)->get();


               if($bookings != ""){
                 foreach ($bookings as $key => $value) {
                       if($value->people_provider_id != ""){
                      $provider = PeopleProvider::where('id', $value->people_provider_id)->first();
                      $attachment = User::where('id',$provider->user_id)->first();
                      $image = URL::to('/').'/profile/'.$attachment->image;
                      $data[$key]['provider_id'] = $value->people_provider_id;
                      $data[$key]['provider_user_id'] = $provider->user_id;
                      $data[$key]['title'] = $provider->title;
                      $data[$key]['attachment'] = $image;
                      $data[$key]['booking_id'] = $value->id;
                      $data[$key]['provider_type'] = '1';

                    }elseif($value->places_provider_id != ""){
                       $provider = PlaceProvider::where('id', $value->places_provider_id)->first();
                       $attachment = Attachment::where('places_provider_id',$value->places_provider_id)->first();
                       $image = URL::to('/').'/attachments/'.$attachment->filenames;
                       $data[$key]['provider_id'] = $value->places_provider_id;
                       $data[$key]['provider_user_id'] = $provider->user_id;
                       $data[$key]['title'] = $provider->title;
                       $data[$key]['attachment'] = $image;
                       $data[$key]['booking_id'] = $value->id;
                       $data[$key]['provider_type'] = '3';



                    }elseif($value->things_provider_id != ""){
                        $provider = ThingProvider::where('id', $value->things_provider_id)->first();
                       $attachment = Attachment::where('things_provider_id',$value->things_provider_id)->first();
                       $image = URL::to('/').'/attachments/'.$attachment->filenames;
                       $data[$key]['provider_id'] = $value->things_provider_id;
                       $data[$key]['provider_user_id'] = $provider->user_id;
                       $data[$key]['title'] = $provider->title;
                       $data[$key]['attachment'] = $image;
                       $data[$key]['booking_id'] = $value->id;
                       $data[$key]['provider_type'] = '2';

                    }
                     $data[$key]['review'] = 0;    
                      
                 }
               }      

                    $result['categories'] = $place;
                    $result['people_categories'] = $people; 
                    $result['things_categories'] = $thing; 
                    $result['bookings'] = $data; 
                    $result['average_rating'] = $ratings_average;
                    $result['status'] = 1; 


       }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }
        return $result;
    }

    public function getthings(Request $request) {

        try {
              $thing = Thing::all();              
                    $result['categories'] = $thing; 
                    $result['status'] = 1;                   
       }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }
        return $result;
    }

      public function getPeople(Request $request) {

        try {
              $people = People::all();              
                    $result['categories'] = $people; 
                    $result['status'] = 1;                   
       }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                        'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }
        return $result;
    }
       public function getPeoplesubcat(Request $request) {

        try {
              $people = People_Subcat::where('user_id', '1')->where('people_cat_id', $request->cat_id)->get();               
                    $result['subcategories'] = $people; 
                    $result['status'] = 1;                   
       }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }
        return $result;
    }

    public function getPlacessubcat(Request $request) {

        try {
              $people = Place_Subcat::where('user_id', '1')->where('places_cat_id', $request->cat_id)->get();               
                    $result['subcategories'] = $people; 
                    $result['status'] = 1;                   
       }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }
        return $result;
    }

      public function getThingsSubcat(Request $request) {

        try {
              $people = Thing_Subcat::where('user_id', '1')->where('things_cat_id', $request->cat_id)->get();               
                    $result['subcategories'] = $people; 
                    $result['status'] = 1;                   
       }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }
        return $result;
    }


       public function BecomeProvider(Request $request) {


        try {

              $loggedInUser = Auth::user();

             if($request->get('subcat_id') == '-1'){
                $subcategory = People_Subcat::where('name' , $request->get('subcat_name'))->where('user_id' , $loggedInUser->id)->first();
                if($subcategory){
                   $subcategory_id = $subcategory->id;
                }else{

                  $SUBCATEGORY = new People_Subcat;
                  $SUBCATEGORY->people_cat_id = $request->get('cat_id');
                  $SUBCATEGORY->name = $request->get('subcat_name');
                  $SUBCATEGORY->user_id = $loggedInUser->id;
                  $SUBCATEGORY->save(); 

                  $subcategory = People_Subcat::where('name' , $request->get('subcat_name'))->where('user_id' , $loggedInUser->id)->first(); 

                  $subcategory_id = $subcategory->id;
                }
              }else{
                    $subcategory_id = $request->get('subcat_id');
                 
              }
              
               
              $provider = PeopleProvider::where('user_id' , $loggedInUser->id)->where('id',$request->get('provider_id'))->first(); 
              
               if($provider){


                if($request->cat_id == ""){
                  $cat_id = $provider->cat_id;
                }else{
                  $cat_id = $request->cat_id;
                }
                if($request->subcat_id == ""){
                  $subcat_id = $provider->subcat_id;
                }else{
                  $subcat_id = $request->subcat_id;
                }
                if($request->title == ""){
                  $title = $provider->title;
                }else{
                  $title = $request->title;
                }
                if($request->description == ""){
                  $description = $provider->description;
                }else{
                  $description = $request->description;
                }
                if($request->country == ""){
                  $country = $provider->country;
                }else{
                  $country = $request->country;
                }
                if($request->address == ""){
                  $address = $provider->address;
                }else{
                  $address = $request->address;
                }
                 if($request->latitude == ""){
                  $latitude = $provider->latitude;
                }else{
                  $latitude = $request->latitude;
                }
                if($request->longitude == ""){
                  $longitude = $provider->longitude;
                }else{
                  $longitude = $request->longitude;
                }
                if($request->city == ""){
                  $city = $provider->city;
                }else{
                  $city = $request->city;
                }
                if($request->state == ""){
                  $state = $provider->state;
                }else{
                  $state = $request->state;
                }
                if($request->unavailable_dates == ""){
                  $unavailable_dates = $provider->available_dates;
                }else{
                  $List = implode(',', $request->unavailable_dates); 
                  $unavailable_dates = $List;              
                }

                if($request->time_in == ""){
                  $time_in = $provider->time_in;
                }else{
                  $time_in = $request->time_in;
                }
                if($request->time_out == ""){
                  $time_out = $provider->time_out;
                }else{
                  $time_out = $request->time_out;
                }               
                if($request->price_per_night == ""){
                  $price_per_night = $provider->price_per_night;
                }else{
                  $price_per_night = $request->price_per_night;
                }

                   if($request->complete_status == ""){
                  $complete_status = '0';
                }else{
                  $complete_status = $request->complete_status;
                }


                $attachments = Attachment::where('people_provider_id' , $provider->id)->get();

             
                if($request->file('attachments') == ''){
                  foreach ($attachments as $key => $value){
                    $attachment[] = $value->filenames;
                  }
                }else{
                $deleteattachment  = Attachment::where('people_provider_id', $provider->id)->delete(); 
               foreach( $request->file('attachments') as $key=>$attachment ){
                 
                     $pics = new Attachment;
                     $pics->people_provider_id = $provider->id;
                     if (!file_exists( public_path('/attachments'))) {
                         mkdir(public_path('/attachments'), 0777, true);
                       }
                       $path =public_path('/attachments/');
                       $image1 = $attachment; 
                       $input['imagename'] = time().rand(10,10000).$key.'.'.$image1->getClientOriginalExtension();
                       $destinationPath = public_path('/attachments');
                       $attachment->move($destinationPath, $input['imagename']);
                       $pics->filenames  =  $input['imagename'];
                      $pics->save();


                   }

                }
                  $data = array();

                 $updateProvider = PeopleProvider::where('user_id' , $loggedInUser->id)->where('id',$request->get('provider_id'))->update([
                  		'cat_id' => $cat_id,
                  		'subcat_id' => $subcat_id,
                  		'title' => $title,
                  		'description' => $description,
                  		'country' => $country,
                  		'address' => $address,
                  		'latitude' => $latitude,
                  		'longitude' => $longitude,
                 		  'available_dates' => $unavailable_dates,
                  		'time_in' => $time_in,
                  		'time_out' => $time_out,
                      'price_per_night' => $price_per_night,
                      'percent_status' => $request->get('percent_status'),
                      'complete_status' => $complete_status,

                  ]);
                   
                  $Provider  = PeopleProvider::where('id',$request->get('provider_id'))->first();
                  $Provider_dates = explode(',', $Provider->available_dates);
                  $attachments = Attachment::select('filenames')->where('people_provider_id' , $provider->id)->get();
                  if($attachments){
                    foreach ($attachments as $key => $value) {
                       $data[]= $value->filenames;
                    }
                  }else{
                    $data[]= '';
                  }
                    
                    $result['provider'] = $Provider; 
                    $result['provider']['attachments'] = $data; 
                    $result['provider']['available_dates'] = $Provider_dates;
                  $result['provider']['unavailable_dates'] = $Provider_dates; 
                    $result['status'] = 1;  
               }else{
                $loggedInUser = Auth::user();

                $provider = PeopleProvider::where('user_id' , $loggedInUser->id)->where('subcat_id',$subcategory_id)->first(); 

                if($provider == ""){
                $provider = new PeopleProvider;
                $provider->cat_id = $request->get('cat_id');
                $provider->subcat_id = $subcategory_id;
                $provider->title = $request->get('title');
                $provider->user_id = $loggedInUser->id;
                $provider->description = $request->get('description');
                $provider->country = $request->get('country');
                $provider->address = $request->get('address');
                $provider->city = $request->get('city');
                $provider->state = $request->get('state');
                $provider->latitude = $request->get('latitude');
                $provider->longitude = $request->get('longitude');
                $provider->percent_status = $request->get('percent_status');

                $provider->save();
                }else{

                  return response()->json([
                  "status" => 0,
                   "message" => "Provider Already Exists",
                   
                   ], 422); 

                } 
               
                //$data  = array('id' => $provider->id );
                $data1 = array();
               $Provider_dates = array();
               $data =PeopleProvider::where('id',$provider->id)->first();
               $dates = explode(',', $data->available_dates);
                $attachments = Attachment::select('filenames')->where('people_provider_id' , $provider->id)->get();
                if($attachments){
                foreach ($attachments as $key => $value) {
                       $data1[]= $value->filenames;
                    }   
                  }else{
                    $data1[]= '';
                  }
                    

                   $dates_data = array_shift($dates);
                   if($dates_data != ''){
                    $Provider_dates[]= $dates_data;
                    }

                $result['provider'] = $data;
                $result['provider']['unavailable_dates'] = $Provider_dates; 
                $result['provider']['attachments'] = $data1;  
                $result['provider']['available_dates'] = $Provider_dates; 
                $result['status'] = 1;  
               } 
              

                                  
       }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }
        return $result;
    }

    public function PlaceProvider(Request $request) {


        try {
              $loggedInUser = Auth::user();

              if($request->get('subcat_id') == -1){
                $subcategory = Place_Subcat::where('name' , $request->get('subcat_name'))->where('user_id' , $loggedInUser->id)->first();
                if($subcategory){
                   $subcategory_id = $subcategory->id;
                }else{

                  $SUBCATEGORY = new Place_Subcat;
                  $SUBCATEGORY->places_cat_id = $request->get('cat_id');
                  $SUBCATEGORY->name = $request->get('subcat_name');
                  $SUBCATEGORY->user_id = $loggedInUser->id;
                  $SUBCATEGORY->save(); 

                  $subcategory = Place_Subcat::where('name' , $request->get('subcat_name'))->where('user_id' , $loggedInUser->id)->first(); 

                  $subcategory_id = $subcategory->id;
                }
              }else{
                    $subcategory_id = $request->get('subcat_id');
                 
              }
              
               
              $provider = PlaceProvider::where('user_id' , $loggedInUser->id)->where('id',$request->get('provider_id'))->first(); 
              
               if($provider){

                if($request->cat_id == ""){
                  $cat_id = $provider->cat_id;
                }else{
                  $cat_id = $request->cat_id;
                }
                if($request->subcat_id == ""){
                  $subcat_id = $provider->subcat_id;
                }else{
                  $subcat_id = $request->subcat_id;
                }
                if($request->title == ""){
                  $title = $provider->title;
                }else{
                  $title = $request->title;
                }
                if($request->description == ""){
                  $description = $provider->description;
                }else{
                  $description = $request->description;
                }
                if($request->country == ""){
                  $country = $provider->country;
                }else{
                  $country = $request->country;
                }
                if($request->address == ""){
                  $address = $provider->address;
                }else{
                  $address = $request->address;
                }
                 if($request->latitude == ""){
                  $latitude = $provider->latitude;
                }else{
                  $latitude = $request->latitude;
                }
                if($request->longitude == ""){
                  $longitude = $provider->longitude;
                }else{
                  $longitude = $request->longitude;
                }
                if($request->amenities_offered == ""){
                  $amenities_offered = $provider->amenities_offered;
                }else{
                 // $amentities_offered = $request->amentities_offered;
                  $List_amenities = implode(',', $request->amenities_offered); 
                  $amenities_offered = $List_amenities; 
                }
                if($request->total_guests == ""){
                  $total_guests = $provider->total_guests;
                }else{
                  $total_guests = $request->total_guests;
                }
                if($request->unavailable_dates == ""){
                  $unavailable_dates = $provider->unavailable_dates;
                }else{
                  $List = implode(',', $request->unavailable_dates); 
                  $unavailable_dates = $List;                
                }              
                if($request->pet_allowance == ""){
                  $pet_allowance = $provider->pet_allowance;
                }else{
                  $pet_allowance = $request->pet_allowance;
                }
                if($request->host_facility == ""){
                  $host_facility = $provider->host_facility;
                }else{
                  $host_facility = $request->host_facility;
                }
                if($request->time_in == ""){
                  $time_in = $provider->time_in;
                }else{
                  $time_in = $request->time_in;
                }
                if($request->time_out == ""){
                  $time_out = $provider->time_out;
                }else{
                  $time_out = $request->time_out;
                }
               
                 if($request->rules == ""){
                  $rules = $provider->rules;
                }else{
                  $rules = $request->rules;
                }
                 if($request->price_per_night == ""){
                  $price_per_night = $provider->price_per_night;
                }else{
                  $price_per_night = $request->price_per_night;
                }


                  if($request->host_name == ""){
                  $host_name = $provider->host_name;
                }else{
                  $host_name = $request->host_name;
                }
                if($request->host_phone == ""){
                  $host_phone = $provider->host_phone;
                }else{
                  $host_phone = $request->host_phone;
                }
                   if($request->complete_status == ""){
                  $complete_status = '0';
                }else{
                  $complete_status = $request->complete_status;
                }

                $attachments = Attachment::where('things_provider_id' , $provider->id)->get();
                
                 if($request->file('attachments') == ""){
                  foreach( $attachments as $key1=>$attachment1 ){
                    $attachment[$key1] = $attachment1->filenames;
                  }
                }else{
                   
                $deleteattachment  = Attachment::where('places_provider_id', $provider->id)->delete(); 
                
               foreach( $request->file('attachments') as $key=>$attachment ){
                  
                     $pics = new Attachment;
                     $pics->places_provider_id = $provider->id;
                     if (!file_exists( public_path('/attachments'))) {
                         mkdir(public_path('/attachments'), 0777, true);
                       }
                       $path =public_path('/attachments/');
                       $image1 = $attachment; 
                       $input['imagename'] = time().rand(10,10000).$key.'.'.$image1->getClientOriginalExtension();
                       $destinationPath = public_path('/attachments');
                       $attachment->move($destinationPath, $input['imagename']);
                       $pics->filenames  =  $input['imagename'];
                      $pics->save();


                   }


                }
            
                 $updateProvider = PlaceProvider::where('user_id' , $loggedInUser->id)->where('id',$request->get('provider_id'))->update([
                  'cat_id' => $cat_id,
                  'subcat_id' => $subcat_id,
                  'title' => $title,
                  'description' => $description,
                  'country' => $country,
                  'address' => $address,
                  'latitude' => $latitude,
                  'longitude' => $longitude,
                  'amenities_offered' => $amenities_offered,        
                  'total_guests' => $total_guests,
                  'unavailable_dates' => $unavailable_dates,
                  'pet_allowance' => $pet_allowance,
                  'host_facility' => $host_facility,
                   'host_name' => $host_name,
                    'host_phone' => $host_phone,
                  'total_guests' => $total_guests,
                  'time_in' => $time_in,
                  'time_out' => $time_out,
                  'price_per_night' => $price_per_night,
                  'rules' => $rules,
                  'percent_status' => $request->get('percent_status'),
                  'complete_status' => $complete_status,
                  
                  ]);

                    $Provider  = PlaceProvider::where('id',$request->get('provider_id'))->first();
                    $Provider_amenities = explode(',', $Provider->amenities_offered);
                    $Provider_dates = explode(',', $Provider->unavailable_dates);
                    $attachments = Attachment::select('filenames')->where('places_provider_id' , $Provider->id)->get();
                    foreach ($attachments as $key => $value) {
                       $data[]= $value->filenames;
                    }
                    $result['provider'] = $Provider; 
                    $result['provider']['attachments'] = $data; 
                    $result['provider']['amenities_offered'] = $Provider_amenities; 
                    $result['provider']['unavailable_dates'] = $Provider_dates; 
                    $result['status'] = 1;  
               }else{
                $loggedInUser = Auth::user();

                $provider = PlaceProvider::where('user_id' , $loggedInUser->id)->where('subcat_id',$subcategory_id)->first(); 

                if($provider == ""){
                    $provider = new PlaceProvider;
                    $provider->cat_id = $request->get('cat_id');
                    $provider->subcat_id = $subcategory_id;
                    $provider->title = $request->get('title');
                    $provider->user_id = $loggedInUser->id;
                    $provider->description = $request->get('description');
                    $provider->country = $request->get('country');
                    $provider->address = $request->get('address');
                    $provider->latitude = $request->get('latitude');
                    $provider->longitude = $request->get('longitude');
                    $provider->percent_status = $request->get('percent_status');
                    
                    $provider->save();
                }else{

                  return response()->json([
                  "status" => 0,
                   "message" => "Provider Already Exists",
                   
                   ], 422); 

                } 
                $Provider_amenities = array();
                    $Provider_dates = array();
                   $data = array();
                  $Provider =PlaceProvider::where('id',$provider->id)->first(); 
                  $amenities = explode(',', $Provider->amenities_offered);
                  $amenities_data = array_shift($amenities);
                  if($amenities_data != "" ){
                    $Provider_amenities[]= $amenities_data;
                    }
                  $dates = explode(',', $Provider->unavailable_dates);
                  $dates_data = array_shift($dates);
                   if($dates_data != ''){
                    $Provider_dates[]= $dates_data;
                    }

                  $attachments = Attachment::select('filenames')->where('places_provider_id' , $provider->id)->get();

                  if($attachments){
                    foreach ($attachments as $key => $value) {
                       $data[]= $value->filenames;
                    }
                  }else{
                      $data[]= '';
                  }
                   
                    $result['provider'] = $Provider; 
                    $result['provider']['attachments'] = $data; 
                    $result['provider']['amenities_offered'] = $Provider_amenities; 
                    $result['provider']['unavailable_dates'] = $Provider_dates; 
                    $result['status'] = 1;  
               } 
              

                                  
       }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }
        return $result;
    }

       public function ThingProvider(Request $request) {

        try {

              $loggedInUser = Auth::user();

              if($request->get('subcat_id') == '-1'){
                $subcategory = Thing_Subcat::where('name' , $request->get('subcat_name'))->where('user_id' , $loggedInUser->id)->first();
                if($subcategory){
                   $subcategory_id = $subcategory->id;
                }else{

                  $SUBCATEGORY = new Thing_Subcat;
                  $SUBCATEGORY->things_cat_id = $request->get('cat_id');
                  $SUBCATEGORY->name = $request->get('subcat_name');
                  $SUBCATEGORY->user_id = $loggedInUser->id;
                  $SUBCATEGORY->save(); 

                  $subcategory = Thing_Subcat::where('name' , $request->get('subcat_name'))->where('user_id' , $loggedInUser->id)->first(); 

                  $subcategory_id = $subcategory->id;
                }
              }else{
                    $subcategory_id = $request->get('subcat_id');                 
              }
             
               
              $provider = ThingProvider::where('user_id' , $loggedInUser->id)->where('id',$request->get('provider_id'))->first(); 
              
               if($provider){


                if($request->cat_id == ""){
                  $cat_id = $provider->cat_id;
                }else{
                  $cat_id = $request->cat_id;
                }
                if($request->subcat_id == ""){
                  $subcat_id = $provider->subcat_id;
                }else{
                  $subcat_id = $request->subcat_id;
                }
                if($request->title == ""){
                  $title = $provider->title;
                }else{
                  $title = $request->title;
                }
                if($request->description == ""){
                  $description = $provider->description;
                }else{
                  $description = $request->description;
                }
                if($request->country == ""){
                  $country = $provider->country;
                }else{
                  $country = $request->country;
                }
                if($request->address == ""){
                  $address = $provider->address;
                }else{
                  $address = $request->address;
                }
                 if($request->latitude == ""){
                  $latitude = $provider->latitude;
                }else{
                  $latitude = $request->latitude;
                }
                if($request->longitude == ""){
                  $longitude = $provider->longitude;
                }else{
                  $longitude = $request->longitude;
                }
                 if($request->unavailable_dates == ""){
                  $unavailable_dates = $provider->unavailable_dates;
                }else{
                  $List = implode(',', $request->unavailable_dates); 
                  $unavailable_dates = $List;                
                }   
                if($request->condition == ""){
                  $condition = $provider->condition;
                }else{
                  $condition = $request->condition;
                }
                if($request->time_in == ""){
                  $time_in = $provider->time_in;
                }else{
                  $time_in = $request->time_in;
                }
                if($request->time_out == ""){
                  $time_out = $provider->time_out;
                }else{
                  $time_out = $request->time_out;
                }
                
                 if($request->rules == ""){
                  $rules = $provider->rules;
                }else{
                  $rules = $request->rules;
                }
                 if($request->price_per_night == ""){
                  $price_per_night = $provider->price_per_night;
                }else{
                  $price_per_night = $request->price_per_night;
                }
                 if($request->complete_status == ""){
                  $complete_status = '0';
                }else{
                  $complete_status = $request->complete_status;
                }
               
                  

                $attachments = Attachment::where('things_provider_id' , $provider->id)->get();

                 if($request->file('attachments') == ""){
                  foreach( $attachments as $key1=>$attachment1 ){
                    $attachment[$key1] = $attachment1->filenames;
                  }

                }else{
                 
                $deleteattachment  = Attachment::where('things_provider_id', $provider->id)->delete(); 
                
               foreach( $request->file('attachments') as $key=>$attachment ){
           
                     $pics = new Attachment;
                     $pics->things_provider_id = $provider->id;
                     if (!file_exists( public_path('/attachments'))) {
                         mkdir(public_path('/attachments'), 0777, true);
                       }
                       $path =public_path('/attachments/');
                       $image1 = $attachment; 
                       $input['imagename'] = time().rand(10,10000).$key.'.'.$image1->getClientOriginalExtension();
                       $destinationPath = public_path('/attachments');
                       $attachment->move($destinationPath, $input['imagename']);
                       $pics->filenames  =  $input['imagename'];
                      $pics->save();
                   }

                }
 
                 $updateProvider = ThingProvider::where('user_id' , $loggedInUser->id)->where('id',$request->get('provider_id'))->update([
                  'cat_id' => $cat_id,
                  'subcat_id' => $subcat_id,
                  'title' => $title,
                  'description' => $description,
                  'country' => $country,
                  'address' => $address,
                  'latitude' => $latitude,
                  'longitude' => $longitude,
                  'condition' => $condition,
                  'unavailable_dates' => $unavailable_dates,            
                  'time_in' => $time_in,
                  'time_out' => $time_out,
                  'price_per_night' => $price_per_night,
                  'rules' => $rules,
                  'percent_status' => $request->get('percent_status'),
                  'complete_status' => $complete_status,
                  
                  ]);
                  $data = array();
                  $Provider  = ThingProvider::where('id',$request->get('provider_id'))->first();
                $Provider_dates = explode(',', $Provider->unavailable_dates);
                $attachments = Attachment::select('filenames')->where('things_provider_id' , $provider->id)->get();
                    foreach ($attachments as $key => $value) {
                       $data[]= $value->filenames;
                    }
                  $result['provider'] = $Provider;
                  $result['provider']['attachments'] = $data; 
                  $result['provider']['unavailable_dates'] = $Provider_dates;
                  $result['status'] = 1;  
               }else{
                $loggedInUser = Auth::user();
 
                $provider = ThingProvider::where('user_id' , $loggedInUser->id)->where('subcat_id',$subcategory_id)->first(); 

                if($provider == ""){
                    $provider = new ThingProvider; 
                    $provider->cat_id = $request->get('cat_id');
                    $provider->subcat_id = $subcategory_id;
                    $provider->title = $request->get('title');
                    $provider->user_id = $loggedInUser->id;
                    $provider->description = $request->get('description');
                    $provider->country = $request->get('country');
                    $provider->address = $request->get('address');
                    $provider->latitude = $request->get('latitude');
                    $provider->longitude = $request->get('longitude');
                    $provider->percent_status = $request->get('percent_status');
                       
                    $provider->save();
                }else{

                  return response()->json([
                  "status" => 0,
                   "message" => "Provider Already Exists",
                   
                   ], 422); 

                } 
               $data = array();
               $Provider =ThingProvider::where('id',$provider->id)->first();
                $Provider_dates = explode(',', $Provider->unavailable_dates);
                $attachments = Attachment::select('filenames')->where('things_provider_id' , $provider->id)->get();
                if($attachments){
                  foreach ($attachments as $key => $value) {
                       $data[]= $value->filenames;
                    }
                }
                    
                $result['provider'] = $Provider; 
                 $result['provider']['attachments'] = $data; 
                $result['provider']['unavailable_dates'] = $Provider_dates;
                $result['status'] = 1;  
               } 
              

                                  
       }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }
        return $result;
    }

    public function delete_provider(Request $request){
      try{
          
          if($request->get('provider_type') == 'people'){
            $chk =  Booking::where('people_provider_id',$request->get('provider_id'))->where('status','1')->first();
            if($chk){
               return response()->json([
                    "status" => 0,
                    "message" => "Service Pending Provider can not be deleted",
                      ], 422); 

            }else{
               $bookings = Booking::where('people_provider_id',$request->get('provider_id'))->get();
              foreach ($bookings as $key => $value) {
                Notification::where('booking_id',$value->id)->delete();
                Review::where('booking_id',$value->id)->delete();
              }
              $bookingdelete = Booking::where('people_provider_id',$request->get('provider_id'))->delete();
              $deleteprovider  = PeopleProvider::where('id', $request->get('provider_id'))->delete(); 
              $deleteattachment  = Attachment::where('people_provider_id', $request->get('provider_id'))->delete(); 

            }
          

          }elseif($request->get('provider_type') == 'place'){

            $chk =  Booking::where('places_provider_id',$request->get('provider_id'))->where('status','1')->first();
            if($chk){
               return response()->json([
                    "status" => 0,
                    "message" => "Service Pending, Provider can not be deleted",
                      ], 422); 

            }else{
              $bookings = Booking::where('places_provider_id',$request->get('provider_id'))->get();
              foreach ($bookings as $key => $value) {
                Notification::where('booking_id',$value->id)->delete();
                Review::where('booking_id',$value->id)->delete();
              }
              $bookingdelete = Booking::where('places_provider_id',$request->get('provider_id'))->delete();
               $deleteprovider  = PlaceProvider::where('id', $request->get('provider_id'))->delete(); 
               $deleteattachment  = Attachment::where('places_provider_id', $request->get('provider_id'))->delete(); 

            } 

          }elseif($request->get('provider_type') == 'thing'){

            $chk =  Booking::where('things_provider_id',$request->get('provider_id'))->where('status','1')->first();
            if($chk){
               return response()->json([
                    "status" => 0,
                    "message" => "Service Pending, Provider can not be deleted",
                      ], 422); 

            }else{
               $bookings = Booking::where('things_provider_id',$request->get('provider_id'))->get();
              foreach ($bookings as $key => $value) {
                Notification::where('booking_id',$value->id)->delete();
                Review::where('booking_id',$value->id)->delete();
              }
              $bookingdelete = Booking::where('things_provider_id',$request->get('provider_id'))->delete();
              $deleteprovider  = ThingProvider::where('id', $request->get('provider_id'))->delete(); 
              $deleteattachment  = Attachment::where('things_provider_id', $request->get('provider_id'))->delete(); 

            }
               
        }
      
       if($deleteprovider){
          return response()->json([
                  "status" => 1,
                  "message" => "Provider deleted successfully.",
                   ], 200); 
       }else{
        return response()->json([
                  "status" => 0,
                  "message" => "No Provider found",
                    ], 422); 

       }

       }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }

    }

    public function getPeopleDetail(Request $request){

      try{
        $loggedInUser = Auth::user();

        $rules = [
                    'latitude' => 'required',
                    'longitude' => 'required',
                ];
      
                $validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {
                    return response()->json([
                       "status" => 0,
                       'errors' => $validator->errors()->toArray(),
                   ], 422);               
                }

        $provider  = PeopleProvider::where('status','1')->where('user_id','<>', $loggedInUser->id)->orderBy(DB::raw("acos( cos( radians({$request->latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$request->longitude}) ) + sin( radians({$request->latitude}) ) * sin(radians(latitude)) ) * 6371 < 15"), 'DESC')->get();
        $people  = People::all();
        $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','people')->get();
       $peoplecategories = array();
       $peopledata = array();
       $coupondata = array();
       $peoplecategories[] = 'All';
       foreach ($people as $key => $value) {
           $peoplecategories[] = $value->name;
       } 
         foreach ($coupon as $key1 => $value) {
        $day = date('Y-m-d',strtotime($value['created_at']));
        $date1 =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days"));
        $date_now = date('Y-m-d');
        
        if(strtotime($date1) >= strtotime($date_now)){
        //  $i++;
          $coupondata[$key1] = $value;
          $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value['background_image'];
          $coupondata[$key1]['valid_till'] =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days")); 
        }      
           
       }
       $arr = array_values($coupondata);   
      foreach ($provider as $key => $value) {
           $name = User::select('name','image')->where('id',$value->user_id)->first();
      
              if (strpos($name->image, 'http') !== false) {
                      $image =  $name->image;
              }else{
                     $image = URL::to('/').'/profile/'.$name->image;
              }
               if($value->ratings  == ""){
                $ratings = '5';
              }else{
                $ratings = $value->ratings;
              }
            $peopledata[$key]['id'] = $value->id;
            $peopledata[$key]['name'] = $value->title;
            $peopledata[$key]['latitude'] = $value->latitude;
            $peopledata[$key]['longitude'] = $value->longitude;
            $peopledata[$key]['ratings'] = $ratings;
            $peopledata[$key]['image'] = $image;
            $peopledata[$key]['address'] = $value->address;
            $peopledata[$key]['hourly_price'] = $value->hourly_price;
            $peopledata[$key]['price_per_night'] = $value->price_per_night;
           
       }  
          $result['status'] = 1;
          $result['categories'] = $peoplecategories;
          $result['data'] = $peopledata;
          $result['coupons'] = $arr;     
          return $result;

       }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }

    }

        public function getPlaceDetail(Request $request){
 
      try{
       $loggedInUser = Auth::user();

        $rules = [
                    'latitude' => 'required',
                    'longitude' => 'required',
                ];
      
                $validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {
                    return response()->json([
                       "status" => 0,
                       'errors' => $validator->errors()->toArray(),
                   ], 422);               
                }
            
        
      $provider  = PlaceProvider::where('status','1')->where('user_id','<>', $loggedInUser->id)->orderBy(DB::raw("acos( cos( radians({$request->latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$request->longitude}) ) + sin( radians({$request->latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->get();
       $place  = Place::all();
       $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','places')->get();
       $placecategories = array();
       $placedata = array();
       $attachments = array();
       $coupondata = array();
       $peoplecategories[] = 'All';
       foreach ($place as $key => $value) {
           $placecategories[] = $value->name;
       }     
        
     foreach ($coupon as $key1 => $value) {
        $day = date('Y-m-d',strtotime($value['created_at']));
        $date1 =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days"));
        $date_now = date('Y-m-d');
        
        if(strtotime($date1) >= strtotime($date_now)){
        //  $i++;
          $coupondata[$key1] = $value;
          $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value['background_image'];
          $coupondata[$key1]['valid_till'] =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days")); 
        }      
           
       }
       $arr = array_values($coupondata);
    
      foreach ($provider as $key => $value) {
           $name = User::select('name','image')->where('id',$value->user_id)->first();
            $images = Attachment::where('places_provider_id',$value->id)->get();
           foreach ($images as $key1 => $value1) {
              $attachments[$key1] = $value1->filenames;
           }

              if (strpos($name->image, 'http') !== false) {
                      $image =  $name->image;
              }else{
                     $image = URL::to('/').'/profile/'.$name->image;
              }
               if($value->ratings  == ""){
                $ratings = '5';
              }else{
                $ratings = $value->ratings;
              }
            $placedata[$key]['id'] = $value->id;
            $placedata[$key]['name'] = $name->name;
            $placedata[$key]['latitude'] = $value->latitude;
            $placedata[$key]['longitude'] = $value->longitude;
            $placedata[$key]['ratings'] = $ratings;
            $placedata[$key]['attachments'] = $attachments;
            $placedata[$key]['address'] = $value->address;
            $placedata[$key]['price_per_night'] = $value->price_per_night;
           
       }  
          $result['status'] = 1;
          $result['categories'] = $placecategories;
          $result['data'] = $placedata;
          $result['coupons'] = $arr;
          return $result;

       }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }

    }
      public function getThingsDetail(Request $request){

        try{
           $loggedInUser = Auth::user();
            $rules = [
                        'latitude' => 'required',
                        'longitude' => 'required',
                    ];
      
                $validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {
                    return response()->json([
                       "status" => 0,
                       'errors' => $validator->errors()->toArray(),
                   ], 422);               
                }
        
       $provider  = ThingProvider::where('status','1')->where('user_id','<>', $loggedInUser->id)->orderBy(DB::raw("acos( cos( radians({$request->latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$request->longitude}) ) + sin( radians({$request->latitude}) ) * sin(radians(latitude)) ) * 6371 < 15"), 'DESC')->get(); 
       $people  = Thing::all();
       $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','things')->get()->toArray();
       $peoplecategories = array();
       $thingdata = array();
       $attachments = array();
       $coupondata = array();
       $thingcategories[] = 'All';
       foreach ($people as $key => $value) {
           $thingcategories[] = $value->name;
       }     
        
       foreach ($coupon as $key1 => $value) {
        $day = date('Y-m-d',strtotime($value['created_at']));
        $date1 =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days"));
        $date_now = date('Y-m-d');
        
        if(strtotime($date1) >= strtotime($date_now)){
        //  $i++;
          $coupondata[$key1] = $value;
          $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value['background_image'];
          $coupondata[$key1]['valid_till'] =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days")); 
        }      
           
       }
       $arr = array_values($coupondata);
       //echo "<pre>";print_r($coupondata);die;
       
      foreach ($provider as $key => $value) {
           $name = User::select('name','image')->where('id',$value->user_id)->first();
           $images = Attachment::where('things_provider_id',$value->id)->get();
           foreach ($images as $key1 => $value1) {
              $attachments[$key1] = URL::to('/').'/attachments/'.$value1->filenames;
           }

           	if($name != ''){
           		if (strpos($name->image, 'http') !== false) {
                      $image =  $name->image;
              }else{
                     $image = URL::to('/').'/profile/'.$name->image;
              }
           	}else{
           		$image = '';
           	}

           if($name != ''){
              $name = $name->name;
           	}else{
           		$name = '';
           	}

              
               if($value->ratings  == ""){
                $ratings = '5';
              }else{
                $ratings = $value->ratings; 
              }
            $thingdata[$key]['id'] = $value->id;
            $thingdata[$key]['name'] = $value->title;
            $thingdata[$key]['owned_by'] = $name;
            $thingdata[$key]['latitude'] = $value->latitude;
            $thingdata[$key]['longitude'] = $value->longitude;
            $thingdata[$key]['ratings'] = $ratings;
            $thingdata[$key]['attachments'] = $attachments;
            $thingdata[$key]['address'] = $value->address;
            $thingdata[$key]['price_per_night'] = $value->price_per_night;
            $thingdata[$key]['hourly_price'] = $value->hourly_price;
           
       } 
          $result['status'] = 1;
          $result['categories'] = $thingcategories;
          $result['data'] = $thingdata;
          $result['coupons'] = $arr;
          return $result;

       }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }

    }

    public function CategoryDetaildata(Request $request){

      $loggedInUser = Auth::user();

       $rules = [
                    'type' => 'required',
                    'latitude' => 'required',
                    'longitude' => 'required',
                ];
      
                $validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {
                    return response()->json([
                       "status" => 0,
                       'errors' => $validator->errors()->toArray(),
                   ], 422);               
                }

       try{

        if($request->get('distance') == 1){
            
             if($request->get('filter_type') == 0 ){

                if($request->get('type') == 'thing'){


              if($request->get('cat_name') == 'All'){

                          $query = "SELECT *, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 AS `distance` FROM `things_provider` WHERE ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15 AND `status` = '1' AND `user_id` != '".$loggedInUser->id."'  ORDER BY `distance` DESC";


                      }else{ 

                           
                           $thingcat  = Thing::where('name',$request->get('cat_name'))->first();
                          $thingcat_id = $thingcat->id; 
                         $query = "SELECT *, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 AS `distance` FROM `things_provider` WHERE ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15 AND `status` = '1' AND `cat_id` = '".$thingcat_id."' AND `user_id` != '".$loggedInUser->id."' ORDER BY `distance` DESC";

                     
                     }
                     $people  = Thing::all();
                    $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','things')->get();
                     $peoplecategories = array();
                     $thingdata = array();
                     $attachments = array();
                     $coupondata = array(); 
                    $thingcategories[] = 'All';
                     foreach ($people as $key => $value) {
                         $thingcategories[] = $value->name;
                     }     
        
                  foreach ($coupon as $key1 => $value) {

                       $coupondata[$key1] = $value;
                       $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value->background_image;
                   }
                 
                    $nearByData = DB::select(DB::raw($query));
                      
                  foreach ($nearByData as $key => $value) {
                         $name = User::select('name','image')->where('id',$value->user_id)->first();
                          $images = Attachment::where('things_provider_id',$value->id)->get();
                         foreach ($images as $key1 => $value1) {
                            $attachments[$key1] = URL::to('/').'/attachments/'.$value1->filenames;
                         }

                        if (strpos($name->image, 'http') !== false) {
                                $image =  $name->image;
                        }else{
                               $image = URL::to('/').'/profile/'.$name->image;
                        }
                         if($value->ratings  == ""){
                          $ratings = '5';
                        }else{
                          $ratings = $value->ratings;
                        }
                        $thingdata[$key]['id'] = $value->id;
                        $thingdata[$key]['name'] = $value->title;
                        $thingdata[$key]['owned_by'] = $name->name;
                        $thingdata[$key]['latitude'] = $value->latitude;
                        $thingdata[$key]['longitude'] = $value->longitude;
                        $thingdata[$key]['ratings'] = $ratings;
                        $thingdata[$key]['attachments'] = $attachments;
                        $thingdata[$key]['address'] = $value->address;
                        $thingdata[$key]['price_per_night'] = $value->price_per_night;
                        $thingdata[$key]['hourly_price'] = $value->hourly_price;
                       
                    }  
                    $result['status'] = 1;
                    //$result['categories'] = $thingcategories;
                    $result['data'] = $thingdata;
                    //$result['coupons'] = $coupondata;
                    return $result;

                }elseif($request->get('type') == 'place'){

                  if($request->get('cat_name') == 'All'){

                      $query = "SELECT *, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 AS `distance` FROM `places_provider` WHERE ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15 AND `status` = '1' AND `user_id` != '".$loggedInUser->id."' ORDER BY `distance` DESC";


                      }else{ 

                           
                         $placecat  = Place::where('name',$request->get('cat_name'))->first();
                         $placecat_id = $placecat->id;
                         $query = "SELECT *, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 AS `distance` FROM `places_provider` WHERE ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15 AND `status` = '1' AND `cat_id` = '".$placecat_id."' AND `user_id` != '".$loggedInUser->id."' ORDER BY  `distance` DESC";

                     
                     }
 

                $nearByData = DB::select(DB::raw($query));
          
               $place  = Place::all();
               $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','places')->get();
               $placecategories = array();
               $placedata = array();
               $attachments = array();
               $coupondata = array();
               $placecategories[] = 'All';
               foreach ($place as $key => $value) {
                   $placecategories[] = $value->name;
               }     
                
                 foreach ($coupon as $key1 => $value) {
                    $day = date('Y-m-d',strtotime($value['created_at']));
                    $date1 =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days"));
                    $date_now = date('Y-m-d');
                    
                    if(strtotime($date1) >= strtotime($date_now)){
                    //  $i++;
                      $coupondata[$key1] = $value;
                      $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value['background_image'];
                      $coupondata[$key1]['valid_till'] =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days")); 
                    }      
                       
                   }
                   $arr = array_values($coupondata);
         
              foreach ($nearByData as $key => $value) {
                   $name = User::select('name','image')->where('id',$value->user_id)->first();
                    $images = Attachment::where('places_provider_id',$value->id)->get();
                   foreach ($images as $key1 => $value1) {
                      $attachments[$key1] = URL::to('/').'/attachments/'.$value1->filenames;
                   }

                      if (strpos($name->image, 'http') !== false) {
                              $image =  $name->image;
                      }else{
                             $image = URL::to('/').'/profile/'.$name->image;
                      }

                      if($value->ratings  == ""){
                        $ratings = '5';
                      }else{
                        $ratings = $value->ratings;
                      }
                    $placedata[$key]['id'] = $value->id;
                    $placedata[$key]['name'] = $value->title;

            $placedata[$key]['owned_by'] = $name->name;
                    $placedata[$key]['latitude'] = $value->latitude;
                    $placedata[$key]['longitude'] = $value->longitude;
                    $placedata[$key]['ratings'] = $ratings;
                    $placedata[$key]['attachments'] = $attachments;
                    $placedata[$key]['address'] = $value->address;
                    $placedata[$key]['price_per_night'] = $value->price_per_night;
                   
               }  
                  $result['status'] = 1;
                  $result['categories'] = $placecategories;
                  $result['data'] = $placedata;
                  $result['coupons'] = $arr;
                  return $result;


                  }elseif($request->get('type') == 'people'){

                     if($request->get('cat_name') == 'All'){

                      $query = "SELECT *, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 AS `distance` FROM `people_provider` WHERE ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15 AND `status` = '1' AND `user_id` != '".$loggedInUser->id."' ORDER BY `distance` DESC";


                      }else{ 

                           
                        $peoplecat  = People::where('name',$request->get('cat_name'))->first();
                    $peoplecat_id = $peoplecat->id;
                       $query = "SELECT *, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 AS `distance` FROM `people_provider` WHERE ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15 AND `status` = '1' AND `cat_id` = '".$peoplecat_id."' AND `user_id` != '".$loggedInUser->id."' ORDER BY `distance` DESC";

                     
                     }
    

                  $nearByData = DB::select(DB::raw($query));


                  
                     $people  = People::all();
                     $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','people')->get();
                     $peoplecategories = array();
                     $peopledata = array();
                     $coupondata = array();
                     $peoplecategories[] = 'All';
                 foreach ($people as $key => $value) {
                     $peoplecategories[] = $value->name;
                 } 
                  foreach ($coupon as $key1 => $value) {
                     $coupondata[$key1] = $value;
                     $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value->background_image;
                 }   
          
                foreach ($nearByData as $key => $value) {
                     $name = User::select('name','image')->where('id',$value->user_id)->first();
                
                        if (strpos($name->image, 'http') !== false) {
                                $image =  $name->image;
                        }else{
                               $image = URL::to('/').'/profile/'.$name->image;
                        }
                        if($value->ratings  == ""){
                          $ratings = '5';
                        }else{
                          $ratings = $value->ratings;
                        }
                      $peopledata[$key]['id'] = $value->id;
                      $peopledata[$key]['name'] = $value->title;
                       $peopledata[$key]['latitude'] = $value->latitude;
                      $peopledata[$key]['longitude'] = $value->longitude;
                      $peopledata[$key]['ratings'] = $ratings;
                      $peopledata[$key]['image'] = $image;
                      $peopledata[$key]['address'] = $value->address;
                      $peopledata[$key]['hourly_price'] = $value->hourly_price;
                      $peopledata[$key]['price_per_night'] = $value->price_per_night;
                      
                     
                 }  
                    $result['status'] = 1;
                    //$result['categories'] = $peoplecategories;
                    $result['data'] = $peopledata;
                    //$result['coupons'] = $coupondata;     
                    return $result;

        }

          }elseif($request->get('filter_type') == 1 ){


            if($request->get('type') == 'thing'){

              if($request->get('cat_name') == 'All'){

                       $query = "SELECT *, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 AS `distance` FROM `things_provider` WHERE ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15 AND `status` = '1' AND `user_id` != '".$loggedInUser->id."' ORDER BY `price_per_night` DESC";


                      }else{ 

                           
                           $thingcat  = Thing::where('name',$request->get('cat_name'))->first();
                          $thingcat_id = $thingcat->id; 
                          $query = "SELECT *, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 AS `distance` FROM `things_provider` WHERE ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15 AND `status` = '1' AND `cat_id` = '".$thingcat_id."' AND `user_id` != '".$loggedInUser->id."' ORDER BY `price_per_night` DESC";
                     
                     }
                    $thingcat  = Thing::where('name',$request->get('cat_name'))->first();
                    $thingcat_id = $thingcat->id; 
                    $people  = Thing::all();
                    $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','things')->get();
                     $peoplecategories = array();
                     $thingdata = array();
                    $attachments = array();
                     $coupondata = array();
                    $peoplecategories[] = 'All';
                     foreach ($people as $key => $value) {
                         $thingcategories[] = $value->name;
                     }     
        
                  foreach ($coupon as $key1 => $value) {
                       $coupondata[$key1] = $value;
                       $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value->background_image;
                   }
      
                    $nearByData = DB::select(DB::raw($query));
                      
                  foreach ($nearByData as $key => $value) {
                         $name = User::select('name','image')->where('id',$value->user_id)->first();
                          $images = Attachment::where('things_provider_id',$value->id)->get();
                         foreach ($images as $key1 => $value1) {
                            $attachments[$key1] = URL::to('/').'/attachments/'.$value1->filenames;
                         }

                        if (strpos($name->image, 'http') !== false) {
                                $image =  $name->image;
                        }else{
                               $image = URL::to('/').'/profile/'.$name->image;
                        }
                         if($value->ratings  == ""){
                          $ratings = '5';
                        }else{
                          $ratings = $value->ratings;
                        }
                        $thingdata[$key]['id'] = $value->id;
                        $thingdata[$key]['name'] = $value->title;
                        $thingdata[$key]['owned_by'] = $name->name;
                        $thingdata[$key]['latitude'] = $value->latitude;
                        $thingdata[$key]['longitude'] = $value->longitude;
                        $thingdata[$key]['ratings'] = $ratings;
                        $thingdata[$key]['attachments'] = $attachments;
                        $thingdata[$key]['address'] = $value->address;
                        $thingdata[$key]['price_per_night'] = $value->price_per_night;
                        $thingdata[$key]['hourly_price'] = $value->hourly_price;
                       
                    }  
                    $result['status'] = 1;
                    //$result['categories'] = $thingcategories;
                    $result['data'] = $thingdata;
                    //$result['coupons'] = $coupondata;
                    return $result;

                }elseif($request->get('type') == 'place'){

                  if($request->get('cat_name') == 'All'){

                      $query = "SELECT *, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 AS `distance` FROM `places_provider` WHERE ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15 AND `status` = '1' AND `user_id` != '".$loggedInUser->id."' ORDER BY `price_per_night` DESC";


                      }else{ 

                           
                      $placecat  = Place::where('name',$request->get('cat_name'))->first();
                      $placecat_id = $placecat->id;
                      $query = "SELECT *, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 AS `distance` FROM `places_provider` WHERE ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15 AND `status` = '1' AND `cat_id` = '".$placecat_id."' AND `user_id` != '".$loggedInUser->id."' ORDER BY `price_per_night` DESC";

                     
                     } 
               $nearByData = DB::select(DB::raw($query));
               $place  = Place::all();
               $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','places')->get();
               $placecategories = array();
               $placedata = array();
               $attachments = array();
               $coupondata = array();
               $placecategories[] = 'All';
               foreach ($place as $key => $value) {
                   $placecategories[] = $value->name;
               }     
                
                 foreach ($coupon as $key1 => $value) {
                    $day = date('Y-m-d',strtotime($value['created_at']));
                    $date1 =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days"));
                    $date_now = date('Y-m-d');
                    
                    if(strtotime($date1) >= strtotime($date_now)){
                    //  $i++;
                      $coupondata[$key1] = $value;
                      $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value['background_image'];
                      $coupondata[$key1]['valid_till'] =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days")); 
                    }      
                       
                   }
                   $arr = array_values($coupondata);

              
              foreach ($nearByData as $key => $value) {
                   $name = User::select('name','image')->where('id',$value->user_id)->first();
                    $images = Attachment::where('places_provider_id',$value->id)->get();
                   foreach ($images as $key1 => $value1) {
                      $attachments[$key1] = URL::to('/').'/attachments/'.$value1->filenames;
                   }

                      if (strpos($name->image, 'http') !== false) {
                              $image =  $name->image;
                      }else{
                             $image = URL::to('/').'/profile/'.$name->image;
                      }

                      if($value->ratings  == ""){
                        $ratings = '5';
                      }else{
                        $ratings = $value->ratings;
                      }
                    $placedata[$key]['id'] = $value->id;
                    $placedata[$key]['name'] = $value->title;

            $placedata[$key]['owned_by'] = $name->name;
                    $placedata[$key]['latitude'] = $value->latitude;
                    $placedata[$key]['longitude'] = $value->longitude;
                    $placedata[$key]['ratings'] = $ratings;
                    $placedata[$key]['attachments'] = $attachments;
                    $placedata[$key]['address'] = $value->address;
                    $placedata[$key]['price_per_night'] = $value->price_per_night;
                   
               }  
                  $result['status'] = 1;
                  $result['categories'] = $placecategories;
                  $result['data'] = $placedata;
                  $result['coupons'] = $arr;
                  return $result;


                  }elseif($request->get('type') == 'people'){

                     if($request->get('cat_name') == 'All'){

                      $query = "SELECT *, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 AS `distance` FROM `people_provider` WHERE ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15 AND `status` = '1' AND `user_id` != '".$loggedInUser->id."' ORDER BY `price_per_night` DESC";


                      }else{ 

                           
                        $peoplecat  = People::where('name',$request->get('cat_name'))->first();
                    $peoplecat_id = $peoplecat->id;
                      $query = "SELECT *, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 AS `distance` FROM `people_provider` WHERE ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15 AND `status` = '1' AND `cat_id` = '".$peoplecat_id."' AND `user_id` != '".$loggedInUser->id."' ORDER BY `price_per_night` DESC";

                     
                     }


                  $nearByData = DB::select(DB::raw($query));
                     $people  = People::all();
                     $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','people')->get();
                     $peoplecategories = array();
                     $peopledata = array();
                     $coupondata = array();
                     $peoplecategories[] = 'All';
                 foreach ($people as $key => $value) {
                     $peoplecategories[] = $value->name;
                 } 
                  foreach ($coupon as $key1 => $value) {
                     $coupondata[$key1] = $value;
                     $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value->background_image;
                 }   
                  
                foreach ($nearByData as $key => $value) {
                     $name = User::select('name','image')->where('id',$value->user_id)->first();
                
                        if (strpos($name->image, 'http') !== false) {
                                $image =  $name->image;
                        }else{
                               $image = URL::to('/').'/profile/'.$name->image;
                        }
                        if($value->ratings  == ""){
                          $ratings = '5';
                        }else{
                          $ratings = $value->ratings;
                        }
                      $peopledata[$key]['id'] = $value->id;
                      $peopledata[$key]['name'] = $value->title;;
                       $peopledata[$key]['latitude'] = $value->latitude;
                      $peopledata[$key]['longitude'] = $value->longitude;
                      $peopledata[$key]['ratings'] = $ratings;
                      $peopledata[$key]['image'] = $image;
                      $peopledata[$key]['address'] = $value->address;
                      $peopledata[$key]['hourly_price'] = $value->hourly_price;
                      $peopledata[$key]['price_per_night'] = $value->price_per_night;
                     
                 }  
                    $result['status'] = 1;
                    //$result['categories'] = $peoplecategories;
                    $result['data'] = $peopledata;
                    //$result['coupons'] = $coupondata;     
                    return $result;

        }




          }elseif($request->get('filter_type') == 2 ){

            if($request->get('type') == 'thing'){

              if($request->get('cat_name') == 'All'){

                     $query = "SELECT *, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 AS `distance` FROM `things_provider` WHERE ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15 AND `status` = '1' AND `user_id` != '".$loggedInUser->id."' ORDER BY `price_per_night` ASC";


                      }else{ 

                           
                           $thingcat  = Thing::where('name',$request->get('cat_name'))->first();
                          $thingcat_id = $thingcat->id; 
                          $query = "SELECT *, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 AS `distance` FROM `things_provider` WHERE ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15 AND `status` = '1' AND `cat_id` = '".$thingcat_id."' AND `user_id` != '".$loggedInUser->id."' ORDER BY `price_per_night` ASC";
                     
                     }
                    $people  = Thing::all();
                    $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','things')->get();
                     $peoplecategories = array();
                     $thingdata = array();
                    $attachments = array();
                     $coupondata = array();
                    $peoplecategories[] = 'All';
                     foreach ($people as $key => $value) {
                         $thingcategories[] = $value->name;
                     }     
        
                  foreach ($coupon as $key1 => $value) {
                       $coupondata[$key1] = $value;
                       $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value->background_image;
                   }
                    
                    $nearByData = DB::select(DB::raw($query));
                      
                  foreach ($nearByData as $key => $value) {
                         $name = User::select('name','image')->where('id',$value->user_id)->first();
                          $images = Attachment::where('things_provider_id',$value->id)->get();
                         foreach ($images as $key1 => $value1) {
                            $attachments[$key1] = URL::to('/').'/attachments/'.$value1->filenames;
                         }

                        if (strpos($name->image, 'http') !== false) {
                                $image =  $name->image;
                        }else{
                               $image = URL::to('/').'/profile/'.$name->image;
                        }
                         if($value->ratings  == ""){
                          $ratings = '5';
                        }else{
                          $ratings = $value->ratings;
                        }
                        $thingdata[$key]['id'] = $value->id;
                        $thingdata[$key]['name'] = $value->title;
                        $thingdata[$key]['owned_by'] = $name->name;
                        $thingdata[$key]['latitude'] = $value->latitude;
                        $thingdata[$key]['longitude'] = $value->longitude;
                        $thingdata[$key]['ratings'] = $ratings;
                        $thingdata[$key]['attachments'] = $attachments;
                        $thingdata[$key]['address'] = $value->address;
                        $thingdata[$key]['price_per_night'] = $value->price_per_night;
                        $thingdata[$key]['hourly_price'] = $value->hourly_price;
                       
                    }  
                    $result['status'] = 1;
                    //$result['categories'] = $thingcategories;
                    $result['data'] = $thingdata;
                    //$result['coupons'] = $coupondata;
                    return $result;

                }elseif($request->get('type') == 'place'){

                    if($request->get('cat_name') == 'All'){
         
                       $query = "SELECT *, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 AS `distance` FROM `places_provider` WHERE ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15 AND `status` = '1' AND `user_id` != '".$loggedInUser->id."' ORDER BY `price_per_night` ASC";


                      }else{ 

                           
                   $placecat  = Place::where('name',$request->get('cat_name'))->first();
                  $placecat_id = $placecat->id;
                       $query = "SELECT *, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 AS `distance` FROM `places_provider` WHERE ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15 AND `status` = '1' AND `cat_id` = '".$placecat_id."' AND `user_id` != '".$loggedInUser->id."' ORDER BY `price_per_night` ASC";

                     
                     } 
              
                $nearByData = DB::select(DB::raw($query));
               $place  = Place::all();
               $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','places')->get();
               $placecategories = array();
               $placedata = array();
               $attachments = array();
               $coupondata = array();
               $placecategories[] = 'All';
               foreach ($place as $key => $value) {
                   $placecategories[] = $value->name;
               }     
                
                 foreach ($coupon as $key1 => $value) {
                    $day = date('Y-m-d',strtotime($value['created_at']));
                    $date1 =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days"));
                    $date_now = date('Y-m-d');
                    
                    if(strtotime($date1) >= strtotime($date_now)){
                    //  $i++;
                      $coupondata[$key1] = $value;
                      $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value['background_image'];
                      $coupondata[$key1]['valid_till'] =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days")); 
                    }      
                       
                   }
                   $arr = array_values($coupondata);

               
              foreach ($nearByData as $key => $value) {
                   $name = User::select('name','image')->where('id',$value->user_id)->first();
                    $images = Attachment::where('places_provider_id',$value->id)->get();
                   foreach ($images as $key1 => $value1) {
                      $attachments[$key1] = URL::to('/').'/attachments/'.$value1->filenames;
                   }

                      if (strpos($name->image, 'http') !== false) {
                              $image =  $name->image;
                      }else{
                             $image = URL::to('/').'/profile/'.$name->image;
                      }

                      if($value->ratings  == ""){
                        $ratings = '5';
                      }else{
                        $ratings = $value->ratings;
                      }
                    $placedata[$key]['id'] = $value->id;
                   $placedata[$key]['name'] = $value->title;

            $placedata[$key]['owned_by'] = $name->name;
                    $placedata[$key]['latitude'] = $value->latitude;
                    $placedata[$key]['longitude'] = $value->longitude;
                    $placedata[$key]['ratings'] = $ratings;
                    $placedata[$key]['attachments'] = $attachments;
                    $placedata[$key]['address'] = $value->address;
                    $placedata[$key]['price_per_night'] = $value->price_per_night;
                   
               }  
                  $result['status'] = 1;
                  $result['categories'] = $placecategories;
                  $result['data'] = $placedata;
                  $result['coupons'] = $arr;
                  return $result;


                  }elseif($request->get('type') == 'people'){

                      if($request->get('cat_name') == 'All'){
         
                       $query = "SELECT *, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 AS `distance` FROM `people_provider` WHERE ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15 AND `status` = '1' AND `user_id` != '".$loggedInUser->id."' ORDER BY `price_per_night` ASC";


                      }else{ 

                           
                   $peoplecat  = People::where('name',$request->get('cat_name'))->first();
                    $peoplecat_id = $peoplecat->id;
                       $query = "SELECT *, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 AS `distance` FROM `people_provider` WHERE ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15 AND `status` = '1' AND `cat_id` = '".$peoplecat_id."' AND `user_id` != '".$loggedInUser->id."' ORDER BY `price_per_night` ASC";

                     
                     } 
                      
                  $nearByData = DB::select(DB::raw($query));

                  
                     $people  = People::all();
                     $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','people')->get();
                     $peoplecategories = array();
                     $peopledata = array();
                     $coupondata = array();
                     $peoplecategories[] = 'All';
                 foreach ($people as $key => $value) {
                     $peoplecategories[] = $value->name;
                 } 
                  foreach ($coupon as $key1 => $value) {
                     $coupondata[$key1] = $value;
                     $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value->background_image;
                 }   
                  
                foreach ($nearByData as $key => $value) {
                     $name = User::select('name','image')->where('id',$value->user_id)->first();
                
                        if (strpos($name->image, 'http') !== false) {
                                $image =  $name->image;
                        }else{
                               $image = URL::to('/').'/profile/'.$name->image;
                        }
                        if($value->ratings  == ""){
                          $ratings = '5';
                        }else{
                          $ratings = $value->ratings;
                        }
                      $peopledata[$key]['id'] = $value->id;
                      $peopledata[$key]['name'] = $value->title;;
                       $peopledata[$key]['latitude'] = $value->latitude;
                      $peopledata[$key]['longitude'] = $value->longitude;
                      $peopledata[$key]['ratings'] = $ratings;
                      $peopledata[$key]['image'] = $image;
                      $peopledata[$key]['address'] = $value->address;
                      $peopledata[$key]['hourly_price'] = $value->hourly_price;
                      $peopledata[$key]['price_per_night'] = $value->price_per_night;
                     
                 }  
                    $result['status'] = 1;
                    //$result['categories'] = $peoplecategories;
                    $result['data'] = $peopledata;
                    //$result['coupons'] = $coupondata;     
                    return $result;

        }


            
          }elseif($request->get('filter_type') == 3 ){

            if($request->get('type') == 'thing'){

               if($request->get('cat_name') == 'All'){

                     $query = "SELECT *, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 AS `distance` FROM `things_provider` WHERE ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15 AND `status` = '1' AND `user_id` != '".$loggedInUser->id."' ORDER BY `ratings` DESC";


                      }else{ 

                           
                           $thingcat  = Thing::where('name',$request->get('cat_name'))->first();
                          $thingcat_id = $thingcat->id; 
                          $query = "SELECT *, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 AS `distance` FROM `things_provider` WHERE ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15 AND `status` = '1' AND `cat_id` = '".$thingcat_id."' AND `user_id` != '".$loggedInUser->id."' ORDER BY `ratings` DESC";
                     
                     }
                            
                    $nearByData = DB::select(DB::raw($query));
                   
                    $people  = Thing::all();
                    $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','things')->get();
                     $peoplecategories = array();
                     $thingdata = array();
                    $attachments = array();
                     $coupondata = array();
                    $peoplecategories[] = 'All';
                     foreach ($people as $key => $value) {
                         $thingcategories[] = $value->name;
                     }     
        
                  foreach ($coupon as $key1 => $value) {
                       $coupondata[$key1] = $value;
                       $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value->background_image;
                   }
             
                      
                  foreach ($nearByData as $key => $value) {
                         $name = User::select('name','image')->where('id',$value->user_id)->first();
                          $images = Attachment::where('things_provider_id',$value->id)->get();
                         foreach ($images as $key1 => $value1) {
                            $attachments[$key1] = URL::to('/').'/attachments/'.$value1->filenames;
                         }

                        if (strpos($name->image, 'http') !== false) {
                                $image =  $name->image;
                        }else{
                               $image = URL::to('/').'/profile/'.$name->image;
                        }
                         if($value->ratings  == ""){
                          $ratings = '5';
                        }else{
                          $ratings = $value->ratings;
                        }
                        $thingdata[$key]['id'] = $value->id;
                        $thingdata[$key]['name'] = $value->title;
                         $thingdata[$key]['owned_by'] = $name->name;
                        $thingdata[$key]['latitude'] = $value->latitude;
                        $thingdata[$key]['longitude'] = $value->longitude;
                        $thingdata[$key]['ratings'] = $ratings;
                        $thingdata[$key]['attachments'] = $attachments;
                        $thingdata[$key]['address'] = $value->address;
                        $thingdata[$key]['price_per_night'] = $value->price_per_night;
                        $thingdata[$key]['hourly_price'] = $value->hourly_price;
                       
                    }  
                    $result['status'] = 1;
                    //$result['categories'] = $thingcategories;
                    $result['data'] = $thingdata;
                    //$result['coupons'] = $coupondata;
                    return $result;

                }elseif($request->get('type') == 'place'){

                   if($request->get('cat_name') == 'All'){

                            $query = "SELECT *, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 AS `distance` FROM `places_provider` WHERE ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15 AND `status` = '1' AND `user_id` != '".$loggedInUser->id."' ORDER BY `ratings` DESC";


                      }else{ 

                           
                 $placecat  = Place::where('name',$request->get('cat_name'))->first();
                  $placecat_id = $placecat->id;
                          $query = "SELECT *, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 AS `distance` FROM `places_provider` WHERE ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15 AND `status` = '1' AND `cat_id` = '".$placecat_id."' AND `user_id` != '".$loggedInUser->id."' ORDER BY `ratings` DESC";
                     
                     }
                
                $nearByData = DB::select(DB::raw($query));
               $place  = Place::all();
               $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','places')->get();
               $placecategories = array();
               $placedata = array();
               $attachments = array();
               $coupondata = array();
               $placecategories[] = 'All';
               foreach ($place as $key => $value) {
                   $placecategories[] = $value->name;
               }     
                
               foreach ($coupon as $key1 => $value) {
                    $day = date('Y-m-d',strtotime($value['created_at']));
                    $date1 =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days"));
                    $date_now = date('Y-m-d');
                    
                    if(strtotime($date1) >= strtotime($date_now)){
                    //  $i++;
                      $coupondata[$key1] = $value;
                      $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value['background_image'];
                      $coupondata[$key1]['valid_till'] =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days")); 
                    }      
                       
                   }
                   $arr = array_values($coupondata);
                
              foreach ($nearByData as $key => $value) {
                   $name = User::select('name','image')->where('id',$value->user_id)->first();
                    $images = Attachment::where('places_provider_id',$value->id)->get();
                   foreach ($images as $key1 => $value1) {
                      $attachments[$key1] = URL::to('/').'/attachments/'.$value1->filenames;
                   }

                      if (strpos($name->image, 'http') !== false) {
                              $image =  $name->image;
                      }else{
                             $image = URL::to('/').'/profile/'.$name->image;
                      }

                      if($value->ratings  == ""){
                        $ratings = '5';
                      }else{
                        $ratings = $value->ratings;
                      }
                    $placedata[$key]['id'] = $value->id;
                    $placedata[$key]['name'] = $value->title;

            $placedata[$key]['owned_by'] = $name->name;
                    $placedata[$key]['latitude'] = $value->latitude;
                    $placedata[$key]['longitude'] = $value->longitude;
                    $placedata[$key]['ratings'] = $ratings;
                    $placedata[$key]['attachments'] = $attachments;
                    $placedata[$key]['address'] = $value->address;
                    $placedata[$key]['price_per_night'] = $value->price_per_night;
                   
               }  
                  $result['status'] = 1;
                  $result['categories'] = $placecategories;
                  $result['data'] = $placedata;
                  $result['coupons'] = $arr;
                  return $result;


                  }elseif($request->get('type') == 'people'){

                      if($request->get('cat_name') == 'All'){

                     $query = "SELECT *, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 AS `distance` FROM `people_provider` WHERE ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15 AND `status` = '1' AND `user_id` != '".$loggedInUser->id."' ORDER BY `ratings` DESC
                     ";


                      }else{ 

                           
                  $peoplecat  = People::where('name',$request->get('cat_name'))->first();
                    $peoplecat_id = $peoplecat->id;
                          $query = "SELECT *, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 AS `distance` FROM `people_provider` WHERE ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15 AND `status` = '1' AND `cat_id` = '".$peoplecat_id."' AND `user_id` != '".$loggedInUser->id."' ORDER BY `ratings` DESC";
                     
                     }


                  $nearByData = DB::select(DB::raw($query));

                     $people  = People::all();
                     $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','people')->get();
                     $peoplecategories = array();
                     $peopledata = array();
                     $coupondata = array();
                     $peoplecategories[] = 'All';
                 foreach ($people as $key => $value) {
                     $peoplecategories[] = $value->name;
                 } 
                  foreach ($coupon as $key1 => $value) {
                     $coupondata[$key1] = $value;
                     $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value->background_image;
                 }   
                  
                foreach ($nearByData as $key => $value) {
                     $name = User::select('name','image')->where('id',$value->user_id)->first();
                
                        if (strpos($name->image, 'http') !== false) {
                                $image =  $name->image;
                        }else{
                               $image = URL::to('/').'/profile/'.$name->image;
                        }
                        if($value->ratings  == ""){
                          $ratings = '5';
                        }else{
                          $ratings = $value->ratings;
                        }
                      $peopledata[$key]['id'] = $value->id;
                      $peopledata[$key]['name'] = $value->title;
                       $peopledata[$key]['latitude'] = $value->latitude;
                      $peopledata[$key]['longitude'] = $value->longitude;
                      $peopledata[$key]['ratings'] = $ratings;
                      $peopledata[$key]['image'] = $image;
                      $peopledata[$key]['address'] = $value->address;
                      $peopledata[$key]['hourly_price'] = $value->hourly_price;
                      $peopledata[$key]['price_per_night'] = $value->price_per_night;
                     
                 }  
                    $result['status'] = 1;
                    //$result['categories'] = $peoplecategories;
                    $result['data'] = $peopledata;
                    //$result['coupons'] = $coupondata;     
                    return $result;

        }
            
          }elseif($request->get('filter_type') == 4 ){

            if($request->get('type') == 'thing'){

                if($request->get('cat_name') == 'All'){

                    $query = "SELECT *, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 AS `distance` FROM `things_provider` WHERE ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15 AND `status` = '1' AND `user_id` != '".$loggedInUser->id."' ORDER BY `ratings` ASC";


                      }else{ 

                           $thingcat  = Thing::where('name',$request->get('cat_name'))->first();
                           $thingcat_id = $thingcat->id;
                         $query = "SELECT *, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 AS `distance` FROM `things_provider` WHERE ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15 AND `status` = '1' AND `cat_id` = '".$thingcat_id."' AND `user_id` != '".$loggedInUser->id."' ORDER BY `ratings` ASC";
                     
                     }

                     
                    $nearByData = DB::select(DB::raw($query));
                    $people  = Thing::all();
                    $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','things')->get();
                     $peoplecategories = array();
                     $thingdata = array();
                    $attachments = array();
                     $coupondata = array();
                    $peoplecategories[] = 'All';
                     foreach ($people as $key => $value) {
                         $thingcategories[] = $value->name;
                     }     
        
                  foreach ($coupon as $key1 => $value) {
                       $coupondata[$key1] = $value;
                       $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value->background_image;
                   }
                    
                      
                  foreach ($nearByData as $key => $value) {
                         $name = User::select('name','image')->where('id',$value->user_id)->first();
                          $images = Attachment::where('things_provider_id',$value->id)->get();
                         foreach ($images as $key1 => $value1) {
                            $attachments[$key1] = URL::to('/').'/attachments/'.$value1->filenames;
                         }

                        if (strpos($name->image, 'http') !== false) {
                                $image =  $name->image;
                        }else{
                               $image = URL::to('/').'/profile/'.$name->image;
                        }
                         if($value->ratings  == ""){
                          $ratings = '5';
                        }else{
                          $ratings = $value->ratings;
                        }
                        $thingdata[$key]['id'] = $value->id;
                        $thingdata[$key]['name'] = $value->title;
                        $thingdata[$key]['owned_by'] = $name->name;
                        $thingdata[$key]['latitude'] = $value->latitude;
                        $thingdata[$key]['longitude'] = $value->longitude;
                        $thingdata[$key]['ratings'] = $ratings;
                        $thingdata[$key]['attachments'] = $attachments;
                        $thingdata[$key]['address'] = $value->address;
                        $thingdata[$key]['price_per_night'] = $value->price_per_night;
                        $thingdata[$key]['hourly_price'] = $value->hourly_price;
                       
                    }  
                    $result['status'] = 1;
                    //$result['categories'] = $thingcategories;
                    $result['data'] = $thingdata;
                    //$result['coupons'] = $coupondata;
                    return $result;

                }elseif($request->get('type') == 'place'){


                   if($request->get('cat_name') == 'All'){

                    $query = "SELECT *, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 AS `distance` FROM `places_provider` WHERE ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15 AND `status` = '1' AND `user_id` != '".$loggedInUser->id."' ORDER BY `ratings` ASC";


                      }else{

                           $placecat  = Place::where('name',$request->get('cat_name'))->first();
                           $placecat_id = $placecat->id;
                           $query = "SELECT *, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 AS `distance` FROM `places_provider` WHERE ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15 AND `status` = '1' AND `cat_id` = '".$placecat_id."'  AND `user_id` != '".$loggedInUser->id."' ORDER BY `ratings` ASC";
                     
                     }

                $nearByData = DB::select(DB::raw($query));
                  
                
               $place  = Place::all();
               $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','places')->get();
               $placecategories = array();
               $placedata = array();
               $attachments = array();
               $coupondata = array();
               $placecategories[] = 'All';
               foreach ($place as $key => $value) {
                   $placecategories[] = $value->name;
               }     
                
              foreach ($coupon as $key1 => $value) {
                    $day = date('Y-m-d',strtotime($value['created_at']));
                    $date1 =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days"));
                    $date_now = date('Y-m-d');
                    
                    if(strtotime($date1) >= strtotime($date_now)){
                    //  $i++;
                      $coupondata[$key1] = $value;
                      $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value['background_image'];
                      $coupondata[$key1]['valid_till'] =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days")); 
                    }      
                       
                   }
                   $arr = array_values($coupondata);
                
              foreach ($nearByData as $key => $value) {
                   $name = User::select('name','image')->where('id',$value->user_id)->first();
                    $images = Attachment::where('places_provider_id',$value->id)->get();
                   foreach ($images as $key1 => $value1) {
                      $attachments[$key1] = URL::to('/').'/attachments/'.$value1->filenames;
                   }

                      if (strpos($name->image, 'http') !== false) {
                              $image =  $name->image;
                      }else{
                             $image = URL::to('/').'/profile/'.$name->image;
                      }

                      if($value->ratings  == ""){
                        $ratings = '5';
                      }else{
                        $ratings = $value->ratings;
                      }
                    $placedata[$key]['id'] = $value->id;
                    $placedata[$key]['name'] = $value->title;
                    $placedata[$key]['owned_by'] = $name->name;
                    $placedata[$key]['latitude'] = $value->latitude;
                    $placedata[$key]['longitude'] = $value->longitude;
                    $placedata[$key]['ratings'] = $ratings;
                    $placedata[$key]['attachments'] = $attachments;
                    $placedata[$key]['address'] = $value->address;
                    $placedata[$key]['price_per_night'] = $value->price_per_night;
                   
               }  
                  $result['status'] = 1;
                  $result['categories'] = $placecategories;
                  $result['data'] = $placedata;
                  $result['coupons'] = $arr;
                  return $result;


                  }elseif($request->get('type') == 'people'){
                     if($request->get('cat_name') == 'All'){

                          $query = "SELECT *, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 AS `distance` FROM `people_provider` WHERE  ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15 AND `status` = '1' AND `user_id` != '".$loggedInUser->id."'ORDER BY `ratings` ASC";
                      }else{

                          $peoplecat  = People::where('name',$request->get('cat_name'))->first();
                          $peoplecat_id = $peoplecat->id;
                          $query = "SELECT *, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 AS `distance` FROM `people_provider` WHERE  ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15 AND `status` = '1'AND `cat_id` = '".$peoplecat_id."'  AND `user_id` != '".$loggedInUser->id."' ORDER BY `ratings` ASC";
                 
                      }
 
                    $nearByData = DB::select(DB::raw($query));
                     $people  = People::all();
                     $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','people')->get();
                     $peoplecategories = array();
                     $peopledata = array();
                     $coupondata = array();
                     $peoplecategories[] = 'All';
                 foreach ($people as $key => $value) {
                     $peoplecategories[] = $value->name;
                 } 
                  foreach ($coupon as $key1 => $value) {
                     $coupondata[$key1] = $value;
                     $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value->background_image;
                 }   
                   
                foreach ($nearByData as $key => $value) {
                     $name = User::select('name','image')->where('id',$value->user_id)->first();
                
                        if (strpos($name->image, 'http') !== false) {
                                $image =  $name->image;
                        }else{
                               $image = URL::to('/').'/profile/'.$name->image;
                        }
                        if($value->ratings  == ""){
                          $ratings = '5';
                        }else{
                          $ratings = $value->ratings;
                        }
                      $peopledata[$key]['id'] = $value->id;
                      $peopledata[$key]['name'] = $value->title;;
                       $peopledata[$key]['latitude'] = $value->latitude;
                      $peopledata[$key]['longitude'] = $value->longitude;
                      $peopledata[$key]['ratings'] = $ratings;
                      $peopledata[$key]['image'] = $image;
                      $peopledata[$key]['address'] = $value->address;
                      $peopledata[$key]['hourly_price'] = $value->hourly_price;
                      $peopledata[$key]['price_per_night'] = $value->price_per_night;
                     
                 }  
                    $result['status'] = 1;
                    //$result['categories'] = $peoplecategories;
                    $result['data'] = $peopledata;
                    //$result['coupons'] = $coupondata;     
                    return $result;

        }
            
          }


        }else{

           if($request->get('filter_type') == 0 ){

            if($request->get('type') == 'thing'){

                 if($request->get('cat_name') == 'All'){
                $provider  = ThingProvider::where('status','1')->where('user_id','<>',$loggedInUser->id)->orderBy(DB::raw("acos( cos( radians({$request->latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$request->longitude}) ) + sin( radians({$request->latitude}) ) * sin(radians(latitude)) ) * 6371 < 15"), 'DESC')->get();     
              }else{
                  $thingcat  = Thing::where('name',$request->get('cat_name'))->first();
                   $thingcat_id = $thingcat->id;
                  $provider  = ThingProvider::where('status','1')->where('user_id','<>',$loggedInUser->id)->where('cat_id',$thingcat_id)->orderBy(DB::raw("acos( cos( radians({$request->latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$request->longitude}) ) + sin( radians({$request->latitude}) ) * sin(radians(latitude)) ) * 6371 < 15"), 'DESC')->get();  
              }
          $people  = Thing::all();
          $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','things')->get();
           $peoplecategories = array();
           $thingdata = array();
          $attachments = array();
           $coupondata = array();
          $peoplecategories[] = 'All';
           foreach ($people as $key => $value) {
               $thingcategories[] = $value->name;
           }     
        
       foreach ($coupon as $key1 => $value) {
           $coupondata[$key1] = $value;
           $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value->background_image;
       }
        
      foreach ($provider as $key => $value) {
           $name = User::select('name','image')->where('id',$value->user_id)->first();
            $images = Attachment::where('things_provider_id',$value->id)->get();
           foreach ($images as $key1 => $value1) {
              $attachments[$key1] = URL::to('/').'/attachments/'.$value1->filenames;
           }

              if (strpos($name->image, 'http') !== false) {
                      $image =  $name->image;
              }else{
                     $image = URL::to('/').'/profile/'.$name->image;
              }
               if($value->ratings  == ""){
                $ratings = '5';
              }else{
                $ratings = $value->ratings;
              }
            $thingdata[$key]['id'] = $value->id;
            $thingdata[$key]['name'] = $value->title;
            $thingdata[$key]['owned_by'] = $name->name;
            $thingdata[$key]['latitude'] = $value->latitude;
            $thingdata[$key]['longitude'] = $value->longitude;
            $thingdata[$key]['ratings'] = $ratings;
            $thingdata[$key]['attachments'] = $attachments;
            $thingdata[$key]['address'] = $value->address;
            $thingdata[$key]['price_per_night'] = $value->price_per_night;
            $thingdata[$key]['hourly_price'] = $value->hourly_price;
           
       }  
          $result['status'] = 1;
          //$result['categories'] = $thingcategories;
          $result['data'] = $thingdata;
          //$result['coupons'] = $coupondata;
          return $result;

        }elseif($request->get('type') == 'place'){

           if($request->get('cat_name') == 'All'){
                 $provider  = PlaceProvider::where('status','1')->where('user_id','<>',$loggedInUser->id)->orderBy(DB::raw("acos( cos( radians({$request->latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$request->longitude}) ) + sin( radians({$request->latitude}) ) * sin(radians(latitude)) ) * 6371 < 15"), 'DESC')->get();   
              }else{
                  $placecat  = Place::where('name',$request->get('cat_name'))->first();
                  $placecat_id = $placecat->id;
                  $provider  = PlaceProvider::where('status','1')->where('user_id','<>',$loggedInUser->id)->where('cat_id',$placecat_id)->orderBy(DB::raw("acos( cos( radians({$request->latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$request->longitude}) ) + sin( radians({$request->latitude}) ) * sin(radians(latitude)) ) * 6371 < 15"), 'DESC')->get();  
              }
       $place  = Place::all();
       $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','places')->get();
       $placecategories = array();
       $placedata = array();
       $attachments = array();
       $coupondata = array();
       $placecategories[] = 'All';
       foreach ($place as $key => $value) {
           $placecategories[] = $value->name;
       }     
        
         foreach ($coupon as $key1 => $value) {
                    $day = date('Y-m-d',strtotime($value['created_at']));
                    $date1 =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days"));
                    $date_now = date('Y-m-d');
                    
                    if(strtotime($date1) >= strtotime($date_now)){
                    //  $i++;
                      $coupondata[$key1] = $value;
                      $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value['background_image'];
                      $coupondata[$key1]['valid_till'] =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days")); 
                    }      
                       
                   }
                   $arr = array_values($coupondata);

     
      foreach ($provider as $key => $value) {
           

            $images = Attachment::where('places_provider_id',$value->id)->get();
           foreach ($images as $key1 => $value1) {
              $attachments[$key1] = URL::to('/').'/attachments/'.$value1->filenames;
           }
           $username = User::select('name','image')->where('id',$value->user_id)->first();

           if($username){
               if(substr_compare($username->image,"http",0,4) === 0) {

                        $image =  $username->image;

                }else{
                       $image = URL::to('/').'/profile/'.$username->image;
                      
                }
                $name = $username->name;
              }else{
                $image = "";
                $name = "";
              }

             
              if($value->ratings  == ""){
                $ratings = '5';
              }else{
                $ratings = $value->ratings;
              }
            $placedata[$key]['id'] = $value->id;
           $placedata[$key]['name'] = $value->title;

            $placedata[$key]['owned_by'] = $name;
            $placedata[$key]['latitude'] = $value->latitude;
            $placedata[$key]['longitude'] = $value->longitude;
            $placedata[$key]['ratings'] = $ratings;

            $placedata[$key]['attachments'] = $attachments;
            $placedata[$key]['address'] = $value->address;
            $placedata[$key]['price_per_night'] = $value->price_per_night;
           
       }  
          $result['status'] = 1;
          $result['categories'] = $placecategories;
          $result['data'] = $placedata;
          $result['coupons'] = $arr;
          return $result;


        }elseif($request->get('type') == 'people'){

          if($request->get('cat_name') == 'All'){
                 $provider  = PeopleProvider::where('status','1')->where('user_id','<>',$loggedInUser->id)->orderBy(DB::raw("acos( cos( radians({$request->latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$request->longitude}) ) + sin( radians({$request->latitude}) ) * sin(radians(latitude)) ) * 6371 < 15"), 'DESC')->get();   
              }else{
                  $peoplecat  = People::where('name',$request->get('cat_name'))->first();
                  $peoplecat_id = $peoplecat->id;
                  $provider  = PeopleProvider::where('status','1')->where('cat_id',$peoplecat_id)->where('user_id','<>',$loggedInUser->id)->orderBy(DB::raw("acos( cos( radians({$request->latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$request->longitude}) ) + sin( radians({$request->latitude}) ) * sin(radians(latitude)) ) * 6371 < 15"), 'DESC')->get();  
              }
        
       $people  = People::all();
       $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','people')->get();
       $peoplecategories = array();
       $peopledata = array();
       $coupondata = array();
       $peoplecategories[] = 'All';
       foreach ($people as $key => $value) {
           $peoplecategories[] = $value->name;
       } 
        foreach ($coupon as $key1 => $value) {
           $coupondata[$key1] = $value;
           $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value->background_image;
       } 

      foreach ($provider as $key => $value) {
           $name = User::select('name','image')->where('id',$value->user_id)->first();
      
              if (strpos($name->image, 'http') !== false) {
                      $image =  $name->image;
              }else{
                     $image = URL::to('/').'/profile/'.$name->image;
              }
              if($value->ratings  == ""){
                $ratings = '5';
              }else{
                $ratings = $value->ratings;
              }
            $peopledata[$key]['id'] = $value->id;
            $peopledata[$key]['name'] = $value->title;
             $peopledata[$key]['latitude'] = $value->latitude;
            $peopledata[$key]['longitude'] = $value->longitude;
            $peopledata[$key]['ratings'] = $ratings;
            $peopledata[$key]['image'] = $image;
            $peopledata[$key]['address'] = $value->address;
            $peopledata[$key]['hourly_price'] = $value->hourly_price;
            $peopledata[$key]['price_per_night'] = $value->price_per_night;
           
       }  
          $result['status'] = 1;
          //$result['categories'] = $peoplecategories;
          $result['data'] = $peopledata;
          //$result['coupons'] = $coupondata;     
          return $result;

        }


          }elseif($request->get('filter_type') == 1 ){

            
            if($request->get('type') == 'thing'){

               if($request->get('cat_name') == 'All'){
                 $provider  = ThingProvider::where('status','1')->where('user_id','<>',$loggedInUser->id)->orderBy('price_per_night', 'DESC')->get(); 
              }else{
                  $thingcat  = Thing::where('name',$request->get('cat_name'))->first();
                  $thingcat_id = $thingcat->id;
                  $provider  = ThingProvider::where('status','1')->where('user_id','<>',$loggedInUser->id)->where('cat_id',$thingcat_id)->orderBy('price_per_night', 'DESC')->get(); 
              }

          
          $people  = Thing::all();
          $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','things')->get();
           $peoplecategories = array();
           $thingdata = array();
          $attachments = array();
           $coupondata = array();
          $peoplecategories[] = 'All';
           foreach ($people as $key => $value) {
               $thingcategories[] = $value->name;
           }     
        
       foreach ($coupon as $key1 => $value) {
           $coupondata[$key1] = $value;
           $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value->background_image;
       }
        
      foreach ($provider as $key => $value) {
           $name = User::select('name','image')->where('id',$value->user_id)->first();
            $images = Attachment::where('things_provider_id',$value->id)->get();
           foreach ($images as $key1 => $value1) {
              $attachments[$key1] = URL::to('/').'/attachments/'.$value1->filenames;
           }

              if (strpos($name->image, 'http') !== false) {
                      $image =  $name->image;
              }else{
                     $image = URL::to('/').'/profile/'.$name->image;
              }
               if($value->ratings  == ""){
                $ratings = '5';
              }else{
                $ratings = $value->ratings;
              }
            $thingdata[$key]['id'] = $value->id;
            $thingdata[$key]['name'] = $value->title;

            $thingdata[$key]['owned_by'] = $name->name;
            $thingdata[$key]['latitude'] = $value->latitude;
            $thingdata[$key]['longitude'] = $value->longitude;
            $thingdata[$key]['ratings'] = $ratings;
            $thingdata[$key]['attachments'] = $attachments;
            $thingdata[$key]['address'] = $value->address;
            $thingdata[$key]['price_per_night'] = $value->price_per_night;
           
       }  
          $result['status'] = 1;
          //$result['categories'] = $thingcategories;
          $result['data'] = $thingdata;
          //$result['coupons'] = $coupondata;
          return $result;

        }elseif($request->get('type') == 'place'){

             if($request->get('cat_name') == 'All'){
                 $provider  = PlaceProvider::where('status','1')->where('user_id','<>',$loggedInUser->id)->orderBy('price_per_night', 'DESC')->get(); 
              }else{
                  $placecat  = Place::where('name',$request->get('cat_name'))->first();
                  $placecat_id = $placecat->id;
                  $provider  = PlaceProvider::where('status','1')->where('cat_id',$placecat_id)->where('user_id','<>',$loggedInUser->id)->orderBy('price_per_night', 'DESC')->get();
              }
         
       $place  = Place::all();
       $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','places')->get();
       $placecategories = array();
       $placedata = array();
       $attachments = array();
       $coupondata = array();
       $placecategories[] = 'All';
       foreach ($place as $key => $value) {
           $placecategories[] = $value->name;
       }     
        
         foreach ($coupon as $key1 => $value) {
                    $day = date('Y-m-d',strtotime($value['created_at']));
                    $date1 =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days"));
                    $date_now = date('Y-m-d');
                    
                    if(strtotime($date1) >= strtotime($date_now)){
                    //  $i++;
                      $coupondata[$key1] = $value;
                      $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value['background_image'];
                      $coupondata[$key1]['valid_till'] =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days")); 
                    }      
                       
                   }
                   $arr = array_values($coupondata);

        
      foreach ($provider as $key => $value) {
           $name = User::select('name','image')->where('id',$value->user_id)->first();
            $images = Attachment::where('places_provider_id',$value->id)->get();
           foreach ($images as $key1 => $value1) {
              $attachments[$key1] = URL::to('/').'/attachments/'.$value1->filenames;
           }

              if (strpos($name->image, 'http') !== false) {
                      $image =  $name->image;
              }else{
                     $image = URL::to('/').'/profile/'.$name->image;
              }

              if($value->ratings  == ""){
                $ratings = '5';
              }else{
                $ratings = $value->ratings;
              }
            $placedata[$key]['id'] = $value->id;
            $placedata[$key]['name'] = $value->title;

            $placedata[$key]['owned_by'] = $name->name;
            $placedata[$key]['latitude'] = $value->latitude;
            $placedata[$key]['longitude'] = $value->longitude;
            $placedata[$key]['ratings'] = $ratings;
            $placedata[$key]['attachments'] = $attachments;
            $placedata[$key]['address'] = $value->address;
            $placedata[$key]['price_per_night'] = $value->price_per_night;
           
       }  
          $result['status'] = 1;
          $result['categories'] = $placecategories;
          $result['data'] = $placedata;
         $result['coupons'] = $arr;
          return $result;


        }elseif($request->get('type') == 'people'){

           if($request->get('cat_name') == 'All'){
                 $provider  = PeopleProvider::where('status','1')->where('user_id','<>',$loggedInUser->id)->orderBy('price_per_night', 'DESC')->get(); 
              }else{
                  $peoplecat  = People::where('status','1')->where('name',$request->get('cat_name'))->first();
                $peoplecat_id = $peoplecat->id;
                $provider  = PeopleProvider::where('cat_id',$peoplecat_id)->where('user_id','<>',$loggedInUser->id)->orderBy('price_per_night ', 'DESC')->get();
              }
         
       $people  = People::all();
       $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','people')->get();
       $peoplecategories = array();
       $peopledata = array();
       $coupondata = array();
       $peoplecategories[] = 'All';
       foreach ($people as $key => $value) {
           $peoplecategories[] = $value->name;
       } 
        foreach ($coupon as $key1 => $value) {
           $coupondata[$key1] = $value;
           $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value->background_image;
       }   
        
      foreach ($provider as $key => $value) {
           $name = User::select('name','image')->where('id',$value->user_id)->first();
      
              if (strpos($name->image, 'http') !== false) {
                      $image =  $name->image;
              }else{
                     $image = URL::to('/').'/profile/'.$name->image;
              }
              if($value->ratings  == ""){
                $ratings = '5';
              }else{
                $ratings = $value->ratings;
              }
            $peopledata[$key]['id'] = $value->id;
            $peopledata[$key]['name'] = $value->title;;
            $peopledata[$key]['latitude'] = $value->latitude;
            $peopledata[$key]['longitude'] = $value->longitude;
            $peopledata[$key]['ratings'] = $ratings;
            $peopledata[$key]['image'] = $image;
            $peopledata[$key]['address'] = $value->address;
            $peopledata[$key]['hourly_price'] = $value->hourly_price;
            $peopledata[$key]['price_per_night'] = $value->price_per_night;
           
         }  
          $result['status'] = 1;
          //$result['categories'] = $peoplecategories;
          $result['data'] = $peopledata;
          //$result['coupons'] = $coupondata;     
          return $result;

        }


          }elseif($request->get('filter_type') == 2 ){


           if($request->get('type') == 'thing'){

             if($request->get('cat_name') == 'All'){
                 $provider  = ThingProvider::where('status','1')->where('user_id','<>',$loggedInUser->id)->orderBy('price_per_night', 'ASC')->get(); 
              }else{
                  $thingcat  = Thing::where('name',$request->get('cat_name'))->first();
                $thingcat_id = $thingcat->id;
                $provider  = ThingProvider::where('status','1')->where('user_id','<>',$loggedInUser->id)->where('cat_id',$thingcat_id)->orderBy('price_per_night', 'ASC')->get();
              }
           
          $people  = Thing::all();
          $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','things')->get();
           $peoplecategories = array();
           $thingdata = array();
          $attachments = array();
           $coupondata = array();
          $peoplecategories[] = 'All';
           foreach ($people as $key => $value) {
               $thingcategories[] = $value->name;
           }     
        
       foreach ($coupon as $key1 => $value) {
           $coupondata[$key1] = $value;
           $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value->background_image;
       }
        
      foreach ($provider as $key => $value) {
           $name = User::select('name','image')->where('id',$value->user_id)->first();
            $images = Attachment::where('things_provider_id',$value->id)->get();
           foreach ($images as $key1 => $value1) {
              $attachments[$key1] = URL::to('/').'/attachments/'.$value1->filenames;
           }

              if (strpos($name->image, 'http') !== false) {
                      $image =  $name->image;
              }else{
                     $image = URL::to('/').'/profile/'.$name->image;
              }
               if($value->ratings  == ""){
                $ratings = '5';
              }else{
                $ratings = $value->ratings;
              }
            $thingdata[$key]['id'] = $value->id;
            $thingdata[$key]['name'] = $value->title;

            $thingdata[$key]['owned_by'] = $name->name;
            $thingdata[$key]['latitude'] = $value->latitude;
            $thingdata[$key]['longitude'] = $value->longitude;
            $thingdata[$key]['ratings'] = $ratings;
            $thingdata[$key]['attachments'] = $attachments;
            $thingdata[$key]['address'] = $value->address;
            $thingdata[$key]['price_per_night'] = $value->price_per_night;
            $thingdata[$key]['hourly_price'] = $value->hourly_price;
           
       }  
          $result['status'] = 1;
          //$result['categories'] = $thingcategories;
          $result['data'] = $thingdata;
          //$result['coupons'] = $coupondata;
          return $result;

        }elseif($request->get('type') == 'place'){

              if($request->get('cat_name') == 'All'){
                 $provider  = PlaceProvider::where('status','1')->where('user_id','<>',$loggedInUser->id)->orderBy('price_per_night', 'ASC')->get(); 
              }else{
                  $placecat  = Place::where('name',$request->get('cat_name'))->first();
                  $placecat_id = $placecat->id;
                  $provider  = PlaceProvider::where('status','1')->where('user_id','<>',$loggedInUser->id)->where('cat_id',$placecat_id)->orderBy('price_per_night', 'ASC')->get(); 
              }
 

             $place  = Place::all();
             $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','places')->get();
             $placecategories = array();
             $placedata = array();
             $attachments = array();
             $coupondata = array();
             $placecategories[] = 'All';
             foreach ($place as $key => $value) {
                 $placecategories[] = $value->name;
             }     
              
               foreach ($coupon as $key1 => $value) {
                    $day = date('Y-m-d',strtotime($value['created_at']));
                    $date1 =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days"));
                    $date_now = date('Y-m-d');
                    
                    if(strtotime($date1) >= strtotime($date_now)){
                    //  $i++;
                      $coupondata[$key1] = $value;
                      $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value['background_image'];
                      $coupondata[$key1]['valid_till'] =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days")); 
                    }      
                       
                   }
                   $arr = array_values($coupondata);

            foreach ($provider as $key => $value) {
                $name = User::select('name','image')->where('id',$value->user_id)->first();
                 $images = Attachment::where('places_provider_id',$value->id)->get();
                foreach ($images as $key1 => $value1) {
                   $attachments[$key1] = URL::to('/').'/attachments/'.$value1->filenames;
                }

                  if (strpos($name->image, 'http') !== false) {
                          $image =  $name->image;
                  }else{
                         $image = URL::to('/').'/profile/'.$name->image;
                  }

                  if($value->ratings  == ""){
                    $ratings = '5';
                  }else{
                    $ratings = $value->ratings;
                  }
                $placedata[$key]['id'] = $value->id;
                $placedata[$key]['name'] = $value->title;

            $placedata[$key]['owned_by'] = $name->name;
                $placedata[$key]['latitude'] = $value->latitude;
                $placedata[$key]['longitude'] = $value->longitude;
                $placedata[$key]['ratings'] = $ratings;
                $placedata[$key]['attachments'] = $attachments;
                $placedata[$key]['address'] = $value->address;
                $placedata[$key]['price_per_night'] = $value->price_per_night;
           
               }  
              $result['status'] = 1;
              $result['categories'] = $placecategories;
              $result['data'] = $placedata;
              $result['coupons'] = $arr;
              return $result;


           }elseif($request->get('type') == 'people'){

            if($request->get('cat_name') == 'All'){
                 $provider  = PeopleProvider::where('status','1')->where('user_id','<>',$loggedInUser->id)->orderBy('price_per_night', 'ASC')->get(); 
              }else{
                  $peoplecat  = People::where('name',$request->get('cat_name'))->first();
                  $peoplecat_id = $peoplecat->id;
                  $provider  = PeopleProvider::where('status','1')->where('user_id','<>',$loggedInUser->id)->where('cat_id',$peoplecat_id)->orderBy('price_per_night', 'ASC')->get(); 
              }
        
       $people  = People::all();
       $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','people')->get();
       $peoplecategories = array();
       $peopledata = array();
       $coupondata = array();
       $peoplecategories[] = 'All';
       foreach ($people as $key => $value) {
           $peoplecategories[] = $value->name;
       } 
        foreach ($coupon as $key1 => $value) {
           $coupondata[$key1] = $value;
           $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value->background_image;
       }   
        
      foreach ($provider as $key => $value) {
           $name = User::select('name','image')->where('id',$value->user_id)->first();
      
              if (strpos($name->image, 'http') !== false) {
                      $image =  $name->image;
              }else{
                     $image = URL::to('/').'/profile/'.$name->image;
              }
              if($value->ratings  == ""){
                $ratings = '5';
              }else{
                $ratings = $value->ratings;
              }
            $peopledata[$key]['id'] = $value->id;
            $peopledata[$key]['name'] = $value->title;
             $peopledata[$key]['latitude'] = $value->latitude;
            $peopledata[$key]['longitude'] = $value->longitude;
            $peopledata[$key]['ratings'] = $ratings;
            $peopledata[$key]['image'] = $image;
            $peopledata[$key]['address'] = $value->address;
            $peopledata[$key]['hourly_price'] = $value->hourly_price;
            $peopledata[$key]['price_per_night'] = $value->price_per_night;
           
         }  
          $result['status'] = 1;
          //$result['categories'] = $peoplecategories;
          $result['data'] = $peopledata;
          //$result['coupons'] = $coupondata;     
          return $result;

        }
            
          }elseif($request->get('filter_type') == 3 ){

             if($request->get('type') == 'thing'){

               if($request->get('cat_name') == 'All'){
                    $provider  = ThingProvider::where('status','1')->where('user_id','<>',$loggedInUser->id)->orderBy('ratings', 'DESC')->get(); 
                }else{
                  $thingcat  = Thing::where('name',$request->get('cat_name'))->first();
                $thingcat_id = $thingcat->id;
                $provider  = ThingProvider::where('status','1')->where('user_id','<>',$loggedInUser->id)->where('cat_id',$thingcat_id)->orderBy('ratings', 'DESC')->get();  
             
                } 

          
          $people  = Thing::all();
          $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','things')->get();
           $peoplecategories = array();
           $thingdata = array();
          $attachments = array();
           $coupondata = array();
          $peoplecategories[] = 'All';
           foreach ($people as $key => $value) {
               $thingcategories[] = $value->name;
           }     
        
       foreach ($coupon as $key1 => $value) {
           $coupondata[$key1] = $value;
           $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value->background_image;
       }
        
      foreach ($provider as $key => $value) {
           $name = User::select('name','image')->where('id',$value->user_id)->first();
            $images = Attachment::where('things_provider_id',$value->id)->get();
           foreach ($images as $key1 => $value1) {
              $attachments[$key1] = URL::to('/').'/attachments/'.$value1->filenames;
           }

              if (strpos($name->image, 'http') !== false) {
                      $image =  $name->image;
              }else{
                     $image = URL::to('/').'/profile/'.$name->image;
              }
               if($value->ratings  == ""){
                $ratings = '5';
              }else{
                $ratings = $value->ratings;
              }
            $thingdata[$key]['id'] = $value->id;
            $thingdata[$key]['name'] = $value->title;
            $thingdata[$key]['owned_by'] = $name->name;
            $thingdata[$key]['latitude'] = $value->latitude;
            $thingdata[$key]['longitude'] = $value->longitude;
            $thingdata[$key]['ratings'] = $ratings;
            $thingdata[$key]['attachments'] = $attachments;
            $thingdata[$key]['address'] = $value->address;
            $thingdata[$key]['price_per_night'] = $value->price_per_night;
            $thingdata[$key]['hourly_price'] = $value->hourly_price;
           
       }  
          $result['status'] = 1;
          //$result['categories'] = $thingcategories;
          $result['data'] = $thingdata;
          //$result['coupons'] = $coupondata;
          return $result;

        }elseif($request->get('type') == 'place'){

          if($request->get('cat_name') == 'All'){
            $provider  = PlaceProvider::where('status','1')->where('user_id','<>',$loggedInUser->id)->orderBy('ratings', 'DESC')->get(); 
          }else{
            $placecat  = Place::where('name',$request->get('cat_name'))->first();
          $placecat_id = $placecat->id;
          $provider  = PlaceProvider::where('status','1')->where('user_id','<>',$loggedInUser->id)->where('cat_id',$placecat_id)->orderBy('ratings', 'DESC')->get(); 
       
          } 
       $place  = Place::all();
       $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','places')->get();
       $placecategories = array();
       $placedata = array();
       $attachments = array();
       $coupondata = array();
       $placecategories[] = 'All';
       foreach ($place as $key => $value) {
           $placecategories[] = $value->name;
       }     
        
        foreach ($coupon as $key1 => $value) {
                    $day = date('Y-m-d',strtotime($value['created_at']));
                    $date1 =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days"));
                    $date_now = date('Y-m-d');
                    
                    if(strtotime($date1) >= strtotime($date_now)){
                    //  $i++;
                      $coupondata[$key1] = $value;
                      $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value['background_image'];
                      $coupondata[$key1]['valid_till'] =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days")); 
                    }      
                       
                   }
                   $arr = array_values($coupondata);

        
      foreach ($provider as $key => $value) {
           $name = User::select('name','image')->where('id',$value->user_id)->first();
            $images = Attachment::where('places_provider_id',$value->id)->get();
           foreach ($images as $key1 => $value1) {
              $attachments[$key1] = URL::to('/').'/attachments/'.$value1->filenames;
           }

              if (strpos($name->image, 'http') !== false) {
                      $image =  $name->image;
              }else{
                     $image = URL::to('/').'/profile/'.$name->image;
              }

              if($value->ratings  == ""){
                $ratings = '5';
              }else{
                $ratings = $value->ratings;
              }
            $placedata[$key]['id'] = $value->id;
            $placedata[$key]['name'] = $value->title;

            $placedata[$key]['owned_by'] = $name->name;
            $placedata[$key]['latitude'] = $value->latitude;
            $placedata[$key]['longitude'] = $value->longitude;
            $placedata[$key]['ratings'] = $ratings;
            $placedata[$key]['attachments'] = $attachments;
            $placedata[$key]['address'] = $value->address;
            $placedata[$key]['price_per_night'] = $value->price_per_night;
           
       }  
          $result['status'] = 1;
          $result['categories'] = $placecategories;
          $result['data'] = $placedata;
          $result['coupons'] = $arr;
          return $result;


        }elseif($request->get('type') == 'people'){

         if($request->get('cat_name') == 'All'){
            $provider  = PeopleProvider::where('status','1')->where('user_id','<>',$loggedInUser->id)->orderBy('ratings', 'DESC')->get(); 
          }else{
            $peoplecat  = People::where('name',$request->get('cat_name'))->first();
            $peoplecat_id = $peoplecat->id;
            $provider  = PeopleProvider::where('status','1')->where('user_id','<>',$loggedInUser->id)->where('cat_id',$peoplecat_id)->orderBy('ratings', 'DESC')->get(); 
          } 
       $people  = People::all();
       $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','people')->get();
       $peoplecategories = array();
       $peopledata = array();
       $coupondata = array();
       $peoplecategories[] = 'All';
       foreach ($people as $key => $value) {
           $peoplecategories[] = $value->name;
       } 
        foreach ($coupon as $key1 => $value) {
           $coupondata[$key1] = $value;
           $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value->background_image;
       }   
        
      foreach ($provider as $key => $value) {
           $name = User::select('name','image')->where('id',$value->user_id)->first();
      
              if (strpos($name->image, 'http') !== false) {
                      $image =  $name->image;
              }else{
                     $image = URL::to('/').'/profile/'.$name->image;
              }
              if($value->ratings  == ""){
                $ratings = '5';
              }else{
                $ratings = $value->ratings;
              }
            $peopledata[$key]['id'] = $value->id;
           $peopledata[$key]['name'] = $value->title;

            $peopledata[$key]['owned_by'] = $name->name;
             $peopledata[$key]['latitude'] = $value->latitude;
            $peopledata[$key]['longitude'] = $value->longitude;
            $peopledata[$key]['ratings'] = $ratings;
            $peopledata[$key]['image'] = $image;
            $peopledata[$key]['address'] = $value->address;
            $peopledata[$key]['hourly_price'] = $value->hourly_price;
            $peopledata[$key]['price_per_night'] = $value->price_per_night;
           
         }  
          $result['status'] = 1;
          //$result['categories'] = $peoplecategories;
          $result['data'] = $peopledata;
          //$result['coupons'] = $coupondata;     
          return $result;

        }


            
          }elseif($request->get('filter_type') == 4 ){

             if($request->get('type') == 'thing'){

              if($request->get('cat_name') == 'All'){
                 $provider  = ThingProvider::where('status','1')->where('user_id','<>',$loggedInUser->id)->orderBy('ratings', 'ASC')->get(); 
              }else{
                  $thingcat  = Thing::where('name',$request->get('cat_name'))->first();
                  $thingcat_id = $thingcat->id;
                  $provider  = ThingProvider::where('status','1')->where('user_id','<>',$loggedInUser->id)->where('cat_id',$thingcat_id)->orderBy('ratings', 'ASC')->get(); 
              }

          
          $thing  = Thing::all();
          $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','things')->get();
           $thingcategories = array();
           $thingdata = array();
          $attachments = array();
           $coupondata = array();
          $thingcategories[] = 'All';
           foreach ($thing as $key => $value) {
               $thingcategories[] = $value->name;
           }     
        
       foreach ($coupon as $key1 => $value) {
           $coupondata[$key1] = $value;
           $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value->background_image;
       }

      foreach ($provider as $key => $value) {
           $name = User::select('name','image')->where('id',$value->user_id)->first();
            $images = Attachment::where('things_provider_id',$value->id)->get();
           foreach ($images as $key1 => $value1) {
              $attachments[$key1] = URL::to('/').'/attachments/'.$value1->filenames;
           }

              if (strpos($name->image, 'http') !== false) {
                      $image =  $name->image;
              }else{
                     $image = URL::to('/').'/profile/'.$name->image;
              }
               if($value->ratings  == ""){
                $ratings = '5';
              }else{
                $ratings = $value->ratings;
              }
            $thingdata[$key]['id'] = $value->id;
            $thingdata[$key]['name'] = $value->title;

            $thingdata[$key]['owned_by'] = $name->name;
            $thingdata[$key]['latitude'] = $value->latitude;
            $thingdata[$key]['longitude'] = $value->longitude;
            $thingdata[$key]['ratings'] = $ratings;
            $thingdata[$key]['attachments'] = $attachments;
            $thingdata[$key]['address'] = $value->address;
            $thingdata[$key]['price_per_night'] = $value->price_per_night;
            $thingdata[$key]['hourly_price'] = $value->hourly_price;
           
       }  
          $result['status'] = 1;
          //$result['categories'] = $thingcategories;
          $result['data'] = $thingdata;
          //$result['coupons'] = $coupondata;
          return $result;

        }elseif($request->get('type') == 'place'){

           if($request->get('cat_name') == 'All'){
                 $provider  = PlaceProvider::where('status','1')->where('user_id','<>',$loggedInUser->id)->orderBy('ratings', 'ASC')->get(); 
              }else{
                  $placecat  = Place::where('name',$request->get('cat_name'))->first();
                $placecat_id = $placecat->id;
                $provider  = PlaceProvider::where('status','1')->where('user_id','<>',$loggedInUser->id)->where('cat_id',$placecat_id)->orderBy('ratings', 'ASC')->get(); 
              }

        
       $place  = Place::all();
       $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','places')->get();
       $placecategories = array();
       $placedata = array();
       $attachments = array();
       $coupondata = array();
       $placecategories[] = 'All';
       foreach ($place as $key => $value) {
           $placecategories[] = $value->name;
       }     
        
         foreach ($coupon as $key1 => $value) {
                    $day = date('Y-m-d',strtotime($value['created_at']));
                    $date1 =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days"));
                    $date_now = date('Y-m-d');
                    
                    if(strtotime($date1) >= strtotime($date_now)){
                    //  $i++;
                      $coupondata[$key1] = $value;
                      $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value['background_image'];
                      $coupondata[$key1]['valid_till'] =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days")); 
                    }      
                       
                   }
                   $arr = array_values($coupondata);

        
      foreach ($provider as $key => $value) {
           $name = User::select('name','image')->where('id',$value->user_id)->first();
            $images = Attachment::where('places_provider_id',$value->id)->get();
           foreach ($images as $key1 => $value1) {
              $attachments[$key1] = URL::to('/').'/attachments/'.$value1->filenames;
           }

              if (strpos($name->image, 'http') !== false) {
                      $image =  $name->image;
              }else{
                     $image = URL::to('/').'/profile/'.$name->image;
              }

              if($value->ratings  == ""){
                $ratings = '5';
              }else{
                $ratings = $value->ratings;
              }
            $placedata[$key]['id'] = $value->id;
            $placedata[$key]['name'] = $value->title;

            $placedata[$key]['owned_by'] = $name->name;
            $placedata[$key]['latitude'] = $value->latitude;
            $placedata[$key]['longitude'] = $value->longitude;
            $placedata[$key]['ratings'] = $ratings;
            $placedata[$key]['attachments'] = $attachments;
            $placedata[$key]['address'] = $value->address;
            $placedata[$key]['price_per_night'] = $value->price_per_night;
           
       }  
          $result['status'] = 1;
          $result['categories'] = $placecategories;
          $result['data'] = $placedata;
          $result['coupons'] = $arr;
          return $result;


        }elseif($request->get('type') == 'people'){

           if($request->get('cat_name') == 'All'){
                 $provider  = PeopleProvider::where('status','1')->where('user_id','<>',$loggedInUser->id)->orderBy('ratings', 'ASC')->get(); 
              }else{
                  $peoplecat  = People::where('name',$request->get('cat_name'))->first();
                $peoplecat_id = $peoplecat->id;
                $provider  = PeopleProvider::where('status','1')->where('cat_id',$peoplecat_id)->where('user_id','<>',$loggedInUser->id)->orderBy('ratings', 'ASC')->get();
              }

         
       $people  = People::all();
       $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','people')->get();
       $peoplecategories = array();
       $peopledata = array();
       $coupondata = array();
       $peoplecategories[] = 'All';
       foreach ($people as $key => $value) {
           $peoplecategories[] = $value->name;
       } 
        foreach ($coupon as $key1 => $value) {
           $coupondata[$key1] = $value;
           $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value->background_image;
       }   
        
      foreach ($provider as $key => $value) {
           $name = User::select('name','image')->where('id',$value->user_id)->first();
      
              if (strpos($name->image, 'http') !== false) {
                      $image =  $name->image;
              }else{
                     $image = URL::to('/').'/profile/'.$name->image;
              }
              if($value->ratings  == ""){
                $ratings = '5';
              }else{
                $ratings = $value->ratings;
              }
            $peopledata[$key]['id'] = $value->id;
            $peopledata[$key]['name'] = $value->title;
             $peopledata[$key]['latitude'] = $value->latitude;
            $peopledata[$key]['longitude'] = $value->longitude;
            $peopledata[$key]['ratings'] = $ratings;
            $peopledata[$key]['image'] = $image;
            $peopledata[$key]['address'] = $value->address;
            $peopledata[$key]['hourly_price'] = $value->hourly_price;
            $peopledata[$key]['price_per_night'] = $value->price_per_night;
           
         }  
          $result['status'] = 1;
          //$result['categories'] = $peoplecategories;
          $result['data'] = $peopledata;
          //$result['coupons'] = $coupondata;     
          return $result;

        }
            
          }

        }


       }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }

    }



   

    Public function Workdetails(Request $request){

    try{

        $rules = [
                    'provider_id' => 'required',
                  
                ];
      
                $validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {
                    return response()->json([
                       "status" => 0,
                       'errors' => $validator->errors()->toArray(),
                   ], 422);               
                }
        $LoggedInUser = Auth::user();

          $provider  = PeopleProvider::where('id',$request->get('provider_id'))->first();

             $unavailable_dates_booking = array();
             $date_new = array();
             $booking_data = Booking::where('people_provider_id',$request->get('provider_id'))->where('status','1')->get();

             if($booking_data){

               foreach ($booking_data as $key => $value) {

              if(date("Y-m-d", strtotime($value->check_in)) == date("Y-m-d",strtotime($value->check_out))){

               $date_new[] =  $this->getDatesFromRange(date("Y-m-d", strtotime($value->check_in)), date("Y-m-d",strtotime($value->check_out)));
              }else{

                $date_new[] =  $this->getDatesFromRange(date("Y-m-d", strtotime($value->check_in)), date("Y-m-d",strtotime('-1 day',strtotime($value->check_out))));
                }

               }       
              
              } 
              $newdates = array();
              if($provider->available_dates == ""){
                  $unavailable_dates = array();

                }else{
                $newdates[] =  $provider->available_dates;              
                if(empty($date_new)){
                  $final_bookingdateslist = array(); 
                }else{

                $final_bookingdateslist = call_user_func_array("array_merge", $date_new); 
                $newdates[] = implode(',', $final_bookingdateslist);
                }
                  $final_unavailable_dates = implode(',', $newdates);
                  $List = explode(',', $final_unavailable_dates);
                  
                    $unavailable_dates = $List;
                                               
                }

          $favourite = Favourite::where('people_provider_id',$request->get('provider_id'))->where('user_id',$LoggedInUser->id)->first();

        if($favourite){
           if($favourite->favourite == "0"){
            $favourites1 = false;
            }else{
            $favourites1 = true;
           } 
          }else{
            $favourites1 = false;
          }
          

          $user_data = User::where('id',$provider->user_id)->first();
          
          $reviews = Review::where('people_provider_id',$request->get('provider_id'))->paginate('5')->toArray();

          $reviews_count = Review::where('people_provider_id',$request->get('provider_id'))->count(); 
         
          $review = array();
          foreach ($reviews['data'] as $key => $value) {

            $user = User::where('id',$value['user_id'])->first();
            $review[$key] = $value;
            if (strpos($user->image, 'http') !== false) {
                      $review[$key]['image']  = $user->image;
              }else{
                     $review[$key]['image'] = URL::to('/').'/profile/'.$user->image;
              }
             $review[$key]['user_name'] = $user->name;
          }
          if($provider){

          $result['status'] = 1;
          $result['data'] = $provider;
          $result['data']['unavailable_dates'] = $unavailable_dates;
          $result['data']['favourite'] = $favourites1;
          $result['data']['sharelink'] = 'https://timernr.com/booking-peopleavailability/'.$provider->encodedid;
          $result['data']['user'] = $user_data['name'];
         if (strpos($user_data->image, 'http') !== false) {
                      $result['data']['image']  = $user_data['image'];
              }else{
                     $result['data']['image'] = URL::to('/').'/profile/'.$user_data['image'];
              }
          $result['data']['total_reviews'] = $reviews_count; 
          $result['data']['total_services'] = '2';    
          $result['data']['reviews'] = $review; 

          return $result;
          }else{

          $result['status'] = 0;
          $result['message'] = 'Something went wrong!'; 
          return $result;

          }

       }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }


    }

 public function getDatesFromRange($start, $end, $format = 'Y-m-d') { 
      
    // Declare an empty array 
    $array = array(); 
      
    // Variable that store the date interval 
    // of period 1 day 
    $interval = new DateInterval('P1D'); 
  
    $realEnd = new DateTime($end); 
    $realEnd->add($interval); 
  
    $period = new DatePeriod(new DateTime($start), $interval, $realEnd); 
  
    // Use loop to store date into array 
    foreach($period as $date) {                  
        $array[] = $date->format($format);  
    } 
  
    // Return the array elements 
    return $array; 
  } 
    Public function ThingsWorkdetails(Request $request){

    try{

        $rules = [
                    'provider_id' => 'required',
                  
                ];
      
                $validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {
                    return response()->json([
                       "status" => 0,
                       'errors' => $validator->errors()->toArray(),
                   ], 422);               
                }
           $LoggedInUser = Auth::user();

            $provider  = ThingProvider::where('id',$request->get('provider_id'))->first();
            $unavailable_dates_booking = array();
            $date_new  = array();
             $booking_data = Booking::where('things_provider_id',$request->get('provider_id'))->where('status','1')->get();
           
            foreach ($booking_data as $key => $value) {

              if(date("Y-m-d", strtotime($value->check_in)) == date("Y-m-d",strtotime($value->check_out))){

                $date_new[] =  $this->getDatesFromRange(date("Y-m-d", strtotime($value->check_in)), date("Y-m-d",strtotime($value->check_out)));
              }else{

                $date_new[] =  $this->getDatesFromRange(date("Y-m-d", strtotime($value->check_in)), date("Y-m-d",strtotime('-1 day',strtotime($value->check_out))));
              }
               
              
              } 
              $newdates = array();
                        
              if($provider->unavailable_dates == ""){
                  $unavailable_dates = array();
                }else{
                $newdates[] =  $provider->unavailable_dates;              
                if(empty($date_new)){
                  $final_bookingdateslist = array(); 
                }else{

                $final_bookingdateslist = call_user_func_array("array_merge", $date_new); 
                $newdates[] = implode(',', $final_bookingdateslist);
                }
                $final_unavailable_dates = implode(',', $newdates);
                  $List = explode(',', $final_unavailable_dates); 
                  $unavailable_dates = $List;              
                }

                $attachments = array();
           $images = Attachment::where('things_provider_id',$provider->id)->get();
           foreach ($images as $key1 => $value1) {
              $attachments[$key1] = URL::to('/').'/attachments/'.$value1->filenames;
           }
            $favourite = Favourite::where('things_provider_id',$request->get('provider_id'))->where('user_id',$LoggedInUser->id)->first();
          if($favourite){
           if($favourite->favourite == "0"){
            $favourites1 = false;
            }else{
            $favourites1 = true;
           } 
          }else{
            $favourites1 = false;
          }
         
          $user_data = User::where('id',$provider->user_id)->first();      
          $reviews = Review::where('things_provider_id',$request->get('provider_id'))->paginate('5')->toArray();

          $reviews_count = Review::where('things_provider_id',$request->get('provider_id'))->count(); 
         
          $review = array();
          foreach ($reviews['data'] as $key => $value) {

            $user = User::where('id',$value['user_id'])->first();
            $review[$key] = $value;
            if (strpos($user->image, 'http') !== false) {
                      $review[$key]['image']  = $user->image;
              }else{
                     $review[$key]['image'] = URL::to('/').'/profile/'.$user->image;
              }
             $review[$key]['user_name'] = $user->name;
          }
      
                
          if($provider){

          $result['status'] = 1;
          $result['data'] = $provider;
          $result['data']['sharelink'] = 'https://timernr.com/booking-thingavailability/'.$provider->encodedid;
          $result['data']['unavailable_dates'] = $unavailable_dates;
          $result['data']['attachments'] = $attachments;
          $result['data']['favourite'] = $favourites1;
          $result['data']['user'] = $user_data['name'];
          if (strpos($user_data->image, 'http') !== false) {
                      $result['data']['image']  = $user_data['image'];
              }else{
                     $result['data']['image'] = URL::to('/').'/profile/'.$user_data['image'];
              }
          $result['data']['total_reviews'] = $reviews_count; 
          $result['data']['total_services'] = '2';    
          $result['data']['reviews'] = $review; 

          return $result;
          }else{

          $result['status'] = 0;
          $result['message'] = 'Something went wrong!'; 
          return $result;

          }

        
        
        
        
          

       }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }


    }

    public function PlacesWorkdetails(Request $request){


    try{

        $rules = [
                    'provider_id' => 'required',
                  
                ];
      
                $validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {
                    return response()->json([
                       "status" => 0,
                       'errors' => $validator->errors()->toArray(),
                   ], 422);               
                }
           $LoggedInUser = Auth::user();
          $date_new = array();
           $unavailable_dates_booking = array();
            $provider  = PlaceProvider::where('id',$request->get('provider_id'))->first();

             $booking_data = Booking::where('places_provider_id',$request->get('provider_id'))->where('status','1')->get();
             
              foreach ($booking_data as $key => $value) {

              if(date("Y-m-d", strtotime($value->check_in)) == date("Y-m-d",strtotime($value->check_out))){

                $date_new[] =  $this->getDatesFromRange(date("Y-m-d", strtotime($value->check_in)), date("Y-m-d",strtotime($value->check_out)));
              }else{

                $date_new[] =  $this->getDatesFromRange(date("Y-m-d", strtotime($value->check_in)), date("Y-m-d",strtotime('-1 day',strtotime($value->check_out))));
              }
            }
             $newdates = array();
                         
              if($provider->unavailable_dates == ""){
                  $unavailable_dates = array();
                }else{

                $newdates[] =  $provider->unavailable_dates;   
                if(empty($date_new)){
                  $final_bookingdateslist = array(); 
                }else{

                $final_bookingdateslist = call_user_func_array("array_merge", $date_new); 
                $newdates[] = implode(',', $final_bookingdateslist);
                }           
                
                $final_unavailable_dates = implode(',', $newdates);
                  $List = explode(',', $final_unavailable_dates); 
                  $unavailable_dates = $List;              

                }

                

           
          $attachments = array();
        
           $images = Attachment::where('places_provider_id',$provider->id)->get();
           if($images){
              foreach ($images as $key1 => $value1) {
                   $attachments[$key1] = URL::to('/').'/attachments/'.$value1->filenames;
              }
           }


           $favourite = Favourite::where('places_provider_id',$request->get('provider_id'))->where('user_id',$LoggedInUser->id)->first();

            if($favourite){
               if($favourite->favourite == "0"){
                $favourites1 = false;
                }else{
                $favourites1 = true;
               } 
             }else{
                 $favourites1 = false;
             }

          $user_data = User::where('id',$provider->user_id)->first();      
          $reviews = Review::where('places_provider_id',$request->get('provider_id'))->paginate('5')->toArray();

          $reviews_count = Review::where('places_provider_id',$request->get('provider_id'))->count();
         
          $review = array();
          foreach ($reviews['data'] as $key => $value) {

            $user = User::where('id',$value['user_id'])->first();
            $review[$key] = $value;
            if (strpos($user->image, 'http') !== false) {
                      $review[$key]['image']  = $user->image;
              }else{
                     $review[$key]['image'] = URL::to('/').'/profile/'.$user->image;
              }
             $review[$key]['user_name'] = $user->name;
          }
          
          if($provider){
         
                if($provider->amenities_offered == ""){
                  $amenities_offered = $provider->amenities_offered;
                }else{
                  $List = explode(',', $provider->amenities_offered); 
                  $amenities_offered = $List;              
                }



                if($provider->pet_allowance == "true"){
                  $pet_allowance = true;
                }else{
                  $pet_allowance = false;              
                }
                if($provider->host_facility == "true"){
                  $host_facility = true;
                }else{
                  $host_facility = false;              
                }
 
          $result['status'] = 1;
          $result['data'] = $provider;
          $result['data']['sharelink'] = 'https://timernr.com/booking-placeavailability/'.$provider->encodedid;
          $result['data']['unavailable_dates'] = $unavailable_dates;
          $result['data']['amenities_offered'] = $amenities_offered;
          $result['data']['pet_allowance'] = $pet_allowance;
          $result['data']['host_facility'] = $host_facility;
          $result['data']['attachments'] = $attachments;
          $result['data']['favourite'] = $favourites1;
          $result['data']['user'] = $user_data['name'];
          if (strpos($user_data->image, 'http') !== false) {
                      $result['data']['image']  = $user_data['image'];
              }else{
                     $result['data']['image'] = URL::to('/').'/profile/'.$user_data['image'];
              }
          $result['data']['total_reviews'] = $reviews_count; 
          $result['data']['total_services'] = '2';    
          $result['data']['reviews'] = $review; 
          

          return $result;
          }else{

          $result['status'] = 0;
          $result['message'] = 'Something went wrong!'; 
          return $result;

          }        

       }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }
      
    }


    Public function AllReviews(Request $request){

    try{

       $rules = [
                    'provider_id' => 'required',
                    'page' => 'required',
                    'type' => 'required',
                  
                ];
      
                $validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {
                    return response()->json([
                       "status" => 0,
                       'errors' => $validator->errors()->toArray(),
                   ], 422);               
                }
          $LoggedInUser = Auth::user();
          if($request->get('type') == "1"){
            $provider  = PeopleProvider::where('id',$request->get('provider_id'))->first();
          $user_data = User::where('id',$provider->user_id)->first();       
          $reviews = Review::where('people_provider_id',$request->get('provider_id'))->paginate(50, ['*'], 'page', $request->get('page'))->toArray();
          $review = array();
          foreach ($reviews['data'] as $key => $value) {

            $user = User::where('id',$value['user_id'])->first();
            $review[$key] = $value;
            if (strpos($user->image, 'http') !== false) {
                      $review[$key]['image']  = $user->image;
              }else{
                     $review[$key]['image'] = URL::to('/').'/profile/'.$user->image;
              }
             $review[$key]['user_name'] = $user->name;
          }

          $result['status'] = 1;
          $result['reviews'] = $review; 
          $result['current_page'] = $reviews['current_page']; 
          $result['first_page_url'] = $reviews['first_page_url'];
          $result['last_page'] = $reviews['last_page'];
          $result['next_page_url'] = $reviews['next_page_url'];
          $result['path'] = $reviews['path'];
          $result['per_page'] = $reviews['per_page'];
          $result['prev_page_url'] = $reviews['prev_page_url'];
          $result['to'] = $reviews['to'];
          $result['total'] = $reviews['total'];

          return $result;

          }elseif($request->get('type') == "2"){

          $provider  = ThingProvider::where('id',$request->get('provider_id'))->first();
          $user_data = User::where('id',$provider->user_id)->first();       
          $reviews = Review::where('things_provider_id',$request->get('provider_id'))->paginate(50, ['*'], 'page', $request->get('page'))->toArray();
          $review = array();
          foreach ($reviews['data'] as $key => $value) {

            $user = User::where('id',$value['user_id'])->first();
            $review[$key] = $value;
            if (strpos($user->image, 'http') !== false) {
                      $review[$key]['image']  = $user->image;
              }else{
                     $review[$key]['image'] = URL::to('/').'/profile/'.$user->image;
              }
             $review[$key]['user_name'] = $user->name;
          }

          $result['status'] = 1;
          $result['reviews'] = $review; 
          $result['current_page'] = $reviews['current_page']; 
          $result['first_page_url'] = $reviews['first_page_url'];
          $result['last_page'] = $reviews['last_page'];
          $result['next_page_url'] = $reviews['next_page_url'];
          $result['path'] = $reviews['path'];
          $result['per_page'] = $reviews['per_page'];
          $result['prev_page_url'] = $reviews['prev_page_url'];
          $result['to'] = $reviews['to'];
          $result['total'] = $reviews['total'];

          return $result;

          }elseif($request->get('type') == "3"){

           $provider  = PlaceProvider::where('id',$request->get('provider_id'))->first();
          $user_data = User::where('id',$provider->user_id)->first();       
          $reviews = Review::where('places_provider_id',$request->get('provider_id'))->paginate(50, ['*'], 'page', $request->get('page'))->toArray();
          $review = array();
          foreach ($reviews['data'] as $key => $value) {

            $user = User::where('id',$value['user_id'])->first();
            $review[$key] = $value;
            if (strpos($user->image, 'http') !== false) {
                      $review[$key]['image']  = $user->image;
              }else{
                     $review[$key]['image'] = URL::to('/').'/profile/'.$user->image;
              }
             $review[$key]['user_name'] = $user->name;
          }

          $result['status'] = 1;
          $result['reviews'] = $review; 
          $result['current_page'] = $reviews['current_page']; 
          $result['first_page_url'] = $reviews['first_page_url'];
          $result['last_page'] = $reviews['last_page'];
          $result['next_page_url'] = $reviews['next_page_url'];
          $result['path'] = $reviews['path'];
          $result['per_page'] = $reviews['per_page'];
          $result['prev_page_url'] = $reviews['prev_page_url'];
          $result['to'] = $reviews['to'];
          $result['total'] = $reviews['total'];

          return $result;

          }



          


       }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }

 
    }

    Public function favourites(Request $request){

      try{

        $rules = [
                    'provider_id' => 'required',
                    'type' => 'required',
                  
                ];

                $validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {
                    return response()->json([
                       "status" => 0,
                       'errors' => $validator->errors()->toArray(),
                   ], 422);               
                }
                $LoggedInUser = Auth::user();
                if($request->get('type') == '1'){

                 $favourite =   Favourite::where('people_provider_id',$request->get('provider_id'))->where('user_id', $LoggedInUser->id)->first();
                   if($favourite){
                      $favourite =   Favourite::where('people_provider_id',$request->get('provider_id'))->where('user_id', $LoggedInUser->id)->update([
                        'favourite' => $request->get('favourite'),

                      ]);
                   }else{

                    $favourite = new Favourite;
                    $favourite->user_id = $LoggedInUser->id;
                    $favourite->favourite = $request->get('favourite');
                    $favourite->people_provider_id = $request->get('provider_id');
                    $favourite->save();
                  
                   }
                    $favourite =   Favourite::where('people_provider_id',$request->provider_id)->where('user_id', $LoggedInUser->id)->first();
                    $result['status'] = 1;
                    $result['favourite'] = $favourite;

                  return $result;



                }elseif($request->get('type') == '2'){

                   $favourite =   Favourite::where('things_provider_id',$request->get('provider_id'))->where('user_id', $LoggedInUser->id)->first();
                   if($favourite){
                      $favourite =   Favourite::where('things_provider_id',$request->get('provider_id'))->where('user_id', $LoggedInUser->id)->update([
                        'favourite' => $request->get('favourite'),

                      ]);
                   }else{
                    $favourite = new Favourite;
                    $favourite->user_id = $LoggedInUser->id;
                    $favourite->favourite = $request->get('favourite');
                    $favourite->things_provider_id = $request->get('provider_id');
                    $favourite->save();

                   }

                   $favourite =   Favourite::where('things_provider_id',$request->get('provider_id'))->where('user_id', $LoggedInUser->id)->first();
                    $result['status'] = 1;
                    $result['favourite'] = $favourite;

                  return $result;

                }elseif($request->get('type') == '3'){

                    $provider =   PlaceProvider::where('id',$request->get('provider_id'))->first();

                    if($provider){
                       $favourite =   Favourite::where('places_provider_id',$request->get('provider_id'))->where('user_id', $LoggedInUser->id)->first();

                   if($favourite){
                      $favourite =   Favourite::where('places_provider_id',$request->get('provider_id'))->where('user_id', $LoggedInUser->id)->update([
                        'favourite' => $request->get('favourite'),

                      ]);
                   }else{
                    $favourite = new Favourite;
                    $favourite->user_id = $LoggedInUser->id;
                    $favourite->favourite = $request->get('favourite');
                    $favourite->places_provider_id = $request->get('provider_id');
                    $favourite->save();
                     

                   }

                   $favourite =   Favourite::where('places_provider_id',$request->get('provider_id'))->where('user_id', $LoggedInUser->id)->first();
                    $result['status'] = 1;
                    $result['favourite'] = $favourite;

                  return $result;
                    }else{

                      return response()->json([
                  "status" => 0,
                  "message" => "Provider Not exist",
                       
                   ], 422); 

                    }
                   
                   

                  
                }


      }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }

    }

     public function createtoken(Request $request)
    {
        $userid = Auth::id();

        try{
           $result = Braintree_ClientToken::generate();
            
            return response()->json([
                'status' => 1,
                'message' => "Token created Successfully.",
                'data' => $result
            ], 200);
        }     

        catch(Exception $e){
            $result = [
                'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $result['status'] = 0;
        }
        return $result;
    }

     public function deletecreditcards(Request $request){

        try{   
              $rules = [                
                  'token' => 'required',     
              ];
              $validator = Validator::make($request->all(), $rules);

              if($validator->fails())
              {
                  return response()->json([
                     "status" => 0,
                     "message" => "Something went wrong!",
                     'errors' => $validator->errors()->toArray(),
                 ], 422);               
              }

           $result = Braintree_PaymentMethod::delete($request->get('token'));
           if($result){

           return response()->json([
                'status' => 1,
                'message' => 'Credit card Deleted Successfully'
           ], 200);

           }else{

           		return response()->json([
	                'status' => 0,
	                'message' => 'Something went wrong!!'
         		  ], 422);

           }
   
         
        }     

        catch(Exception $e){
            $result = [
                'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $result['status'] = 0;
             return $result;
        }
    }

    public function getallcreditcards(Request $request){

    	$loggedInUser = Auth::user();
       $data = array();

        try{   

          if($loggedInUser->customer_id == ""){

          	     return response()->json([
                  'status' => 1,
                  'creditcards' => $data
              ], 200);

          }else{
          
           $result = Braintree_Customer::find($loggedInUser->customer_id);



           if($result){

           	foreach ($result->paymentMethods as $key => $value) {
           	
           	  $data[$key]['expirationDate'] =  $value->expirationDate;
           	  $data[$key]['cardType'] = $value->cardType;
           	  $data[$key]['cardholderName'] =$value->cardholderName;
           	  $data[$key]['customerId'] =$value->customerId;
           	  $data[$key]['token'] =$value->token;
           	  $data[$key]['imageUrl'] =$value->imageUrl;
           	  $data[$key]['maskedNumber'] =$value->maskedNumber;       	        	   
           }            
           return response()->json([
                'status' => 1,
                'creditcards' => $data
           ], 200);

           }else{

           		return response()->json([
	                'status' => 0,
	                'creditcards' => $data
         		  ], 422);

           }

          }    
         
        }     

        catch(Exception $e){
            $result = [
                'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $result['status'] = 0;

        }
        return $result;
    }

   public function createpaymentcard(Request $request)
    {
         $loggedInUser = Auth::user();
         if($request->get('expirationDate')){
        	$date = explode('/', $request->get('expirationDate'));
        	$expiration_month = $date[0];
        	$expiration_year = $date[1];
        }
          $data = array();
        try{
      $rules = [                
              'nonce' => 'required',     
          ];
          $validator = Validator::make($request->all(), $rules);

              if($validator->fails())
              {
                  return response()->json([
                     "status" => 0,
                     "message" => "Something went wrong!",
                     'errors' => $validator->errors()->toArray(),
                 ], 422);               
              }

        	if($loggedInUser->customer_id == ""){

        		$result = Braintree_Customer::create([
				    'firstName' => $loggedInUser->name,
				    'lastName' => $loggedInUser->lastname,
				    'paymentMethodNonce' => $request->get('nonce'),
				]);

				if ($result->success) {

				User::where('id',$loggedInUser->id)->update(['customer_id'=>$result->customer->id]);

				$payment_method = Braintree_PaymentMethod::create([
			    'customerId' => $result->customer->id,
			    'number' => $request->get('number'),
			    'expirationMonth' => $expiration_month,
			    'expirationYear' => $expiration_year,
			    'cardholderName' => $request->get('cardholderName'),
			    'cvv' =>  $request->get('cvv'),
			    'paymentMethodNonce' => $request->get('nonce'), 
			    'options' => [
			        'verifyCard' => true
			    ]
				 ]);

					
				 if($payment_method->success){



        $data['expirationDate'] = $payment_method->paymentMethod->expirationDate;
        $data['cardholderName'] =$payment_method->paymentMethod->cardholderName;
        $data['customerId'] =$payment_method->paymentMethod->customerId;
        $data['token'] =$payment_method->paymentMethod->token;
        $data['imageUrl'] =$payment_method->paymentMethod->imageUrl;
        $data['maskedNumber'] =$payment_method->paymentMethod->maskedNumber;
						
				 	return response()->json([
		                'status' => 1,
		                'message' => "Saved Card Successfully.",
                    'creditcard' => $data,
	            	], 200);

				 }else{
				 	return response()->json([
		                'status' => 0,
		                'message' => $payment_method->message,
		           
	            	], 422);
				 }
				
				} else {
				    foreach($result->errors->deepAll() AS $error) {

				        $error_message = $error->code . ": " . $error->message . "\n";
				    }
				    return response()->json([
		                'status' => 0,
		                'message' => $error_message,
		           
	            	], 422);
				}

	        	}else{
          $unique_id_number = array();
          $customer = Braintree_Customer::find($loggedInUser->customer_id);
          foreach ($customer->paymentMethods as $key => $value) {
            $unique_id_number[$key] = $value->uniqueNumberIdentifier;
             
           } 
            
          $payment_method = Braintree_PaymentMethod::create([
				    'customerId' => $loggedInUser->customer_id,
				    'number' => $request->get('number'),
				     'expirationMonth' => $expiration_month,
			   		 'expirationYear' => $expiration_year,
			   		 'cardholderName' => $request->get('cardholderName'),
				    'cvv' =>  $request->get('cvv'),
				    'paymentMethodNonce' => $request->get('nonce'), 
				    'options' => [
				        'verifyCard' => true,
				    ]
			    ]); 
    
		      if($payment_method->success){

             $cardAlreadyExist = false;
             $currentPaymentMethod = $payment_method->paymentMethod->uniqueNumberIdentifier;
              //The in_array function was not working so I used foreach to check if     card identifier exist or not
              foreach ($unique_id_number as $key => $uid) {

                if( $currentPaymentMethod  == $uid)
                  {
                      $cardAlreadyExist = true;
              //Here you have to delete the currently added card
                          $payment_token = $payment_method->paymentMethod->token;
                          Braintree_PaymentMethod::delete($payment_token);

                     return response()->json([
                        'status' => 1,
                        'message' => "Card Already exists.",
                        'creditcard' => $data,
                    ], 422);

                  }else{

                     $cardAlreadyExist = false;

                  }
                }

                  $data['expirationDate'] = $payment_method->paymentMethod->expirationDate;
                  $data['cardholderName'] =$payment_method->paymentMethod->cardholderName;
                  $data['customerId'] =$payment_method->paymentMethod->customerId;
                  $data['token'] =$payment_method->paymentMethod->token;
                  $data['imageUrl'] =$payment_method->paymentMethod->imageUrl;
                  $data['maskedNumber'] =$payment_method->paymentMethod->maskedNumber;                     
                     
                  return response()->json([
                        'status' => 1,
                        'message' => "Saved Card Successfully.",
                        'creditcard' => $data,
                    ], 200);
      
            

      			 }else{

      			 	return response()->json([
      	                'status' => 0,
      	                'message' => $payment_method->message,
      	           
                  	], 422);
      			 }

        }

        
        }     

        catch(Exception $e){
            $result = [
                'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $result['status'] = 0;
             return $result;
        }
    }


    public function payment(Request $request)
    {
       
        $user = Auth::user(); 
       
        try{  
            $rules = [                
                'amount' => 'required',     
                'type' => 'required',
                'provider_id' => 'required',
            ];
            $validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {
                    return response()->json([
                       "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422);               
                }
                $slot = array();


               if($request->get('coupon_id')){
                 $coupon_data = Coupon::where('coupon_code',$request->get('coupon_id'))->first();
                 if($coupon_data){
                    $coupon_id = $coupon_data->id;
                 }else{

                   return response()->json([
                       "status" => 0,
                       "message" => "Coupon not valid",
                       
                   ], 422);    

                 }
               }else{
                  $coupon_id = "";
               }

              if($request->get('type') == "1"){
                 $provider_user = PeopleProvider::where('id',$request->get('provider_id'))->first();
                 $provider_user_id = $provider_user->user_id;
              }elseif($request->get('type') == "3"){
                $provider_user = PlaceProvider::where('id',$request->get('provider_id'))->first();
                 $provider_user_id = $provider_user->user_id;  
              }elseif($request->get('type') == "2"){
                 $provider_user = ThingProvider::where('id',$request->get('provider_id'))->first();
                 $provider_user_id = $provider_user->user_id; 
              }

            if($request->get('nonce') != ""){
             

              $charge = Braintree_Transaction::sale([
              'amount' => $request->amount,
              'paymentMethodNonce' => $request->nonce,     
            ]);

            }else{
              $charge = Braintree_Transaction::sale([
              'amount' => $request->amount,
              'paymentMethodToken' => $request->token,    
            ]);

            }
            

 

            if ($charge->success || !is_null($charge->transaction)) {
        
            	$booking = new Booking;
            	$booking->user_id = $user->id;
            	if($request->get('type') == "1"){
					       $booking->people_provider_id = $request->get('provider_id');
            	}elseif($request->get('type') == "3"){
            		$booking->places_provider_id = $request->get('provider_id');	
            	}elseif($request->get('type') == "2"){
            		$booking->things_provider_id = $request->get('provider_id');
            	}

      
              $booking->provider_user_id  = $provider_user_id;
            	$booking->check_in  = $request->get('check_in');
            	$booking->check_out = $request->get('check_out');
              $booking->time_in   = $request->get('time_in');
              $booking->time_out  = $request->get('time_out');
            	$booking->total_amount = $charge->transaction->amount;
            	$booking->coupon_id  = $coupon_id;
            	//$booking->user_vault = $total_amount_provider_vault;
              $booking->status = 1;
            	$booking->save();


              $wallettransaction = new WalletTransaction;
              $wallettransaction->provider_user_id = $provider_user_id;
              if($request->get('type') == "1"){
                 $wallettransaction->people_provider_id = $request->get('provider_id');
              }elseif($request->get('type') == "3"){
                $wallettransaction->places_provider_id = $request->get('provider_id');  
              }elseif($request->get('type') == "2"){
                $wallettransaction->things_provider_id = $request->get('provider_id');
              }
              $wallettransaction->transaction_amount  = $charge->transaction->amount;
              $wallettransaction->date = date('Y-m-d');
              $wallettransaction->transaction_amount_status = '0';
              $wallettransaction->user_id = $user->id;  
              $wallettransaction->booking_id = $booking->id;           
              $wallettransaction->save();

            	$user_data = User::where('id',$provider_user_id)->first();
				      $total_user_vault_amount = $user_data->user_vault_total + $charge->transaction->amount;
            	User::where('id',$provider_user_id)->update(['user_vault_total'=> $total_user_vault_amount]);

			       	$provider_user_vault_final = User::where('id',$provider_user_id)->first();
            	$booking_data = Booking::where('id',$booking->id)->first();
              
              //Notifications start
                  $reciever = $user_data->id; 
                  $notification = new Notification;
                  $notification->user_id = $reciever;
                  $notification->message = 'Your booking has been Confirmed';
                  $notification->sender = $reciever;
                  $notification->reciever = $user->id;
                  $notification->booking_id = $booking->id;
                  $notification->type = 1;
                  $notification->save();

                  $notification = new Notification;
                  $notification->user_id = $user->id;
                  $notification->message = 'New booking Request';
                  $notification->sender = $user->id;
                  $notification->reciever = $reciever;
                  $notification->booking_id = $booking->id;
                  $notification->type = 1;
                  $notification->save();

                   $notification = new Notification;
                  $notification->user_id = $user->id;
                  $notification->message = 'Recieved booking Request payment';
                  $notification->sender = $user->id;
                  $notification->reciever = $reciever;
                  $notification->booking_id = $booking->id;
                  $notification->type = 1;
                  $notification->save();

                 
                  $this->sendPushNotification($user->device_token,'Booking Confirmation','Your booking has been Confirmed');
                   $this->sendPushNotification($user_data->device_token,'Booking Request','New booking Request');  
                   $this->sendPushNotification($user_data->device_token,'Booking Payment','Recieved booking Request payment');             

              //Notification end

            	  $result['status'] = 1;
                $result['message'] = "payment done successfully";
                $result['booking'] = $booking_data;
                $result['booking']['user_total_vault'] =  $provider_user_vault_final->user_vault_total;
            }
            else
            {
               return response()->json([
                       "status" => 0,
                       "message" => $charge->message,
                       
                   ], 422); 
            }
        }
        catch(Exception $e){
            $result = [
                'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $result['status'] = 0;
             return $result;
        }
        return $result;
   }

    public function sendPushNotification($token,$title='',$msg="") {

       $url = 'https://fcm.googleapis.com/fcm/send';
               $serverkey = 'AAAAEmcRsng:APA91bEGt33nTosoGVa_kb1vOLnxXFvrjjja3DR8M_hT7rkYpdKmEmbtM1sqMqsgsGi8EkoVRvfiD802zRlKawB-ornIV6EKTfcCbR0dl7M2kHmPmF9H57mAiyaSmUmCPHQP22fnJmSW';
                     $url = 'https://fcm.googleapis.com/fcm/send';
                     
                     $fields = array(

                       'to' => $token,
                       'notification'  => array(
                                        'title' => $title, 
                                        'body' =>  $msg,
                                        ),
                        'data' => array(
                                    'title' => $title, 
                                    'body' =>  $msg,
                                    'click_action' =>  'FLUTTER_NOTIFICATION_CLICK',
                                    'type' => '2',

                                  )         
                     );
                     $headers = array(
                       'Authorization: key=' . $serverkey,
                       'Content-Type: application/json'
                     );
                     $ch = curl_init();
                     curl_setopt($ch, CURLOPT_URL, $url);
                     curl_setopt($ch, CURLOPT_POST, true);
                     curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                     curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                     curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
                    $result = curl_exec($ch);
                     curl_close($ch);


               return $result;
   }
   public function applycoupon(Request $request){

      $user_id = Auth::id(); 
       
        try{  
            $rules = [                
                'amount' => 'required',
                'coupon_code' => 'required',
            ];

            $validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {
                    return response()->json([
                       "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422);               
                }

               if($request->type == '1'){
               		$type = 'people';
               }elseif($request->type == '2'){
               		$type = 'things';
               }elseif($request->type == '3'){
               		$type = 'places';
               }

               $coupon = Coupon::where('coupon_code',$request->get('coupon_code'))->first();
               if($coupon->applicable_on == 'all' ){

	               	if($coupon){

	                $expiry_date =  date('Y-m-d', strtotime($coupon->created_at. ' + '.$coupon->valid_for.' days'));

	               if(strtotime(date("Y-m-d")) > strtotime($expiry_date)){

	                   return response()->json([
	                       "message" => "This coupon code has been expired.",
	                       'errors' => $validator->errors()->toArray(),
	                   ], 422);  

	               }else{


	                 if($coupon->rules ==  "greater than equal to"){

	                if($request->get('amount') >= $coupon->amount){
	                  $discount = $coupon->discount/100;
	                  $discounted_price = $request->get('amount') * $discount;
	                  $total_amount = $request->get('amount') - $discounted_price;

	                   return response()->json([
	                       'status' => 1,
	                       "amount" => $discounted_price,
	                   ], 200);

	                  }else{
	                    return response()->json([
	                       'status' => 0,
	                       "message" => "Coupon Not Valid",
	                   ], 422);
	                  }
	                  

	                 }elseif($coupon->rules ==  "less than equal to"){

	                  if($request->get('amount') <= $coupon->amount){
	                    
	                    $discount = $coupon->discount/100;
	                    $discounted_price = $request->get('amount') * $discount;
	                    $total_amount = $request->get('amount') - $discounted_price;

	                   return response()->json([
	                       'status' => 1,
	                       "amount" => $discounted_price,
	                   ], 200);
	                    
	                  }else{
	                    return response()->json([
	                       'status' => 0,
	                       "message" => "Coupon Not Valid",
	                   ], 422);
	                  }

	                 }elseif($coupon->rules ==  "less than"){

	                   if($request->get('amount') < $coupon->amount){

	                    $discount = $coupon->discount/100;
	                    $discounted_price = $request->get('amount') * $discount;
	                    $total_amount = $request->get('amount') - $discounted_price;

	                   return response()->json([
	                       'status' => 1,
	                       "amount" => $discounted_price,
	                   ], 200);
	                    
	                  }else{
	                    return response()->json([
	                       'status' => 0,
	                       "message" => "Coupon Not Valid",
	                   ], 422);
	                  }

	                 }elseif($coupon->rules ==  "greater than"){

	                  if($request->get('amount') > $coupon->amount){

	                    $discount = $coupon->discount/100;
	                    $discounted_price = $request->get('amount') * $discount;
	                    $total_amount = $request->get('amount') - $discounted_price;

	                   return response()->json([
	                       'status' => 1,
	                       "amount" => $discounted_price,
	                   ], 200);
	                    
	                  }else{
	                    return response()->json([
	                       'status' => 0,
	                       "message" => "Coupon Not Valid",
	                   ], 422);
	                  }

	                 }

	               }

	               }else{

	                return response()->json([
	                       'status' => 0,
	                       "message" => "Coupon Not Exists",
	                   ], 422);


	               }

               }else{

               if($coupon->applicable_on == $type) {

	            if($coupon){

	                $expiry_date =  date('Y-m-d', strtotime($coupon->created_at. ' + '.$coupon->valid_for.' days'));

	               if(strtotime(date("Y-m-d")) > strtotime($expiry_date)){

	                   return response()->json([
	                       "message" => "This coupon code has been expired.",
	                       'errors' => $validator->errors()->toArray(),
	                   ], 422);  

	               }else{


	             	if($coupon->rules ==  "greater than equal to"){

		                if($request->get('amount') >= $coupon->amount){
		                  $discount = $coupon->discount/100;
		                  $discounted_price = $request->get('amount') * $discount;
		                  $total_amount = $request->get('amount') - $discounted_price;

		                   return response()->json([
		                       'status' => 1,
		                       "amount" => $discounted_price,
		                   ], 200);

		                  }else{
		                    return response()->json([
		                       'status' => 0,
		                       "message" => "Coupon Not Valid",
		                   ], 422);
		                  }
	                  

	                 }elseif($coupon->rules ==  "less than equal to"){

	                  if($request->get('amount') <= $coupon->amount){
	                    
	                    $discount = $coupon->discount/100;
	                    $discounted_price = $request->get('amount') * $discount;
	                    $total_amount = $request->get('amount') - $discounted_price;

	                   return response()->json([
	                       'status' => 1,
	                       "amount" => $discounted_price,
	                   ], 200);
	                    
	                  }else{
	                    return response()->json([
	                       'status' => 0,
	                       "message" => "Coupon Not Valid",
	                   ], 422);
	                  }

	                 }elseif($coupon->rules ==  "less than"){

	                   if($request->get('amount') < $coupon->amount){

	                    $discount = $coupon->discount/100;
	                    $discounted_price = $request->get('amount') * $discount;
	                    $total_amount = $request->get('amount') - $discounted_price;

	                   return response()->json([
	                       'status' => 1,
	                       "amount" => $discounted_price,
	                   ], 200);
	                    
	                  }else{
	                    return response()->json([
	                       'status' => 0,
	                       "message" => "Coupon Not Valid",
	                   ], 422);
	                  }

	                 }elseif($coupon->rules ==  "greater than"){

	                  if($request->get('amount') > $coupon->amount){

	                    $discount = $coupon->discount/100;
	                    $discounted_price = $request->get('amount') * $discount;
	                    $total_amount = $request->get('amount') - $discounted_price;

	                   return response()->json([
	                       'status' => 1,
	                       "amount" => $discounted_price,
	                   ], 200);
	                    
	                  }else{
	                    return response()->json([
	                       'status' => 0,
	                       "message" => "Coupon Not Valid",
	                   ], 422);
	                  }

	                 }

	               }

	               }else{

	                return response()->json([
	                       'status' => 0,
	                       "message" => "Coupon Not Exists",
	                   ], 422);


	               }

               }else{

               		return response()->json([
	                       'status' => 0,
	                       "message" => "Coupon Not Valid",
	                   ], 422);
               }
           }
                             
              
        }
        catch(Exception $e){
            $result = [
                'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $result['status'] = 0;
             return $result;
        }

   }

     public function slots(Request $request){ 

    try{

      $user_id = Auth::id(); 
            $rules = [      
                'timezone' => 'required',          
                'type' => 'required',
                'provider_id' => 'required',
                'check_in' => 'required',
                'check_out' => 'required'
            ];
            $check_in = date('Y-m-d',strtotime($request->get('check_in')));
            $check_out = date('Y-m-d',strtotime($request->get('check_out')));
           
            $validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {
                    return response()->json([
                       "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422);               
                }
                $slotsbooked = array();
                $sltnames  = array();
                if($request->get('type') == "1"){
                 $provider_user = PeopleProvider::where('id',$request->get('provider_id'))->first();
                 $booking_data = Booking::where('people_provider_id',$request->get('provider_id'))->where('time_slots','<>','')->where('status','1')->get(); 
                 
                  foreach ($booking_data as $key => $value) {
                    if(date('Y-m-d',strtotime($value->check_in)) == $check_in){
                      $sltnames[] = $value->time_slots;
                      }              
                    }
                     if(!empty($sltnames)){
                        $slts =  implode(',', $sltnames);
                        $slots_data =  explode(',', $slts);                      
                      foreach ($slots_data as $key => $value) {
                        $data =   Slot::where('slots',$value)->first();
                        $slotsbooked[$key]['start'] = $data->Starttime;
                        $slotsbooked[$key]['end'] = $data->Endtime;
                       }
                     }
                     
                 $time_in = $provider_user->time_in;
                 $time_out = $provider_user->time_out;

              }elseif($request->get('type') == "3"){
                $provider_user = PlaceProvider::where('id',$request->get('provider_id'))->first();
                 $booking_data = Booking::where('places_provider_id',$request->get('provider_id'))->where('time_slots','<>','')->where('status','1')->get();

                 foreach ($booking_data as $key => $value) {
                    if(date('Y-m-d',strtotime($value->check_in)) == $check_in){
                      $sltnames[] = $value->time_slots;
                      }  
                     }
                if(!empty($sltnames)){
                   $slts =  implode(',', $sltnames);

                   $slots_data =  explode(',', $slts);
                 
                 foreach ($slots_data as $key => $value) {
                  $data =   Slot::where('slots',$value)->first();
                  $slotsbooked[$key]['start'] = $data->Starttime;
                  $slotsbooked[$key]['end'] = $data->Endtime;
                 }
               }
                 $time_in = $provider_user->time_in;
                 $time_out = $provider_user->time_out;
              }elseif($request->get('type') == "2"){
                 $provider_user = ThingProvider::where('id',$request->get('provider_id'))->first();
                 $booking_data = Booking::where('things_provider_id',$request->get('provider_id'))->where('time_slots','<>','')->where('status','1')->get();
                 foreach ($booking_data as $key => $value) {
                     if(date('Y-m-d',strtotime($value->check_in)) == $check_in){
                      $sltnames[] = $value->time_slots;
                      }  
                     }
                  if(!empty($sltnames)){
                    $slts =  implode(',', $sltnames);
                    $slots_data =  explode(',', $slts);
                   
                   foreach ($slots_data as $key => $value) {
                    $data =   Slot::where('slots',$value)->first();
                    $slotsbooked[$key]['start'] = $data->Starttime;
                    $slotsbooked[$key]['end'] = $data->Endtime;
                   }
                 }
                 $time_in = $provider_user->time_in;
                 $time_out = $provider_user->time_out;
              }
 
                    $data = array();
                    $date = new DateTime("now", new DateTimeZone($request->get('timezone')) );
                    $now = $date->format('G:00');                   
                    $checkstart = new DateTime($time_in);
                    $checkstart_time = $checkstart->format('G:00');
                    $start = new DateTime($time_in);
                    $end = new DateTime($time_out);
                    $start_time = $start->format('G:00');
                    $end_time = $end->format('G:00');
          
                  if(strtotime ($start_time) >= strtotime ($end_time)){
                      $schedule = [
                          'start' => $start_time,
                          'end' => $end_time,
                      ];
                      $newtime_out = '11:59 PM';
                      if($checkstart_time < $now){
                         $schedule = [
                          'start' => $now,
                          'end' => $newtime_out,
                         ];
                          $newstart_time = $now;
                      }else{
                        $schedule = [
                          'start' => $start_time,
                          'end' => $newtime_out,
                        ];
                      }
                    
                    }else{
                
                      if($checkstart_time < $now){
                          
                          $schedule = [
                          'start' => $now,
                          'end' => $end_time,
                          ];
                      
                      }else{
                         $schedule = [
                          'start' => $start_time,
                          'end' => $end_time,
                          ];
                        
                      }
                                
                    }

                $start = Carbon::instance(new DateTime($schedule['start']));
                $end = Carbon::instance(new DateTime($schedule['end']));
              

                $events = $slotsbooked;

            $minSlotHours = 1;
            $minSlotMinutes = 0;
            $minInterval = CarbonInterval::hour($minSlotHours)->minutes($minSlotMinutes);

             
          $reqSlotHours = 1;
          $reqSlotMinutes = 0;
          $reqInterval = CarbonInterval::hour($reqSlotHours)->minutes($reqSlotMinutes);

          $ReturnArray = array();

        foreach(new DatePeriod($start, $minInterval, $end) as $key => $slot){

            $to = $slot->copy()->add($reqInterval); 
          
            $ReturnArray[$key]['slot'] = $slot->format('G:00') . ' - ' . $to->format('G:00');
            
          if($this->slotAvailable($slot, $to, $events)){

                $ReturnArray[$key]['isbooked'] = 1;

            }else{

                $ReturnArray[$key]['isbooked'] = 0;
            }


            
        }     
               $data['time_slots'] = $ReturnArray;
                   return $data;
              
              


        }catch(Exception $e){
            $result = [
                'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $result['status'] = 0;
             return $result;
        }
      }

   function slotAvailable($from, $to, $events){

            foreach($events as $event){
                $eventStart = Carbon::instance(new DateTime($event['start']));
                $eventEnd = Carbon::instance(new DateTime($event['end']));
                if($from->between($eventStart, $eventEnd) && $to->between($eventStart, $eventEnd)){

                    return false;
                }
            }
            return true;
        }
 
   public function favourites_savedlist(Request $request){

    try{

      $user_id = Auth::id(); 

      $rules = [                
                'type' => 'required',
            ];

            $validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {
                    return response()->json([
                       "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422);               
                }
      $data = array();

      if($request->get('type') == '1'){

        $favourite = Favourite::where('user_id',$user_id)->where('favourite', '1')->where('people_provider_id','<>', "")->get();

        if(count($favourite) != 0){
 
           foreach ($favourite as $key => $value) {

          $provider = PeopleProvider::where('id',$value->people_provider_id )->first();
          $attachment = User::where('id',$provider->user_id )->first();
          $image = URL::to('/').'/profile/'.$attachment->image;
          $data['favourite_list'][$key]['provider_id'] = $value->people_provider_id; 
          $data['favourite_list'][$key]['title'] = $provider->title; 
          $data['favourite_list'][$key]['ratings'] = $provider->ratings; 
          $data['favourite_list'][$key]['address'] = $provider->address;
          $data['favourite_list'][$key]['image'] = $image;

          # code...
        }

        }else{ 
            $data['favourite_list'] = $favourite;

        }

       

      }elseif($request->get('type') == '2'){
        $favourite = Favourite::where('user_id',$user_id)->where('favourite', '1')->where('things_provider_id','<>', "")->get();
         if(count($favourite) != 0){

          foreach ($favourite as $key => $value) {
            $provider = ThingProvider::where('id',$value->things_provider_id )->first();
             $attachment = Attachment::where('things_provider_id',$provider->id )->first();
              
              $image = URL::to('/').'/attachments/'.$attachment->filenames;
              $data['favourite_list'][$key]['provider_id'] = $value->things_provider_id; 
              $data['favourite_list'][$key]['title'] = $provider->title; 
              $data['favourite_list'][$key]['ratings'] = $provider->ratings; 
              $data['favourite_list'][$key]['address'] = $provider->address;
              $data['favourite_list'][$key]['image'] = $image;
        }

        }else{
          
          $data['favourite_list'] = $favourite;
        }
        

      }elseif($request->get('type') == '3'){
        $favourite = Favourite::where('user_id',$user_id)->where('favourite', '1')->where('places_provider_id','<>', "")->get();
         if(count($favourite) != 0){ 

          foreach ($favourite as $key => $value) {
          $provider = PlaceProvider::where('id',$value->places_provider_id )->first();
          $attachment = Attachment::where('places_provider_id',$provider->id )->first();
          $image = URL::to('/').'/attachments/'.$attachment->filenames;
         $data['favourite_list'][$key]['provider_id'] = $value->places_provider_id; 
          $data['favourite_list'][$key]['title'] = $provider->title; 
          $data['favourite_list'][$key]['ratings'] = $provider->ratings; 
          $data['favourite_list'][$key]['address'] = $provider->address;
           $data['favourite_list'][$key]['image'] = $image;
        }

        }else{

          $data['favourite_list'] = $favourite;
          
        }
        
      }

      return $data;

    }catch(Exception $e){
            $result = [
                'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $result['status'] = 0;
             return $result;
        }

   }

public function booking_list(Request $request){

      $user_id = Auth::id(); 
       
        try{  

           $rules = [                
              'type' => 'required',
            ];

            $validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {
                    return response()->json([
                       "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422);               
                }

            $data = array();

            if($request->get('type') == '1'){


            if($request->get('provider_type') == '1'){
              $bookings = Booking::where('user_id', $user_id)->where('status','1')->where('people_provider_id','<>','')->get();

              foreach ($bookings as $key => $value) {
                  $provider_user = PeopleProvider::where('id',$value->people_provider_id )->first();
                  $attachment = User::where('id',$provider_user->user_id )->first();


                $data[$key]['id'] = $value->id;
                $data[$key]['date'] = $value->check_in;
                $data[$key]['title'] = $provider_user->title;
                $data[$key]['user_id'] = $attachment->id;
                $data[$key]['user_name'] = $attachment->name;
                $data[$key]['user_image'] = URL::to('/').'/profile/'.$attachment->image;
                $data[$key]['image'] = URL::to('/').'/profile/'.$attachment->image;
               
              } 

            }elseif($request->get('provider_type') == '2'){
              $bookings = Booking::where('user_id', $user_id)->where('status','1')->where('things_provider_id','<>','')->get();
         

                foreach ($bookings as $key => $value) {
                  
                  $provider_user = ThingProvider::where('id',$value->things_provider_id )->first(); 
                  $attachment = Attachment::where('things_provider_id',$value->things_provider_id )->first();
                  $user = User::where('id',$provider_user->user_id )->first();
                $data[$key]['id'] = $value->id;
                $data[$key]['date'] = $value->check_in;
                $data[$key]['user_id'] = $user->id;
                $data[$key]['title'] = $provider_user->title;
                $data[$key]['user_name'] = $user->name;
                $data[$key]['user_image'] = URL::to('/').'/profile/'.$user->image;
                $data[$key]['image'] = URL::to('/').'/attachments/'.$attachment->filenames;
               
              }

            }elseif($request->get('provider_type') == '3'){
               $bookings = Booking::where('user_id', $user_id)->where('status','1')->where('places_provider_id','<>','')->get();

                foreach ($bookings as $key => $value) {
                   
                  $provider_user = PlaceProvider::where('id',$value->places_provider_id )->first();
                  $attachment = Attachment::where('places_provider_id',$value->places_provider_id )->first();
                  $user = User::where('id',$provider_user->user_id )->first();
                $data[$key]['id'] = $value->id;
                 $data[$key]['date'] = $value->check_in;
                $data[$key]['title'] = $provider_user->title;
                $data[$key]['user_id'] = $user->id;
                $data[$key]['user_name'] = $user->name;
                $data[$key]['user_image'] = URL::to('/').'/profile/'.$user->image;
                $data[$key]['image'] = URL::to('/').'/attachments/'.$attachment->filenames;
               
              }

            }else{

             $bookings = Booking::where('user_id', $user_id)->where('status','1')->get();

              foreach ($bookings as $key => $value) {
               
                if($value->people_provider_id != ""){

                  $provider_user = PeopleProvider::where('id',$value->people_provider_id )->first();
                    $attachment = User::where('id',$provider_user->user_id )->first();
                    $user_id = $attachment->id;
                    $user_name = $attachment->name;
                    $user_image = URL::to('/').'/profile/'.$attachment->image;
                    $image = URL::to('/').'/profile/'.$attachment->image;
                    $provider_type = '1';

                }elseif($value->things_provider_id != ""){

                  $provider_user = ThingProvider::where('id',$value->things_provider_id )->first(); 
                  $attachment = Attachment::where('things_provider_id',$value->things_provider_id )->first();
                  $user = User::where('id',$provider_user->user_id )->first();
                  $user_id = $user->id;
                  $user_name = $user->name;
                  $user_image = URL::to('/').'/profile/'.$user->image;
                  $image = URL::to('/').'/attachments/'.$attachment->filenames;
                  $provider_type = '2';

                }elseif($value->places_provider_id != ""){

                  $provider_user = PlaceProvider::where('id',$value->places_provider_id )->first();
                  $attachment = Attachment::where('places_provider_id',$value->places_provider_id )->first();
                  $user = User::where('id',$provider_user->user_id )->first();
                  $user_id = $user->id;
                  $user_name = $user->name;
                  $user_image = URL::to('/').'/profile/'.$user->image;
                  $image = URL::to('/').'/attachments/'.$attachment->filenames;
                  $provider_type = '3';
                }

                $data[$key]['id'] = $value->id;
                $data[$key]['user_id'] = $user_id ;
                $data[$key]['user_name'] = $user_name;
                $data[$key]['user_image'] = $user_image;
                $data[$key]['date'] = $value->check_in;
                $data[$key]['title'] = $provider_user->title;
                $data[$key]['image'] = $image;
               
              }

            }

            }elseif($request->get('type') == '2'){

            if($request->get('provider_type') == '1'){
              $bookings = Booking::where('user_id', $user_id)->where('status','2')->where('people_provider_id','<>','')->get();

              foreach ($bookings as $key => $value) {
                  $provider_user = PeopleProvider::where('id',$value->people_provider_id )->first();
                  $attachment = User::where('id',$provider_user->user_id )->first();


                $data[$key]['id'] = $value->id;
                $data[$key]['user_id'] = $attachment->id;
                $data[$key]['user_name'] = $attachment->name;
                $data[$key]['user_image'] = URL::to('/').'/profile/'.$attachment->image;
                 $data[$key]['date'] = $value->check_in;
                $data[$key]['title'] = $provider_user->title;
                $data[$key]['image'] = URL::to('/').'/profile/'.$attachment->image;
               
              }

            }elseif($request->get('provider_type') == '2'){
              $bookings = Booking::where('user_id', $user_id)->where('status','2')->where('things_provider_id','<>','')->get();

              foreach ($bookings as $key => $value) {
                  
                  $provider_user = ThingProvider::where('id',$value->things_provider_id )->first(); 
                  $attachment = Attachment::where('things_provider_id',$value->things_provider_id )->first();
                  $user = User::where('id',$provider_user->user_id )->first();
                
                $data[$key]['user_id'] = $provider_user->title;
                $data[$key]['user_name'] = $user->name;
                $data[$key]['user_image'] = URL::to('/').'/profile/'.$user->image;

                $data[$key]['id'] = $value->id;
                 $data[$key]['date'] = $value->check_in;
                $data[$key]['title'] = $provider_user->title;
                $data[$key]['image'] = URL::to('/').'/attachments/'.$attachment->filenames;
               
              }

            }elseif($request->get('provider_type') == '3'){
               $bookings = Booking::where('user_id', $user_id)->where('status','2')->where('places_provider_id','<>','')->get();

               foreach ($bookings as $key => $value) {
                  
                  $provider_user = PlaceProvider::where('id',$value->places_provider_id )->first();
                  $attachment = Attachment::where('places_provider_id',$value->places_provider_id )->first();
                   $user = User::where('id',$provider_user->user_id )->first();
                
                $data[$key]['user_id'] = $provider_user->title;
                $data[$key]['user_name'] = $user->name;
                $data[$key]['user_image'] = URL::to('/').'/profile/'.$user->image;
                $data[$key]['id'] = $value->id;
                 $data[$key]['date'] = $value->check_in;
                $data[$key]['title'] = $provider_user->title;
                $data[$key]['image'] = URL::to('/').'/attachments/'.$attachment->filenames;
               
              }


            }else{
             $bookings = Booking::where('user_id', $user_id)->where('status','2')->get();

              foreach ($bookings as $key => $value) {
               
                if($value->people_provider_id != ""){

                  $provider_user = PeopleProvider::where('id',$value->people_provider_id )->first();
                   $attachment = User::where('id',$provider_user->user_id )->first();
                   $user_id = $attachment->id;
                   $user_name = $attachment->name;
                   $user_image = URL::to('/').'/profile/'.$attachment->image;
                   $image = URL::to('/').'/profile/'.$attachment->image;
                   $provider_type = '1';

                }elseif($value->things_provider_id != ""){

                  $provider_user = ThingProvider::where('id',$value->things_provider_id )->first(); 
                  $attachment = Attachment::where('things_provider_id',$value->things_provider_id )->first();
                  $user = User::where('id',$provider_user->user_id )->first();
                  $user_id = $user->id;
                  $user_name = $user->name;
                  $user_image = URL::to('/').'/profile/'.$user->image;
                   $image = URL::to('/').'/attachments/'.$attachment->filenames;
                   $provider_type = '2';

                }elseif($value->places_provider_id != ""){

                  $provider_user = PlaceProvider::where('id',$value->places_provider_id )->first();
                  $attachment = Attachment::where('places_provider_id',$value->places_provider_id )->first();
                  $user = User::where('id',$provider_user->user_id )->first();
                  $user_id = $user->id;
                  $user_name = $user->name;
                  $user_image = URL::to('/').'/profile/'.$user->image;
                   $image = URL::to('/').'/attachments/'.$attachment->filenames;
                   $provider_type = '3';
                }

                $data[$key]['id'] = $value->id;
                $data[$key]['user_id'] = $user_id ;
                $data[$key]['user_name'] = $user_name;
                $data[$key]['user_image'] = $user_image;
                 $data[$key]['date'] = $value->check_in;
                $data[$key]['title'] = $provider_user->title;
                $data[$key]['image'] = $image;
               
              }
            }

            }elseif($request->get('type') == '3'){

            if($request->get('provider_type') == '1'){
              $bookings = Booking::where('user_id', $user_id)->where('status','3')->where('people_provider_id','<>','')->get();


              foreach ($bookings as $key => $value) {
                  $provider_user = PeopleProvider::where('id',$value->people_provider_id )->first();
                  $attachment = User::where('id',$provider_user->user_id )->first();
                 

                 $data[$key]['id'] = $value->id;
                 $data[$key]['user_id'] = $attachment->id;
                 $data[$key]['user_name'] = $attachment->name;
                 $data[$key]['user_image'] = URL::to('/').'/profile/'.$attachment->image;
                 $data[$key]['date'] = $value->check_in;
                $data[$key]['title'] = $provider_user->title;
                $data[$key]['image'] = URL::to('/').'/profile/'.$attachment->image;
               
              }

            }elseif($request->get('provider_type') == '2'){
              $bookings = Booking::where('user_id', $user_id)->where('status','3')->where('things_provider_id','<>','')->get();

              foreach ($bookings as $key => $value) {
                  
                  $provider_user = ThingProvider::where('id',$value->things_provider_id )->first(); 
                  $attachment = Attachment::where('things_provider_id',$value->things_provider_id )->first();
                   $user = User::where('id',$provider_user->user_id )->first();
                
                $data[$key]['user_id'] = $provider_user->title;
                $data[$key]['user_name'] = $user->name;
                $data[$key]['user_image'] = URL::to('/').'/profile/'.$user->image;
                  $data[$key]['id'] = $value->id;
                  $data[$key]['date'] = $value->check_in;
                  $data[$key]['title'] = $provider_user->title;
                  $data[$key]['image'] = URL::to('/').'/attachments/'.$attachment->filenames;
               
              }

            }elseif($request->get('provider_type') == '3'){
               $bookings = Booking::where('user_id', $user_id)->where('status','3')->where('places_provider_id','<>','')->get();

               foreach ($bookings as $key => $value) {
                  
                  $provider_user = PlaceProvider::where('id',$value->places_provider_id )->first();
                  $attachment = Attachment::where('places_provider_id',$value->places_provider_id )->first();
                   $user = User::where('id',$provider_user->user_id )->first();
                
                $data[$key]['user_id'] = $provider_user->title;
                $data[$key]['user_name'] = $user->name;
                $data[$key]['user_image'] = URL::to('/').'/profile/'.$user->image;
                 $data[$key]['id'] = $value->id;
                 $data[$key]['date'] = $value->check_in;
                $data[$key]['title'] = $provider_user->title;
                $data[$key]['image'] = URL::to('/').'/attachments/'.$attachment->filenames;
               
              }


            }else{
             $bookings = Booking::where('user_id', $user_id)->where('status','3')->get();

              foreach ($bookings as $key => $value) {
               
                if($value->people_provider_id != ""){

                  $provider_user = PeopleProvider::where('id',$value->people_provider_id )->first();
                  $user_id = $attachment->id;
                   $user_name = $attachment->name;
                   $user_image = URL::to('/').'/profile/'.$attachment->image;
                  $attachment = User::where('id',$provider_user->user_id )->first();
                  $image = URL::to('/').'/profile/'.$attachment->image;
                  $provider_type = '1';

                }elseif($value->things_provider_id != ""){

                  $provider_user = ThingProvider::where('id',$value->things_provider_id )->first(); 
                  $attachment = Attachment::where('things_provider_id',$value->things_provider_id )->first();
                  $user = User::where('id',$provider_user->user_id )->first();
                  $user_id = $user->id;
                  $user_name = $user->name;
                  $user_image = URL::to('/').'/profile/'.$user->image;
                  $image = URL::to('/').'/attachments/'.$attachment->filenames;
                  $provider_type = '2';

                }elseif($value->places_provider_id != ""){

                  $provider_user = PlaceProvider::where('id',$value->places_provider_id )->first();
                  $attachment = Attachment::where('places_provider_id',$value->places_provider_id )->first();
                  $user = User::where('id',$provider_user->user_id )->first();
                  $user_id = $user->id;
                  $user_name = $user->name;
                  $user_image = URL::to('/').'/profile/'.$user->image;
                   $image = URL::to('/').'/attachments/'.$attachment->filenames;
                   $provider_type = '3';
                }

                $data[$key]['id'] = $value->id;
                $data[$key]['user_id'] = $user_id ;
                $data[$key]['user_name'] = $user_name;
                $data[$key]['user_image'] = $user_image;
                $data[$key]['date'] = $value->check_in;
                $data[$key]['title'] = $provider_user->title;
                $data[$key]['image'] = $image;
               
              }
            }
               
 
            }

           

             return response()->json([
                       'status' => 1,
                       "bookings" => $data,
                   ], 200);

              
        }
        catch(Exception $e){
            $result = [
              'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $result['status'] = 0;
             return $result;
        }
   }

   public function booking_requestlist(Request $request){


      $user_id = Auth::id(); 
       
        try{  

           $rules = [                
              'type' => 'required',
            ];

            $validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {
                    return response()->json([
                       "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422);               
                }

            $data = array();

            if($request->get('type') == '1'){


            if($request->get('provider_type') == '1'){

              $provider = PeopleProvider::where('user_id',$user_id)->where('status','1')->get();

              
              foreach ($provider as $key1 => $value1) {
                
                $bookings = Booking::where('people_provider_id', $value1->id)->where('status','1')->get();

                  foreach ($bookings as $key => $value) {
                      $provider_user = PeopleProvider::where('id',$value->people_provider_id)->where('status','1')->first();
                      $provider_category = People::where('id',$provider_user->cat_id)->first();
                      $attachment = User::where('id',$provider_user->user_id )->first();

                      $data[$key]['booking_id'] = $value->id;
                      $data[$key]['provider_id'] = $provider_user->id;
                      $data[$key]['title'] = $provider_user->title;
                      $data[$key]['average_ratings'] = $provider_user->ratings;
                      $data[$key]['category'] = $provider_category->name;
                      $data[$key]['date'] = $value->check_in;
                      $data[$key]['image'] = URL::to('/').'/profile/'.$attachment->image;
                   }

              
              }           

            }elseif($request->get('provider_type') == '2'){

              $provider = ThingProvider::where('user_id',$user_id)->where('status','1')->get();

              
              foreach ($provider as $key1 => $value1) {
                
                $bookings = Booking::where('things_provider_id', $value1->id)->where('status','1')->get();

                  foreach ($bookings as $key => $value) {
                      $provider_user = ThingProvider::where('id',$value->things_provider_id)->where('status','1')->first();
                       $provider_category = Thing::where('id',$provider_user->cat_id)->first();
                      $attachment = Attachment::where('things_provider_id',$value->things_provider_id )->first();

                      $data[$key]['booking_id'] = $value->id;
                      $data[$key]['provider_id'] = $provider_user->id;
                      $data[$key]['title'] = $provider_user->title;
                      $data[$key]['average_ratings'] = $provider_user->ratings;
                      $data[$key]['category'] = $provider_category->name;
                      $data[$key]['date'] = $value->check_in;
                      $data[$key]['image'] = URL::to('/').'/profile/'.$attachment->filenames;
                   }      
              }
             

            }elseif($request->get('provider_type') == '3'){

               $provider = PlaceProvider::where('user_id',$user_id)->where('status','1')->get();

              
              foreach ($provider as $key1 => $value1) {
                
                $bookings = Booking::where('places_provider_id', $value1->id)->where('status','1')->get();
                  

                  foreach ($bookings as $key => $value) {
                      $provider_user = PlaceProvider::where('id',$value->places_provider_id)->where('status','1')->first();
                      $provider_category = Place::where('id',$provider_user->cat_id)->first();
                      $attachment = Attachment::where('places_provider_id',$value->things_provider_id )->first();

                      $data[$key]['booking_id'] = $value->id;
                      $data[$key]['provider_id'] = $provider_user->id;
                      $data[$key]['title'] = $provider_user->title;
                       $data[$key]['category'] = $provider_category->name;
                      $data[$key]['average_ratings'] = $provider_user->ratings;
                      $data[$key]['date'] = $value->check_in;
                      $data[$key]['image'] = URL::to('/').'/profile/'.$attachment->filenames;
                   }      
              }

            }else{

              $bookings = Booking::where('status','1')->where('provider_user_id',$user_id)->get();

              foreach ($bookings as $key => $value) {
               
                if($value->people_provider_id != ""){
 
                  $provider_user = PeopleProvider::where('id',$value->people_provider_id)->first();
                  
                    $provider_category = People::where('id',$provider_user->cat_id)->first();
                     $attachment = User::where('id',$value->user_id )->first();
                     $image = URL::to('/').'/profile/'.$attachment->image;
                     $booking_id = $value->id;
                     $date = $value->check_in;
                     $provider_id = $provider_user->id;
                     $average_ratings = $provider_user->ratings;
                            $provider_category = $provider_category->name;
                     $title = $provider_user->title;
                     $provider_type = '1';

                }elseif($value->things_provider_id != ""){

                  $provider_user = ThingProvider::where('id',$value->things_provider_id )->first(); 
                  
                    $provider_category = Thing::where('id',$provider_user->cat_id)->first();
                  $attachment = Attachment::where('things_provider_id',$value->things_provider_id )->first();
                  $image = URL::to('/').'/attachments/'.$attachment->filenames;
                    $booking_id = $value->id;
                     $date = $value->check_in;
                     $provider_id = $provider_user->id;
                     $average_ratings = $provider_user->ratings;
                            $provider_category = $provider_category->name;
                     $title = $provider_user->title;
                  $provider_type = '2';
                    
                  

                }elseif($value->places_provider_id != ""){

                  $provider_user = PlaceProvider::where('id',$value->places_provider_id )->first();

                      $provider_category = Place::where('id',$provider_user->cat_id)->first();
                    $attachment = Attachment::where('places_provider_id',$value->places_provider_id )->first();
                   $image = URL::to('/').'/attachments/'.$attachment->filenames;
                     $booking_id = $value->id;
                     $date = $value->check_in;
                     $provider_id = $provider_user->id;
                      $average_ratings = $provider_user->ratings;
                      $provider_category = $provider_category->name;
                     $title = $provider_user->title;
                   $provider_type = '3';
                   
                 
                }

                 $data[$key]['booking_id'] = $booking_id;
                $data[$key]['provider_id'] = $provider_id;
                $data[$key]['date'] = $date;
                $data[$key]['category'] = $provider_category;
                $data[$key]['average_ratings'] = $average_ratings;
                $data[$key]['title'] = $title;
                $data[$key]['image'] = $image;
              
               
              }

            
              }              
             

            }elseif($request->get('type') == '2'){

            if($request->get('provider_type') == '1'){


              $provider = PeopleProvider::where('user_id',$user_id)->where('status','1')->get();

              
              foreach ($provider as $key1 => $value1) {
                
                $bookings = Booking::where('people_provider_id', $value1->id)->where('status','2')->get();

                  foreach ($bookings as $key => $value) {
                      $provider_user = PeopleProvider::where('id',$value->people_provider_id)->where('status','1')->first();
                      $provider_category = People::where('id',$provider_user->cat_id)->first();
                      $attachment = User::where('id',$provider_user->user_id )->first();

                      $data[$key]['booking_id'] = $value->id;
                      $data[$key]['provider_id'] = $provider_user->id;
                      $data[$key]['title'] = $provider_user->title;
                      $data[$key]['average_ratings'] = $provider_user->ratings;
                        $data[$key]['category'] = $provider_category->name;
                      $data[$key]['date'] = $value->check_in;
                      $data[$key]['image'] = URL::to('/').'/profile/'.$attachment->image;
                   }

              
              }     

            }elseif($request->get('provider_type') == '2'){

               $provider = ThingProvider::where('user_id',$user_id)->where('status','1')->get();

              
              foreach ($provider as $key1 => $value1) {
                
                $bookings = Booking::where('things_provider_id', $value1->id)->where('status','2')->get();
                foreach ($bookings as $key => $value) {
                  
                  $provider_user = ThingProvider::where('id',$value->things_provider_id )->first(); 
                  $provider_category = Thing::where('id',$provider_user->cat_id)->first();
                  $attachment = Attachment::where('things_provider_id',$value->things_provider_id )->first();

                $data[$key]['booking_id'] = $value->id;
                $data[$key]['provider_id'] = $provider_user->id;
                $data[$key]['title'] = $provider_user->title;
                $data[$key]['average_ratings'] = $provider_user->ratings;
                  $data[$key]['category'] = $provider_category->name;
                $data[$key]['date'] = $value->check_in;
                $data[$key]['image'] = URL::to('/').'/profile/'.$attachment->filenames;
               
              }
            }

            }elseif($request->get('provider_type') == '3'){
              
              $provider = PlaceProvider::where('user_id',$user_id)->where('status','1')->get();

              
              foreach ($provider as $key1 => $value1) {
                
                $bookings = Booking::where('places_provider_id', $value1->id)->where('status','2')->get();

                foreach ($bookings as $key => $value) {
                      $provider_user = PlaceProvider::where('id',$value->places_provider_id)->where('status','1')->first();
                      $provider_category = Place::where('id',$provider_user->cat_id)->first();
                      $attachment = Attachment::where('places_provider_id',$value->things_provider_id )->first();

                      $data[$key]['booking_id'] = $value->id;
                      $data[$key]['provider_id'] = $provider_user->id;
                      $data[$key]['title'] = $provider_user->title;
                      $data[$key]['average_ratings'] = $provider_user->ratings;
                        $data[$key]['category'] = $provider_category->name;
                      $data[$key]['date'] = $value->check_in;
                      $data[$key]['image'] = URL::to('/').'/profile/'.$attachment->filenames;
                   }        
               
              }

            }else{
             $bookings = Booking::where('status','2')->where('provider_user_id',$user_id)->get();

              foreach ($bookings as $key => $value) {
               
               if($value->people_provider_id != ""){

                  $provider_user = PeopleProvider::where('id',$value->people_provider_id)->first();
                    $provider_category = People::where('id',$provider_user->cat_id)->first();
                     $attachment = User::where('id',$value->user_id )->first();
                     $image = URL::to('/').'/profile/'.$attachment->image;
                     $booking_id = $value->id;
                     $date = $value->check_in;
                     $provider_id = $provider_user->id;
                     $provider_category = $provider_category->name;
                     $average_ratings = $provider_user->ratings;
                     $title = $provider_user->title;
                     $provider_type = '1';
                  
                   

                }elseif($value->things_provider_id != ""){

                  $provider_user = ThingProvider::where('id',$value->things_provider_id )->first(); 
                 
                    $provider_category = Thing::where('id',$provider_user->cat_id)->first();
                   $attachment = Attachment::where('things_provider_id',$value->things_provider_id )->first();
                  $image = URL::to('/').'/attachments/'.$attachment->filenames;
                    $booking_id = $value->id;
                     $date = $value->check_in;
                     $provider_id = $provider_user->id;
                     $provider_category = $provider_category->name;
                     $average_ratings = $provider_user->ratings;
                     $title = $provider_user->title;
                  $provider_type = '2';
                  

                }elseif($value->places_provider_id != ""){

                  $provider_user = PlaceProvider::where('id',$value->places_provider_id )->first();
                  
                    $provider_category = Place::where('id',$provider_user->cat_id)->first();
                    $attachment = Attachment::where('places_provider_id',$value->places_provider_id )->first();
                   $image = URL::to('/').'/attachments/'.$attachment->filenames;
                     $booking_id = $value->id;
                     $date = $value->check_in;
                     $provider_id = $provider_user->id;
                     $provider_category = $provider_category->name;
                      $average_ratings = $provider_user->ratings;
                     $title = $provider_user->title;
                   $provider_type = '3';
                 
                }
              
                $data[$key]['booking_id'] = $booking_id;
                $data[$key]['provider_id'] = $provider_id;
                $data[$key]['date'] = $date;
                $data[$key]['category'] = $provider_category;
                $data[$key]['average_ratings'] = $average_ratings;
                $data[$key]['title'] = $title;
                $data[$key]['image'] = $image;
               
              }
            }

            }elseif($request->get('type') == '3'){

            if($request->get('provider_type') == '1'){


               $provider = PeopleProvider::where('user_id',$user_id)->where('status','1')->get();

              
              foreach ($provider as $key1 => $value1) {
                
                $bookings = Booking::where('people_provider_id', $value1->id)->where('status','3')->get();

                  foreach ($bookings as $key => $value) {
                      $provider_user = PeopleProvider::where('id',$value->people_provider_id)->where('status','1')->first();
                       $provider_category = People::where('id',$provider_user->cat_id)->first();
                      $attachment = User::where('id',$provider_user->user_id )->first();

                      $data[$key]['booking_id'] = $value->id;
                      $data[$key]['provider_id'] = $provider_user->id;
                      $data[$key]['title'] = $provider_user->title;
                      $data[$key]['average_ratings'] = $provider_user->ratings;
                          $data[$key]['category'] = $provider_category->name;
                      $data[$key]['date'] = $value->check_in;
                      $data[$key]['image'] = URL::to('/').'/profile/'.$attachment->image;
                   }

              
              }  

            }elseif($request->get('provider_type') == '2'){
             
             $provider = ThingProvider::where('user_id',$user_id)->where('status','1')->get();

              
              foreach ($provider as $key1 => $value1) {
                
                $bookings = Booking::where('things_provider_id', $value1->id)->where('status','3')->get();
                foreach ($bookings as $key => $value) {
                  
                  $provider_user = ThingProvider::where('id',$value->things_provider_id )->first(); 
                   $provider_category = Thing::where('id',$provider_user->cat_id)->first();
                  $attachment = Attachment::where('things_provider_id',$value->things_provider_id )->first();

                $data[$key]['booking_id'] = $value->id;
                $data[$key]['provider_id'] = $provider_user->id;
                $data[$key]['title'] = $provider_user->title;
                $data[$key]['average_ratings'] = $provider_user->ratings;
                    $data[$key]['category'] = $provider_category->name;
                $data[$key]['date'] = $value->check_in;
                $data[$key]['image'] = URL::to('/').'/profile/'.$attachment->filenames;
               
              }
            }

            }elseif($request->get('provider_type') == '3'){
           
                $provider = PlaceProvider::where('user_id',$user_id)->where('status','1')->get();

              
              foreach ($provider as $key1 => $value1) {
                
                $bookings = Booking::where('places_provider_id', $value1->id)->where('status','3')->get();

                foreach ($bookings as $key => $value) {
                      $provider_user = PlaceProvider::where('id',$value->places_provider_id)->where('status','1')->first();
                       $provider_category = Place::where('id',$provider_user->cat_id)->first();
                      $attachment = Attachment::where('places_provider_id',$value->things_provider_id )->first();

                      $data[$key]['booking_id'] = $value->id;
                      $data[$key]['provider_id'] = $provider_user->id;
                      $data[$key]['title'] = $provider_user->title;
                      $data[$key]['average_ratings'] = $provider_user->ratings;
                          $data[$key]['category'] = $provider_category->name;
                      $data[$key]['date'] = $value->check_in;
                      $data[$key]['image'] = URL::to('/').'/profile/'.$attachment->filenames;
                   }        
               
              }


            }else{
             $bookings = Booking::where('status','3')->where('provider_user_id',$user_id)->get();
              foreach ($bookings as $key => $value) {  
                  if($value->people_provider_id != ""){

                  $provider_user = PeopleProvider::where('id',$value->people_provider_id)->first();
                   $provider_category = People::where('id',$provider_user->cat_id)->first();

                     $attachment = User::where('id',$value->user_id )->first();
                     $image = URL::to('/').'/profile/'.$attachment->image;
                     $booking_id = $value->id;
                     $date = $value->check_in;
                     $provider_id = $provider_user->id;
                     $average_ratings = $provider_user->ratings;
                     $title = $provider_user->title;
                     $provider_category = $provider_category->name;
                     $provider_type = '1';
                     
                 

                }elseif($value->things_provider_id != ""){

                  $provider_user = ThingProvider::where('id',$value->things_provider_id )->first(); 
                   $provider_category = Thing::where('id',$provider_user->cat_id)->first();
                  $attachment = Attachment::where('things_provider_id',$value->things_provider_id )->first();
                  $image = URL::to('/').'/attachments/'.$attachment->filenames;
                     $booking_id = $value->id;
                     $date = $value->check_in;
                     $provider_id = $provider_user->id;
                     $average_ratings = $provider_user->ratings;
                     $title = $provider_user->title;
                     $provider_category = $provider_category->name;
                  $provider_type = '2';
            
                  
                  

                }elseif($value->places_provider_id != ""){

                  $provider_user = PlaceProvider::where('id',$value->places_provider_id )->first();
                    
                     $provider_category = Place::where('id',$provider_user->cat_id)->first();

                    $attachment = Attachment::where('places_provider_id',$value->places_provider_id )->first();
                   $image = URL::to('/').'/attachments/'.$attachment->filenames;
                     $booking_id = $value->id;
                     $date = $value->check_in;
                     $provider_id = $provider_user->id;
                      $average_ratings = $provider_user->ratings;
                     $title = $provider_user->title;
                     $provider_category = $provider_category->name;
                   $provider_type = '3';

                 
              
                }

                       $data[$key]['booking_id'] = $booking_id;
                  $data[$key]['provider_id'] = $provider_id;
                  $data[$key]['date'] = $date;
                  $data[$key]['average_ratings'] = $average_ratings;
                   $data[$key]['category'] = $provider_category;
                  $data[$key]['title'] = $title;
                  $data[$key]['image'] = $image;
               
               
              }
            }
               
 
            }

           

             return response()->json([
                       'status' => 1,
                       "bookings" => $data,
                   ], 200);

              
        }
        catch(Exception $e){
            $result = [
              'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $result['status'] = 0;
             return $result;
        }
   }

   public function my_progress(Request $request){

      try{

        $user_id = Auth::id();

          $reviews = Review::where('provider_user_id',$user_id)->where('reviews','<>','')->count();
          $ratings_total = Review::where('provider_user_id',$user_id)->get()->sum('ratings');
          $ratings_count = Review::where('provider_user_id',$user_id)->count();
         $total_bookings =  Booking::where('provider_user_id',$user_id)->count();

           $overall_earnings =  WalletTransaction::where('provider_user_id',$user_id)->where('transaction_amount_status','0')->get()->sum("transaction_amount");
           if($ratings_total){
            $aveage_rating = $ratings_total/$ratings_count;
          }else{
            $aveage_rating = "";
          }
          

           

           return response()->json([
                  "status" => 1,
                  "message" => "Progress!!!",
                  'overall_earnings' =>   $overall_earnings,
                  'review_count'=> $reviews,
                  'total_bookings' => $total_bookings,
                  'overall_ratings' => number_format((float)$aveage_rating, 2, '.', ''),
                  
                   ], 200);

        }
        catch(Exception $e){
            $result = [
              'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $result['status'] = 0;
             return $result;
        }

   }

   public function bookingListDetail(Request $request){
    $user_id = Auth::id();
    try{

         $rules = [                
              'booking_type' => 'required',
              'booking_id' => 'required',
            ];

            $validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {
                    return response()->json([
                       "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422);               
                }

        if($request->get('booking_type') == '1'){
            
          $bookings = Booking::where('id', $request->get('booking_id'))->where('status', '1')->first();

           $coupon = Coupon::where('id',$bookings->coupon_id)->first();
          if($coupon){
            $coupon_data =  $coupon->discount;

          }else{
            $coupon_data =  "";
          }
          $reviews = Review::where('booking_id', $request->get('booking_id'))->first();
          if($reviews){
            $ratings = $reviews->ratings;
            $reviews = $reviews->reviews;
          }else{
            $ratings = '';
             $reviews = '';
          }

          if($bookings){
            if($bookings->people_provider_id == '' &&  $bookings->things_provider_id == ''){
            $provider_user = PlaceProvider::where('id',$bookings->places_provider_id )->first();
            $reviews_count = Review::where('places_provider_id', $provider_user->id)->count();
            $attachment = Attachment::where('places_provider_id',$bookings->places_provider_id )->first();
            $image = URL::to('/').'/attachments/'.$attachment->filenames;
            $customer = User::where('id',$bookings->user_id)->first();
            $host = User::where('id',$bookings->provider_user_id)->first();

            $data['status'] = 1;
            $data['data']['booking_id'] = $bookings->id;
            $data['data']['check_in'] = $bookings->check_in;
            $data['data']['check_out'] = $bookings->check_out;
            $data['data']['time_in'] = $bookings->time_in;
            $data['data']['time_out'] = $bookings->time_out;
            $data['data']['total_amount'] = $bookings->total_amount;
            $data['data']['title'] = $provider_user->title;
            $data['data']['address'] = $provider_user->address;
            $data['data']['latitude'] = $provider_user->latitude;
            $data['data']['longitude'] = $provider_user->longitude;
            $data['data']['guests'] = $provider_user->total_guests;
            $data['data']['average_rating'] = $provider_user->ratings;
            $data['data']['ratings'] = $ratings;
            $data['data']['reviews'] = $reviews;
            $data['data']['reviews_count'] = $reviews_count;
            $data['data']['coupon'] = $coupon_data;
            $data['data']['price_per_night'] = $provider_user->price_per_night;
            $data['data']['image'] = $image;
            $data['data']['customer_id'] = $bookings->user_id; 
            $data['data']['customer_name'] = $customer->name;
            $data['data']['customer_image'] = URL::to('/').'/profile/'.$customer->image;
            $data['data']['host_id'] = $bookings->provider_user_id;
            $data['data']['host_name'] = $host->name;
            $data['data']['host_image'] = URL::to('/').'/profile/'.$host->image;
        
            $data['provider_type'] = '3';

                  // $provider_type = '3';

          }elseif($bookings->people_provider_id == '' &&  $bookings->places_provider_id == ''){

              $provider_user = ThingProvider::where('id',$bookings->things_provider_id )->first();
              $reviews_count = Review::where('things_provider_id', $provider_user->id)->count();
              $attachment = Attachment::where('things_provider_id',$bookings->things_provider_id )->first();
              $image = URL::to('/').'/attachments/'.$attachment->filenames;
               $customer = User::where('id',$bookings->user_id)->first();
            $host = User::where('id',$bookings->provider_user_id)->first();
               $data['status'] = 1;
              $data['data']['booking_id'] = $bookings->id;
              $data['data']['check_in'] = $bookings->check_in;
              $data['data']['check_out'] = $bookings->check_out;
              $data['data']['time_in'] = $bookings->time_in;
              $data['data']['time_out'] = $bookings->time_out;
              $data['data']['total_amount'] = $bookings->total_amount;
              $data['data']['title'] = $provider_user->title;
              $data['data']['address'] = $provider_user->address;
              $data['data']['latitude'] = $provider_user->latitude;
            $data['data']['longitude'] = $provider_user->longitude;
            $data['data']['average_rating'] = $provider_user->ratings;
            $data['data']['ratings'] = $ratings;
            $data['data']['reviews'] = $reviews;
             $data['data']['reviews_count'] = $reviews_count;
             $data['data']['coupon'] = $coupon_data;
              $data['data']['price_per_night'] = $provider_user->price_per_night;
              $data['data']['image'] = $image;
               $data['data']['customer_id'] = $bookings->user_id; 
            $data['data']['customer_name'] = $customer->name;
            $data['data']['customer_image'] = URL::to('/').'/profile/'.$customer->image;
            $data['data']['host_id'] = $bookings->provider_user_id;
            $data['data']['host_name'] = $host->name;
            $data['data']['host_image'] = URL::to('/').'/profile/'.$host->image;
              $data['provider_type'] = '2';

          }elseif($bookings->places_provider_id == '' &&  $bookings->things_provider_id == ''){

                $provider_user = PeopleProvider::where('id',$bookings->people_provider_id )->first();
                 $reviews_count = Review::where('people_provider_id', $provider_user->id)->count();
              $attachment = User::where('id',$provider_user->user_id )->first();
              $image = URL::to('/').'/profile/'.$attachment->image;
              $customer = User::where('id',$bookings->user_id)->first();
            $host = User::where('id',$bookings->provider_user_id)->first();

               $data['status'] = 1;
              $data['data']['booking_id'] = $bookings->id;
              $data['data']['check_in'] = $bookings->check_in;
              $data['data']['check_out'] = $bookings->check_out;
              $data['data']['time_in'] = $bookings->time_in;
              $data['data']['time_out'] = $bookings->time_out;
              $data['data']['total_amount'] = $bookings->total_amount;
              $data['data']['title'] = $provider_user->title;
              $data['data']['address'] = $provider_user->address;
              $data['data']['latitude'] = $provider_user->latitude;
              $data['data']['longitude'] = $provider_user->longitude;
              $data['data']['average_rating'] = $provider_user->ratings;
              $data['data']['ratings'] = $ratings;
              $data['data']['reviews'] = $reviews;
              $data['data']['reviews_count'] = $reviews_count;
              $data['data']['coupon'] = $coupon_data;
              $data['data']['reviews'] = $reviews;
              $data['data']['price_per_night'] = $provider_user->price_per_night;
              $data['data']['image'] = $image;
                    $data['data']['customer_id'] = $bookings->user_id; 
            $data['data']['customer_name'] = $customer->name;
            $data['data']['customer_image'] = URL::to('/').'/profile/'.$customer->image;
            $data['data']['host_id'] = $bookings->provider_user_id;
            $data['data']['host_name'] = $host->name;
            $data['data']['host_image'] = URL::to('/').'/profile/'.$host->image;
              $data['provider_type'] = '1';

          }

          }else{
             $data['status'] = 0;
             $data['message'] = "Something went wrong!!";

          }

          

         


        }elseif($request->get('booking_type') == '2'){

          $bookings = Booking::where('id', $request->get('booking_id'))->where('status', '2')->first();

          if($user_id == $bookings->cancelled_by){
            $bookings_cancelled_me = true;
          }else{
            $bookings_cancelled_me = false;
          }
          $bookings_cancelled = User::where('id', $bookings->cancelled_by)->first();
            $coupon = Coupon::where('id',$bookings->coupon_id)->first();
          if($coupon){
            $coupon_data =  $coupon->discount;

          }else{
            $coupon_data =  "";
          }
          $reviews = Review::where('booking_id', $request->get('booking_id'))->first();
          if($reviews){
            $ratings = $reviews->ratings;
            $reviews = $reviews->reviews;
          }else{
            $ratings = '';
            $reviews = '';
          }
          if($bookings){


          if($bookings->people_provider_id == '' &&  $bookings->things_provider_id == ''){
            $provider_user = PlaceProvider::where('id',$bookings->places_provider_id )->first();
             $reviews_count = Review::where('places_provider_id', $provider_user->id)->count();
            $attachment = Attachment::where('places_provider_id',$bookings->places_provider_id )->first();
            $image = URL::to('/').'/attachments/'.$attachment->filenames;
             $customer = User::where('id',$bookings->user_id)->first();
            $host = User::where('id',$bookings->provider_user_id)->first();

             $data['status'] = 1;
            $data['data']['booking_id'] = $bookings->id;
            $data['data']['check_in'] = $bookings->check_in;
            $data['data']['check_out'] = $bookings->check_out;
            $data['data']['time_in'] = $bookings->time_in;
            $data['data']['time_out'] = $bookings->time_out;
            $data['data']['total_amount'] = $bookings->total_amount;
            $data['data']['cancelled_by'] = $bookings_cancelled->name;
            $data['data']['cancelled_by_id'] = $bookings->cancelled_by;
            $data['data']['bookings_cancelled_by_me'] = $bookings_cancelled_me;
            $data['data']['title'] = $provider_user->title;
            $data['data']['address'] = $provider_user->address;
            $data['data']['latitude'] = $provider_user->latitude;
            $data['data']['longitude'] = $provider_user->longitude;
            $data['data']['guests'] = $provider_user->total_guests;
            $data['data']['average_rating'] = $provider_user->ratings;
            $data['data']['ratings'] =  $ratings;
            $data['data']['reviews'] = $reviews;
            $data['data']['reviews_count'] = $reviews_count;
            $data['data']['coupon'] = $coupon_data;
            $data['data']['price_per_night'] = $provider_user->price_per_night;
            $data['data']['image'] = $image;
            $data['data']['customer_id'] = $bookings->user_id; 
            $data['data']['customer_name'] = $customer->name;
            $data['data']['customer_image'] = URL::to('/').'/profile/'.$customer->image;
            $data['data']['host_id'] = $bookings->provider_user_id;
            $data['data']['host_name'] = $host->name;
            $data['data']['host_image'] = URL::to('/').'/profile/'.$host->image;
            $data['provider_type'] = '3';
                  // $provider_type = '3';

          }elseif($bookings->people_provider_id == '' &&  $bookings->places_provider_id == ''){

              $provider_user = ThingProvider::where('id',$bookings->things_provider_id )->first();
              $reviews_count = Review::where('things_provider_id', $provider_user->id)->count();
              $attachment = Attachment::where('things_provider_id',$bookings->things_provider_id )->first();
              $image = URL::to('/').'/attachments/'.$attachment->filenames;
               $customer = User::where('id',$bookings->user_id)->first();
            $host = User::where('id',$bookings->provider_user_id)->first();

               $data['status'] = 1;
              $data['data']['booking_id'] = $bookings->id;
              $data['data']['check_in'] = $bookings->check_in;
              $data['data']['check_out'] = $bookings->check_out;
              $data['data']['time_in'] = $bookings->time_in;
              $data['data']['time_out'] = $bookings->time_out;
              $data['data']['total_amount'] = $bookings->total_amount;
              $data['data']['cancelled_by'] = $bookings_cancelled->name;
              $data['data']['cancelled_by_id'] = $bookings->cancelled_by;
               $data['data']['bookings_cancelled_by_me'] = $bookings_cancelled_me;
              $data['data']['title'] = $provider_user->title;
              $data['data']['address'] = $provider_user->address;
              $data['data']['latitude'] = $provider_user->latitude;
              $data['data']['longitude'] = $provider_user->longitude;
              $data['data']['average_rating'] = $provider_user->ratings;
              $data['data']['ratings'] = $ratings;
              $data['data']['reviews'] = $reviews;
              $data['data']['reviews_count'] = $reviews_count;
              $data['data']['coupon'] = $coupon_data;
              $data['data']['price_per_night'] = $provider_user->price_per_night;
              $data['data']['image'] = $image;
                $data['data']['customer_id'] = $bookings->user_id; 
            $data['data']['customer_name'] = $customer->name;
            $data['data']['customer_image'] = URL::to('/').'/profile/'.$customer->image;
            $data['data']['host_id'] = $bookings->provider_user_id;
            $data['data']['host_name'] = $host->name;
            $data['data']['host_image'] = URL::to('/').'/profile/'.$host->image;
              $data['provider_type'] = '2';

          }elseif($bookings->places_provider_id == '' &&  $bookings->things_provider_id == ''){

                $provider_user = PeopleProvider::where('id',$bookings->people_provider_id )->first();
                 $reviews_count = Review::where('people_provider_id', $provider_user->id)->count();
              $attachment = User::where('id',$provider_user->user_id )->first();
              $image = URL::to('/').'/profile/'.$attachment->image;
               $customer = User::where('id',$bookings->user_id)->first();
            $host = User::where('id',$bookings->provider_user_id)->first();

               $data['status'] = 1;
              $data['data']['booking_id'] = $bookings->id;
              $data['data']['check_in'] = $bookings->check_in;
              $data['data']['check_out'] = $bookings->check_out;
              $data['data']['time_in'] = $bookings->time_in;
              $data['data']['time_out'] = $bookings->time_out;
              $data['data']['total_amount'] = $bookings->total_amount;
              $data['data']['cancelled_by'] = $bookings_cancelled->name;
              $data['data']['cancelled_by_id'] = $bookings->cancelled_by;
               $data['data']['bookings_cancelled_by_me'] = $bookings_cancelled_me;
              $data['data']['title'] = $provider_user->title;
              $data['data']['address'] = $provider_user->address;
              $data['data']['latitude'] = $provider_user->latitude;
              $data['data']['longitude'] = $provider_user->longitude;
              $data['data']['average_rating'] = $provider_user->ratings;
              $data['data']['ratings'] = $ratings;
              $data['data']['reviews'] = $reviews;
               $data['data']['reviews_count'] = $reviews_count;
               $data['data']['coupon'] = $coupon_data;
              $data['data']['price_per_night'] = $provider_user->price_per_night;
              $data['data']['image'] = $image;
                $data['data']['customer_id'] = $bookings->user_id; 
            $data['data']['customer_name'] = $customer->name;
            $data['data']['customer_image'] = URL::to('/').'/profile/'.$customer->image;
            $data['data']['host_id'] = $bookings->provider_user_id;
            $data['data']['host_name'] = $host->name;
            $data['data']['host_image'] = URL::to('/').'/profile/'.$host->image;
              $data['provider_type'] = '1';

          }
        }else{
           $data['status'] = 0;
             $data['message'] = "Something went wrong!!";

        }

          
        }elseif($request->get('booking_type') == '3'){

          $bookings = Booking::where('id', $request->get('booking_id'))->where('status', '3')->first();
          $coupon = Coupon::where('id',$bookings->coupon_id)->first();
          if($coupon){
            $coupon_data =  $coupon->discount;

          }else{
            $coupon_data =  "";
          }

           $reviews = Review::where('booking_id', $request->get('booking_id'))->first();
          if($reviews){
            $ratings = $reviews->ratings;
            $reviews = $reviews->reviews;
          }else{
            $ratings = '';
            $reviews = '';
          }
          if($bookings){
          if($bookings->people_provider_id == '' &&  $bookings->things_provider_id == ''){
            $provider_user = PlaceProvider::where('id',$bookings->places_provider_id )->first();
             $reviews_count = Review::where('places_provider_id', $provider_user->id)->count();
            $attachment = Attachment::where('places_provider_id',$bookings->places_provider_id )->first();
            $image = URL::to('/').'/attachments/'.$attachment->filenames;
             $customer = User::where('id',$bookings->user_id)->first();
            $host = User::where('id',$bookings->provider_user_id)->first();

             $data['status'] = 1;
            $data['data']['booking_id'] = $bookings->id;
            $data['data']['check_in'] = $bookings->check_in;
            $data['data']['check_out'] = $bookings->check_out;
            $data['data']['time_in'] = $bookings->time_in;
            $data['data']['time_out'] = $bookings->time_out;
            $data['data']['total_amount'] = $bookings->total_amount;
            $data['data']['title'] = $provider_user->title;
            $data['data']['address'] = $provider_user->address;
            $data['data']['latitude'] = $provider_user->latitude;
            $data['data']['longitude'] = $provider_user->longitude;
            $data['data']['guests'] = $provider_user->total_guests;
            $data['data']['average_rating'] = $provider_user->ratings;
            $data['data']['ratings'] = $ratings;
            $data['data']['reviews'] = $reviews;
            $data['data']['coupon'] = $coupon_data;
             $data['data']['reviews_count'] = $reviews_count;
            $data['data']['price_per_night'] = $provider_user->price_per_night;
            $data['data']['image'] = $image;
              $data['data']['customer_id'] = $bookings->user_id; 
            $data['data']['customer_name'] = $customer->name;
            $data['data']['customer_image'] = URL::to('/').'/profile/'.$customer->image;
            $data['data']['host_id'] = $bookings->provider_user_id;
            $data['data']['host_name'] = $host->name;
            $data['data']['host_image'] = URL::to('/').'/profile/'.$host->image;
            $data['provider_type'] = '3';
                  // $provider_type = '3';

          }elseif($bookings->people_provider_id == '' &&  $bookings->places_provider_id == ''){

              $provider_user = ThingProvider::where('id',$bookings->things_provider_id )->first();
               $reviews_count = Review::where('things_provider_id', $provider_user->id)->count();
              $attachment = Attachment::where('things_provider_id',$bookings->things_provider_id )->first();
              $image = URL::to('/').'/attachments/'.$attachment->filenames;
               $customer = User::where('id',$bookings->user_id)->first();
            $host = User::where('id',$bookings->provider_user_id)->first();

               $data['status'] = 1;
              $data['data']['booking_id'] = $bookings->id;
              $data['data']['check_in'] = $bookings->check_in;
              $data['data']['check_out'] = $bookings->check_out;
              $data['data']['time_in'] = $bookings->time_in;
              $data['data']['time_out'] = $bookings->time_out;
              $data['data']['total_amount'] = $bookings->total_amount;
              $data['data']['title'] = $provider_user->title;
              $data['data']['address'] = $provider_user->address;
              $data['data']['latitude'] = $provider_user->latitude;
              $data['data']['longitude'] = $provider_user->longitude;
              $data['data']['average_rating'] = $provider_user->ratings;
              $data['data']['ratings'] = $ratings;
              $data['data']['reviews'] = $reviews;
               $data['data']['reviews_count'] = $reviews_count;
               $data['data']['coupon'] = $coupon_data;
              $data['data']['price_per_night'] = $provider_user->price_per_night;
              $data['data']['image'] = $image;
                $data['data']['customer_id'] = $bookings->user_id; 
            $data['data']['customer_name'] = $customer->name;
            $data['data']['customer_image'] = URL::to('/').'/profile/'.$customer->image;
            $data['data']['host_id'] = $bookings->provider_user_id;
            $data['data']['host_name'] = $host->name;
            $data['data']['host_image'] = URL::to('/').'/profile/'.$host->image;
              $data['provider_type'] = '2';

          }elseif($bookings->places_provider_id == '' &&  $bookings->things_provider_id == ''){

                $provider_user = PeopleProvider::where('id',$bookings->people_provider_id )->first();
                 $reviews_count = Review::where('people_provider_id', $provider_user->id)->count();
              $attachment = User::where('id',$provider_user->user_id )->first();
              $image = URL::to('/').'/profile/'.$attachment->image;
               $customer = User::where('id',$bookings->user_id)->first();
            $host = User::where('id',$bookings->provider_user_id)->first();

               $data['status'] = 1;
              $data['data']['booking_id'] = $bookings->id;
              $data['data']['check_in'] = $bookings->check_in;
              $data['data']['check_out'] = $bookings->check_out;
              $data['data']['time_in'] = $bookings->time_in;
              $data['data']['time_out'] = $bookings->time_out;
              $data['data']['total_amount'] = $bookings->total_amount;
              $data['data']['title'] = $provider_user->title;
              $data['data']['address'] = $provider_user->address;
              $data['data']['latitude'] = $provider_user->latitude;
              $data['data']['longitude'] = $provider_user->longitude;
              $data['data']['price_per_night'] = $provider_user->price_per_night;
              $data['data']['average_rating'] = $provider_user->ratings;
              $data['data']['ratings'] = $ratings;
              $data['data']['reviews'] = $reviews;
              $data['data']['reviews_count'] = $reviews_count;
              $data['data']['coupon'] = $coupon_data;
              $data['data']['image'] = $image;
                $data['data']['customer_id'] = $bookings->user_id; 
            $data['data']['customer_name'] = $customer->name;
            $data['data']['customer_image'] = URL::to('/').'/profile/'.$customer->image;
            $data['data']['host_id'] = $bookings->provider_user_id;
            $data['data']['host_name'] = $host->name;
            $data['data']['host_image'] = URL::to('/').'/profile/'.$host->image;
              $data['provider_type'] = '1';

          }

           }else{
           $data['status'] = 0;
             $data['message'] = "Something went wrong!!";

        }


          
        }
        return $data;
      }
        catch(Exception $e){
            $result = [
              'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $result['status'] = 0;
             return $result;
        }
    }

    public function CancelBooking(Request $request){
      try{

        $user = Auth::user();
           $rules = [                
              'booking_id' => 'required',
            ];

            $validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {
                    return response()->json([
                       "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422);               
                }

                //1: Booking User (Customer) 2: Provider Booked (Service Provider)
                  $booking_data = Booking::where('id',$request->get('booking_id'))->first();
                  if($user->id == $booking_data->provider_user_id){
                      $reciever = $booking_data->user_id;
                  }else{
                      $reciever = $booking_data->provider_user_id;
                  }
                  $User1 = $booking_data->provider_user_id;
                  $User2 = $booking_data->user_id;
                  $user1_data =  User::where('id',$User1)->first();
                  $user2_data =  User::where('id',$User2)->first();
                  $booking = Booking::where('id',$request->get('booking_id'))->update([
                    'status' => '2',
                    'cancelled_by' => $user->id,
                  ]);

                  $notification = new Notification;
                  $notification->user_id = $user->id;
                  $notification->message = 'Booking Cancelled by '.$user->name;
                  $notification->sender = $user->id;
                  $notification->reciever = $reciever;
                  $notification->booking_id = $request->get('booking_id');
                  $notification->type = 2;
                  $notification->save();

                  $device_tokens = [$user1_data->device_token, $user2_data->device_token];

                  foreach ($device_tokens as $key => $value) {

                      $serverkey = 'AAAAEmcRsng:APA91bEGt33nTosoGVa_kb1vOLnxXFvrjjja3DR8M_hT7rkYpdKmEmbtM1sqMqsgsGi8EkoVRvfiD802zRlKawB-ornIV6EKTfcCbR0dl7M2kHmPmF9H57mAiyaSmUmCPHQP22fnJmSW';
                     $url = 'https://fcm.googleapis.com/fcm/send';
                     
                     $fields = array(

                       'to' => $value,
                       'notification'  => array('title' => 'Cancel Booking', 'body' =>  'Booking Cancelled by '.$user->name ),
                        'data' => array(
                          'title' => 'Cancel Booking', 
                          'body' =>  'Booking Cancelled by '.$user->name, 
                          'click_action' =>  'FLUTTER_NOTIFICATION_CLICK',
                          'type' => '3',
                        )         
                     );
                     $headers = array(
                       'Authorization: key=' . $serverkey,
                       'Content-Type: application/json'
                     );
                     $ch = curl_init();
                     curl_setopt($ch, CURLOPT_URL, $url);
                     curl_setopt($ch, CURLOPT_POST, true);
                     curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
                     curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                     curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
                     curl_exec($ch);
                     curl_close($ch);

                  }              
                   
                 

                if($booking){

                  return response()->json([
                  "status" => 1,
                  "message" => "Cancelled booking successfully!!!",
                  
                   ], 200);

                }else{

                  return response()->json([
                  "status" => 0,
                  "message" => "Something went wrong!",
                       
                   ], 422);

                }

        }
        catch(Exception $e){
            $result = [
              'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $result['status'] = 0;
             return $result;
        }

    }

    public function Host_transaction_history(Request $request){

      try{

        $user = Auth::user();
         $rules = [                
              'type' => 'required',
            ];

            $validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {
                    return response()->json([
                       "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422);               
                }
       
             $data = array();
             $overall_earnings =  WalletTransaction::where('provider_user_id',$user->id)->where('transaction_amount_status','0')->get()->sum("transaction_amount");
           
          
             if($request->get('type') == '1'){

              $transactions =  WalletTransaction::where('provider_user_id',$user->id)->where('transaction_amount_status','0')->orderBy('date', 'DESC')->get();


             foreach ($transactions as $key => $value) {

                 if($value->people_provider_id != ""){
                   $provider = PeopleProvider::where('id',$value->people_provider_id)->first();
                   $people =   People::where('id',$provider->cat_id)->first();
                   $provider_id = $value->people_provider_id;
                   $category = $people->name;
                }elseif ($value->places_provider_id != "") {
                   $provider = PlaceProvider::where('id',$value->places_provider_id)->first();
                    $place =   Place::where('id',$provider->cat_id)->first();
                    $category = $place->name;
                  $provider_id = $value->places_provider_id;
                }elseif ($value->things_provider_id != "") {
                    $provider = ThingProvider::where('id',$value->things_provider_id)->first();
                    $thing =   Thing::where('id',$provider->cat_id)->first();
                    $category = $thing->name;
                    $provider_id = $value->things_provider_id;
                }
              
              $data[$key]['date'] = date('Y-m-d H:i:s',strtotime($value->updated_at));
               $data[$key]['category'] = $category;
              $data[$key]['transaction_amount_status'] = $value->transaction_amount_status;
              $data[$key]['provider_id'] = $provider_id;
              $data[$key]['provider_title'] = $provider->title;
              $data[$key]['amount'] = $value->transaction_amount;    
             }

             }elseif($request->get('type') == '2'){

              $transactions =  WalletTransaction::where('provider_user_id',$user->id)->where('transaction_amount_status','1')->orderBy('date', 'DESC')->get();
              
             foreach ($transactions as $key => $value) {
              $provider_id  = ''; 
              $category = ''; 
               $title = '';
                       if($value->people_provider_id != ""){
                   $provider = PeopleProvider::where('id',$value->people_provider_id)->first();
                   $people =   People::where('id',$provider->cat_id)->first();
                   $provider_id = $value->people_provider_id;
                   $category = $people->name;
                   $title = $provider->title;
                }elseif ($value->places_provider_id != "") {
                   $provider = PlaceProvider::where('id',$value->places_provider_id)->first();
                    $place =   Place::where('id',$provider->cat_id)->first();
                    $category = $place->name;
                  $provider_id = $value->places_provider_id;
                  $title = $provider->title;
                }elseif ($value->things_provider_id != "") {
                    $provider = ThingProvider::where('id',$value->things_provider_id)->first();
                    $thing =   Thing::where('id',$provider->cat_id)->first();
                    $category = $thing->name;
                    $provider_id = $value->things_provider_id;
                    $title = $provider->title;
                }
              
              $data[$key]['date'] = date('Y-m-d H:i:s', strtotime($value->updated_at));
                $data[$key]['category'] = $category; 
              $data[$key]['transaction_amount_status'] = $value->transaction_amount_status;
              $data[$key]['provider_id'] = $provider_id;
              $data[$key]['provider_title'] = $title;
              $data[$key]['amount'] = $value->transaction_amount;    
             }

             }elseif($request->get('type') == '3'){

              $transactions =  WalletTransaction::where('provider_user_id',$user->id)->where('transaction_amount_status','2')->orderBy('date', 'DESC')->get();

             foreach ($transactions as $key => $value) {
               $provider_id  = ''; 
              $category = '';
              $title = ""; 
                if($value->people_provider_id != ""){
                   $provider = PeopleProvider::where('id',$value->people_provider_id)->first();
                   $people =   People::where('id',$provider->cat_id)->first();
                   $provider_id = $value->people_provider_id;
                   $category = $people->name;
                   $title = $provider->title;
                }elseif ($value->places_provider_id != "") {
                   $provider = PlaceProvider::where('id',$value->places_provider_id)->first();
                    $place =   Place::where('id',$provider->cat_id)->first();
                    $category = $place->name;
                  $provider_id = $value->places_provider_id;
                  $title = $provider->title;
                }elseif ($value->things_provider_id != "") {
                    $provider = ThingProvider::where('id',$value->things_provider_id)->first();
                    $thing =   Thing::where('id',$provider->cat_id)->first();
                    $category = $thing->name;
                    $provider_id = $value->things_provider_id;
                    $title = $provider->title;
                }

              $data[$key]['date'] = date('Y-m-d H:i:s',strtotime($value->updated_at));
              $data[$key]['category'] = $category;
              $data[$key]['transaction_amount_status'] = $value->transaction_amount_status;
              $data[$key]['provider_id'] = $provider_id;
              $data[$key]['provider_title'] = $title;
              $data[$key]['amount'] = $value->transaction_amount;    
             }

             }elseif($request->get('type') == '0'){

              $transactions =  WalletTransaction::where('provider_user_id',$user->id)->orderBy('date', 'DESC')->get();


             foreach ($transactions as $key => $value) {
              $category = "";
              $provider_id = "";
              $title = "";

                 if($value->people_provider_id != ""){
                   $provider = PeopleProvider::where('id',$value->people_provider_id)->first();
                   $people =   People::where('id',$provider->cat_id)->first();
                   $provider_id = $value->people_provider_id;
                   $category = $people->name;
                   $title = $provider->title;
                }elseif ($value->places_provider_id != "") {
                   $provider = PlaceProvider::where('id',$value->places_provider_id)->first();
                    $place =   Place::where('id',$provider->cat_id)->first();
                    $category = $place->name;
                  $provider_id = $value->places_provider_id;
                  $title = $provider->title;
                }elseif ($value->things_provider_id != "") {
                    $provider = ThingProvider::where('id',$value->things_provider_id)->first();
                    $thing =   Thing::where('id',$provider->cat_id)->first();
                    $category = $thing->name;
                    $provider_id = $value->things_provider_id;
                    $title = $provider->title;
                }
              
              $data[$key]['date'] = date('Y-m-d H:i:s',strtotime($value->updated_at));
               $data[$key]['category'] = $category;
              $data[$key]['transaction_amount_status'] = $value->transaction_amount_status;
              $data[$key]['provider_id'] = $provider_id;
              $data[$key]['provider_title'] = $title;
              $data[$key]['amount'] = $value->transaction_amount;    
             }

             }

            
            

                if($transactions){

                  return response()->json([
                  "status" => 1,
                  "message" => "Host transaction history!!!",
                  'overall_earnings' =>   $overall_earnings,
                  'data'=> $data,
                  
                   ], 200);

                }else{

                  return response()->json([
                  "status" => 0,
                  "message" => "Something went wrong!",
                       
                   ], 422);

                }

        }
        catch(Exception $e){
            $result = [
              'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $result['status'] = 0;
             return $result;
        }

    }
    

   public function addReview(Request $request){

      try{

        $loggedInUser = Auth::user();
           $rules = [                
              'booking_id' => 'required',
              'provider_id' => 'required',
              'provider_user_id' => 'required',
              'ratings' => 'required',
              'provider_type' => 'required',

            ];

            $validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {
                    return response()->json([
                       "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422);               
                }

               
               
                $check_review = Review::where('booking_id',$request->get('booking_id'))->first();
                if($check_review){

                   if($request->get('reviews') != ""){
                   $reviews = $request->get('reviews');
                }else{
                   $reviews = "";
                }

                  if($request->get('provider_type') == '1'){



                      $review_update = Review::where('booking_id',$request->get('booking_id'))->update([
                        'user_id' => $loggedInUser->id,
                        'booking_id' => $request->get('booking_id'),
                        'provider_user_id' => $request->get('provider_user_id'),
                        'people_provider_id' => $request->get('provider_id'),
                        'reviews' => $reviews,
                        'ratings' => $request->get('ratings'),
                      ]);


                      $avgproviderrating = Review::where('people_provider_id',$request->get('provider_id'))->avg('ratings');

                      PeopleProvider::where('id',$request->get('provider_id'))->update([
                          'ratings' => $avgproviderrating,
                      ]);
 

                 }elseif($request->get('provider_type') == '2'){

                  $review_update = Review::where('booking_id',$request->get('booking_id'))->update([
                        'user_id' => $loggedInUser->id,
                        'booking_id' => $request->get('booking_id'),
                        'provider_user_id' => $request->get('provider_user_id'),
                        'things_provider_id' => $request->get('provider_id'),
                        'reviews' => $reviews,
                        'ratings' => $request->get('ratings'),
                      ]);

                  
                  $avgproviderrating = Review::where('things_provider_id',$request->get('provider_id'))->avg('ratings');

                  ThingProvider::where('id',$request->get('provider_id'))->update([
                      'ratings' => $avgproviderrating,
                  ]);
                 }elseif($request->get('provider_type') == '3'){

                  $review_update = Review::where('booking_id',$request->get('booking_id'))->update([
                        'user_id' => $loggedInUser->id,
                        'booking_id' => $request->get('booking_id'),
                        'provider_user_id' => $request->get('provider_user_id'),
                        'places_provider_id' => $request->get('provider_id'),
                        'reviews' => $reviews,
                        'ratings' => $request->get('ratings'),
                      ]);

                  $avgproviderrating = Review::where('places_provider_id',$request->get('provider_id'))->avg('ratings');

                  PlaceProvider::where('id',$request->get('provider_id'))->update([
                      'ratings' => $avgproviderrating,
                  ]);

                 }
                 
                  $review_update_data =  Review::where('id',$review_update->id)->first();
                     if($review_update_data){

                      return response()->json([
                      "status" => 1,
                      "message" => "Review Upadted successfully!!!",
                      'data' => $review_update_data,
                      
                       ], 200);

                    }else{

                      return response()->json([
                      "status" => 0,
                      "message" => "Something went wrong!",
                           
                       ], 422);

                    }


                }else{
                   if($request->get('reviews') != ""){
                   $reviews = $request->get('reviews');
                }else{
                   $reviews = "";
                } 

                 $review = new Review;
                 if($request->get('provider_type') == '1'){

                   $provider_id = $request->get('provider_id');
                   $review->people_provider_id = $provider_id;



                 }elseif($request->get('provider_type') == '2'){

                   $provider_id = $request->get('provider_id');
                   $review->things_provider_id = $provider_id;
                  
                 }elseif($request->get('provider_type') == '3'){

                   $provider_id = $request->get('provider_id');
                   $review->places_provider_id = $provider_id;
                 }

                  $review->user_id = $loggedInUser->id;
                  $review->booking_id = $request->get('booking_id');
                  $review->provider_user_id = $request->get('provider_user_id');
                  $review->ratings = $request->get('ratings');
                  $review->reviews = $reviews;
                  $review->save();
                  $review_data =  Review::where('id',$review->id)->first();

                  if($request->get('provider_type') == '1'){

                    $avgproviderrating = Review::where('people_provider_id',$request->get('provider_id'))->avg('ratings');

                      PeopleProvider::where('id',$request->get('provider_id'))->update([
                          'ratings' => $avgproviderrating,
                      ]);



                 }elseif($request->get('provider_type') == '2'){

                   $avgproviderrating = Review::where('things_provider_id',$request->get('provider_id'))->avg('ratings');

                  ThingProvider::where('id',$request->get('provider_id'))->update([
                      'ratings' => $avgproviderrating,
                  ]);
                  
                 }elseif($request->get('provider_type') == '3'){

                     $avgproviderrating = Review::where('places_provider_id',$request->get('provider_id'))->avg('ratings');

                  PlaceProvider::where('id',$request->get('provider_id'))->update([
                      'ratings' => $avgproviderrating,
                  ]);
                 }
                
                     if($review_data){

                      return response()->json([
                      "status" => 1,
                      "message" => "Review Added successfully!!!",
                      'data' => $review_data,
                      
                       ], 200);

                    }else{

                      return response()->json([
                      "status" => 0,
                      "message" => "Something went wrong!",
                           
                       ], 422);

                    }

                }
                 

               

        }
        catch(Exception $e){
            $result = [
              'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $result['status'] = 0;
             return $result;
        }

   }

   public function provider_reviews(Request $request){

    try{

      $user_id = Auth::id();

      $rules = [                
              'type' => 'required',
            ];

            $validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {
                    return response()->json([
                       "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422);               
                }

      $review = array();

      if($request->get('type') == '1'){
        $reviews = Review::where('provider_user_id',$user_id)->where('people_provider_id','<>','')->where('reviews','<>','')->get();

      if($reviews){
      
        foreach($reviews as $key => $value){
          $provider = PeopleProvider::where('id',$value->people_provider_id)->first();
          $user = User::where('id',$value->user_id)->first();
          $review[$key]['reviews'] = $value->reviews; 
          $review[$key]['title'] = $provider->title;       
          $review[$key]['user'] = $user->name; 
          $review[$key]['date'] = date('Y-m-d',strtotime($value->created_at)); 
          $review[$key]['image'] = URL::to('/').'/profile/'.$user->image; 
          $review[$key]['ratings'] = $value->ratings; 
        }
      }

      }elseif($request->get('type') == '2'){

        $reviews = Review::where('provider_user_id',$user_id)->where('things_provider_id','<>','')->where('reviews','<>','')->get();

              if($reviews){
              
                foreach($reviews as $key => $value){
                  $provider = ThingProvider::where('id',$value->things_provider_id)->first();
                  $user = User::where('id',$value->user_id)->first();
                  $review[$key]['reviews'] = $value->reviews; 
                  $review[$key]['title'] = $provider->title;
                  $review[$key]['date'] = date('Y-m-d',strtotime($value->created_at)); 
                  $review[$key]['user'] = $user->name; 
                  $review[$key]['image'] = URL::to('/').'/profile/'.$user->image; 
                  $review[$key]['ratings'] = $value->ratings; 
                }
              
        }else{

          return response()->json([
                      "status" => 0,
                      "message" => "Something went wrong!",
                           
                       ], 422);

        }
      }elseif($request->get('type') == '3'){

        $reviews = Review::where('provider_user_id',$user_id)->where('places_provider_id','<>','')->where('reviews','<>','')->get();

              if($reviews){
              
                foreach($reviews as $key => $value){
                  $provider = PlaceProvider::where('id',$value->places_provider_id)->first();
                  $user = User::where('id',$value->user_id)->first();
                  $review[$key]['reviews'] = $value->reviews; 
                  $review[$key]['date'] = date('Y-m-d',strtotime($value->created_at)); 
                  $review[$key]['title'] = $provider->title;
                  $review[$key]['user'] = $user->name; 
                  $review[$key]['image'] = URL::to('/').'/profile/'.$user->image; 
                  $review[$key]['ratings'] = $value->ratings; 
                }
              
        }else{

          return response()->json([
                      "status" => 0,
                      "message" => "Something went wrong!",
                           
                       ], 422);

        }
      }elseif($request->get('type') == '0'){

        $reviews = Review::where('provider_user_id',$user_id)->where('reviews','<>','')->get();

      if($reviews){
      
        foreach($reviews as $key => $value){
              if($value->people_provider_id != ""){
               $provider = PeopleProvider::where('id',$value->people_provider_id)->first();
               
               $title = $provider->title;
            }elseif ($value->places_provider_id != "") {
               $provider = PlaceProvider::where('id',$value->places_provider_id)->first();        
              $title = $provider->title;
            }elseif ($value->things_provider_id != "") {
                $provider = ThingProvider::where('id',$value->things_provider_id)->first();               
                $title = $provider->title;
            }
          $user = User::where('id',$value->user_id)->first();
          $review[$key]['reviews'] = $value->reviews;
          $review[$key]['title'] = $title ;
          $review[$key]['user'] = $user->name; 
          $review[$key]['date'] = date('Y-m-d',strtotime($value->created_at)); 
          $review[$key]['image'] = URL::to('/').'/profile/'.$user->image; 
          $review[$key]['ratings'] = $value->ratings; 
        }
      
        }else{

          return response()->json([
                      "status" => 0,
                      "message" => "Something went wrong!",
                           
                       ], 422);

        }
      }

        return response()->json([
                      "status" => 1,
                      'data' => $review,
                      
                       ], 200);


    }
        catch(Exception $e){
            $result = [
              'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $result['status'] = 0;
             return $result;
        }

   }

   public function check_balance(Request $request){

    try{
      $user = Auth::user();

      if($user){

          if($user->user_vault_total == ''){
            $user_vault_total = 0;
          }else{
            $user_vault_total = $user->user_vault_total;
          }
     
           return response()->json([
                      "status" => 1,
                      'balance' => $user_vault_total ,
                      
                       ], 200);
        
        
       

      }else{

        return response()->json([
                      "status" => 0,
                      "message" => "Something went wrong!",
                           
                       ], 422);
      }

    }
        catch(Exception $e){
            $result = [
              'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $result['status'] = 0;
             return $result;
        }

   }

      public function vault_withdraw(Request $request){

    try{
         $user = Auth::user();

              $rules = [                
              'amount' => 'required',
              'account_holder' => 'required',
              'account_number' => 'required',
              'bank_name' => 'required',
              'iban' => 'required',
              'sort_code' => 'required',
            ];

            $validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {
                    return response()->json([
                       "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422);               
                }

              $wallettransaction = new WalletTransaction;
              $wallettransaction->provider_user_id = $user->id;              
              $wallettransaction->transaction_amount  = $request->get('amount');
              $wallettransaction->account_holder  = $request->get('account_holder');
              $wallettransaction->account_number  = $request->get('account_number');
              $wallettransaction->bank_name  = $request->get('bank_name');
              $wallettransaction->iban  = $request->get('iban');
              $wallettransaction->sort_code  = $request->get('sort_code');
              $wallettransaction->date = date('Y-m-d H:i:s');
              $wallettransaction->transaction_amount_status = '1';
              $wallettransaction->save();

        if($wallettransaction){

         $balance_left = $user->user_vault_total - $request->get('amount');

         User::where('id',$user->id)->update([
          'user_vault_total' => $balance_left,
         ]);

         $user_data =  User::where('id',$user->id)->first();

          $data = WalletTransaction::where('id',$wallettransaction->id)->first();

     
           return response()->json([
                      "status" => 1,
                      'message' => 'Transaction Completed Successfully',
                      'transaction' => $data ,
                      'balance' => $user_data->user_vault_total,
                      
                       ], 200);

      }else{

        return response()->json([
                      "status" => 0,
                      "message" => "Something went wrong!",
                           
                       ], 422);
      }

    }
        catch(Exception $e){
            $result = [
              'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $result['status'] = 0;
             return $result;
        }

   }

    public function listings(Request $request){

    try{

      $user_id = Auth::id();
       $rules = [                
              'type' => 'required',
            ];

            $validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {
                    return response()->json([
                       "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422);               
                }
                $data = array();
                if($request->get('type') == '1'){

                $provider =   PeopleProvider::where('user_id',$user_id)->where('cat_id','<>','')->get();

                if($provider){

                  foreach ($provider as $key => $value) {

                    $unavailable_dates_booking = array();
                    $date_new = array();
                    $booking_data = Booking::where('people_provider_id',$value->id)->where('status','1')->get();

                   if($booking_data){

                     foreach ($booking_data as $key => $value2) {

                    if(date("Y-m-d", strtotime($value2->check_in)) == date("Y-m-d",strtotime($value2->check_out))){

                     $date_new[] =  $this->getDatesFromRange(date("Y-m-d", strtotime($value2->check_in)), date("Y-m-d",strtotime($value2->check_out)));
                    }else{

                      $date_new[] =  $this->getDatesFromRange(date("Y-m-d", strtotime($value2->check_in)), date("Y-m-d",strtotime('-1 day',strtotime($value2->check_out))));
                      }

                     }       
                    
                    } 
                   $attachments = array();
                   $amenities_offered = array();
                   $user =  User::where('id',$value->user_id)->first();
                   $people =   People::where('id',$value->cat_id)->first();
                   $people_subcat = People_Subcat::where('id',$value->subcat_id)->first();
                   $attachments_all =  Attachment::where('people_provider_id',$value->id)->get();
                   foreach ($attachments_all as $key1 => $value1){
                    $attachments[] = $value1->filenames;
                  }
                    if($value->status == "0"){
                      $status = "Not Approved by admin";
                    }else{
                      $status = "Approved by admin";
                    }
                     if($value->percent_status == "1"){
                      $percent_status = 33;
                    }elseif($value->percent_status == "2"){
                       $percent_status = 66;
                    }elseif($value->percent_status == "3"){
                       $percent_status = 100;
                    }
                  
                    $data[$key]['title'] = $value->title;
                    $data[$key]['date'] = date('Y-m-d H:i:s',strtotime($value->updated_at));
                    
                    $data[$key]['Category'] = $people->name;
                    $data[$key]['complete_status'] = $value->complete_status;
                    $data[$key]['percent_status'] = $percent_status;
                    $data[$key]['status'] = $status;
                      if($user->image != ""){
                     $data[$key]['image'] = URL::to('/').'/profile/'.$user->image;
                    }else{
                      $data[$key]['image'] = '';
                    }
                    $data[$key]['detail'] = $value;
                     $newdates = array();
                    if($value->available_dates == ""){
                        $unavailable_dates = array();

                      }else{
                      $newdates[] =  $value->available_dates;              
                      if(empty($date_new)){
                        $final_bookingdateslist = array(); 
                      }else{

                      $final_bookingdateslist = call_user_func_array("array_merge", $date_new); 
                      $newdates[] = implode(',', $final_bookingdateslist);
                      }
                        $final_unavailable_dates = implode(',', $newdates);
                        $List = explode(',', $final_unavailable_dates);
                        
                          $unavailable_dates = $List;
                                                     
                      }
                      $data[$key]['detail']['available_dates'] = $unavailable_dates;
                      $data[$key]['detail']['amenities_offered'] = $amenities_offered;
                       $data[$key]['detail']['unavailable_dates'] = $unavailable_dates;
                       $data[$key]['detail']['attachments'] = $attachments;
                        if($value->price_per_night == ""){
                          $data[$key]['detail']['price_per_night'] = 0;
                       }
                       $data[$key]['detail']['subcat_name'] = $people_subcat->name;
                   /* $data[$key]['image'] = URL::to('/').'/profile/'.$user->image;*/


                  }
                    return response()->json([
                        "status" => 1,
                        'data' => $data,
                        
                         ], 200);

                    }else{

                      return response()->json([
                                  "status" => 0,
                                  "message" => "Something went wrong!",
                                       
                                   ], 422);

                    }

                }elseif($request->get('type') == '2'){

                 $provider =  ThingProvider::where('user_id',$user_id)->where('cat_id','<>','')->get();

                  if($provider){

                   foreach ($provider as $key => $value) {

                     $unavailable_dates_booking = array();
                    $date_new = array();
                    $booking_data = Booking::where('things_provider_id',$value->id)->where('status','1')->get();
                   
                   if($booking_data){

                     foreach ($booking_data as $key => $value2) {

                    if(date("Y-m-d", strtotime($value2->check_in)) == date("Y-m-d",strtotime($value2->check_out))){

                     $date_new[] =  $this->getDatesFromRange(date("Y-m-d", strtotime($value2->check_in)), date("Y-m-d",strtotime($value2->check_out)));
                    }else{

                      $date_new[] =  $this->getDatesFromRange(date("Y-m-d", strtotime($value2->check_in)), date("Y-m-d",strtotime('-1 day',strtotime($value2->check_out))));
                      }

                     }       
                    
                    }
                     $thing =   Thing::where('id',$value->cat_id)->first();
                     $things_subcat = Thing_Subcat::where('id',$value->subcat_id)->first();
                    $attachment =  Attachment::where('things_provider_id',$value->id)->first();
                    $attachments = array();
                    $amenities_offered = array();
                    $attachments_all =  Attachment::where('things_provider_id',$value->id)->get();
                     foreach ($attachments_all as $key1 => $value1){
                       $attachments[] = $value1->filenames;
                    }
                    if($value->status == "0"){
                      $status = "Not Approved by admin";
                    }else{
                      $status = "Approved by admin";
                    }
                        if($value->status == "0"){
                      $status = "Not Approved by admin";
                    }else{
                      $status = "Approved by admin";
                    }
                     if($value->percent_status == "1"){
                      $percent_status = 25;
                    }elseif($value->percent_status == "2"){
                       $percent_status = 50;
                    }elseif($value->percent_status == "3"){
                       $percent_status = 75;
                    }elseif($value->percent_status == "4"){
                       $percent_status = 100;
                    }
                    $data[$key]['title'] = $value->title;
                    $data[$key]['date'] = date('Y-m-d H:i:s',strtotime($value->updated_at));
                    $data[$key]['Category'] = $thing->name;
                    $data[$key]['complete_status'] = $value->complete_status;
                    $data[$key]['percent_status'] = $percent_status;
                    $data[$key]['status'] = $status;
                     if($attachment != ""){
                     $data[$key]['image'] = URL::to('/').'/attachments/'.$attachment->filenames;
                    }else{
                      $data[$key]['image'] = '';
                    }
                    $data[$key]['detail'] = $value;
                        $newdates = array();
                    if($value->unavailable_dates == ""){
                        $unavailable_dates = array();

                      }else{
                      $newdates[] =  $value->unavailable_dates;              
                      if(empty($date_new)){
                        $final_bookingdateslist = array(); 
                      }else{

                      $final_bookingdateslist = call_user_func_array("array_merge", $date_new); 
                      $newdates[] = implode(',', $final_bookingdateslist);
                      }
                        $final_unavailable_dates = implode(',', $newdates);
                        $List = explode(',', $final_unavailable_dates);
                        
                          $unavailable_dates = $List;
                                                     
                      }
                       $data[$key]['detail']['unavailable_dates'] = $unavailable_dates;
                       $data[$key]['detail']['amenities_offered'] = $amenities_offered;
                       $data[$key]['detail']['attachments'] = $attachments;
                        if($value->price_per_night == ""){
                          $data[$key]['detail']['price_per_night'] = 0;
                       }
                        $data[$key]['detail']['subcat_name'] = $things_subcat->name;
                  }

                  return response()->json([
                        "status" => 1,
                        'data' => $data,
                        
                         ], 200);

                    }else{

                      return response()->json([
                                  "status" => 0,
                                  "message" => "Something went wrong!",
                                       
                                   ], 422);

                    }

                }elseif($request->get('type') == '3'){

                 $provider =  PlaceProvider::where('user_id',$user_id)->where('cat_id','<>','')->get();
                 if($provider){

                   foreach ($provider as $key => $value2) {

                     $unavailable_dates_booking = array();
                    $date_new = array();
                    $booking_data = Booking::where('places_provider_id',$value2->id)->where('status','1')->get();

                   if($booking_data){

                     foreach ($booking_data as $key => $value) {

                    if(date("Y-m-d", strtotime($value->check_in)) == date("Y-m-d",strtotime($value->check_out))){

                     $date_new[] =  $this->getDatesFromRange(date("Y-m-d", strtotime($value->check_in)), date("Y-m-d",strtotime($value->check_out)));
                    }else{

                      $date_new[] =  $this->getDatesFromRange(date("Y-m-d", strtotime($value->check_in)), date("Y-m-d",strtotime('-1 day',strtotime($value->check_out))));
                      }

                     }       
                    
                    }
                     $attachments = array();
                    $attachment =  Attachment::where('places_provider_id',$value2->id)->first();
                    $attachments_all =  Attachment::where('places_provider_id',$value2->id)->get();
                    $place =   Place::where('id',$value2->cat_id)->first();
            
                    $places_subcat = Place_Subcat::where('id',$value2->subcat_id)->first();
                    foreach ($attachments_all as $key1 => $value1){
                       $attachments[] = $value1->filenames;
                    }
                    if($value2->status == "0"){
                      $status = "Not Approved by admin";
                    }else{
                      $status = "Approved by admin";
                    }
                        if($value2->percent_status == "1"){
                      $percent_status = 25;
                    }elseif($value2->percent_status == "2"){
                       $percent_status = 50;
                    }elseif($value2->percent_status == "3"){
                       $percent_status = 75;
                    }elseif($value2->percent_status == "4"){
                       $percent_status = 100;
                    }

                  
                    $data[$key]['title'] = $value2->title;
                       $data[$key]['date'] = date('Y-m-d H:i:s',strtotime($value2->updated_at));
                    $data[$key]['Category'] = $place->name;
                    $data[$key]['complete_status'] = $value2->complete_status;
                    $data[$key]['percent_status'] = $percent_status;
                    $data[$key]['status'] = $status;
                    if($attachment != ""){
                     $data[$key]['image'] = URL::to('/').'/attachments/'.$attachment->filenames;
                    }else{
                      $data[$key]['image'] = '';
                    }
                    $data[$key]['detail'] = $value2;
                    if($value2->unavailable_dates == ""){
                        $unavailable_dates = array();

                      }else{
                      $newdates[] =  $value2->unavailable_dates;              
                      if(empty($date_new)){
                        $final_bookingdateslist = array(); 
                      }else{

                      $final_bookingdateslist = call_user_func_array("array_merge", $date_new); 
                      $newdates[] = implode(',', $final_bookingdateslist);
                      }
                        $final_unavailable_dates = implode(',', $newdates);
                        $List = explode(',', $final_unavailable_dates);
                        
                          $unavailable_dates = $List;
                                                     
                      }

                      if($value2->amenities_offered == ""){
                        $amenities_offered = array();

                      }else{
                      
                        $List = explode(',', $value2->amenities_offered);
                         $amenities_offered = $List; 
                                                     
                      }
                      $data[$key]['detail']['amenities_offered'] = $amenities_offered;
                       $data[$key]['detail']['unavailable_dates'] = $unavailable_dates;
                       $data[$key]['detail']['attachments'] = $attachments;
                      if($value2->price_per_night == ""){
                          $data[$key]['detail']['price_per_night'] = 0;
                       }
                      $data[$key]['detail']['subcat_name'] = $places_subcat->name;
                      if($value2->pet_allowance == ""){
                        $data[$key]['detail']['pet_allowance'] = false;
                      }else{
                        if($value2->pet_allowance == "true"){
                        $data[$key]['detail']['pet_allowance'] = true;
                      }else{
                         $data[$key]['detail']['pet_allowance'] = false;
                      }

                      }
                      if($value2->host_facility == ""){
                        $data[$key]['detail']['host_facility'] = false;
                      }else{
                        if($value2->host_facility == "true"){
                        $data[$key]['detail']['host_facility'] = true;
                      }else{
                         $data[$key]['detail']['host_facility'] = false;
                      }

                      }
                      if($value2->host_name == ""){
                        $data[$key]['detail']['host_name'] = '';
                      }
                      if($value2->host_phone == ""){
                        $data[$key]['detail']['host_phone'] = '';
                      }
                  }
                  return response()->json([
                        "status" => 1,
                        'data' => $data,
                        
                         ], 200);

                    }else{

                      return response()->json([
                                  "status" => 0,
                                  "message" => "Something went wrong!",
                                       
                                   ], 422);

                    }

                }

    }
        catch(Exception $e){
            $result = [
              'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $result['status'] = 0;
             return $result;
        }

   }

  public function provider_details(Request $request){

    try{

       $user = Auth::user();
       

            
              $data = array();

              $provider = PeopleProvider::where('user_id', $user->id)->where('complete_status', '1')->get();

              if($provider !=  ''){

                foreach ($provider as $key => $value) {
                $Category = People::where('id',$value->cat_id)->first();
                $SubCategory = People_Subcat::where('id',$value->subcat_id)->first();
                $attachment = array();
               $attachments =  Attachment::where('people_provider_id',$value->id)->get();
                 foreach ($attachments as $key1 => $value1) {
                  $attachment[$key1] = $value1->filenames;
                 }

                
                $data[$key]['title'] =  $value->title;
                $data[$key]['description'] =  $value->description;
                $data[$key]['category'] =  $Category->name;
                $data[$key]['subcategory'] =  $SubCategory->name;
                $data[$key]['category_image'] =  URL::to('/').'/peoples/'.$Category->image;
                $data[$key]['price_per_night'] =  $value->price_per_night;
                
              }
              $documents = array();
              foreach ($provider as $key => $value) {

                $attachment = array();
               $attachments =  Attachment::where('people_provider_id',$value->id)->get();

                 foreach ($attachments as $key1 => $value1) {
                  $attachment[$key1] = URL::to('/').'/attachments/'.$value1->filenames;
                 }

                  $documents[$key] =  $attachment;
          
              }
              if(!empty($documents)){
                $document =  call_user_func_array("array_merge", $documents);
              }else{
                $document = array();
              }
              
          
                return response()->json([
                        "status" => 1,
                        'data' => $data,
                        'attachments' => $document,
                        'user_name' => $user->name,
                        'image' => URL::to('/').'/profile/'.$user->image,
                        
                         ], 200);

              }else{

                 return response()->json([
                                  "status" => 0,
                                  "message" => "Something went wrong!",
                                       
                                   ], 422);


              }

              
              
    }
        catch(Exception $e){
            $result = [
              'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $result['status'] = 0;
             return $result;
        }

  }

   public function get_provider_details(Request $request){ 

    try{

       $user = Auth::user();


       $rules = [                
              'type' => 'required',
              'provider_id' => 'required',
            ];

            $validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {
                    return response()->json([
                       "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422);               
                }


                if($request->get('type') == '1'){

                  $provider = PeopleProvider::where('id', $request->get('provider_id'))->first();

                  if($provider != ''){
                     $attachment = array();
                    $attachments =  Attachment::where('people_provider_id',$provider->id)->get();
                   foreach ($attachments as $key1 => $value1) {
                     $attachment[$key1]['id'] = $value1->id;
                    $attachment[$key1]['image'] = URL::to('/').'/attachments/'.$value1->filenames;
                   }

                  $data['title'] =  $provider->title;
                  $data['description'] =  $provider->description;
                  if($provider->available_dates != ''){
                    $data['unavailable_dates'] =  explode(',', $provider->available_dates); 
                  }else{
                    $data['unavailable_dates'] = array();
                  }
                  $data['amenities_offered'] = array();
                  $data['price_per_night'] =  $provider->price_per_night;
                  $data['time_in'] =  $provider->time_in;
                  $data['time_out'] =  $provider->time_out;
                  $data['attachments'] =  $attachment;

                  }
                 


                }elseif($request->get('type') == '2'){
                  
                   $provider = ThingProvider::where('id', $request->get('provider_id'))->first();
                    if($provider != ''){

                                   $attachment = array();
                    $attachments =  Attachment::where('things_provider_id',$provider->id)->get();
                   foreach ($attachments as $key1 => $value1) {
                       $attachment[$key1]['id'] = $value1->id;
                    $attachment[$key1]['image'] = URL::to('/').'/attachments/'.$value1->filenames;
                   }
                    $data['title'] =  $provider->title;
                    $data['description'] =  $provider->description;
                      if($provider->unavailable_dates != ''){
                    $data['unavailable_dates'] =  explode(',', $provider->unavailable_dates); 
                  }else{
                    $data['unavailable_dates'] = array();
                  }
                    $data['amenities_offered'] = array();
                    $data['price_per_night'] =  $provider->price_per_night;
                    $data['time_in'] =  $provider->time_in;
                    $data['time_out'] =  $provider->time_out;
                    $data['attachments'] =  $attachment;


                    }
       
                }elseif($request->get('type') == '3'){

                   $provider = PlaceProvider::where('id', $request->get('provider_id'))->first();
                   
                   if($provider != ''){

                  $attachment = array();
                  $attachments =  Attachment::where('places_provider_id',$provider->id)->get();
                   foreach ($attachments as $key1 => $value1) {
                     $attachment[$key1]['id'] = $value1->id;
                    $attachment[$key1]['image'] = URL::to('/').'/attachments/'.$value1->filenames;
                   
                   }

                  $data['title'] =  $provider->title;
                  $data['description'] =  $provider->description;
                  if($provider->host_facility == ''){
                    $data['host_facility'] = false ;
                  }else{
                    if($provider->host_facility == 'true'){
                    $data['host_facility'] = true ;
                    }else{
                      $data['host_facility'] = false ;
                    }

                  }
                   if($provider->host_name == ''){
                    $data['host_name'] = '' ;
                    }else{
                      $data['host_name'] = $provider->host_name ;
                    }

                     if($provider->host_phone == ''){
                       $data['host_phone'] = '' ;
                    }else{
                      $data['host_phone'] = $provider->host_phone ;
                    }
                    
                  if($provider->unavailable_dates != ''){
                    $data['unavailable_dates'] =  explode(',', $provider->unavailable_dates); 
                  }else{
                    $data['unavailable_dates'] = array();
                  } 
                   if($provider->amenities_offered != ''){
                    $data['amenities_offered'] =  explode(',', $provider->amenities_offered); 
                  }else{
                    $data['amenities_offered'] = array();
                  }        
                  $data['price_per_night'] =  $provider->price_per_night;
                  $data['time_in'] =  $provider->time_in;
                  $data['time_out'] =  $provider->time_out;
                  $data['attachments'] =  $attachment;
                  }

                }

              
                return response()->json([
                        "status" => 1,
                        'data' => $data,                       
                        
                         ], 200);        
              
    }
        catch(Exception $e){
            $result = [
              'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $result['status'] = 0;
             return $result;
        }

  }

  public function delete_attachments(Request $request){

    try{

      $user = Auth::user();


          $rules = [                
              'id' => 'required',
            ];

          $validator = Validator::make($request->all(), $rules);

          if($validator->fails())
          {
              return response()->json([
                 "message" => "Something went wrong!",
                 'errors' => $validator->errors()->toArray(),
             ], 422);               
          }

         $delete_attachments = Attachment::where('id',$request->get('id'))->delete();
          if($delete_attachments){

            return response()->json([
                        "status" => 1,
                        'message' => 'Attachment Deleted Successfully!!',                       
                        
                         ], 200);

          }else{

              return response()->json([
                                  "status" => 0,
                                  "message" => "Something went wrong!",
                                       
                                   ], 422);

          }


    }
        catch(Exception $e){
            $result = [
              'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $result['status'] = 0;
             return $result;
        }

  }

 public function edit_provider_detail(Request $request){
   
    try{

      $loggedInUser = Auth::user();


       $rules = [                
              'type' => 'required',
              'provider_id' => 'required',
            ];

            $validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {
                    return response()->json([
                       "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422);               
                }

             


                if($request->get('type') == '1'){

                  $provider = PeopleProvider::where('id', $request->get('provider_id'))->first();

                  if($provider != ''){

                    if($request->time_in == ""){
                      $time_in = $provider->time_in;
                    }else{
                      $time_in = $request->time_in;                        
                    }

                    if($request->time_out == ""){
                      $time_out = $provider->time_out;
                    }else{
                      $time_out = $request->time_out;
                    }

                    if($request->price_per_night == ""){
                      $price_per_night = $provider->price_per_night;
                    }else{
                      $price_per_night = $request->price_per_night;
                    }

                    if($request->unavailable_dates == ""){
                      $unavailable_dates = $provider->available_dates;
                    }else{
                      $List = implode(',', $request->unavailable_dates); 
                      $unavailable_dates = $List;              
                    }

                      if($request->file('attachments') != ''){
                      
                       foreach( $request->file('attachments') as $key=>$attachment ){

                         $pics = new Attachment;
                         $pics->people_provider_id = $provider->id;
                         if (!file_exists( public_path('/attachments'))) {
                             mkdir(public_path('/attachments'), 0777, true);
                           }
                           $path =public_path('/attachments/');
                           $image1 = $attachment; 
                           $input['imagename'] = time().rand(10,10000).$key.'.'.$image1->getClientOriginalExtension();
                           $destinationPath = public_path('/attachments');
                           $attachment->move($destinationPath, $input['imagename']);
                           $pics->filenames  =  $input['imagename'];
                          $pics->save();

                       }
                    }

                    $updateProvider = PeopleProvider::where('user_id' , $loggedInUser->id)->where('id',$request->get('provider_id'))->update([                      
                      'available_dates' => $unavailable_dates,
                      'time_in' => $time_in,
                      'time_out' => $time_out,
                      'price_per_night' => $price_per_night,
                    ]);

                         if($updateProvider){
                          $attachment_all = array();
                    $data =  PeopleProvider::where('user_id' , $loggedInUser->id)->where('id',$request->get('provider_id'))->first();
                     $attachment_images = Attachment::where('people_provider_id',$request->get('provider_id'))->get();

                      foreach ($attachment_images as $key1 => $value1) {
                    $attachment_all[$key1] = $value1->filenames;
                  } 

                      return response()->json([
                        "status" => 1,
                        'data' => $data,
                        'attachments' => $attachment_all,
                        
                         ], 200);

                    }else{

                      return response()->json([
                                  "status" => 0,
                                  "message" => "Something went wrong!",
                                       
                                   ], 422);


                    }

                 

                  }
                 


                }elseif($request->get('type') == '2'){

                  $provider = ThingProvider::where('id', $request->get('provider_id'))->first();

                  if($provider != ''){

                    if($request->time_in == ""){
                      $time_in = $provider->time_in;
                    }else{
                      $time_in = $request->time_in;                        
                    }

                    if($request->time_out == ""){
                      $time_out = $provider->time_out;
                    }else{
                      $time_out = $request->time_out;
                    }

                    if($request->price_per_night == ""){
                      $price_per_night = $provider->price_per_night;
                    }else{
                      $price_per_night = $request->price_per_night;
                    }

                    if($request->unavailable_dates == ""){
                      $unavailable_dates = $provider->unavailable_dates;
                    }else{
                      $List = implode(',', $request->unavailable_dates); 
                      $unavailable_dates = $List;              
                    }

                    if($request->file('attachments') != ''){
                    
                     foreach( $request->file('attachments') as $key=>$attachment ){

                       $pics = new Attachment;
                       $pics->things_provider_id = $provider->id;
                       if (!file_exists( public_path('/attachments'))) {
                           mkdir(public_path('/attachments'), 0777, true);
                         }
                         $path =public_path('/attachments/');
                         $image1 = $attachment; 
                         $input['imagename'] = time().rand(10,10000).$key.'.'.$image1->getClientOriginalExtension();
                         $destinationPath = public_path('/attachments');
                         $attachment->move($destinationPath, $input['imagename']);
                         $pics->filenames  =  $input['imagename'];
                        $pics->save();

                     }
                  }

                    $updateProvider = ThingProvider::where('user_id' , $loggedInUser->id)->where('id',$request->get('provider_id'))->update([                      
                      'unavailable_dates' => $unavailable_dates,
                      'time_in' => $time_in,
                      'time_out' => $time_out,
                      'price_per_night' => $price_per_night,
                    ]);

                    if($updateProvider){
                      $attachment_all = array();
                    $data =  ThingProvider::where('user_id' , $loggedInUser->id)->where('id',$request->get('provider_id'))->first();
                        $attachment_images = Attachment::where('things_provider_id',$request->get('provider_id'))->get();

                      foreach ($attachment_images as $key1 => $value1) {
                    $attachment_all[$key1]= $value1->filenames;
                   
                   }

                      return response()->json([
                        "status" => 1,
                        'data' => $data,
                        'attachments' =>$attachment_all,
                        
                         ], 200);
                     

                    }else{

                      return response()->json([
                                  "status" => 0,
                                  "message" => "Something went wrong!",
                                       
                                   ], 422);


                    }


                 

                  }           

                }elseif($request->get('type') == '3'){

                  $provider = PlaceProvider::where('id', $request->get('provider_id'))->first();

                  if($provider != ''){

                    if($request->time_in == ""){
                      $time_in = $provider->time_in;
                    }else{
                      $time_in = $request->time_in;                        
                    }

                    if($request->time_out == ""){
                      $time_out = $provider->time_out;
                    }else{
                      $time_out = $request->time_out;
                    }


                    if($request->host_facility == ""){
                      if($provider->host_facility == ''){
                        $host_facility = 'false';
                      }else{
                         if($provider->host_facility == 'true'){
                            $host_facility = 'true';
                          }else{
                            $host_facility = 'false';
                          }
                      }
                    }else{
                       $host_facility = $request->host_facility;
                      
                    }

                   if($request->host_name == ""){              
                       $host_name = $provider->host_name;                 
                    }else{
                      $host_name = $request->host_name;
                    }
                    if($request->host_phone == ''){
                       $host_phone = $provider->host_phone;
                    }else{
                      $host_phone = $request->host_phone;
                    }

                    if($request->price_per_night == ""){
                      $price_per_night = $provider->price_per_night;
                    }else{
                      $price_per_night = $request->price_per_night;
                    }

                    if($request->unavailable_dates == ""){
                      $unavailable_dates = $provider->unavailable_dates;
                    }else{
                      $List = implode(',', $request->unavailable_dates); 
                      $unavailable_dates = $List;              
                    }

                    if($request->amenities_offered == ""){
                      $amenities_offered = $provider->amenities_offered;
                    }else{
                      $List = implode(',', $request->amenities_offered); 
                      $amenities_offered = $List;              
                    }

                      if($request->file('attachments') != ''){
                      
                       foreach( $request->file('attachments') as $key=>$attachment ){

                         $pics = new Attachment;
                         $pics->places_provider_id = $provider->id;
                         if (!file_exists( public_path('/attachments'))) {
                             mkdir(public_path('/attachments'), 0777, true);
                           }
                           $path =public_path('/attachments/');
                           $image1 = $attachment; 
                           $input['imagename'] = time().rand(10,10000).$key.'.'.$image1->getClientOriginalExtension();
                           $destinationPath = public_path('/attachments');
                           $attachment->move($destinationPath, $input['imagename']);
                           $pics->filenames  =  $input['imagename'];
                          $pics->save();

                       }
                    }

                    $updateProvider = PlaceProvider::where('user_id' , $loggedInUser->id)->where('id',$request->get('provider_id'))->update([                      
                      'unavailable_dates' => $unavailable_dates,
                      'amenities_offered' => $amenities_offered,
                      'time_in' => $time_in,
                      'time_out' => $time_out,
                      'host_facility' => $host_facility,
                      'host_name' => $host_name,
                      'host_phone' => $host_phone,
                      'price_per_night' => $price_per_night,
                    ]);

                    if($updateProvider){
                      $attachment_all = array();
                    $data =  PlaceProvider::where('user_id' , $loggedInUser->id)->where('id',$request->get('provider_id'))->first();
                    $attachment_images = Attachment::where('places_provider_id',$request->get('provider_id'))->get();

                      foreach ($attachment_images as $key1 => $value1) {
                         $attachment_all[$key1]= $value1->filenames;
                      }

                      return response()->json([
                        "status" => 1,
                        'data' => $data,
                        'attachments' =>$attachment_all,
                        
                         ], 200);

                    }else{

                      return response()->json([
                                  "status" => 0,
                                  "message" => "Something went wrong!",
                                       
                                   ], 422);
                    }
                 

                  }
                 
                }

     }
        catch(Exception $e){
            $result = [
              'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $result['status'] = 0;
             return $result;
        }

  }

  public function SpecificUsersChat(Request $request){

    try{

       $loggedInUser = Auth::user();

            $rules = [                            
              'reciever_id' => 'required',
            ];

            $validator = Validator::make($request->all(), $rules);

                  if($validator->fails())
                {
                    return response()->json([
                       "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422);               
                }
                $chat_seen = Chat::where('sender_id',$request->get('reciever_id'))->where('reciever_id',$loggedInUser->id)->where('status_seen','0')->update([
                    'status_seen' => '1'
                  ]);
                $chat_headseen = Chat_head::where('sender_id',$request->get('reciever_id'))->where('reciever_id',$loggedInUser->id)->where('status_seen','0')->update([
                    'status_seen' => '1'
                  ]);

               $chat =  DB::table('chats')->where([ ['sender_id', '=', $loggedInUser->id], ['reciever_id', '=', $request->get('reciever_id')],['deleteby_user', '!=', $loggedInUser->id] ])->orwhere([ ['sender_id', '=', $request->get('reciever_id')], ['reciever_id', '=', $loggedInUser->id], ['deleteby_user', '!=', $loggedInUser->id],])->orderBy('updated_at','DESC')->get();

              
               $data = array();
               if($chat != ""){
                   foreach ($chat as $key => $value) {
                      $data[$key]['chat_id'] = $value->id;
                      $data[$key]['message'] = $value->message;
                      $data[$key]['message_type'] = $value->message_type;
                      $data[$key]['sender_id'] = $value->sender_id;
                      $data[$key]['status_seen'] = $value->status_seen;
                      $data[$key]['date'] = strtotime($value->updated_at).'000';
                      
                    }

                   return response()->json([
                            "status" => 1,
                            'data' => $data,
                                                 
                             ], 200);
               }else{

                    return response()->json([
                                  "status" => 0,
                                  "message" => "Something went wrong!",
                                       
                                   ], 422);

               }
           



    }
        catch(Exception $e){
            $result = [
              'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $result['status'] = 0;
             return $result;
        }

  }

   public function Show_lastmessage(Request $request){

    try{

       $loggedInUser = Auth::user();

              $chat =  DB::table('chat_heads')->where([ ['sender_id', '=', $loggedInUser->id],['deleteby_user', '<>', $loggedInUser->id], ])->orwhere([ ['reciever_id', '=', $loggedInUser->id], ['deleteby_user', '<>', $loggedInUser->id], ])->orderBy('updated_at','DESC')->get();

            /*   $chat = Chat_head::where('sender_id',$loggedInUser->id)->orwhere('reciever_id', $loggedInUser->id)->where('deleteby_user','<>', $loggedInUser->id)->orderBy('updated_at','DESC')->get();*/
                 $data = array();
                 
               if($chat){
                foreach ($chat as $key => $value) {
                    if($value->sender_id == $loggedInUser->id){
                       $user =   User::where('id',$value->reciever_id)->first();
                       $chatseen = '1';
                    }else{
                      $user =   User::where('id',$value->sender_id)->first();
                      $chatseen = $value->status_seen;
                    }

                

                    if($value->message_type == '2'){
                      $data[$key]['message'] = 'Image';
                      $data[$key]['message_type'] = $value->message_type;
                          $data[$key]['user_name'] = $user->name;
                      if($user->image == " "){
                         $data[$key]['user_image'] = '';
                      }else{
                         $data[$key]['user_image'] = URL::to('/').'/profile/'.$user->image;
                      }
                      $data[$key]['user_id'] = $user->id;
                      $data[$key]['status_seen'] = $chatseen;
                      $data[$key]['sender_id'] = $value->sender_id;
                      $data[$key]['date'] = strtotime($value->updated_at)*1000;
                    }else{
                        if($value->last_message == ''){
                          $message = ' ';
                        }else{
                           $message = $value->last_message;
                        }
                       $data[$key]['message'] = $message;
                       $data[$key]['message_type'] = $value->message_type;
                       $data[$key]['user_name'] = $user->name;
                           if($user->image == ""){
                         $data[$key]['user_image'] = '';
                      }else{
                         $data[$key]['user_image'] = URL::to('/').'/profile/'.$user->image;
                      }
                      $data[$key]['user_id'] = $user->id;
                      $data[$key]['status_seen'] = $chatseen;
                       $data[$key]['sender_id'] = $value->sender_id;
                       $data[$key]['date'] = strtotime($value->updated_at)*1000;

                    }         
                      
                    }

                   return response()->json([
                            "status" => 1,
                            'data' => $data,
                                                 
                             ], 200);
               }else{

                    return response()->json([
                                  "status" => 0,
                                  "message" => "Something went wrong!",
                                       
                                   ], 422);

               }
           



    }
        catch(Exception $e){
            $result = [
              'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $result['status'] = 0;
             return $result;
        }

  }



}
