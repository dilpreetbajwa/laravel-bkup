<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Place;
use App\People;
use App\Thing;
use App\Coupon;
use App\People_Subcat;
use App\Place_Subcat;
use App\Thing_Subcat;
use App\PeopleProvider;
use App\PlaceProvider;
use App\ThingProvider;
use App\Favourite;
use Auth;
use App\User;
use App\Attachment;
use App\WalletTransaction;
use URL;
use Validator;
use DB;
use App\Review;
use Braintree_Transaction;
use Braintree_Customer;
use Braintree_WebhookNotification;
use Braintree_Subscription;
use Braintree_PaymentMethod;
use Braintree_CreditCard;
use Braintree_ClientToken;
use DateTime;
use App\Booking;
use SplitTime;
use DateTimeZone;
use Carbon\Carbon;
use Carbon\CarbonInterval;
use DatePeriod;
use App\Booking_Slot;
use App\Slot;
use App\Chat;
use App\Chat_head;
use DateInterval; 

class ChatController extends Controller
{
    public function SpecificUsersChat(Request $request){

    try{

       $loggedInUser = Auth::user();

            $rules = [                            
              'reciever_id' => 'required',
            ];

            $validator = Validator::make($request->all(), $rules);

                  if($validator->fails())
                {
                    return response()->json([
                       "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422);               
                }
                $chat_seen = Chat::where('sender_id',$request->get('reciever_id'))->where('reciever_id',$loggedInUser->id)->where('status_seen','0')->update([
                    'status_seen' => '1'
                  ]);
                $chat_headseen = Chat_head::where('sender_id',$request->get('reciever_id'))->where('reciever_id',$loggedInUser->id)->where('status_seen','0')->update([
                    'status_seen' => '1'
                  ]);

               $chat =  DB::table('chats')->where([ ['sender_id', '=', $loggedInUser->id], ['reciever_id', '=', $request->get('reciever_id')], ])->orwhere([ ['sender_id', '=', $request->get('reciever_id')], ['reciever_id', '=', $loggedInUser->id], ])->orderBy('updated_at','DESC')->get();

               // Model::where('sender_id','=','1')->where('column_2 ','=','value_2')->get();
               //$chat = Chat::where(['sender_id' => $loggedInUser->id,'reciever_id' => $request->get('reciever_id')])->orwhere(['sender_id' => $request->get('reciever_id'),'reciever_id' => $loggedInUser->id])->get();
              
               $data = array();
               if($chat != ""){
                   foreach ($chat as $key => $value) {

                      $data[$key]['message'] = $value->message;
                      $data[$key]['message_type'] = $value->message_type;
                      $data[$key]['sender_id'] = $value->sender_id;
                      $data[$key]['status_seen'] = $value->status_seen;
                      $data[$key]['date'] = strtotime($value->updated_at);
                      
                    }

                   return response()->json([
                            "status" => 1,
                            'data' => $data,
                                                 
                             ], 200);
               }else{

                    return response()->json([
                                  "status" => 0,
                                  "message" => "Something went wrong!",
                                       
                                   ], 422);

               }
           



    }
        catch(Exception $e){
            $result = [
              'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $result['status'] = 0;
             return $result;
        }

  }

  public function deleteChat(Request $request){

    try{

       $loggedInUser = Auth::user();

            $rules = [                  
              'reciever_id' => 'required',                
            ];

            $validator = Validator::make($request->all(), $rules);

                  if($validator->fails())
                {
                    return response()->json([
                       "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422);               
                }

                $chat =  DB::table('chats')->where([ ['sender_id', '=', $loggedInUser->id], ['reciever_id', '=', $request->get('reciever_id')],['deleteby_user', '=', $request->get('reciever_id')], ])->orwhere([ ['sender_id', '=', $request->get('reciever_id')], ['reciever_id', '=', $loggedInUser->id], ['deleteby_user', '=', $request->get('reciever_id')], ])->delete();

                $chathead =  DB::table('chat_heads')->where([ ['sender_id', '=', $loggedInUser->id], ['reciever_id', '=', $request->get('reciever_id')],['deleteby_user', '=', $request->get('reciever_id')], ])->orwhere([ ['sender_id', '=', $request->get('reciever_id')], ['reciever_id', '=', $loggedInUser->id], ['deleteby_user', '=', $request->get('reciever_id')], ])->delete();

                $chathead_delete =  DB::table('chat_heads')->where([ ['sender_id', '=', $loggedInUser->id], ['reciever_id', '=', $request->get('reciever_id')],['deleteby_user', '=', ''], ])->orwhere([ ['sender_id', '=', $request->get('reciever_id')], ['reciever_id', '=', $loggedInUser->id], ['deleteby_user', '=', ''],])->update([
                        'deleteby_user' => $loggedInUser->id,
                  ]);


               $chat_delete =  DB::table('chats')->where([ ['sender_id', '=', $loggedInUser->id], ['reciever_id', '=', $request->get('reciever_id')],['deleteby_user', '=', ''], ])->orwhere([ ['sender_id', '=', $request->get('reciever_id')], ['reciever_id', '=', $loggedInUser->id], ['deleteby_user', '=', ''],])->update([
		                    'deleteby_user' => $loggedInUser->id,
		                  ]);

                
                	if($chat_delete){

                			return response()->json([
                            	"status" => 1,
                            	'message' => 'Chat deleted Successfully',
                                                 
                             ], 200);
		             }else{

		                    return response()->json([
                                  "status" => 0,
                                  "message" => "Something went wrong!",
		                    ], 422);
					 }


    }
        catch(Exception $e){
            $result = [
              'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $result['status'] = 0;
             return $result;
        }

  }

}
