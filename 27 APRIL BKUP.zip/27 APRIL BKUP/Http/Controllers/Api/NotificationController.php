<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use URL;
use Validator;
use DB;
use App\Faq;
use App\Notification;
use App\User;

class NotificationController extends Controller
{
    public function notifications(){
    	 $user =   Auth::user();
        try {

        	$notification = Notification::where('reciever', $user->id)->get();
        	$data = array();
        	if($notification){

        		foreach ($notification as $key => $value) {

        			$sender_user = User::where('id',$value->sender)->first();

        			$data[$key]['message'] = $value->message;
              $data[$key]['user_nmae'] = $sender_user->name;
        			$data[$key]['image'] = URL::to('/').'/profile/'.$sender_user->image;
        			$data[$key]['date'] = strtotime($value->updated_at)*1000;
        			# code...
        		}

        		return response()->json([
                  "status" => 1,
                  'data' => $data,
                   ], 200); 

        	}else{

        		return response()->json([
                  "status" => 0,
                  'data' => $data,
                   ], 422); 

        	}



        }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }
    }
}
