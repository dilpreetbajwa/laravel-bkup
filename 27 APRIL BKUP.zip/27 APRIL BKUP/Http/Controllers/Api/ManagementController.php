<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use URL;
use Validator;
use DB;

use App\Faq;
use App\Privacy;


class ManagementController extends Controller
{
    public function faq(){
    	 $user =   Auth::user();
        try {

        	$faq = Faq::all();
        	$data = array();
        	if($faq){

        		foreach ($faq as $key => $value) {

        			$data[$key]['id'] = $value->id;
        			$data[$key]['question'] = $value->question;
        			$data[$key]['answer'] = $value->answer;
        			# code...
        		}

        		return response()->json([
                  "status" => 1,
                  'data' => $data,
                   ], 200); 

        	}else{

        		return response()->json([
                  "status" => 0,
                  'data' => $data,
                   ], 422); 

        	}



        }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }
    }

        public function terms_and_condition(){
       $user =   Auth::user();
        try {

          $data = Privacy::where('title','Terms and Conditions')->first();
         
           if($data){
          return $data->description; 

          }else{

            return 'No Data'; 

          }



        }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }
    }

      public function privacy_policy(){
       $user =   Auth::user();
        try {

          $data = Privacy::where('title','Privacy Policy')->first();
         
          if($data){
          return $data->description; 

          }else{

            return 'No Data'; 

          }



        }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }
    }

     public function about_us(){
       $user =   Auth::user();
        try {

          $data = Privacy::where('title','About Us')->first();
         
         if($data){
          return $data->description; 

          }else{

            return 'No Data'; 

          }



        }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }
    }
    public function paymentTermOfService(){
       $user =   Auth::user();
        try {

          $data = Privacy::where('title','Payment Terms and Services')->first();
         
         if($data){
          return $data->description; 

          }else{

            return 'No Data'; 

          }



        }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }
    }
    public function nonDiscrimination(){
       $user =   Auth::user();
        try {

          $data = Privacy::where('title','Non Discrimination')->first();
         
         if($data){
          return $data->description; 

          }else{

            return 'No Data'; 

          }



        }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }
    }
}
