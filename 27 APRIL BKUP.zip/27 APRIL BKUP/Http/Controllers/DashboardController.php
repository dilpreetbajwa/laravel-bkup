<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Booking;
use App\Menu;
use Auth;
class DashboardController extends Controller
{
     public function index(){

        $user = Auth::user();

     	$total_users = User::count();
     	$total_users_providers = User::where('role','3')->count();
     	$total_bookings = Booking::count();
     	$total_bookings_earnings = Booking::where('status' ,'!=','2')->sum('total_amount');
        $menu = Menu::where('user_id', $user->id)->pluck('menu_name')->toArray(); 

    	return view('admin.dashboard')->with(compact('total_users','total_bookings','total_users_providers','total_bookings_earnings','menu'));
    }
     public function getUsers(){
        $menu = Menu::where('user_id', $user->id)->pluck('menu_name')->toArray(); 
    	return view('admin.user_list')->with(compact('menu'));
    }
}
