<?php

namespace App\Http\Controllers\Web;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Validator;
use Auth;
use App\User;
use Twilio;
use Twilio\Rest\Client;
use Twilio\Exceptions\RestException;
use Socialite;
use URL;
use Redirect;
use Mail;
use App\Mail\ForgotPassword;
use  MetzWeb\Instagram\Instagram;
use GeoIP;
use App\PeopleProvider;
use App\PlaceProvider;
use App\ThingProvider;
use App\People;
use App\Thing;
use App\Place;
use App\Coupon;
use App\Attachment;
use App\Booking;
use App\Favourite;
use DB;
use App\Privacy;
use App\Faq;
use App\People_Subcat;
use App\Place_Subcat;
use App\Thing_Subcat;
use App\Review;
use App\Support_IssueType;
use App\Support;
use App\WalletTransaction;
use Pagination;
use Braintree_Transaction;
use Braintree_Customer;
use Braintree_WebhookNotification;
use Braintree_Subscription;
use Braintree_PaymentMethod;
use Braintree_CreditCard;
use Braintree_ClientToken;
use DateInterval; 
use SplitTime;
use DateTime;
use Carbon\Carbon;
use Carbon\CarbonInterval;
use DatePeriod;
use App\Booking_Slot;
use App\Slot;
use App\Chat;
use App\Chat_head;
use App\Notification;
use \Stripe\Stripe;
Use \Stripe\Charge;
use \Stripe\Transfer;
use \Stripe\Account;
use \Stripe\Customer;
use \Stripe\Balance;
use \Stripe\FileUpload;
use \Stripe\Token;
use \Stripe\Payout;
use \Stripe\Plan;
use \Stripe\Subscription;
use \Stripe\Source;
use \Stripe\Error\Base;


class HomeController extends Controller
{

    private  $instagram ;

    function  __construct ()  { 
       
        $this->instagram  =  new  Instagram ( array ( 
            'apiKey'  =>   '6eff94bbdff04644be20a767bf5b0b52',
            'apiSecret'  =>   'ee360b9d679c4b67a56c38004683e9f5',
            'apiCallback'  =>  'https://timernr.com/instagram/callback/' 
        )); 
    }

  public function index()
  {
    $alltoprated = PeopleProvider::with('getimage')->distinct('user_id')->orderBy('ratings','DESC')->take(10)->get();

    $allcategories = Place::orderBy('name')->get();
    $alltopratedplaces = PlaceProvider::orderBy('ratings','DESC')->take(10);   
    $allplacecat =  Place::orderBy('name')->get();
    $allthingscat = Thing::orderBy('name')->get();
    $allpeoplecat = People::orderBy('name')->get();
   
    return view('frontend.index')->with(compact('allcategories','alltopratedplaces','allplacecat','allthingscat','allpeoplecat'));

  }
  public function show_categories(Request $request)
  {
    $cattype = $request->booking;

    
    if($request->booking == "home")
    {      
      $allcategories = Place::orderBy('name')->get();
      $alltoprated = PlaceProvider::with('getimage')->orderBy('ratings','DESC')->take(10)->get();           
    }
    else if($request->booking == "menu1")
    {
      $allcategories = Thing::orderBy('name')->get();
       $alltoprated = ThingProvider::with('getimage')->orderBy('ratings','DESC')->take(10)->get();
    }
    else if($request->booking == "menu2")
    {
      $allcategories = People::orderBy('name')->get();
       $alltoprated = PeopleProvider::with('getimage')->distinct('user_id')->orderBy('ratings','DESC')->take(10)->get();
    }
     $view1 = view('frontend.homepage.rated',compact('cattype','alltoprated'))->render();
     $view = view('frontend.homepage.categories',compact('cattype','allcategories'))->render();
      return response()->json(['html'=>$view,'htmlrated'=>$view1]);
  }

	public function user_login(Request $request){
		$uname = $request->email;
		$upwd = $request->password;
    $today =  date('Y-m-d');
        $rules = [
            'email' => 'required',
            'password' => 'required'
        ];
        $validator = Validator::make($request->all(), $rules);
        if($validator->fails())
        {
            return response()->json(['errors'=>$validator->errors()->all()]);              
        }
        if(Auth::attempt(['email' => $uname , 'password' => $upwd,'role'=>array(2,3)  ]))
        {           
          $result['message'] = 'Login successfully.';
          $result['success'] = 1;   
          $image= URL::to('/').'/profile/'.Auth::user()->image;
          $request->session()->put('loginval', 1);
          $request->session()->put('image_src',$image );
          $request->session()->put('fname',Auth::user()->name);
          $request->session()->put('lname',Auth::user()->lastname);
          $request->session()->put('role',Auth::user()->role);
          Booking::where('user_id',Auth::user()->id)->where('status','1')->whereDate('check_out', '<', $today)->update([
                    'status' => '3',
                   ]);

          $reviews =  Review::pluck('booking_id');
          $bookings = Booking::where('user_id',Auth::user()->id)->where('status','3')->whereNotIn('id',$reviews)->get();


          if(count($bookings)>0){
          	
            
            $request->session()->put('reviews',1);
           }


        }else{
        	return response()->json([
           "errors" => ['Please enter correct username and password.'],
       		]); 
	    }	        
	return $result;
    }


    public function check_email(Request $request)
    {
      if(Auth::check())
      {
        $userid = Auth::id();
        $email_exists = User::where('email',$request->email)->where('id','<>',$userid)->first();
      }
      else{
        $email_exists = User::where('email',$request->email)->first();
      }
        if($email_exists)
            return 0;
        else
            return 1;
    }

    public function check_phone(Request $request)
    {

       if(Auth::check())
      {

        $userid = Auth::id();
        $phone_exists = User::where('phone_number',$request->phone)->where('id','<>',$userid)->first();

      }
      else{
        $phone_exists = User::where('phone_number',$request->phone)->first();
      }
         if($phone_exists['phone_number']===NULL)
            return 1;
        else if($phone_exists)
            return 0;
        else
            return 1;
    }

     public function check_password(Request $request)
    {
        if($request->pwd == $request->cpwd)
            return 1;
        else
            return 0;
    }

     public function sign_up(Request $request)
    {  
      

     if(strcmp($request->otp_original,$request->otp)==0)
      {
        $code = $request->cc_code;
        $code1 = $request->cc_in;
        
        $mainUser = new User;
        $mainUser->name = $request->get('firstname');
        $mainUser->email = $request->get('emailaddress');
        $mainUser->password = bcrypt($request->get('password'));
        $mainUser->lastname = $request->get('lastname');
        //$mainUser->facebook_id = $request->get('facebook_id');
        $mainUser->phone_number = $request->get('phoneno');
       // $mainUser->country_code = $request->get('country_code');
        $mainUser->dob = $request->get('bday');
        $mainUser->gender = $request->get('gender');
        $mainUser->role = '2';
        $image1 =  $request->image;
        $mainUser->country_code = $code;
        $mainUser->country_initials = $code1;
        
        if($image1!=""){
          $image = $image1->getClientOriginalName();
          if($image!= ""){      
            if (!file_exists( public_path('/profile'))) {
              mkdir(public_path('/profile'), 0777, true);
            }
            $path =public_path('/profile/');
            $image_name = $image; 
            $input['imagename'] = time().rand(10,10000).'.'.$image1->getClientOriginalExtension();
            $destinationPath = public_path('/profile');
            $image1->move($destinationPath, $input['imagename']);
            $mainUser->image  =  $input['imagename'];
          } 
        }
          if($mainUser->save())
            return 1;
          else
            return 2;
      }
      else
      return 0;
    }

    public function send_otp(Request $request)
    {
        $phoneno = "+".$request->code.$request->phone;       
        $account_sid = 'AC78ab3b2e188f933475cfa6875e12c05c';
        $auth_token = '07eca2e621e34e549ffa5c480b55c5b7';
        $twilio_number = "+12408235499";
        $digits = 4;
        $otp = rand(pow(10, $digits-1), pow(10, $digits)-1);
        try
        {
            $client = new Client($account_sid, $auth_token);
           $res = $client->messages->create(
            // Where to send a text message (your cell phone?)
            $phoneno,
            array(
                'from' => $twilio_number,
                'body' => 'Your one time verifivation code is :'.$otp
            )
            );
           if($res){

              return response()->json([
                 "otp" => $otp,
                 "success"=>1
                 
             ]);
                
            }
           else
            {
                 return response()->json([
                 "otp" => $otp,
                 "success"=>0
                 
             ]);
            }
        }
        catch ( \Services_Twilio_RestException $e ) {
           
            return response()->json([
           "message" => $e->getMessage(),
           "success"=>0
           
       ]);
          
        }
        catch ( RestException $e ) {
              
                return response()->json([
               "message" => $e->getMessage(),
               "success"=>0,
               "otp" => $otp
           ]);
        }
        return $result;
    }

    public function redirectSiteFb()
    {
        return Socialite::driver('facebook')->redirect();
    }

    /**
     * Obtain the user information from GitHub.
     *
     * @return \Illuminate\Http\Response
     */
  public function handleFacebookCallback()
  {
    $user = Socialite::driver('facebook')->user();
    $username = $user->name;
    $useremail = $user->email;
    $userimage = $user->avatar;
    $facebook_email =  User::where('email',$user->email)->first(); 

    if($facebook_email != ""){                
      $update = User::where(["email" => $user->email])->update([ 
          'facebook_id' => $user->id
      ]);
      return redirect()->route('home1')->with( ['loginval' => 1]);
    }
    else{
      $signup_id = 1;
      return redirect()->route('home1')->with( ['signup_id' => 1,'username'=>$username, 'useremail'=>$useremail, 'userimage'=>$userimage] );
	  }
	}

	public function redirectSitegoogle()
    {
       return Socialite::driver('google')->redirect();
    }

    /**
     * Obtain the user information from GitHub.
     *
     * @return \Illuminate\Http\Response
     */
  public function handleGoogleCallback()
  {
    $user = Socialite::driver('google')->stateless()->user();

    $username = $user->name;
    $useremail = $user->email;
    $userimage = $user->avatar;

    $google_email =  User::where('email',$user->email)->first();  
    if($google_email != ""){                
      $update = User::where(["email" => $user->email])->update([ 
          'google_id' => $user->id
      ]);
      return redirect()->route('home1')->with( ['loginval' => 1]);
    }
    else{

      $signup_id = 1;
     return redirect()->route('home1')->with( ['signup_id' => 1,'username'=>$username, 'useremail'=>$useremail, 'userimage'=>$userimage] );
  	}
	}


  public function logout(Request $request){
    Auth::logout();
    $request->session()->forget('loginval');   
    DB::table('users')
        ->where('id', 'id')
        ->update(['userheaderstatus' => 0]);
    return redirect()->route('home1');
    }

  public function forgotpassword(Request $request)
  {
    $user = User::where('email',$request->email)->first();
    if($user){
        $email = $request->email;
        $dummy_pass =  str_random(8);
        $password = bcrypt($dummy_pass);
        $user->password = $password;
        $user->save();
        Mail::to($email)->send(new ForgotPassword($user->name,$dummy_pass));
       return 'Email has been sent.';
    }
    else
    {
      return "User with this email does not exist";
    }
  }

   public  function  instagramLogin ()  { 
        return  redirect ($this->instagram->getLoginUrl(array ( 
            'basic' 
        ))); 
    }
   
    public  function  instagramCallback (Request $request )  {       
      $code  =  $request->code ;

      $data  =  $this->instagram->getOAuthToken ($code ); 
      $this->instagram->setAccessToken($data);
      $user  =  $this->instagram->getUser();    
      $username = $user->data->full_name;
	  $userimage = $user->data->profile_picture;
	  $instagram_id =  User::where('instagram_id',$user->data->id)->first();  
	    if($instagram_id != ""){ 
	      return redirect()->route('home1')->with( ['loginval' => 1]);
	    }
	    else{
	      $signup_id = 1;
	     return redirect()->route('home1')->with( ['signup_id' => 1,'username'=>$username, 'useremail'=>'', 'userimage'=>$userimage] );
	  	}
    } 

    public function userprofile(Request $request)
    {
    	$userid = Auth::id();
    	$userdata = User::where('id',$userid)->first();

    	return view('frontend.profile')->with(compact('userdata'));
    }

    public function updateprofile(Request $request)
    {
    	
       $code = $request->cc_code;
     	
        $mainUser = User::find($request->userid);
        if($code!=""){
        	
        	$mainUser->country_code = $code;
        }
       
       	else{
       		
       		$mainUser->country_code = $request->get('originalcodeid');
       	}
       	 $code1 = $request->cc_in;

        if($code1!=""){
        	
        	$mainUser->country_initials = $code1;
        }
       
       	else{
       		
       		$mainUser->country_initials = $request->get('originalcodeinitial');
       	}

        $mainUser->name = $request->get('txtfn');

        $mainUser->email = $request->get('txtemail');       
        $mainUser->lastname = $request->get('txtln');
        //$mainUser->facebook_id = $request->get('facebook_id');
        $mainUser->phone_number = $request->get('phoneno1');
       // $mainUser->country_code = $request->get('country_code');
        $mainUser->dob = $request->get('bday');
        $mainUser->gender = $request->get('gender');
        $mainUser->role = '2';
       
       
        $image1 =  $request->image;

        if($image1!=""){
          $image = $image1->getClientOriginalName();
          if($image!= ""){      
            if (!file_exists( public_path('/profile'))) {
              mkdir(public_path('/profile'), 0777, true);
            }
            $path =public_path('/profile/');
            $image_name = $image; 
            $input['imagename'] = time().rand(10,10000).'.'.$image1->getClientOriginalExtension();
            $destinationPath = public_path('/profile');
            $image1->move($destinationPath, $input['imagename']);
            $mainUser->image  =  $input['imagename'];
          } 
        }
          if($mainUser->save())
            return 1;
          else
            return 2;
    }

  public function getplacelistings(Request $request,$id=null){

    if(Auth::check() && Auth::user()->userheaderstatus==1)
    {
      return Redirect::back()->withInput()->with("booking_modal", 1);     
    }
    


    if(Auth::check())
      $userid = Auth::user()->id;
    else
      $userid = "";

    if ($request->isMethod('post')) {
          if($id =="getplacelistingshome") {  

            $location = GeoIP::getLocation();
            $latitude = $location['lat'];
            $longitude = $location['lon']; 
            $provider =   PlaceProvider::where('status','1')->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->paginate(10);            
            $providerall  = PlaceProvider::where('status','1')->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->get(); 
            $filter = '0';
            $id = 'All';
          }

          $id = $request->catval;          
         if($request->get('latitude') != '' && $request->get('longitude') != ''){

            $latitude  = $request->latitude;
            $longitude  = $request->longitude;
            $filter = $request->get('filter');
           
            if($request->get('filter') == '0'){
               
              if( $id == 'All'){
            

              $provider = PlaceProvider::select(DB::raw("*, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->orderBy(DB::raw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 "), 'DESC')->paginate(10);

                }else{ 

                  $placecat_id = $request->catval;

                   $provider  = PlaceProvider::select(DB::raw("*,ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->where('cat_id',$placecat_id)->orderBy(DB::raw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 "), 'DESC')->paginate(10);
              }
 
             
            }elseif($request->get('filter') == '1'){

              if( $id == 'All'){

                        $provider  = PlaceProvider::select(DB::raw("*, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->orderBy('price_per_night','DESC')->paginate(10);
                      }else{ 

                      $placecat_id = $request->catval;
                       $provider  = PlaceProvider::select(DB::raw("*, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->where('cat_id',$placecat_id)->orderBy('price_per_night','DESC')->paginate(10);
                     } 
                  

            }elseif($request->get('filter') == '2'){

              if( $id == 'All'){
                    
                        $provider  = PlaceProvider::select(DB::raw("*, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->orderBy('price_per_night','ASC')->paginate(10);

                      }else{ 
                      $placecat_id = $request->catval;
                      
                        $provider  = PlaceProvider::select(DB::raw("*, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->where('cat_id',$placecat_id)->orderBy('price_per_night','ASC')->paginate(10);
                     
                     } 
                    
            }elseif($request->get('filter') == '3'){

                    if( $id == 'All'){

                             $provider  = PlaceProvider::select(DB::raw("*, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->orderBy('ratings','DESC')->paginate(10);
                      }else{ 
                          $placecat_id = $request->catval;
                           $provider  = PlaceProvider::select(DB::raw("*, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->where('cat_id',$placecat_id)->orderBy('ratings','DESC')->paginate(10);
                     }
                  

            }elseif($request->get('filter') == '4'){

              if( $id == 'All'){

                     $provider  = PlaceProvider::select(DB::raw("*, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->orderBy('ratings','ASC')->paginate(10);

                      }else{

                           $placecat_id = $request->catval;
                            $provider = PlaceProvider::select(DB::raw("*, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->where('cat_id',$placecat_id)->orderBy('ratings','ASC')->paginate(10);
                     
                     }
            }

          }else{


            $location = GeoIP::getLocation();
            $latitude = $location['lat'];
            $longitude = $location['lon'];
            $id = $request->catval;
             $filter = $request->get('filter');


              if($request->get('filter') == '0'){

               if($id =='All'){

                 $placecat_id = $request->catval;
                 $provider  = PlaceProvider::where('status','1')->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->paginate(10);

                 $providerall  = PlaceProvider::where('status','1')->where('cat_id',$placecat_id)->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->get();
                
              }else{

              
                  $placecat_id = $request->catval;
                  $provider  = PlaceProvider::where('status','1')->where('cat_id',$placecat_id)->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15"), 'DESC')->paginate(10); 
                  $provider_page  = PlaceProvider::where('status','1')->where('cat_id',$placecat_id)->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15"), 'DESC')->paginate(10); 

              }


            }elseif($request->get('filter') == '1'){

               if($id == 'All'){
                $provider  = PlaceProvider::where('status','1')->where('user_id','<>',$userid)->orderBy('price_per_night', 'DESC')->paginate(10);

                $provider_page  = PlaceProvider::where('status','1')->where('user_id','<>',$userid)->paginate(10); 


              }else{

                   $placecat_id = $request->catval;
                  $provider  = PlaceProvider::where('status','1')->where('cat_id',$placecat_id)->where('user_id','<>',$userid)->orderBy('price_per_night', 'DESC')->paginate(10);
                  $provider  = PlaceProvider::where('status','1')->where('cat_id',$placecat_id)->where('user_id','<>',$userid)->orderBy('price_per_night', 'DESC')->paginate(10);

              }

            }elseif($request->get('filter') == '2'){

                   if($id == 'All'){
                 $provider  = PlaceProvider::where('status','1')->where('user_id','<>',$userid)->orderBy('price_per_night', 'ASC')->paginate(10);

                   $provider_page  = PlaceProvider::where('status','1')->where('user_id','<>',$userid)->orderBy('price_per_night', 'ASC')->paginate(10); 
              }else{

                  $placecat_id = $request->catval;
                  $provider  = PlaceProvider::where('status','1')->where('cat_id',$placecat_id)->where('user_id','<>',$userid)->orderBy('price_per_night', 'ASC')->paginate(10);
                  $provider_page  = PlaceProvider::where('status','1')->where('user_id','<>',$userid)->orderBy('price_per_night', 'ASC')->paginate(10); 
              }

            }elseif($request->get('filter') == '3'){

              if($id == 'All'){
                $provider  = PlaceProvider::where('status','1')->where('user_id','<>',$userid)->orderBy('ratings', 'DESC')->paginate(10); 
                $provider  = PlaceProvider::where('status','1')->where('user_id','<>',$userid)->orderBy('ratings', 'DESC')->paginate(10); 

              }else{
                
                $placecat_id = $request->catval;
              $provider  = PlaceProvider::where('status','1')->where('cat_id',$placecat_id)->where('user_id','<>',$userid)->orderBy('ratings', 'DESC')->paginate(10);
               $provider  = PlaceProvider::where('status','1')->where('cat_id',$placecat_id)->where('user_id','<>',$userid)->orderBy('ratings', 'DESC')->paginate(10); 
           
              } 

            }elseif($request->get('filter') == '4'){

              if($id == 'All'){
                 $provider  = PlaceProvider::where('status','1')->where('user_id','<>',$userid)->orderBy('ratings', 'ASC')->paginate(10);
                 $provider_page  = PlaceProvider::where('status','1')->where('user_id','<>',$userid)->orderBy('ratings', 'ASC')->paginate(10);

              }else{
                 $placecat_id = $request->catval;
                $provider  = PlaceProvider::where('status','1')->where('user_id','<>',$userid)->where('cat_id',$placecat_id)->orderBy('ratings', 'ASC')->paginate(10);
                $provider_page  = PlaceProvider::where('status','1')->where('user_id','<>',$userid)->where('cat_id',$placecat_id)->orderBy('ratings', 'ASC')->paginate(10);  

              }

            }

          }
      }

     else if($id!="" && $id !="getplacelistingshome")
        {

        $placecat_id = base64_decode($id);
        $location = GeoIP::getLocation();
        $latitude = $location['lat'];
        $longitude = $location['lon']; 
        $filter = 0;
        $provider  = PlaceProvider::where('status','1')->where('cat_id',$placecat_id)->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->paginate(10);
        $providerall  = PlaceProvider::where('status','1')->where('cat_id',$placecat_id)->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->get(); 
       
       $place  = Place::orderBy('name')->get();
       $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','places')->get();
       $placecategories = array();
       $placedata = array();
       $attachments = array();
       $coupondata = array();
       $peoplecategories[] = 'All';
       foreach ($place as $key => $value) {
           //$placecategories[]=  $value->name;
          $placecategories[$key]['name'] = $value->name;
           $placecategories[$key]['id'] = $value->id;
        }     
          
         foreach ($coupon as $key1 => $value) {
        $day = date('Y-m-d',strtotime($value['created_at']));
        $date1 =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days"));
        $date_now = date('Y-m-d');
        
        if(strtotime($date1) >= strtotime($date_now)){
        //  $i++;
          $coupondata[$key1] = $value;
          $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value['background_image'];
          $coupondata[$key1]['valid_till'] =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days")); 
        }      
           
       }
       $arr = array_values($coupondata);  
      
        foreach ($provider as $key => $value) {
         $name = User::select('name','image')->where('id',$value->user_id)->first();
         $images = Attachment::where('places_provider_id',$value->id)->get();
         foreach ($images as $key1 => $value1) {
            $attachments[$key1] = $value1->filenames;
         } 
          if (strpos($name['image'], 'http') !== false) {
                  $image =  $name->image;
          }else{
                 $image = URL::to('/').'/profile/'.$name['image'];
          }
           if($value->ratings  == ""){
            $ratings = '5';
          }else{
            $ratings = $value->ratings;
          }
          $placedata[$key]['id'] = $value->id;
          $placedata[$key]['name'] = $name['name'];
          $placedata[$key]['title'] = $value['title'];
          $placedata[$key]['description'] = $value['description'];
          $placedata[$key]['total_guests'] = $value->total_guests;
          $placedata[$key]['amenities_offered'] =$value->amenities_offered;
          $placedata[$key]['latitude'] = $value->latitude;
          $placedata[$key]['longitude'] = $value->longitude;
          $placedata[$key]['ratings'] = $ratings;
          $placedata[$key]['attachments'] = $attachments;
          $placedata[$key]['address'] = $value->address;
          $placedata[$key]['price_per_night'] = $value->price_per_night;   
          $placedata[$key]['encodedid'] = $value->encodedid;            
        }  
        $location = array();
        $placeids = array();
        $loc= array();
        $i = 0;
        $j= 0;

        foreach ($providerall as $key => $value) {

          $placeids[$key] = $value->encodedid;
          
        }


        foreach ($providerall as $key => $value) {
          for($i=0;$i<=2;$i++)
          {
            if($i==0)
             $loc[$i] = $value->address;
           if($i==1)
             $loc[$i] = $value->latitude;
           if($i==2)
             $loc[$i] = $value->longitude;
          }
          $location[$j] = $loc;
          $j++;               
        }    

        
        $result['categories'] = $placecategories;
        $result['data'] = $placedata;
        $result['coupons'] = $arr;
        $type = "place";
      echo  view('frontend.booking_place')->with(compact('result','provider','location','id','filter','placecat_id','placeids','latitude','longitude'));
      die;
        }
      else
      {

        $location = GeoIP::getLocation();
        $latitude = $location['lat'];
        $longitude = $location['lon']; 
        $provider  = PlaceProvider::where('status','1')->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->paginate(10);
        $providerall  = PlaceProvider::where('status','1')->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->get(); 
      
     // $provider = $providerall;
      }
        $location = GeoIP::getLocation();
        $latitude = $location['lat'];
        $longitude = $location['lon']; 
        
        $providerall  = PlaceProvider::where('status','1')->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->get(); 
      

      $id = $request->catval;
      $filter = $request->get('filter');


       $place  = Place::orderBy('name')->get();
       $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','places')->get();
       $placecategories = array();
       $placedata = array();
       $attachments = array();
       $coupondata = array();
       $peoplecategories[] = 'All';
       foreach ($place as $key => $value) {
           //$placecategories[]=  $value->name;
          $placecategories[$key]['name'] = $value->name;
           $placecategories[$key]['id'] = $value->id;
        }     
          
      foreach ($coupon as $key1 => $value) {
        $day = date('Y-m-d',strtotime($value['created_at']));
        $date1 =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days"));
        $date_now = date('Y-m-d');
        
        if(strtotime($date1) >= strtotime($date_now)){
        //  $i++;
          $coupondata[$key1] = $value;
          $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value['background_image'];
          $coupondata[$key1]['valid_till'] =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days")); 
        }      
           
       }
       $arr = array_values($coupondata);
      
        foreach ($provider as $key => $value) {
         $name = User::select('name','image')->where('id',$value->user_id)->first();
         $images = Attachment::where('places_provider_id',$value->id)->get();
         foreach ($images as $key1 => $value1) {
            $attachments[$key1] = $value1->filenames;
         } 

         if($name){
          $name1 = $name->name;

           if (strpos($name->image, 'http') !== false) {
                  $image =  $name->image;
          }else{
                 $image = URL::to('/').'/profile/'.$name->image;
          }

        }else{
          $image =  '';
           $name1= '';

        }
         
           if($value->ratings  == ""){
            $ratings = '5';
          }else{
            $ratings = $value->ratings;
          }
          $placedata[$key]['id'] = $value->id;
          $placedata[$key]['name'] = $name1;
          $placedata[$key]['title'] = $value->title;
          $placedata[$key]['description'] = $value->description;
          $placedata[$key]['total_guests'] = $value->total_guests;
          $placedata[$key]['amenities_offered'] =$value->amenities_offered;
          $placedata[$key]['latitude'] = $value->latitude;
          $placedata[$key]['longitude'] = $value->longitude;
          $placedata[$key]['ratings'] = $ratings;
          $placedata[$key]['attachments'] = $attachments;
          $placedata[$key]['address'] = $value->address;
          $placedata[$key]['price_per_night'] = $value->price_per_night; 
          $placedata[$key]['encodedid'] = $value->encodedid;                 
        }  

         $placeids = array();
        $location = array();
        $loc= array();
        $i = 0;
        $j= 0;

         foreach ($providerall as $key => $value) {
          $placeids[$key] = $value->encodedid; 
          
        }

        foreach ($providerall as $key => $value) {
          for($i=0;$i<=2;$i++)
          {
            if($i==0)
             $loc[$i] = $value->address;
           if($i==1)
             $loc[$i] = $value->latitude;
           if($i==2)
             $loc[$i] = $value->longitude;
          }
          $location[$j] = $loc;
          $j++;               
        }    

        
        $result['categories'] = $placecategories;
        $result['data'] = $placedata;
        $result['coupons'] = $arr;
        $type = "place";


        if ($request->isMethod('post')) {

         $type = 1;
         

          $view = view('frontend.bookingplaceview',compact('result','provider_page','id','filter','location','type','provider'))->render();
            return response()->json(['html'=>$view]);
        }
         else{


          
      echo  view('frontend.booking_place')->with(compact('result','provider','location','id','filter','placeids','provider_page'));    
        }    
      }


  public function getpeoplelistings( Request $request,$id=null){
    if(Auth::check() && Auth::user()->userheaderstatus==1)
    {
      return Redirect::back()->withInput()->with("booking_modal", 1);     
    }
      if(Auth::check())
        $userid = Auth::user()->id;
      else
        $userid = "";
         if ($request->isMethod('post')) {
          $id = $request->catval;
          
         if($request->get('latitude') != '' && $request->get('longitude') != ''){

            $latitude  = $request->latitude;
            $longitude  = $request->longitude;
            $filter = $request->get('filter');
           
            if($request->get('filter') == '0'){
               
              if( $id == 'All'){

                $provider = PeopleProvider::select(DB::raw("*, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->orderBy(DB::raw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 "), 'DESC')->paginate(10);


                }else{ 
            
                   $placecat_id = $request->catval;

                   $provider  = PeopleProvider::select(DB::raw("*,ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->where('cat_id',$placecat_id)->orderBy(DB::raw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 "), 'DESC')->paginate(10);
               }

            
            }elseif($request->get('filter') == '1'){

              if( $id == 'All'){

                $provider  = PeopleProvider::select(DB::raw("*, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->orderBy('price_per_night','DESC')->paginate(10);

                      }else{ 

                      $placecat_id = $request->catval;
                     $provider  = PeopleProvider::select(DB::raw("*, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->where('cat_id',$placecat_id)->orderBy('price_per_night','DESC')->paginate(10);

                     
                     } 
                     $provider = DB::select(DB::raw($query));

            }elseif($request->get('filter') == '2'){

              if( $id == 'All'){
         
                     $provider  = PeopleProvider::select(DB::raw("*, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->orderBy('price_per_night','ASC')->paginate(10);


                      }else{ 

                    
                  $placecat_id = $request->catval;
                      
                      $provider  = PeopleProvider::select(DB::raw("*, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->where('cat_id',$placecat_id)->orderBy('price_per_night','ASC')->paginate(10);

                     
                     } 
                    

            }elseif($request->get('filter') == '3'){

                    if( $id == 'All'){

                          $provider  = PeopleProvider::select(DB::raw("*, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->orderBy('ratings','DESC')->paginate(10);


                      }else{         
                
                  $placecat_id = $request->catval;
                  $provider  = PeopleProvider::select(DB::raw("*, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->where('cat_id',$placecat_id)->orderBy('ratings','DESC')->paginate(10);
                          
                     
                     }
                     $provider = DB::select(DB::raw($query));

            }elseif($request->get('filter') == '4'){

              if( $id == 'All'){

                     $provider  = PeopleProvider::select(DB::raw("*, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->orderBy('ratings','ASC')->paginate(10);


                      }else{

                           $placecat_id = $request->catval;
                            $provider = PeopleProvider::select(DB::raw("*, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->where('cat_id',$placecat_id)->orderBy('ratings','ASC')->paginate(10);
                     
                     }
            }

          }else{


            $location = GeoIP::getLocation();
            $latitude = $location['lat'];
            $longitude = $location['lon']; 
            $id = $request->catval;
            

              if($request->get('filter') == '0'){

               if($id =='All'){

              
                 $provider = PeopleProvider::where('status','1')->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->paginate(10); 
                



              }else{

              
                  $placecat_id = $request->catval;
                  $provider  = PeopleProvider::where('status','1')->where('cat_id',$placecat_id)->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15"), 'DESC')->paginate(10); 

              }


            }elseif($request->get('filter') == '1'){

               if($id == 'All'){

                 $provider  = PeopleProvider::where('status','1')->where('user_id','<>',$userid)->orderBy('price_per_night', 'DESC')->paginate(10);

              }else{

                   $placecat_id = $request->catval;
                  $provider  = PeopleProvider::where('status','1')->where('cat_id',$placecat_id)->where('user_id','<>',$userid)->orderBy('price_per_night', 'DESC')->paginate(10);

              }

            }elseif($request->get('filter') == '2'){

                   if($id == 'All'){
                 $provider  = PeopleProvider::where('status','1')->where('user_id','<>',$userid)->orderBy('price_per_night', 'ASC')->paginate(10);
              }else{

                  $placecat_id = $request->catval;
                  $provider  = PeopleProvider::where('status','1')->where('cat_id',$placecat_id)->where('user_id','<>',$userid)->orderBy('price_per_night', 'ASC')->paginate(10); 
              }

            }elseif($request->get('filter') == '3'){

              if($id == 'All'){
                $provider  = PeopleProvider::where('status','1')->where('user_id','<>',$userid)->orderBy('ratings', 'DESC')->paginate(10); 
              }else{
                
                $placecat_id = $request->catval;
              $provider  = PeopleProvider::where('status','1')->where('cat_id',$placecat_id)->where('user_id','<>',$userid)->orderBy('ratings', 'DESC')->paginate(10); 
           
              } 

            }elseif($request->get('filter') == '4'){

              if($id == 'All'){
                 $provider  = PeopleProvider::where('status','1')->where('user_id','<>',$userid)->orderBy('ratings', 'ASC')->paginate(10); 
              }else{
                 $placecat_id = $request->catval;
                $provider  = PeopleProvider::where('status','1')->where('user_id','<>',$userid)->where('cat_id',$placecat_id)->orderBy('ratings', 'ASC')->paginate(10); 
              }

            }

          }
       }
         else if($id!="")
        {
        $people_id = base64_decode($id);
        $location = GeoIP::getLocation();
        $latitude = $location['lat'];
        $longitude = $location['lon']; 
        $filter = 0;
        $provider  = PeopleProvider::where('status','1')->where('cat_id',$people_id)->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->paginate(10); 
        $providerall  = PeopleProvider::where('status','1')->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->get(); 

        $people  = People::orderBy('name')->get();
        $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','people')->get();
       $peoplecategories = array();
       $peopledata = array();
       $coupondata = array();
       $peoplecategories=array();
       foreach ($people as $key => $value) {
           $peoplecategories[$key]['name'] = $value->name;
            $peoplecategories[$key]['id'] = $value->id;
       } 
        foreach ($coupon as $key1 => $value) {
        $day = date('Y-m-d',strtotime($value['created_at']));
        $date1 =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days"));
        $date_now = date('Y-m-d');
        
        if(strtotime($date1) >= strtotime($date_now)){
        //  $i++;
          $coupondata[$key1] = $value;
          $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value['background_image'];
          $coupondata[$key1]['valid_till'] =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days")); 
        }      
           
       }
       $arr = array_values($coupondata);    
      foreach ($provider as $key => $value) {
       $name = User::select('name','image')->where('id',$value->user_id)->first();
  
          if (strpos($name->image, 'http') !== false) {
                  $image =  $name->image;
          }else{
                 $image = URL::to('/').'/profile/'.$name->image;
          }
           if($value->ratings  == ""){
            $ratings = '5';
          }else{
            $ratings = $value->ratings;
          }
        $peopledata[$key]['id'] = $value->id;
        $peopledata[$key]['name'] = $value->name;
        $peopledata[$key]['title'] = $value->title;
        $peopledata[$key]['description'] = $name->description;
        $peopledata[$key]['latitude'] = $value->latitude;
        $peopledata[$key]['longitude'] = $value->longitude;
        $peopledata[$key]['ratings'] = $ratings;
        $peopledata[$key]['image'] = $image;
        $peopledata[$key]['description'] = $value->description;
        $peopledata[$key]['address'] = $value->address;
        $peopledata[$key]['hourly_price'] = $value->hourly_price;  
        $peopledata[$key]['price_per_night'] = $value->price_per_night;    
        $peopledata[$key]['encodedid'] = $value->encodedid;                   
      }
      $j = 0;
      $location = array();
      $placeids = array();


    foreach ($providerall as $key => $value) {

          $placeids[$key] = $value->encodedid;
           
        }


       foreach ($provider as $key => $value) {
          for($i=0;$i<=2;$i++)
          {
            if($i==0)
             $loc[$i] = $value->address;
           if($i==1)
             $loc[$i] = $value->latitude;
           if($i==2)
             $loc[$i] = $value->longitude;
          }
          $location[$j] = $loc;
          $j++;               
        } 
        $result['categories'] = $peoplecategories;
        $result['data'] = $peopledata;
        $result['coupons'] = $arr;

        echo  view('frontend.booking_people')->with(compact('result','provider','id','filter','location','people_id','placeids','latitude','longitude')); 
        die;
      }
      else
      {
         $location = GeoIP::getLocation();
            $latitude = $location['lat'];
            $longitude = $location['lon']; 
        
            $provider = PeopleProvider::where('status','1')->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->paginate(10); 



         $providerall  = PeopleProvider::where('status','1')->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->get(); 
      }
      $id = $request->catval;
      $filter = $request->get('filter');

        $location = GeoIP::getLocation();
        $latitude = $location['lat'];
        $longitude = $location['lon']; 
         $providerall  = PeopleProvider::where('status','1')->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->get();  

       /* $provider  = PeopleProvider::orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15"), 'DESC')->paginate(10);*/
        $people  = People::orderBy('name')->get();
        $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','people')->get();
       $peoplecategories = array();
       $peopledata = array();
       $coupondata = array();
       $peoplecategories=array();
       foreach ($people as $key => $value) {
           $peoplecategories[$key]['name'] = $value->name;
            $peoplecategories[$key]['id'] = $value->id;
       } 
         foreach ($coupon as $key1 => $value) {
        $day = date('Y-m-d',strtotime($value['created_at']));
        $date1 =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days"));
        $date_now = date('Y-m-d');
        
        if(strtotime($date1) >= strtotime($date_now)){
        //  $i++;
          $coupondata[$key1] = $value;
          $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value['background_image'];
          $coupondata[$key1]['valid_till'] =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days")); 
        }      
           
       }
       $arr = array_values($coupondata); 
      foreach ($provider as $key => $value) {
       $name = User::select('name','image')->where('id',$value->user_id)->first();
  
          if (strpos($name->image, 'http') !== false) {
                  $image =  $name->image;
          }else{
                 $image = URL::to('/').'/profile/'.$name->image;
          }
           if($value->ratings  == ""){
            $ratings = '5';
          }else{
            $ratings = $value->ratings;
          }
        $peopledata[$key]['id'] = $value->id;
        $peopledata[$key]['name'] = $value->name;
        $peopledata[$key]['title'] = $value->title;
        $peopledata[$key]['description'] = $name->description;
        $peopledata[$key]['latitude'] = $value->latitude;
        $peopledata[$key]['longitude'] = $value->longitude;
        $peopledata[$key]['ratings'] = $ratings;
        $peopledata[$key]['image'] = $image;
        $peopledata[$key]['description'] = $value->description;
        $peopledata[$key]['address'] = $value->address;
        $peopledata[$key]['hourly_price'] = $value->hourly_price;  
        $peopledata[$key]['price_per_night'] = $value->price_per_night;  
        $peopledata[$key]['encodedid'] = $value->encodedid;           
      }
      $j = 0;
      $location = array();
      $placeids = array();

       foreach ($providerall as $key => $value) {

          $placeids[$key] = $value->encodedid;
          
        }

       foreach ($provider as $key => $value) {
          for($i=0;$i<=2;$i++)
          {
            if($i==0)
             $loc[$i] = $value->address;
           if($i==1)
             $loc[$i] = $value->latitude;
           if($i==2)
             $loc[$i] = $value->longitude;
          }
          $location[$j] = $loc;
          $j++;               
        } 


      $result['categories'] = $peoplecategories;
      $result['data'] = $peopledata;
      $result['coupons'] = $arr;

      if ($request->isMethod('post')) {
        
         
          $view = view('frontend.bookingpeopleview',compact('result','provider','id','filter','location','latitude','longitude'))->render();
            return response()->json(['html'=>$view]);
        }
         else{
        // echo "<pre>"; print_r($location); die;

          echo  view('frontend.booking_people')->with(compact('result','provider','id','filter','location','placeids')); 
        }
    }


    public function getthingslistings(Request $request,$id=null){ 

       if(Auth::check() && Auth::user()->userheaderstatus==1)
    {
      return Redirect::back()->withInput()->with("booking_modal", 1);     
    }

        if(Auth::check())
        $userid = Auth::user()->id;
      else
        $userid = "";

        if ($request->isMethod('post')) {
          $id = $request->catval;
          
         if($request->get('latitude') != '' && $request->get('longitude') != ''){
              $latitude  = $request->latitude;
              $longitude  = $request->longitude;
              $filter = $request->get('filter');
            if($request->get('filter') == '0'){
              if( $id == 'All'){   

                $provider = ThingProvider::select(DB::raw("*, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->orderBy(DB::raw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 "), 'DESC')->paginate(10);

              }else{ 
                $placecat_id = $request->catval;
                $provider  = ThingProvider::select(DB::raw("*,ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->where('cat_id',$placecat_id)->orderBy(DB::raw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 "), 'DESC')->paginate(10);
              }
              
            }elseif($request->get('filter') == '1'){

              if( $id == 'All'){
                $provider  = ThingProvider::select(DB::raw("*, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->orderBy('price_per_night','DESC')->paginate(10);


              }else{ 

              $placecat_id = $request->catval;
               $provider  = ThingProvider::select(DB::raw("*, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->where('cat_id',$placecat_id)->orderBy('price_per_night','DESC')->paginate(10);
             } 
                    

            }elseif($request->get('filter') == '2'){

              if( $id == 'All'){
         
                      $provider  = ThingProvider::select(DB::raw("*, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->orderBy('price_per_night','ASC')->paginate(10);

                      }else{ 

                    
                      $placecat_id = $request->catval;
                        $provider  = ThingProvider::select(DB::raw("*, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->where('cat_id',$placecat_id)->orderBy('price_per_night','ASC')->paginate(10);
                     
                     } 
                    

            }elseif($request->get('filter') == '3'){

                    if( $id == 'All'){

                        $provider  = ThingProvider::select(DB::raw("*, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->orderBy('ratings','DESC')->paginate(10);


                      }else{ 

                           
                
                  $placecat_id = $request->catval;
                         $provider  = ThingProvider::select(DB::raw("*, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->where('cat_id',$placecat_id)->orderBy('ratings','DESC')->paginate(10);
                     
                     }
                   

            }elseif($request->get('filter') == '4'){

              if( $id == 'All'){

                    $provider  = ThingProvider::select(DB::raw("*, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->orderBy('ratings','ASC')->paginate(10);


                      }else{

                           $placecat_id = $request->catval;
                           $provider = ThingProvider::select(DB::raw("*, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS( $request->latitude ) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS( $request->latitude )) * COS( RADIANS( `longitude` ) - RADIANS( $request->longitude )) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->where('cat_id',$placecat_id)->orderBy('ratings','ASC')->paginate(10);
                     
                     }
                     $provider = DB::select(DB::raw($query));

            }

          }else{


            $location = GeoIP::getLocation();
            $latitude = $location['lat'];
            $longitude = $location['lon']; 
            $id = $request->catval;

             $providerall  = ThingProvider::where('status','1')->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->get();

              if($request->get('filter') == '0'){

               if($id =='All'){
              
                 $provider  = ThingProvider::where('status','1')->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->paginate(10);
                
              }else{
                  $placecat_id = $request->catval;
                  $provider  = ThingProvider::where('status','1')->where('cat_id',$placecat_id)->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15"), 'DESC')->paginate(10); 
              }


            }elseif($request->get('filter') == '1'){

               if($id == 'All'){

                 $provider  = ThingProvider::where('status','1')->where('user_id','<>',$userid)->orderBy('price_per_night', 'DESC')->paginate(10);
                  $providerall  = ThingProvider::where('status','1')->where('user_id','<>',$userid)->orderBy('price_per_night', 'DESC')->paginate(10);


              }else{

                   $placecat_id = $request->catval;
                  $provider  = ThingProvider::where('status','1')->where('user_id','<>',$userid)->where('cat_id',$placecat_id)->orderBy('price_per_night', 'DESC')->paginate(10);


              }

            }elseif($request->get('filter') == '2'){

                   if($id == 'All'){
                 $provider  = ThingProvider::where('status','1')->where('user_id','<>',$userid)->orderBy('price_per_night', 'ASC')->paginate(10);
              }else{

                  $placecat_id = $request->catval;
                  $provider  = ThingProvider::where('status','1')->where('user_id','<>',$userid)->where('cat_id',$placecat_id)->orderBy('price_per_night', 'ASC')->paginate(10);
              }

            }elseif($request->get('filter') == '3'){

              if($id == 'All'){
                $provider  = ThingProvider::where('status','1')->where('user_id','<>',$userid)->orderBy('ratings', 'DESC')->paginate(10);
              }else{
                
                $placecat_id = $request->catval;
              $provider  = ThingProvider::where('status','1')->where('cat_id',$placecat_id)->where('user_id','<>',$userid)->orderBy('ratings', 'DESC')->paginate(10);
           
              } 

            }elseif($request->get('filter') == '4'){

              if($id == 'All'){
                 $provider  = ThingProvider::where('status','1')->where('user_id','<>',$userid)->orderBy('ratings', 'ASC')->paginate(10); 
              }else{
                 $placecat_id = $request->catval;
                $provider  = ThingProvider::where('status','1')->where('user_id','<>',$userid)->where('cat_id',$placecat_id)->orderBy('ratings', 'ASC')->paginate(10); 
              }

            }

          }
      }
      else if($id!="")
      {

        $thing_id = base64_decode($id);
        $location = GeoIP::getLocation();
        $latitude = $location['lat'];
        $longitude = $location['lon']; 
        $filter = 0;
        $provider  = ThingProvider::where('status','1')->where('cat_id',$thing_id)->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->paginate(10); 

        $providerall  = ThingProvider::where('status','1')->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->get(); 

        $people  = Thing::orderBy('name')->get();
        $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','things')->get();
       $peoplecategories = array();
       $thingdata = array();
       $attachments = array();
       $coupondata = array();
       $thingcategories= array();
      foreach ($people as $key => $value) {
       
        $thingcategories[$key]['name'] = $value->name;
         $thingcategories[$key]['id'] = $value->id;
      }  
      foreach ($coupon as $key1 => $value) {
        $day = date('Y-m-d',strtotime($value['created_at']));
        $date1 =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days"));
        $date_now = date('Y-m-d');
        
        if(strtotime($date1) >= strtotime($date_now)){
        //  $i++;
          $coupondata[$key1] = $value;
          $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value['background_image'];
          $coupondata[$key1]['valid_till'] =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days")); 
        }      
           
       }
       $arr = array_values($coupondata);
      
      foreach ($provider as $key => $value) {
        $name = User::select('name','image')->where('id',$value->user_id)->first();
        $images = Attachment::where('things_provider_id',$value->id)->get();
       foreach ($images as $key1 => $value1) {
          $attachments[$key1] = URL::to('/').'/attachments/'.$value1->filenames;
        }
          if (strpos($name->image, 'http') !== false) {
                  $image =  $name->image;
          }else{
                 $image = URL::to('/').'/profile/'.$name->image;
          }
           if($value->ratings  == ""){
            $ratings = '5';
          }else{
            $ratings = $value->ratings;
          }
        $thingdata[$key]['id'] = $value->id;
        $thingdata[$key]['name'] = $value->title;
        $thingdata[$key]['owned_by'] = $name->name;
        $thingdata[$key]['latitude'] = $value->latitude;
        $thingdata[$key]['longitude'] = $value->longitude;
        $thingdata[$key]['ratings'] = $ratings;
        $thingdata[$key]['attachments'] = $attachments;
        $thingdata[$key]['description'] = $value->description;
        $thingdata[$key]['address'] = $value->address;
        $thingdata[$key]['price_per_night'] = $value->price_per_night;
        $thingdata[$key]['encodedid'] = $value->encodedid;               
      } 
      $location= array();
      $placeids  = array();

    foreach ($providerall as $key => $value) {

          $placeids[$key] = $value->encodedid;
           
        }

      $j = 0;
      foreach ($provider as $key => $value) {
          for($i=0;$i<=2;$i++)
          {
            if($i==0)
             $loc[$i] = $value->address;
           if($i==1)
             $loc[$i] = $value->latitude;
           if($i==2)
             $loc[$i] = $value->longitude;
          }
          $location[$j] = $loc;
          $j++;               
        }   
      $result['status'] = 1;
      $result['categories'] = $thingcategories;
      $result['data'] = $thingdata;
      $result['coupons'] = $arr;
      echo  view('frontend.booking_thing')->with(compact('result','provider','id','filter','location','thing_id','placeids','latitude','longitude')); 
      die;
    }
      else
      {

         $location = GeoIP::getLocation();
            $latitude = $location['lat'];
            $longitude = $location['lon']; 
         $provider  = ThingProvider::where('status','1')->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->paginate(10);
          $providerall  = ThingProvider::where('status','1')->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->get(); 
      }

      $id = $request->catval;
      $filter = $request->get('filter');  

          $location = GeoIP::getLocation();
          $latitude = $location['lat'];
          $longitude = $location['lon']; 
         $providerall  = ThingProvider::where('status','1')->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->get();   

   
      $people  = Thing::orderBy('name')->get();
      $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','things')->get();
     $peoplecategories = array();
     $thingdata = array();
     $attachments = array();
     $coupondata = array();
     $thingcategories= array();
      foreach ($people as $key => $value) {
       
        $thingcategories[$key]['name'] = $value->name;
         $thingcategories[$key]['id'] = $value->id;
      }  
       foreach ($coupon as $key1 => $value) {
        $day = date('Y-m-d',strtotime($value['created_at']));
        $date1 =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days"));
        $date_now = date('Y-m-d');
        
        if(strtotime($date1) >= strtotime($date_now)){
        //  $i++;
          $coupondata[$key1] = $value;
          $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value['background_image'];
          $coupondata[$key1]['valid_till'] =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days")); 
        }      
           
       }
       $arr = array_values($coupondata);
      
      foreach ($provider as $key => $value) {
        $name = User::select('name','image')->where('id',$value->user_id)->first();
        $images = Attachment::where('things_provider_id',$value->id)->get();
       foreach ($images as $key1 => $value1) {
          $attachments[$key1] = URL::to('/').'/attachments/'.$value1->filenames;
        }
          if (strpos($name->image, 'http') !== false) {
                  $image =  $name->image;
          }else{
                 $image = URL::to('/').'/profile/'.$name->image;
          }
           if($value->ratings  == ""){
            $ratings = '5';
          }else{
            $ratings = $value->ratings;
          }
        $thingdata[$key]['id'] = $value->id;
        $thingdata[$key]['name'] = $value->title;
        $thingdata[$key]['owned_by'] = $name->name;
        $thingdata[$key]['latitude'] = $value->latitude;
        $thingdata[$key]['longitude'] = $value->longitude;
        $thingdata[$key]['ratings'] = $ratings;
        $thingdata[$key]['attachments'] = $attachments;
        $thingdata[$key]['description'] = $value->description;
        $thingdata[$key]['address'] = $value->address;
        $thingdata[$key]['price_per_night'] = $value->price_per_night;
        $thingdata[$key]['encodedid'] = $value->encodedid;                       
      } 
      $location = array();
       $placeids = array();
        $loc= array();
        $i = 0;
        $j= 0;


        foreach ($providerall as $key => $value) {

          $placeids[$key] = $value->encodedid;
          
        }


        foreach ($providerall as $key => $value) {
          for($i=0;$i<=2;$i++)
          {
            if($i==0)
             $loc[$i] = $value->address;
           if($i==1)
             $loc[$i] = $value->latitude;
           if($i==2)
             $loc[$i] = $value->longitude;
          }
          $location[$j] = $loc;
          $j++;               
        }    
       
        
      $result['status'] = 1;
      $result['categories'] = $thingcategories;
      $result['data'] = $thingdata;
      $result['coupons'] = $arr;
      if ($request->isMethod('post')) {
         
          $view = view('frontend.bookingthingview',compact('result','provider','id','filter','location','latitude','longitude'))->render();
            return response()->json(['html'=>$view]);
        }
         else{

           echo  view('frontend.booking_thing')->with(compact('result','provider','id','filter','location','placeids')); 
        }
    }

    public function getcategorylisting(Request $request,$id)
    {
      $url = request()->segment(1);

    }

    public function addplacesdetails(Request $request)
    {

       if ($request->isMethod('post')) 
        {
          $loggedInUser = Auth::user();

          if($request->get('subcatlist') == "other"){
            $subcategory = Place_Subcat::where('name' , $request->get('subcatname'))->where('user_id' , $loggedInUser->id)->first();
          if($subcategory){
              $subcategory_id = $subcategory->id;
          }else{
              $SUBCATEGORY = new Place_Subcat;
              $SUBCATEGORY->places_cat_id = $request->get('catdata');
              $SUBCATEGORY->name = $request->get('subcatname');
              $SUBCATEGORY->user_id = $loggedInUser->id;
              $SUBCATEGORY->save(); 
              $subcategory = Place_Subcat::where('name' , $request->get('subcatname'))->where('user_id' , $loggedInUser->id)->first(); 

              $subcategory_id = $subcategory->id;
            }
          }else{
                $subcategory_id = $request->get('subcatlist');                 
          }

          $provider = new PlaceProvider;
          $provider->cat_id = $request->get('catdata');
          $provider->subcat_id = $subcategory_id;
          $provider->title = $request->get('title');
          $provider->user_id = $loggedInUser->id;
          $provider->description = $request->get('description');
          $provider->country = $request->get('country');
          $provider->address = $request->get('address');
          $provider->latitude = $request->get('latitude');
          $provider->longitude = $request->get('longitude');
          $arramenities = implode(",",$request->amenities);
          $provider->amenities_offered = $arramenities;
          $provider->total_guests = $request->guest;
          $provider->host_name = $request->host_name;
          $provider->host_phone = $request->host_phone;

          
          $provider->unavailable_dates = $request->dates;
          if($request->pet_allow!="")
          $provider->pet_allowance = "true";
          else
          $provider->pet_allowance = "false";
          if($request->host_facility!="")
           $provider->host_facility = "true";
          else
          $provider->host_facility = "false";
         $provider->time_in = $request->timepicker_in;
         $provider->time_out = $request->timepicker_out;
         $provider->price_per_night = $request->pricingpernight;
         $provider->rules = $request->rules;
         $provider->percent_status = 3;
        
        $provider->save();
        $encodedidplace = $provider->id;
        PlaceProvider::where('id',$encodedidplace)->update(['encodedid'=>base64_encode($encodedidplace)]);
         
         if($files=$request->file('uploadfile')){
        foreach($files as $file){
           $pics = new Attachment;
           $pics->places_provider_id = $provider->id;
          $name=$file->getClientOriginalName();
          if (!file_exists( public_path('/attachments'))) {
            mkdir(public_path('/attachments'), 0777, true);
          }
          $path =public_path('/attachments/');
         
          $input['imagename'] = time().rand(10,10000).'.'.$file->getClientOriginalExtension();
          $destinationPath = public_path('/attachments');
         $file->move($destinationPath, $input['imagename']);
         $pics->filenames  =  $input['imagename'];
         $pics->save();
        }
      }    
      $attachments = Attachment::select('filenames')->where('places_provider_id',$provider->id)->get();  
      $placedetails = PlaceProvider::where('id',$provider->id)->first(); 
      $pid = base64_encode($provider->id);  


      return redirect()->route('confirmplacedetails',$pid)->with( ['providerid' => $provider->id,'pics'=>$attachments,'placedetails'=>$placedetails]);              
      }
    
      $place = Place::orderBy('name')->get(); 
      return view('frontend.becomeplacesprovider')->with(compact('place'));
    }
    public function bookingplacedetail(Request $request,$id=null)
    {
     /* if(!Auth::check())
      {
        return redirect()->route('home1')->with( ['loginid11' =>11]);
      }*/
      $attachments = Attachment::select('filenames')->where('places_provider_id',$id)->get();  
      $placedetails = PlaceProvider::where('id',$id)->first(); 
      $userdet = User::where('id',$placedetails['user_id'])->first();
      return view('frontend.booking_placedetail')->with(compact('attachments','placedetails','id','userdet'))  ;
    }
    public function bookingplaceavailability(Request $request,$id=null)
    {
      $id = base64_decode($id);
      if(Auth::check())
      {
        $user_id = Auth::id();
        $favourite =   Favourite::where('places_provider_id',$id)->where('user_id', $user_id)->value('favourite');        
      }
      $attachments = Attachment::select('filenames')->where('places_provider_id',$id)->get(); 
      $allimages = array();
      foreach ($attachments as $key => $value) {
        $allimages[$key]= URL::to('/').'/attachments/'.$value['filenames'];
      }
      $placedetails = PlaceProvider::where('id',$id)->first();
      $unavailable_dates_booking = array();
            $date_new = array();
            $booking_data = Booking::where('places_provider_id',$id)->where('status','1')->get();
          if($booking_data){
               foreach ($booking_data as $key => $value) {
                if(date("Y-m-d", strtotime($value->check_in)) == date("Y-m-d",strtotime($value->check_out))){
               $date_new[] =  $this->getDatesFromRange(date("Y-m-d", strtotime($value->check_in)), date("Y-m-d",strtotime($value->check_out)));
               }else{
                $date_new[] =  $this->getDatesFromRange(date("Y-m-d", strtotime($value->check_in)), date("Y-m-d",strtotime('-1 day',strtotime($value->check_out))));
                }
              }

            
                $newdates[] =  $placedetails['unavailable_dates'];              
                if(empty($date_new)){

                  $final_bookingdateslist = array(); 
                }else{

                $final_bookingdateslist = call_user_func_array("array_merge", $date_new); 

                $newdates[] = implode(',', $final_bookingdateslist);

                }
                  $final_unavailable_dates = implode(',', array_filter($newdates));

                  $unavailable_dates = $final_unavailable_dates;                                         
               
            }
      $userdet = User::where('id',$placedetails['user_id'])->first();

      $reviews_place= Review::where('places_provider_id',$id)->where('reviews','<>','')->orderBy('created_at','Desc')->take(3)->get();
      $review_place = array();

      if($reviews_place){    
        foreach($reviews_place as $key => $value){
          $provider = PlaceProvider::where('id',$value->places_provider_id)->first();

          $user = User::where('id',$value->user_id)->first();
          $review_place[$key]['reviews'] = $value->reviews; 
          $review_place[$key]['datemonth'] = date('F',strtotime($value->created_at));
          $review_place[$key]['dateyear'] = date('Y',strtotime($value->created_at)); 
          $review_place[$key]['title'] = $provider->title;
          $review_place[$key]['user'] = $user->name; 
          $review_place[$key]['image'] = URL::to('/').'/profile/'.$user->image; 
          $review_place[$key]['ratings'] = $value->ratings; 
        }  
      }


      return view('frontend.booking_placeavailability')->with(compact('attachments','placedetails','id','userdet','favourite','review_place','allimages','unavailable_dates'))  ;
    }
    public function addthingdetails(Request $request)
    {
      if ($request->isMethod('post')) 
        {
          $loggedInUser = Auth::user();

          if($request->get('subcatlist') == "other"){
            $subcategory = Thing_Subcat::where('name' , $request->get('subcatname'))->where('user_id' , $loggedInUser->id)->first();
          if($subcategory){
              $subcategory_id = $subcategory->id;
          }else{
              $SUBCATEGORY = new Thing_Subcat;
              $SUBCATEGORY->things_cat_id = $request->get('catdata');
              $SUBCATEGORY->name = $request->get('subcatname');
              $SUBCATEGORY->user_id = $loggedInUser->id;
              $SUBCATEGORY->save(); 
              $subcategory = Thing_Subcat::where('name' , $request->get('subcatname'))->where('user_id' , $loggedInUser->id)->first(); 

              $subcategory_id = $subcategory->id;
            }
          }else{
            $subcategory_id = $request->get('subcatlist');                 
          }

          $provider = new ThingProvider;
          $provider->cat_id = $request->get('catdata');
          $provider->subcat_id = $subcategory_id;
          $provider->title = $request->get('title');
          $provider->user_id = $loggedInUser->id;
          $provider->description = $request->get('description');
          $provider->address = $request->get('address');
          $provider->latitude = $request->get('latitude');
          $provider->longitude = $request->get('longitude');
          $provider->unavailable_dates = $request->dates;
          $provider->time_in = $request->timepicker_in;
          $provider->time_out = $request->timepicker_out;
          $provider->price_per_night = $request->pricingpernight;
          $provider->rules = $request->rules;
          $provider->condition = $request->condition;
           $provider->percent_status = 3;
        
          $provider->save();
          $encodedidplace = $provider->id;
          ThingProvider::where('id',$encodedidplace)->update(['encodedid'=>base64_encode($encodedidplace)]);
         
         if($files=$request->file('uploadfile')){
        foreach($files as $file){
           $pics = new Attachment;
           $pics->things_provider_id = $provider->id;
          $name=$file->getClientOriginalName();
          if (!file_exists( public_path('/attachments'))) {
            mkdir(public_path('/attachments'), 0777, true);
          }
          $path =public_path('/attachments/');
         
          $input['imagename'] = time().rand(10,10000).'.'.$file->getClientOriginalExtension();
          $destinationPath = public_path('/attachments');
         $file->move($destinationPath, $input['imagename']);
         $pics->filenames  =  $input['imagename'];
         $pics->save();
        }
      }    
      $attachments = Attachment::select('filenames')->where('things_provider_id',$provider->id)->get();  
      $thingsdetails = ThingProvider::where('id',$provider->id)->first(); 
       $pid = base64_encode($provider->id);  
      return redirect()->route('confirmthingdetails',$pid)->with( ['providerid' => 
        $provider->id,'pics'=>$attachments,'thingsdetails'=>$thingsdetails]);
      }
      $thing = Thing::orderBy('name')->get(); 
      return view('frontend.becomethingsprovider')->with(compact('thing'));       
    }

     public function test(Request $request)
    {

      $all =  PeopleProvider::all();
       foreach($all as $a)
       PeopleProvider::where('id',$a['id'])->update(['encodedid'=>base64_encode($a['id'])]);
    }
    public function bookingthingdetail(Request $request,$id=null)
    {
      /*if(!Auth::check())
      {
        return redirect()->route('home1')->with( ['loginid11' =>11]);
      }*/
      $attachments = Attachment::select('filenames')->where('things_provider_id',$id)->get();  
      $thingsdetails = ThingProvider::where('id',$id)->first();
      $userdet = User::where('id',$thingsdetails['user_id'])->first();
      return view('frontend.booking_thingdetail')->with(compact('attachments','thingsdetails','id','userdet'))  ;
    }
    public function bookingthingavailability(Request $request,$id=null)
    {
      if(Auth::check())
      {
        $user_id = Auth::id();
        $favourite =   Favourite::where('things_provider_id',$id)->where('user_id', $user_id)->value('favourite');     
      }
      $id = base64_decode($id);
      $attachments = Attachment::select('filenames')->where('things_provider_id',$id)->get();  
      $allimages = array();
      foreach ($attachments as $key => $value) {
        $allimages[$key]= URL::to('/').'/attachments/'.$value['filenames'];
      }
      $thingsdetails = ThingProvider::where('id',$id)->first();

       $unavailable_dates_booking = array();
            $date_new = array();
            $booking_data = Booking::where('things_provider_id',$id)->where('status','1')->get();
           // return $booking_data;
           if($booking_data){
               foreach ($booking_data as $key => $value) {
                if(date("Y-m-d", strtotime($value->check_in)) == date("Y-m-d",strtotime($value->check_out))){
               $date_new[] =  $this->getDatesFromRange(date("Y-m-d", strtotime($value->check_in)), date("Y-m-d",strtotime($value->check_out)));
               }else{
                $date_new[] =  $this->getDatesFromRange(date("Y-m-d", strtotime($value->check_in)), date("Y-m-d",strtotime('-1 day',strtotime($value->check_out))));
                }
              }

            
                $newdates[] =  $thingsdetails['unavailable_dates'];              
                if(empty($date_new)){

                  $final_bookingdateslist = array(); 
                }else{

                $final_bookingdateslist = call_user_func_array("array_merge", $date_new); 

                $newdates[] = implode(',', $final_bookingdateslist);

                }
                  $final_unavailable_dates = implode(',', array_filter($newdates));

                  $unavailable_dates = $final_unavailable_dates;                                         
               
            }
            

      $userdet = User::where('id',$thingsdetails['user_id'])->first();

      $reviewsthings = Review::where('things_provider_id',$id)->orderBy('created_at','desc')->where('reviews','<>','')->take(3)->get();

      $review_things = array();

    if($reviewsthings){
      foreach($reviewsthings as $key => $value){
        $provider = ThingProvider::where('id',$value->things_provider_id)->first();
        $user = User::where('id',$value->user_id)->first();
        $review_things[$key]['reviews'] = $value->reviews; 
        $review_things[$key]['title'] = $provider->title;
        $review_things[$key]['datemonth'] = date('F',strtotime($value->created_at));
        $review_things[$key]['dateyear'] = date('Y',strtotime($value->created_at));
        $review_things[$key]['user'] = $user->name; 
        $review_things[$key]['image'] = URL::to('/').'/profile/'.$user->image; 
        $review_things[$key]['ratings'] = $value->ratings; 
      }
    }
   // return $unavailable_dates;

      return view('frontend.booking_thingavailability')->with(compact('attachments','thingsdetails','id','userdet','favourite','review_things','allimages','unavailable_dates'))  ;
    }

    public function addservicedetails(Request $request)
    {
      if ($request->isMethod('post')) 
        {
          $loggedInUser = Auth::user();

          if($request->get('subcatlist') == "other"){
            $subcategory = People_Subcat::where('name' , $request->get('subcatname'))->where('user_id' , $loggedInUser->id)->first();
          if($subcategory){
              $subcategory_id = $subcategory->id;
          }else{
              $SUBCATEGORY = new People_Subcat;
              $SUBCATEGORY->people_cat_id = $request->get('catdata');
              $SUBCATEGORY->name = $request->get('subcatname');
              $SUBCATEGORY->user_id = $loggedInUser->id;
              $SUBCATEGORY->save(); 
              $subcategory = People_Subcat::where('name' , $request->get('subcatname'))->where('user_id' , $loggedInUser->id)->first(); 

              $subcategory_id = $subcategory->id;
            }
          }else{
            $subcategory_id = $request->get('subcatlist');                 
          }
          $provider = new PeopleProvider;
          $provider->cat_id = $request->get('catdata');
          $provider->subcat_id = $subcategory_id;
          $provider->title = $request->get('title');
          $provider->user_id = $loggedInUser->id;
          $provider->description = $request->get('description');
          $provider->country = $request->get('country');
          $provider->address = $request->get('address');
          $provider->latitude = $request->get('latitude');
          $provider->longitude = $request->get('longitude');
          $provider->available_dates = $request->dates;
         $provider->time_in = $request->timepicker_in;
         $provider->time_out = $request->timepicker_out;
         $provider->price_per_night = $request->pricingpernight;
         $provider->percent_status = 2;

         $provider->save();
          $encodedidplace = $provider->id;
          PeopleProvider::where('id',$encodedidplace)->update(['encodedid'=>base64_encode($encodedidplace)]);
         
         if($files=$request->file('uploadfile')){
        foreach($files as $file){
           $pics = new Attachment;
           $pics->people_provider_id = $provider->id;
          $name=$file->getClientOriginalName();
          if (!file_exists( public_path('/attachments'))) {
            mkdir(public_path('/attachments'), 0777, true);
          }
          $path =public_path('/attachments/');
         
          $input['imagename'] = time().rand(10,10000).'.'.$file->getClientOriginalExtension();
          $destinationPath = public_path('/attachments');
         $file->move($destinationPath, $input['imagename']);
         $pics->filenames  =  $input['imagename'];
         $pics->save();
        }
      }    
      $attachments = Attachment::select('filenames')->where('people_provider_id',$provider->id)->get();  
      $peopledetails = PeopleProvider::where('id',$provider->id)->first();
       $pid = base64_encode($provider->id);  

      return redirect()->route('confirmservicedetails',$pid)->with( ['providerid' => $provider->id,'pics'=>$attachments,'peopledetails'=>$peopledetails]);
      }       
      $people = People::orderBy('name')->get(); 
      return view('frontend.becomeserviceprovider')->with(compact('people'));    
    }
    public function bookingpeopledetail(Request $request,$id=null)
    {
      /*if(!Auth::check())
      {
        return redirect()->route('home1')->with( ['loginid11' =>11]);
      }*/
      $attachments = Attachment::select('filenames')->where('people_provider_id',$id)->get();  
      $peopledetails = PeopleProvider::where('id',$id)->first(); 
      $userdet = User::where('id',$peopledetails['user_id'])->first();
      return view('frontend.booking_peopledetail')->with(compact('attachments','peopledetails','id','userdet')) ;
    }
     public function bookingpeopleavailability(Request $request,$id=null)
    {
      if(Auth::check())
      {
        $user_id = Auth::id();
        $favourite =   Favourite::where('people_provider_id',$id)->where('user_id', $user_id)->first();
      }
      $id = base64_decode($id);
      $attachments = Attachment::select('filenames')->where('people_provider_id',$id)->get();  
      $allimages = array();
      foreach ($attachments as $key => $value) {
        $allimages[$key]= URL::to('/').'/attachments/'.$value['filenames'];
      }
      $peopledetails = PeopleProvider::where('id',$id)->first();
      $unavailable_dates_booking = array();
            $date_new = array();
            $booking_data = Booking::where('people_provider_id',$id)->where('status','1')->get();
           if($booking_data){
               foreach ($booking_data as $key => $value) {
                if(date("Y-m-d", strtotime($value->check_in)) == date("Y-m-d",strtotime($value->check_out))){
               $date_new[] =  $this->getDatesFromRange(date("Y-m-d", strtotime($value->check_in)), date("Y-m-d",strtotime($value->check_out)));
               }else{
                $date_new[] =  $this->getDatesFromRange(date("Y-m-d", strtotime($value->check_in)), date("Y-m-d",strtotime('-1 day',strtotime($value->check_out))));
                }
              }

            
                $newdates[] =  $peopledetails['unavailable_dates'];              
                if(empty($date_new)){

                  $final_bookingdateslist = array(); 
                }else{

                $final_bookingdateslist = call_user_func_array("array_merge", $date_new); 

                $newdates[] = implode(',', $final_bookingdateslist);

                }
                  $final_unavailable_dates = implode(',', array_filter($newdates));

                  $unavailable_dates = $final_unavailable_dates;                                         
               
            }
            

       $userdet = User::where('id',$peopledetails['user_id'])->first();
       $review_people = array();
      $reviewspeople = Review::where('people_provider_id',$id)->where('reviews','<>','')->orderBy('created_at','desc')->take(3)->get();
      $pastservices = Booking::where('status',3)->where('provider_user_id',$id)->count();
      $reviewall = Review::where('provider_user_id',$id)->count();
    if($reviewspeople){    
      foreach($reviewspeople as $key => $value){
        $provider = PeopleProvider::where('id',$value->people_provider_id)->first();
        $user = User::where('id',$value->user_id)->first();
        $review_people[$key]['reviews'] = $value->reviews; 
        $review_people[$key]['title'] = $provider->title;       
        $review_people[$key]['user'] = $user->name; 
        $review_people[$key]['datemonth'] = date('F',strtotime($value->created_at));
        $review_people[$key]['dateyear'] = date('Y',strtotime($value->created_at));
        $review_people[$key]['image'] = URL::to('/').'/profile/'.$user->image; 
        $review_people[$key]['ratings'] = $value->ratings; 
      }
    }
       
      return view('frontend.booking_peopleavailability')->with(compact('attachments','peopledetails','id','userdet','favourite','review_people','allimages','pastservices','reviewall','unavailable_dates'))  ;
    }

    public function getsubcategoriesplaces(Request $request)
    {
      $people = Place_Subcat::where('user_id', '1')->where('places_cat_id', $request->id)->get();
      return $people;  
    }
     public function getsubcategoriesthings(Request $request)
    { 

      $people = Thing_Subcat::where('user_id', '1')->where('things_cat_id', $request->id)->get();  
      return $people;  
    }

    public function getsubcategoriespeople(Request $request)
    {
      $people = People_Subcat::where('user_id', '1')->where('people_cat_id', $request->id)->get();
      return $people;  
    }

    public function getplacelistings1(){
     $location = GeoIP::getLocation();
            $latitude = $location['lat'];
            $longitude = $location['lon']; 
         $provider  = PlaceProvider::orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->paginate(10); 
      
     
       $place  = Place::orderBy('name')->get();
       $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','places')->get();
       $placecategories = array();
       $placedata = array();
       $attachments = array();
       $coupondata = array();
       $peoplecategories[] = 'All';
       foreach ($place as $key => $value) {
           //$placecategories[]=  $value->name;
          $placecategories[$key]['name'] = $value->name;
           $placecategories[$key]['id'] = $value->id;
        }     
          
         foreach ($coupon as $key1 => $value) {
            $coupondata[$key1] = $value;
            $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value->background_image;
         }
      
        foreach ($provider as $key => $value) {
         $name = User::select('name','image')->where('id',$value->user_id)->first();
         $images = Attachment::where('places_provider_id',$value->id)->get();
         foreach ($images as $key1 => $value1) {
            $attachments[$key1] = $value1->filenames;
         } 
          if (strpos($name->image, 'http') !== false) {
                  $image =  $name->image;
          }else{
                 $image = URL::to('/').'/profile/'.$name->image;
          }
           if($value->ratings  == ""){
            $ratings = '5';
          }else{
            $ratings = $value->ratings;
          }
          $placedata[$key]['id'] = $value->id;
          $placedata[$key]['name'] = $name->name;
          $placedata[$key]['title'] = $value->title;
          $placedata[$key]['description'] = $value->description;
          $placedata[$key]['total_guests'] = $value->total_guests;
          $placedata[$key]['amenities_offered'] =$value->amenities_offered;
          $placedata[$key]['latitude'] = $value->latitude;
          $placedata[$key]['longitude'] = $value->longitude;
          $placedata[$key]['ratings'] = $ratings;
          $placedata[$key]['attachments'] = $attachments;
          $placedata[$key]['address'] = $value->address;
          $placedata[$key]['price_per_night'] = $value->price_per_night;            
        }  
        $location = array();
        $i = 0;

        foreach ($provider as $key => $value) {
         $i = 0;
         $location[$key][$i] =  '"London Eye, London"';
         $i = 1;
         $location[$key][$i] = $value->latitude;
          $i = 2;
         $location[$key][$i] = $value->longitude;
               
        }    
        $result['categories'] = $placecategories;
        $result['data'] = $placedata;
        $result['coupons'] = $arr;
        $type = "place";
        $filter= 0;
        $id = 'All';
             
      echo  view('frontend.booking_place')->with(compact('result','provider','location','id','filter'));
    }


    public function bookingpagedata(Request $request)
    {
      $this->getplacelistings($request,'getplacelistingshome');
      if($request->typeofbooking=="home")
        return redirect()->route('placelisting');
      else if($request->typeofbooking=="menu1")
         return redirect()->route('thingslisting');
      else if($request->typeofbooking=="menu2")
       return redirect()->route('peoplelisting');
    }

    public function test1(Request $request)
    {  
      
      if($files=$request->file('uploadfile')){
        foreach($files as $file){
          $name=$file->getClientOriginalName();
          if (!file_exists( public_path('/places'))) {
            mkdir(public_path('/places'), 0777, true);
          }
          $path =public_path('/places/');
         
          $input['imagename'] = time().rand(10,10000).'.'.$file->getClientOriginalExtension();
          $destinationPath = public_path('/places');
         $file->move($destinationPath, $input['imagename']);
        }
      }
    }

  public function confirmplaces(Request $request)
  {
    if($request->type==1){
      PlaceProvider::where('id',$request->id)->update(['complete_status'=>'1']);
      PlaceProvider::where('id',$request->id)->update(['percent_status'=>'4']);
      
      return 1;
    }
     else if($request->type==2)
    {
       PlaceProvider::where('id',$request->id)->delete();
       return 1;
    }
  }
   public function confirmthings(Request $request)
  {
   
    if($request->type==1){
      ThingProvider::where('id',$request->id)->update(['complete_status'=>'1']);
      ThingProvider::where('id',$request->id)->update(['percent_status'=>'4']);
      return 1;
    }
     else if($request->type==2)
    {
       ThingProvider::where('id',$request->id)->delete();
       return 1;
    }
  }
   public function confirmpeople(Request $request)
  {   
    if($request->type==1){
      PeopleProvider::where('id',$request->id)->update(['complete_status'=>'1']);
      PeopleProvider::where('id',$request->id)->update(['percent_status'=>'3']);
      return 1;
    }
     else if($request->type==2)
    {
       PeopleProvider::where('id',$request->id)->delete();
       return 1;
    }
  }

public function backtologin(Request $request)
{
  return Redirect::back()->withInput()->with("show_modal", 1);
}
  public function paymentservices(Request $request,$id = null,$checkindate=null,$checkoutdate=null)
  {
    if(!Auth::check())
    {
      return Redirect::back()->withInput()->with("show_modal", 1);
     
    }
    else
    {
      $show_modal = 0;
    }

    $checkindate = $checkindate;
    $checkoutdate = $checkoutdate; 

    $timeDiff = abs(strtotime($checkoutdate) - strtotime($checkindate));
    $no_of_days = $timeDiff/86400;
    $datemonthin = date('M', strtotime($checkindate)); 
    $datedayin = date('d', strtotime($checkindate)); 
    $datedaydatein = date('M d, Y', strtotime($checkindate));
    $datemonthout = date('M', strtotime($checkoutdate)); 
    $datedayout = date('d', strtotime($checkoutdate)); 
    $datedaydateout = date('M d, Y', strtotime($checkoutdate));    
    $provider_data =  PeopleProvider::where('id',$id)->first();
    $allreviewscount = Review::where('places_provider_id',$id)->count();
    $time_in = $provider_data['time_in'];
    $time_out = $provider_data['time_out'];
    if ($no_of_days==0)

      $no_of_days = 1;

    return view('frontend.payment_services')->with(compact('checkindate','checkoutdate','no_of_days','provider_data','datemonthin','datedayin','datedaydatein','datemonthout','datedayout','datedaydateout','allreviewscount','time_in','time_out'));
    
  }

  public function paymentplaces(Request $request,$id = null,$guest=null,$checkindate=null,$checkoutdate=null)
  {
    if(!Auth::check())
    {
      return Redirect::back()->withInput()->with("show_modal", 1);
    }
    else
    {
      $show_modal = 0;
    }
    $checkindate = $checkindate;
    $checkoutdate = $checkoutdate; 
    $guests = $guest;
    if($checkindate=="" ||$checkoutdate =="")
    { 
      /*return Redirect::back()->withInput()->with("show_error", 1);*/
    }
    $checkindate = date('Y-m-d',strtotime($checkindate));
    $checkoutdate = date('Y-m-d',strtotime($checkoutdate));

    $timeDiff = abs(strtotime($checkoutdate) - strtotime($checkindate));
    $no_of_days = $timeDiff/86400;
    $datemonthin = date('M', strtotime($checkindate)); 
    $datedayin = date('d', strtotime($checkindate)); 
    $datedaydatein = date('M d, Y', strtotime($checkindate));
    $datemonthout = date('M', strtotime($checkoutdate)); 
    $datedayout = date('d', strtotime($checkoutdate)); 
    $datedaydateout = date('M d, Y', strtotime($checkoutdate));
    
    $provider_data =  PlaceProvider::where('id',$id)->first();
    $time_in = $provider_data['time_in'];
    $time_out = $provider_data['time_out'];

    $allreviewscount = Review::where('places_provider_id',$id)->count();


    return view('frontend.payment_places')->with(compact('checkindate','checkoutdate','no_of_days','provider_data','datemonthin','datedayin','datedaydatein','datemonthout','datedayout','datedaydateout','show_modal','show_error','allreviewscount','guests','time_in','time_out'));

    
  }

  public function paymentthings(Request $request,$id = null,$checkindate=null,$checkoutdate=null)
  {
    
    if(!Auth::check())
    {
      return Redirect::back()->withInput()->with("show_modal", 1);
     
    }
    else
    {
      $show_modal = 0;
    }
    $checkindate = $checkindate;
    $checkoutdate = $checkoutdate; 
    $timeDiff = abs(strtotime($checkoutdate) - strtotime($checkindate));
    $no_of_days = $timeDiff/86400;
    $datemonthin = date('M', strtotime($checkindate)); 
    $datedayin = date('d', strtotime($checkindate)); 
    $datedaydatein = date('M d, Y', strtotime($checkindate));
    $datemonthout = date('M', strtotime($checkoutdate)); 
    $datedayout = date('d', strtotime($checkoutdate)); 
    $datedaydateout = date('M d, Y', strtotime($checkoutdate));    
    $provider_data =  ThingProvider::where('id',$id)->first();   
    $providerid = $request->providerid;
    $allreviewscount = Review::where('things_provider_id',$id)->count();
     $time_in = $provider_data['time_in'];
    $time_out = $provider_data['time_out'];
    if ($no_of_days==0)
      $no_of_days = 1;
    return view('frontend.payment_things')->with(compact('checkindate','checkoutdate','no_of_days','provider_data','datemonthin','datedayin','datedaydatein','datemonthout','datedayout','datedaydateout','roviderid','allreviewscount','time_in','time_out'));
  }




   public function createtoken(Request $request)
    {
        $userid = Auth::id();

        try{
           $result = Braintree_ClientToken::generate();
            
            return response()->json([
                'status' => 1,
                'message' => "Token created Successfully.",
                'data' => $result
            ], 200);
        }     

        catch(Exception $e){
            $result = [
                'error'=> $e->getMessage(). ' Line No '. $e->getLine() . ' In File'. $e->getFile()
            ];
            Log::error($e->getTraceAsString());
            $result['status'] = 0;
        }
        return $result;
    }

    public function payment(Request $request)
    {
      Stripe::setApiKey("sk_test_rO1deNfgI5H5VzykOzk21cVO00fNXMt0bd");
     
           $user_id = Auth::id(); 
            if($request->get('type') == "1"){
                 $provider_user = PeopleProvider::where('id',$request->get('provider_id'))->first();

                 $provider_user_id = $provider_user->user_id;
              }elseif($request->get('type') == "3"){
                $provider_user = PlaceProvider::where('id',$request->get('provider_id'))->first();

                 $provider_user_id = $provider_user->user_id;  
              }elseif($request->get('type') == "2"){
                 $provider_user = ThingProvider::where('id',$request->get('provider_id'))->first();
                 $provider_user_id = $provider_user->user_id; 
              }       
             $charge = \Stripe\Charge::create([
              'amount' => $request->amount*100,
              'currency' => 'usd',
              'description' => 'Example charge',
              'source' => $request->stripetoken,
            ]);
      if(empty($charge['failure_code']) && $charge['paid'] == 1 && $charge['captured'] == 1){          
           
              $booking = new Booking;
              $booking->user_id = $user_id;
              if($request->get('type') == "1"){
                 $booking->people_provider_id = $request->get('provider_id');
              }elseif($request->get('type') == "3"){
                $booking->places_provider_id = $request->get('provider_id');  
              }elseif($request->get('type') == "2"){
                $booking->things_provider_id = $request->get('provider_id');
              }      
              $booking->provider_user_id  = $provider_user_id;
              $booking->check_in  = $request->get('check_in');
              $booking->check_out = $request->get('check_out');
              $booking->time_in   = $request->get('time_in');
              $booking->time_out  = $request->get('time_out');
              $booking->total_amount = $charge->amount/100;
              $booking->coupon_id  = $request->get('coupon_id');
              //$booking->user_vault = $total_amount_provider_vault;
              $booking->status = 1;
              $booking->save();

              $wallettransaction = new WalletTransaction;
              $wallettransaction->provider_user_id = $provider_user_id;
              if($request->get('type') == "1"){
                 $wallettransaction->people_provider_id = $request->get('provider_id');
              }elseif($request->get('type') == "3"){
                $wallettransaction->places_provider_id = $request->get('provider_id');  
              }elseif($request->get('type') == "2"){
                $wallettransaction->things_provider_id = $request->get('provider_id');
              }
              $wallettransaction->transaction_amount  = $charge->amount/100;
              $wallettransaction->date = date('Y-m-d');
              $wallettransaction->transaction_amount_status = '0'; 
              $wallettransaction->user_id = $user_id;  
              $wallettransaction->booking_id = $booking->id;            
              $wallettransaction->save();

              $user_data = User::where('id',$provider_user_id)->first();
              $total_user_vault_amount = $user_data->user_vault_total + $charge->amount/100;
              User::where('id',$provider_user_id)->update(['user_vault_total'=> $total_user_vault_amount]);

              $provider_user_vault_final = User::where('id',$provider_user_id)->first();

              $provider_userID = $user_data->id; 
              $reciever = $user_data->id; 
              $notification = new Notification;
              $notification->user_id = $provider_userID;
              $notification->message = 'Your booking has been Confirmed';
              $notification->sender = $provider_userID;
              $notification->reciever = $user_id;
              $notification->booking_id =$booking->id;
              $notification->type = 1;
              $notification->save();

              $notification = new Notification;
              $notification->user_id =  $user_id;
              $notification->message = 'New booking Request';
              $notification->sender =  $user_id;
              $notification->reciever = $reciever;
              $notification->booking_id =$booking->id;
              $notification->type = 1;
              $notification->save();

               $notification = new Notification;
              $notification->user_id =  $user_id;
              $notification->message = 'Recieved booking Request payment';
              $notification->sender =  $user_id;
              $notification->reciever = $reciever;
              $notification->booking_id =$booking->id;
              $notification->type = 1;
              $notification->save();

              
              $booking_data = Booking::where('id',$booking->id)->first();
                $result['status'] = 1;
                $result['message'] = "payment done successfully";
                $result['booking'] = $booking_data;
                return 1;
                
            }
            else
            {
               return response()->json([
                       "status" => 0,
                       "message" => $charge->message,
                       
                   ], 422); 
            }
            return 1;
        }

   /* public function applycoupon(Request $request)
  {

    if($request->type == '1'){
        $type = 'people';
    }elseif($request->type == '2'){
      $type = 'things';
    }elseif($request->type == '3'){
      $type = 'places';
    }
     $coupon = Coupon::where('coupon_code',$request->get('couponcode'))->first();
     $coupon_id = $coupon['id'];
     if($coupon){
      $expiry_date =  date('Y-m-d', strtotime($coupon->created_at. ' + '.$coupon->valid_for.' days'));
     if(strtotime(date("Y-m-d")) > strtotime($expiry_date)){
         return response()->json([
             "message" => "This coupon code has been expired.",
             'status' => 0,
         ]);  

     }else{
      if($coupon->rules ==  "greater than equal to"){

      if($request->get('amount') >= $coupon->amount){
        $discount = $coupon->discount/100;
        $discounted_price = $request->get('amount') * $discount;
        $total_amount = $request->get('amount') - $discounted_price;

         return response()->json([
             'status' => 1,
             "amount" => $total_amount,
             "discount"=>$discounted_price,
             "coupon_id" => $coupon_id
         ]);

        }else{
          return response()->json([
             'status' => 0,
             "message" => "Coupon Not Valid",
         ]);
        }
       }elseif($coupon->rules ==  "less than equal to"){

        if($request->get('amount') <= $coupon->amount){
          
          $discount = $coupon->discount/100;
          $discounted_price = $request->get('amount') * $discount;
          $total_amount = $request->get('amount') - $discounted_price;

         return response()->json([
             'status' => 1,
             "amount" => $total_amount,
             "discount"=>$discounted_price,
             "coupon_id" => $coupon_id
         ]);
          
        }else{
          return response()->json([
             'status' => 0,
             "message" => "Coupon Not Valid",
         ]);
        }

       }elseif($coupon->rules ==  "less than"){

         if($request->get('amount') < $coupon->amount){

          $discount = $coupon->discount/100;
          $discounted_price = $request->get('amount') * $discount;
          $total_amount = $request->get('amount') - $discounted_price;

         return response()->json([
             'status' => 1,
             "amount" => $total_amount,
             "discount"=>$discounted_price,
             "coupon_id" => $coupon_id
         ]);
          
        }else{
          return response()->json([
             'status' => 0,
             "message" => "Coupon Not Valid",
         ]);
        }

       }elseif($coupon->rules ==  "greater than"){

        if($request->get('amount') > $coupon->amount){

          $discount = $coupon->discount/100;
          $discounted_price = $request->get('amount') * $discount;
          $total_amount = $request->get('amount') - $discounted_price;

         return response()->json([
             'status' => 1,
             "amount" => $total_amount,
             "discount"=>$discounted_price,
             "coupon_id" => $coupon_id
         ]);
          
        }else{
          return response()->json([
             'status' => 0,
             "message" => "Coupon Not Valid",
         ]);
        }

      }

     }

     }else{

      return response()->json([
             'status' => 2,
             "message" => "Coupon Not Exists",
         ]);
     }
  }*/

     public function applycoupon(Request $request)
  {
    if($request->type == '1'){
        $type = 'people';
    }elseif($request->type == '2'){
      $type = 'things';
    }elseif($request->type == '3'){
      $type = 'places';
    }
     $coupon = Coupon::where('coupon_code',$request->get('couponcode'))->first();
     $coupon_id = $coupon['id'];
      if($coupon['applicable_on'] == 'all' ){
     if($coupon){
      $expiry_date =  date('Y-m-d', strtotime($coupon->created_at. ' + '.$coupon->valid_for.' days'));
     if(strtotime(date("Y-m-d")) > strtotime($expiry_date)){
         return response()->json([
             "message" => "This coupon code has been expired.",
             'status' => 0,
         ]);  

     }else{
      if($coupon->rules ==  "greater than equal to"){

      if($request->get('amount') >= $coupon->amount){
        $discount = $coupon->discount/100;
         $discounted_price = round(($request->get('amount') * $discount),2);
        $total_amount = $request->get('amount') - $discounted_price;

         return response()->json([
             'status' => 1,
             "amount" => $total_amount,
             "discount"=>$discounted_price,
             "coupon_id" => $coupon_id,
             'original_amount' =>$request->amount
         ]);

        }else{
          return response()->json([
             'status' => 0,
             "message" => "Coupon Not Valid",
         ]);
        }
       }elseif($coupon->rules ==  "less than equal to"){

        if($request->get('amount') <= $coupon->amount){
          
          $discount = $coupon->discount/100;
          $discounted_price = round(($request->get('amount') * $discount),2);
          $total_amount = $request->get('amount') - $discounted_price;


         return response()->json([
             'status' => 1,
             "amount" => $total_amount,
             "discount"=>$discounted_price,
             "coupon_id" => $coupon_id,
             'original_amount' =>$request->amount
         ]);
          
        }else{
          return response()->json([
             'status' => 0,
             "message" => "Coupon Not Valid",
         ]);
        }

       }elseif($coupon->rules ==  "less than"){

         if($request->get('amount') < $coupon->amount){

          $discount = $coupon->discount/100;
           $discounted_price = round(($request->get('amount') * $discount),2);
          $total_amount = $request->get('amount') - $discounted_price;

         return response()->json([
             'status' => 1,
             "amount" => $total_amount,
             "discount"=>$discounted_price,
             "coupon_id" => $coupon_id,
             'original_amount' =>$request->amount
         ]);
          
        }else{
          return response()->json([
             'status' => 0,
             "message" => "Coupon Not Valid",
         ]);
        }

       }elseif($coupon->rules ==  "greater than"){

        if($request->get('amount') > $coupon->amount){

          $discount = $coupon->discount/100;
           $discounted_price = round(($request->get('amount') * $discount),2);
          $total_amount = $request->get('amount') - $discounted_price;

         return response()->json([
             'status' => 1,
             "amount" => $total_amount,
             "discount"=>$discounted_price,
             "coupon_id" => $coupon_id,
             'original_amount' =>$request->amount
         ]);
          
        }else{
          return response()->json([
             'status' => 0,
             "message" => "Coupon Not Valid",
         ]);
        }

      }

     }

     }else{

      return response()->json([
             'status' => 2,
             "message" => "Coupon Not Exists",
         ]);
     }
  }
  else if($coupon['applicable_on'] == $type) {


    if($coupon){
      $expiry_date =  date('Y-m-d', strtotime($coupon->created_at. ' + '.$coupon->valid_for.' days'));
     if(strtotime(date("Y-m-d")) > strtotime($expiry_date)){
         return response()->json([
             "message" => "This coupon code has been expired.",
             'status' => 0,
         ]);  

     }else{
      if($coupon->rules ==  "greater than equal to"){

      if($request->get('amount') >= $coupon->amount){
        $discount = $coupon->discount/100;
          $discounted_price = round(($request->get('amount') * $discount),2);
        $total_amount = $request->get('amount') - $discounted_price;

         return response()->json([
             'status' => 1,
             "amount" => $total_amount,
             "discount"=>$discounted_price,
             "coupon_id" => $coupon_id,
             'original_amount' =>$request->amount
         ]);

        }else{
          return response()->json([
             'status' => 0,
             "message" => "Coupon Not Valid",
         ]);
        }
       }elseif($coupon->rules ==  "less than equal to"){

        if($request->get('amount') <= $coupon->amount){
          
          $discount = $coupon->discount/100;
            $discounted_price = round(($request->get('amount') * $discount),2);
          $total_amount = $request->get('amount') - $discounted_price;

         return response()->json([
             'status' => 1,
             "amount" => $total_amount,
             "discount"=>$discounted_price,
             "coupon_id" => $coupon_id,
             'original_amount' =>$request->amount
         ]);
          
        }else{
          return response()->json([
             'status' => 0,
             "message" => "Coupon Not Valid",
         ]);
        }

       }elseif($coupon->rules ==  "less than"){

         if($request->get('amount') < $coupon->amount){

          $discount = $coupon->discount/100;
            $discounted_price = round(($request->get('amount') * $discount),2);
          $total_amount = $request->get('amount') - $discounted_price;

         return response()->json([
             'status' => 1,
             "amount" => $total_amount,
             "discount"=>$discounted_price,
             "coupon_id" => $coupon_id,
             'original_amount' =>$request->amount
         ]);
          
        }else{
          return response()->json([
             'status' => 0,
             "message" => "Coupon Not Valid",
         ]);
        }

       }elseif($coupon->rules ==  "greater than"){

        if($request->get('amount') > $coupon->amount){

          $discount = $coupon->discount/100;
            $discounted_price = round(($request->get('amount') * $discount),2);
          $total_amount = $request->get('amount') - $discounted_price;

         return response()->json([
             'status' => 1,
             "amount" => $total_amount,
             "discount"=>$discounted_price,
             "coupon_id" => $coupon_id,
             'original_amount' =>$request->amount
         ]);
          
        }else{
          return response()->json([
             'status' => 0,
             "message" => "Coupon Not Valid",
         ]);
        }

      }

     }

     }else{

      return response()->json([
             'status' => 2,
             "message" => "Coupon Not Exists",
         ]);
     }


    }else{

                  return response()->json([
                         'status' => 0,
                         "message" => "Coupon Not Valid",
                     ]);
               }



}
/*
   public function applycoupon(Request $request){

      

   }*/

  public function bookings_history(Request $request)
  {
    if(!Auth::check())
    {
      return redirect()->route('home1')->with( ['show_modal' =>1]);
      $show_modal = 1;
    }
    else
    {
      $show_modal = 0;
      $user_id = Auth::id(); 
      $role = User::where('id',$user_id)->value('role');
      $data_place = array();
      $data_things = array();
      $data_people = array();
      $data = array();
    

      if ($request->isMethod('post')) {

        if($request->filter==0){
          $typebooking = $request->type;
          $filter= $request->filter;
          if($typebooking==1)
          $bookings = Booking::where('user_id', $user_id)->where('status','1')->orderby('id','desc')->paginate(1);
          if($typebooking==2)
          $bookings = Booking::where('user_id', $user_id)->where('status','2')->orderby('id','desc')->paginate(1);
        if($typebooking==3)
          $bookings = Booking::where('user_id', $user_id)->where('status','3')->orderby('id','desc')->paginate(1);


              foreach ($bookings as $key => $value) {
               
                if($value->people_provider_id != ""){

                  $provider_user = PeopleProvider::where('id',$value->people_provider_id )->first();
                    $attachment = User::where('id',$provider_user->user_id )->first();
                    $user_id = $attachment->id;
                    $user_name = $attachment->name;
                    $user_image = URL::to('/').'/profile/'.$attachment->image;
                    $image = URL::to('/').'/profile/'.$attachment->image;
                    $category = People_Subcat::where('people_cat_id',$provider_user->cat_id)->value('name');
                    $place = 0;  

                }elseif($value->things_provider_id != ""){

                  $provider_user = ThingProvider::where('id',$value->things_provider_id )->first(); 
                  $attachment = Attachment::where('things_provider_id',$value->things_provider_id )->first();
                  $user = User::where('id',$value->user_id )->first();
                  $user_id = $user->id;
                  $user_name = $user->name;
                  $user_image = URL::to('/').'/profile/'.$user->image;
                  $image = URL::to('/').'/attachments/'.$attachment->filenames;
                  $category=Thing_Subcat::where('things_cat_id',$provider_user->cat_id)->value('name');
                  $place = 0;         
                  

                }elseif($value->places_provider_id != ""){

                  $provider_user = PlaceProvider::where('id',$value->places_provider_id )->first();
                  $attachment = Attachment::where('places_provider_id',$value->places_provider_id )->first();
                  $user = User::where('id',$value->user_id )->first();
                  $user_id = $user->id;
                  $user_name = $user->name;
                  $user_image = URL::to('/').'/profile/'.$user->image;
                  $image = URL::to('/').'/attachments/'.$attachment->filenames;
                  $category = Place_Subcat::where('places_cat_id',  $provider_user->cat_id)->value('name');   
                  $place = 1;  
                  $hostname = $provider_user->host_name;
                  $hostph = $provider_user->host_phone;           
                }

                $data[$key]['id'] = $value->id;
                $data[$key]['user_id'] = $user_id ;
                $data[$key]['user_name'] = $user_name;
                $data[$key]['date'] = $value->check_in;
                $data[$key]['title'] = $provider_user->title;
                $data[$key]['amount'] = $value->total_amount;
                $data[$key]['location'] = $provider_user->address;
                $data[$key]['user_image'] = $user_image;
                $data[$key]['image'] = $image;
                $data[$key]['category'] = $category;
                $data[$key]['place'] = $place;
                $hostname = $provider_user->host_name;
                $hostph = $provider_user->host_phone; 
                $data[$key]['hname'] = $hostname;
                $data[$key]['hphone'] = $hostph ;
                $data[$key]['encodedid'] = $provider_user['encodedid'];

              }   
              

             $view = view('frontend.booking_upcoming',compact('data','filter','bookings','typebooking'))->render();
             return response()->json(['html'=>$view,'filter'=>$filter,'typebooking'=>$typebooking]);
        }
        if($request->type==1 && $request->filter==1 ){

          $filter = $request->filter;
          $typebooking = $request->type;
          $bookings = Booking::where('user_id', $user_id)->where('status','1')->where('places_provider_id','<>','')->orderby('id','desc')->get();
          $i=0;

          foreach ($bookings as $key => $value) {             
            $provider_user = PlaceProvider::where('id',$value->places_provider_id )->first();
            $attachment = Attachment::where('places_provider_id',$value->places_provider_id )->first();

            $user = User::where('id',$provider_user->user_id )->first();
            $data_place[$i]['id'] = $value->id;
            $data_place[$i]['date'] = $value->check_in;
            $data_place[$i]['title'] = $provider_user->title;
            $data_place[$i]['user_id'] = $user->id;
            $data_place[$i]['user_name'] = $user->name;
            $data_place[$i]['amount'] = $value->total_amount;
            $data_place[$i]['location'] = $provider_user->address;
            $data_place[$i]['category'] = Place_Subcat::where('places_cat_id',
              $provider_user->cat_id)->value('name');
            $data_place[$i]['user_image'] = URL::to('/').'/profile/'.$user->image;
            $data_place[$i]['image'] = URL::to('/').'/attachments/'.$attachment->filenames;
            $hostname = $provider_user->host_name;
            $hostph = $provider_user->host_phone; 
            $data_place[$i]['hname'] =  $hostname;
            $data_place[$i]['hphone'] = $hostph;
            $data[$i]['encodedid'] = $provider_user['encodedid']  ;
            $i++;
          }
            $view = view('frontend.booking_upcoming',compact('data_place','filter','bookings','typebooking'))->render();
             return response()->json(['html'=>$view,'filter'=>$filter,'typebooking'=>$typebooking]);
        }

        else if($request->type==1 && $request->filter==2 ){
          $filter = $request->filter; 
          $typebooking = $request->type;
          $bookings = Booking::where('user_id', $user_id)->where('status','1')->where('things_provider_id','<>','')->orderby('id','desc')->get();
          $i=0;
          foreach ($bookings as $key => $value) {
                
            $provider_user = ThingProvider::where('id',$value->things_provider_id )->first(); 
            $attachment = Attachment::where('things_provider_id',$value->things_provider_id )->first();
                $user = User::where('id',$provider_user->user_id )->first();
            $data_things[$i]['id'] = $value->id;
            $data_things[$i]['date'] = $value->check_in;
            $data_things[$i]['user_id'] = $user->id;
            $data_things[$i]['title'] = $provider_user->title;
            $data_things[$i]['user_name'] = $user->name;
            $data_things[$i]['user_image'] = URL::to('/').'/profile/'.$user->image;
            $data_things[$i]['amount'] = $value->total_amount;
            $data_things[$i]['location'] = $provider_user->address;
            $data_things[$i]['encodedid'] = $provider_user['encodedid']  ;
            $data_things[$i]['category'] =Thing_Subcat::where('things_cat_id',
            $provider_user->cat_id)->value('name');
            $data_things[$i]['image'] = URL::to('/').'/attachments/'.$attachment->filenames;
            $i++;
          }
         $view = view('frontend.booking_upcoming',compact('data_things','filter','bookings','typebooking'))->render();
           return response()->json(['html'=>$view,'filter'=>$filter,'typebooking'=>$typebooking]);
        }
        else if($request->type==1 && $request->filter==3){
          $filter = $request->filter;
          $typebooking = $request->type;
          $bookings = Booking::where('user_id', $user_id)->where('status','1')->where('people_provider_id','<>','')->orderby('id','desc')->get();       
          $i=0;
          foreach ($bookings as $key => $value) {
            $provider_user = PeopleProvider::where('id',$value->people_provider_id )->first();
            $attachment = User::where('id',$provider_user->user_id )->first();
            $data_people[$i]['id'] = $value->id;
            $data_people[$i]['date'] = $value->check_in;
            $data_people[$i]['title'] = $provider_user->title;
            $data_people[$i]['user_id'] = $attachment->id;
            $data_people[$i]['user_name'] = $attachment->name;
            $data_people[$i]['amount'] = $value->total_amount;
            $data_people[$i]['location'] = $provider_user->address;
           $data_people[$i]['encodedid'] = $provider_user['encodedid']  ;
            $data_people[$i]['category'] = People_Subcat::where('people_cat_id',$provider_user->cat_id)->value('name');
            $data_people[$i]['image'] = URL::to('/').'/profile/'.$attachment->image;
            /*$data_people[$i]['image'] = URL::to('/').'/attachments/'.$attachment->image;*/
            $i++;               
          } 
         $view = view('frontend.booking_upcoming',compact('data_people','filter','typebooking','bookings'))->render();
           return response()->json(['html'=>$view,'filter'=>$filter,'typebooking'=>$typebooking]);
        }
       else if($request->type==2 && $request->filter==1 ){

          $filter = $request->filter;
          $typebooking = $request->type;
          
          $bookings = Booking::where('user_id', $user_id)->where('status','2')->where('places_provider_id','<>','')->orderby('id','desc')->get();
          $i=0;

          foreach ($bookings as $key => $value) {             
            $provider_user = PlaceProvider::where('id',$value->places_provider_id )->first();
            $attachment = Attachment::where('places_provider_id',$value->places_provider_id )->first();
            

            $user = User::where('id',$provider_user->user_id )->first();
            $data_place[$i]['id'] = $value->id;
            $data_place[$i]['date'] = $value->check_in;
            $data_place[$i]['title'] = $provider_user->title;
            $data_place[$i]['user_id'] = $user->id;
            $data_place[$i]['user_name'] = $user->name;
            $data_place[$i]['amount'] = $value->total_amount;
            $data_place[$i]['location'] = $provider_user->address;
            $data_place[$i]['encodedid'] = $provider_user['encodedid']  ;
            $data_place[$i]['category'] = Place_Subcat::where('places_cat_id',
              $provider_user->cat_id)->value('name');
            $data_place[$i]['user_image'] = URL::to('/').'/profile/'.$user->image;
            $data_place[$i]['image'] = URL::to('/').'/attachments/'.$attachment->filenames;
            $hostname = $provider_user->host_name;
            $hostph = $provider_user->host_phone; 
            $data_place[$i]['hname'] =  $hostname;
            $data_place[$i]['hphone'] = $hostph;
            $i++;
          }


           $view = view('frontend.booking_upcoming',compact('data_place','filter','typebooking','bookings'))->render();
            return response()->json(['html'=>$view,'filter'=>$filter,'typebooking'=>$typebooking]);
        }
        else if($request->type==2 && $request->filter==2 ){
          $filter = $request->filter; 
          $typebooking = $request->type;
          $i=0;
          $bookings = Booking::where('user_id', $user_id)->where('status','2')->where('things_provider_id','<>','')->orderby('id','desc')->get();
          foreach ($bookings as $key => $value) {
                
            $provider_user = ThingProvider::where('id',$value->things_provider_id )->first(); 
            $attachment = Attachment::where('things_provider_id',$value->things_provider_id )->first();
                $user = User::where('id',$provider_user->user_id )->first();
            $data_things[$i]['id'] = $value->id;
            $data_things[$i]['date'] = $value->check_in;
            $data_things[$i]['user_id'] = $user->id;
            $data_things[$i]['title'] = $provider_user->title;
            $data_things[$i]['user_name'] = $user->name;
            $data_things[$i]['user_image'] = URL::to('/').'/profile/'.$user->image;
            $data_things[$i]['amount'] = $value->total_amount;
            $data_things[$i]['location'] = $provider_user->address;
            $data_things[$i]['encodedid'] = $provider_user['encodedid']  ;
            $data_things[$i]['category'] =Thing_Subcat::where('things_cat_id',
            $provider_user->cat_id)->value('name');
              $data_things[$i]['image'] = URL::to('/').'/attachments/'.$attachment->filenames;
              $i++;
          }
          $view = view('frontend.booking_upcoming',compact('data_things','filter','typebooking','bookings'))->render();
           return response()->json(['html'=>$view,'filter'=>$filter,'typebooking'=>$typebooking]);
        }
        else if($request->type==2 && $request->filter==3){
          $filter = $request->filter;
          $typebooking = $request->type;
          $i=0;
          $bookings = Booking::where('user_id', $user_id)->where('status','2')->where('people_provider_id','<>','')->orderby('id','desc')->get();     

          foreach ($bookings as $key => $value) {
            $provider_user = PeopleProvider::where('id',$value->people_provider_id )->first();
            $attachment = User::where('id',$provider_user->user_id )->first();
            $data_people[$i]['id'] = $value->id;
            $data_people[$i]['date'] = $value->check_in;
            $data_people[$i]['title'] = $provider_user->title;
            $data_people[$i]['user_id'] = $attachment->id;
            $data_people[$i]['user_name'] = $attachment->name;
            $data_people[$i]['amount'] = $value->total_amount;
            $data_people[$i]['location'] = $provider_user->address;
            $data_people[$i]['encodedid'] = $provider_user['encodedid']  ;
            $data_people[$i]['category'] = People_Subcat::where('people_cat_id',$provider_user->cat_id)->value('name');
            $data_people[$i]['image'] = URL::to('/').'/profile/'.$attachment->image;
           /* $data_people[$i]['image'] = URL::to('/').'/attachments/'.$attachment->image; */
            $i++;              
          } 

          $view = view('frontend.booking_upcoming',compact('data_people','filter','typebooking','bookings'))->render();
           return response()->json(['html'=>$view,'filter'=>$filter,'typebooking'=>$typebooking]);
        }
        else if($request->type==3 && $request->filter==1 ){

          $filter = $request->filter;
          $typebooking = $request->type;
          $bookings = Booking::where('user_id', $user_id)->where('status','3')->where('places_provider_id','<>','')->orderby('id','desc')->get();
          $i=0;
          foreach ($bookings as $key => $value) {             
            $provider_user = PlaceProvider::where('id',$value->places_provider_id )->first();
            $attachment = Attachment::where('places_provider_id',$value->places_provider_id )->first();

            $user = User::where('id',$provider_user->user_id )->first();
            $data_place[$i]['id'] = $value->id;
            $data_place[$i]['date'] = $value->check_in;
            $data_place[$i]['title'] = $provider_user->title;
            $data_place[$i]['user_id'] = $user->id;
            $data_place[$i]['user_name'] = $user->name;
            $data_place[$i]['amount'] = $value->total_amount;
            $data_place[$i]['location'] = $provider_user->address;
             $data_place[$i]['encodedid'] = $provider_user['encodedid']  ;
            $data_place[$i]['category'] = Place_Subcat::where('places_cat_id',
              $provider_user->cat_id)->value('name');
            $data_place[$i]['user_image'] = URL::to('/').'/profile/'.$user->image;
            $data_place[$i]['image'] = URL::to('/').'/attachments/'.$attachment->filenames;
            $hostname = $provider_user->host_name;
            $hostph = $provider_user->host_phone; 
            $data_place[$i]['hname'] =  $hostname;
            $data_place[$i]['hphone'] = $hostph;
            $i++;
            
          }
            $view = view('frontend.booking_upcoming',compact('data_place','filter','typebooking','bookings'))->render();
             return response()->json(['html'=>$view,'filter'=>$filter,'typebooking'=>$typebooking]);
        }
        else if($request->type==3 && $request->filter==2 ){
          $filter = $request->filter; 
          $typebooking = $request->type;
          $i=0;
          $bookings = Booking::where('user_id', $user_id)->where('status','3')->where('things_provider_id','<>','')->orderby('id','desc')->get();
          foreach ($bookings as $key => $value) {
                
            $provider_user = ThingProvider::where('id',$value->things_provider_id )->first(); 
            $attachment = Attachment::where('things_provider_id',$value->things_provider_id )->first();
                $user = User::where('id',$provider_user->user_id )->first();
            $data_things[$i]['id'] = $value->id;
            $data_things[$i]['date'] = $value->check_in;
            $data_things[$i]['user_id'] = $user->id;
            $data_things[$i]['title'] = $provider_user->title;
            $data_things[$i]['user_name'] = $user->name;
            $data_things[$i]['user_image'] = URL::to('/').'/profile/'.$user->image;
            $data_things[$i]['amount'] = $value->total_amount;
            $data_things[$i]['location'] = $provider_user->address;
             $data_things[$i]['encodedid'] = $provider_user['encodedid']  ;
            $data_things[$i]['category'] =Thing_Subcat::where('things_cat_id',
            $provider_user->cat_id)->value('name');
              $data_things[$i]['image'] = URL::to('/').'/attachments/'.$attachment->filenames;
              $i++;
          }
          $view = view('frontend.booking_upcoming',compact('data_things','filter','typebooking','bookings'))->render();
           return response()->json(['html'=>$view,'filter'=>$filter,'typebooking'=>$typebooking]);
        }
        else if($request->type==3 && $request->filter==3){
          $filter = $request->filter;
          $typebooking = $request->type;
          $i=0;
          $bookings = Booking::where('user_id', $user_id)->where('status','3')->where('people_provider_id','<>','')->orderby('id','desc')->get();       
          foreach ($bookings as $key => $value) {
            $provider_user = PeopleProvider::where('id',$value->people_provider_id )->first();
            $attachment = User::where('id',$provider_user->user_id )->first();
            $data_people[$i]['id'] = $value->id;
            $data_people[$i]['date'] = $value->check_in;
            $data_people[$i]['title'] = $provider_user->title;
            $data_people[$i]['user_id'] = $attachment->id;
            $data_people[$i]['user_name'] = $attachment->name;
            $data_people[$i]['amount'] = $value->total_amount;
            $data_people[$i]['encodedid'] = $provider_user['encodedid']  ;
            $data_people[$i]['location'] = $provider_user->address;
            $data_people[$i]['category'] = People_Subcat::where('people_cat_id',$provider_user->cat_id)->value('name');
            $data_people[$i]['image'] = URL::to('/').'/profile/'.$attachment->image;
          /*  $data_people[$i]['image'] = URL::to('/').'/attachments/'.$attachment->image;*/
            $i++;               
          } 
         $view = view('frontend.booking_upcoming',compact('data_people','filter','typebooking','bookings'))->render();
           return response()->json(['html'=>$view,'filter'=>$filter,'typebooking'=>$typebooking]);
        }



      }
      else
      {

          $bookings = Booking::where('user_id', $user_id)->where('status','1')->get();
         
              foreach ($bookings as $key => $value) {
               
                if($value->people_provider_id != ""){

                  $provider_user = PeopleProvider::where('id',$value->people_provider_id )->first();
                    $attachment = User::where('id',$provider_user->user_id )->first();
                    $user_id = $attachment->id;
                    $user_name = $attachment->name;
                    $image = URL::to('/').'/profile/'.$attachment->image;
                   /* $image = URL::to('/').'/attachments/'.$attachment->image;*/
                    $category = People_Subcat::where('people_cat_id',$provider_user->cat_id)->value('name');
                    $place = 0; 

                }elseif($value->things_provider_id != ""){

                  $provider_user = ThingProvider::where('id',$value->things_provider_id )->first(); 
                  $attachment = Attachment::where('things_provider_id',$value->things_provider_id )->first();
                  $user = User::where('id',$value->user_id )->first();
                  $user_id = $user->id;
                  $user_name = $user->name;
                  $user_image = URL::to('/').'/profile/'.$user->image;
                  $image = URL::to('/').'/attachments/'.$attachment->filenames;
                  $category=Thing_Subcat::where('things_cat_id',$provider_user->cat_id)->value('name');
                  $place = 0; 
                  

                }elseif($value->places_provider_id != ""){

                  $provider_user = PlaceProvider::where('id',$value->places_provider_id )->first();
                  $attachment = Attachment::where('places_provider_id',$value->places_provider_id )->first();
                  $user = User::where('id',$value->user_id )->first();
                  $user_id = $user->id;
                  $user_name = $user->name;
                  $user_image = URL::to('/').'/profile/'.$user->image;
                  $image = URL::to('/').'/attachments/'.$attachment->filenames;
                  $category = Place_Subcat::where('places_cat_id',  $provider_user->cat_id)->value('name');   
                  $place = 1;    
                  $hostname = $provider_user->host_name;
                  $hostph = $provider_user->host_phone;            
                }

                $data[$key]['id'] = $value->id;
                $data[$key]['user_id'] = $user_id ;
                $data[$key]['user_name'] = $user_name;
                $data[$key]['date'] = $value->check_in;
                $data[$key]['title'] = $provider_user->title;
                $data[$key]['amount'] = $value->total_amount;
                $data[$key]['location'] = $provider_user->address;
                /*$data[$key]['user_image'] = $user_image;*/
                $data[$key]['image'] = $image;
                $data[$key]['category'] = $category;
                $data[$key]['place'] = $place;
                $data[$key]['encodedid'] = $provider_user->encodedid;
                $hostname = $provider_user->host_name;
                

                $hostph = $provider_user->host_phone; 
                $data[$key]['hname'] =  $hostname;
                $data[$key]['hphone'] = $hostph;
              }   
                $filter=0;

                return view('frontend.bookings_history')->with(compact('data','filter','typebooking'));
      }
    }
   
    
  
}

public function request_bookinglist(Request $request)
{

  $place = 0;
  $user_id = Auth::id(); 
  $data = array();
  $data_place = array();
  $data_things = array();
  $data_people = array();

  if ($request->isMethod('post')) {
    
    if($request->filter==0){
      $typebooking = $request->type;
      $filter= $request->filter;
      if($typebooking==1)
       $bookings = Booking::where('status','1')->where('provider_user_id',$user_id)->orderby('id','desc')->get();
      if($typebooking==2)
        $bookings =Booking::where('status','2')->where('provider_user_id',$user_id)->orderby('id','desc')->get();
      if($typebooking==3)
        $bookings = Booking::where('status','3')->where('provider_user_id',$user_id)->orderby('id','desc')->get();

      foreach ($bookings as $key => $value) {         
        if($value->people_provider_id != ""){
          $provider_user = PeopleProvider::where('id',$value->people_provider_id)->first();            
          $provider_category = People::where('id',$provider_user->cat_id)->first();
           $attachment = User::where('id',$provider_user->user_id )->first();
          $image = URL::to('/').'/profile/'.$attachment['image'];
          $booking_id = $value->id;
          $date = $value->check_in;
          $provider_id = $provider_user->id;
          $average_ratings = $provider_user->ratings;
          $provider_category = $provider_category->name;
          $title = $provider_user->title;
          $provider_type = '1';
        }elseif($value->things_provider_id != ""){
          $provider_user = ThingProvider::where('id',$value->things_provider_id )->first();             
          $provider_category = Thing::where('id',$provider_user->cat_id)->first();
          $attachment = Attachment::where('things_provider_id',$value->things_provider_id )->first();
          $image = URL::to('/').'/attachments/'.$attachment->filenames;
            $booking_id = $value['id'];
             $date = $value['check_in'];
             $provider_id = $provider_user['id'];
             $average_ratings = $provider_user['ratings'];
                    $provider_category = $provider_category['name'];
             $title = $provider_user['title'];
          $provider_type = '2';
        }elseif($value->places_provider_id != ""){
          $provider_user = PlaceProvider::where('id',$value->places_provider_id )->first();
          $provider_category = Place::where('id',$provider_user['cat_id'])->first();
          $attachment = Attachment::where('places_provider_id',$value->places_provider_id )->first();
          $image = URL::to('/').'/attachments/'.$attachment->filenames;
          $booking_id = $value['id'];
          $date = $value['check_in'];
          $provider_id = $provider_user['id'];
          $average_ratings = $provider_user['ratings'];
          $provider_category = $provider_category['name'];
          $title = $provider_user['title'];
          $provider_type = '3';
        }
        $data[$key]['id'] = $booking_id;
        $data[$key]['provider_id'] = $provider_id;
        $data[$key]['date'] = $date;
        $data[$key]['category'] = $provider_category;
        $data[$key]['average_ratings'] = $average_ratings;
        $data[$key]['title'] = $title;
        $data[$key]['image'] = $image;
        $data[$key]['amount'] = $value->total_amount;
        $data[$key]['location'] = $provider_user['address'];
      }
      $view = view('frontend.booking_upcomingprovider',compact('data','filter','typebooking'))->render();
      return response()->json(['html'=>$view,'filter'=>$filter,'typebooking'=>$typebooking]);
    }
     else if($request->type==1 && $request->filter==1 ){
          $filter = $request->filter;
          $typebooking = $request->type;

          $provider = PlaceProvider::where('user_id',$user_id)->where('status','1')->get();
           $i=0;
          foreach ($provider as $key1 => $value1) {
            $bookings = Booking::where('places_provider_id', $value1->id)->where('status','1')->orderby('id','desc')->get();

            foreach ($bookings as $value) {
              $provider_user = PlaceProvider::where('id',$value->places_provider_id)->where('status','1')->first();
              $provider_category = Place::where('id',$provider_user['cat_id'])->first();
              $attachment = Attachment::where('places_provider_id',$value->things_provider_id )->first();

              $data_place[$i]['id'] = $value['id'];
              $data_place[$i]['provider_id'] = $provider_user['id'];
              $data_place[$i]['title'] = $provider_user['title'];
              $data_place[$i]['category'] = $provider_category['name'];
              $data_place[$i]['average_ratings'] = $provider_user['ratings'];
              $data_place[$i]['date'] = $value['check_in'];
              $data_place[$i]['amount'] = $value['total_amount'];
              $data_place[$i]['location'] = $provider_user['address'];
              $data_place[$i]['image'] = URL::to('/').'/attachments/'.$attachment['filenames'];
              $i++;
              
            }      
          }


            $view = view('frontend.booking_upcomingprovider',compact('data_place','filter','','typebooking'))->render();
             return response()->json(['html'=>$view,'filter'=>$filter,'typebooking'=>$typebooking]);
        }

    else if($request->type==1 && $request->filter==2 ){

      $filter = $request->filter; 
      $typebooking = $request->type;
      $provider = ThingProvider::where('user_id',$user_id)->where('status','1')->get();
       $i=0;
          foreach ($provider as $key1 => $value1) {
            $bookings = Booking::where('things_provider_id', $value1->id)->where('status','1')->orderby('id','desc')->get();
            foreach ($bookings as $key => $value) {
              $provider_user = ThingProvider::where('id',$value->things_provider_id)->where('status','1')->first();
               $provider_category = Thing::where('id',$provider_user['cat_id'])->first();
              $attachment = Attachment::where('things_provider_id',$value->things_provider_id )->first();

              $data_things[$i]['id'] = $value['id'];
              $data_things[$i]['provider_id'] = $provider_user['id'];
              $data_things[$i]['title'] = $provider_user['title'];
              $data_things[$i]['average_ratings'] = $provider_user['ratings'];
              $data_things[$i]['category'] = $provider_category['name'];
              $data_things[$i]['date'] = $value['check_in'];
              $data_things[$i]['amount'] = $value['total_amount'];
              $data_things[$i]['location'] = $provider_user['address'];
              $data_things[$i]['image'] = URL::to('/').'/attachments/'.$attachment['filenames'];
              $i++;
            }      
          }             
      $view = view('frontend.booking_upcomingprovider',compact('data_things','filter','typebooking'))->render();
      return response()->json(['html'=>$view,'filter'=>$filter,'typebooking'=>$typebooking]);
    }
    else if($request->type==1 && $request->filter==3){
      $filter = $request->filter;
      $typebooking = $request->type;
      $provider = PeopleProvider::where('user_id',$user_id)->where('status','1')->get();
        $i=0;
        //$data33 = array();
          foreach ($provider as $key1 => $value1) {
            $bookings = Booking::where('people_provider_id', $value1->id)->where('status','1')->orderby('id','desc')->get();

             foreach ($bookings as $key => $value) {

                $provider_user = PeopleProvider::where('id',$value->people_provider_id)->where('status','1')->first();
                $provider_category = People::where('id',$provider_user['cat_id'])->first();
                $attachment = User::where('id',$provider_user->user_id )->first();

                $data_people[$i]['id'] = $value['id'];
                $data_people[$i]['provider_id'] = $provider_user['id'];
                $data_people[$i]['title'] = $provider_user['title'];
                $data_people[$i]['average_ratings'] = $provider_user['ratings'];
                $data_people[$i]['category'] = $provider_category['name'];
                $data_people[$i]['date'] = $value['check_in'];
                $data_people[$i]['amount'] = $value['total_amount'];
                $data_people[$i]['location'] = $provider_user['address'];
                
                $data_people[$i]['image'] = URL::to('/').'/profile/'.$attachment['image'];
                $i++;
             }
             //$data33[$key1]= $data_people;
          }   


     
      $view = view('frontend.booking_upcomingprovider',compact('data_people','filter','typebooking'))->render();
      return response()->json(['html'=>$view,'filter'=>$filter,'typebooking'=>$typebooking]);
    }
     else if($request->type==2 && $request->filter==1 ){
      $filter = $request->filter;
      $typebooking = $request->type;
      $provider = PlaceProvider::where('user_id',$user_id)->where('status','1')->get();
      $i=0;
      foreach ($provider as $key1 => $value1) {
        $bookings = Booking::where('places_provider_id', $value1->id)->where('status','2')->orderby('id','desc')->get();
        foreach ($bookings as $key => $value) {
          $provider_user = PlaceProvider::where('id',$value->places_provider_id)->where('status','1')->first();
          $provider_category = Place::where('id',$provider_user['cat_id'])->first();
          $attachment = Attachment::where('places_provider_id',$value->things_provider_id )->first();

          $data_place[$i]['id'] = $value['id'];
          $data_place[$i]['provider_id'] = $provider_user['id'];
          $data_place[$i]['title'] = $provider_user['title'];
          $data_place[$i]['category'] = $provider_category['name'];
          $data_place[$i]['average_ratings'] = $provider_user['ratings'];
          $data_place[$i]['date'] = $value['check_in'];          
          $data_place[$i]['location'] = $provider_user['address'];
          $data_place[$i]['amount'] = $value['total_amount'];
          $data_place[$i]['image'] = URL::to('/').'/attachments/'.$attachment['filenames'];
          $i++;
        }      
      }
      
        $view = view('frontend.booking_upcomingprovider',compact('data_place','filter','','typebooking'))->render();
         return response()->json(['html'=>$view,'filter'=>$filter,'typebooking'=>$typebooking]);
    }

    else if($request->type==2 && $request->filter==2 ){
      $filter = $request->filter; 
      $typebooking = $request->type;
      $i=0;
      $provider = ThingProvider::where('user_id',$user_id)->where('status','1')->get();
          foreach ($provider as $key1 => $value1) {
            $bookings = Booking::where('things_provider_id', $value1->id)->where('status','2')->orderby('id','desc')->get();
            foreach ($bookings as $key => $value) {
              $provider_user = ThingProvider::where('id',$value->things_provider_id)->where('status','1')->first();
               $provider_category = Thing::where('id',$provider_user['cat_id'])->first();
              $attachment = Attachment::where('things_provider_id',$value->things_provider_id )->first();

              $data_things[$i]['id'] = $value['id'];
              $data_things[$i]['provider_id'] = $provider_user['id'];
              $data_things[$i]['title'] = $provider_user['title'];
              $data_things[$i]['average_ratings'] = $provider_user['ratings'];
              $data_things[$i]['category'] = $provider_category['name'];
              $data_things[$i]['amount'] = $value['total_amount'];
              $data_things[$i]['date'] = $value['check_in'];
              $data_things[$i]['location'] = $provider_user['address'];
              $data_things[$i]['image'] = URL::to('/').'/attachments/'.$attachment['filenames'];
              $i++;
            }      
          }             
      $view = view('frontend.booking_upcomingprovider',compact('data_things','filter','typebooking'))->render();
      return response()->json(['html'=>$view,'filter'=>$filter,'typebooking'=>$typebooking]);
    }
    else if($request->type==2 && $request->filter==3){
      $filter = $request->filter;
      $typebooking = $request->type;
      $i=0;
      $provider = PeopleProvider::where('user_id',$user_id)->where('status','1')->get();
          foreach ($provider as $key1 => $value1) {
            $bookings = Booking::where('people_provider_id', $value1->id)->where('status','2')->orderby('id','desc')->get();
              foreach ($bookings as $key => $value) {
                $provider_user = PeopleProvider::where('id',$value->people_provider_id)->where('status','1')->first();
                $provider_category = People::where('id',$provider_user['cat_id'])->first();
                $attachment = User::where('id',$provider_user->user_id )->first();

                $data_people[$i]['id'] = $value['id'];
                $data_people[$i]['provider_id'] = $provider_user['id'];
                $data_people[$i]['title'] = $provider_user['title'];
                $data_people[$i]['average_ratings'] = $provider_user['ratings'];
                $data_people[$i]['category'] = $provider_category['name'];
                $data_people[$i]['amount'] = $value['total_amount'];
                $data_people[$i]['date'] = $value['check_in'];
                $data_people[$i]['location'] = $provider_user['address'];
                $data_people[$i]['image'] = URL::to('/').'/profile/'.$attachment['image'];
                $i++;
             }
          }    
      $view = view('frontend.booking_upcomingprovider',compact('data_people','filter','typebooking'))->render();
      return response()->json(['html'=>$view,'filter'=>$filter,'typebooking'=>$typebooking]);
    }
    else if($request->type==3 && $request->filter==1 ){
      $filter = $request->filter;
      $typebooking = $request->type;
      $i=0;
      $provider = PlaceProvider::where('user_id',$user_id)->where('status','1')->get();
      foreach ($provider as $key1 => $value1) {
        $bookings = Booking::where('places_provider_id', $value1->id)->where('status','3')->orderby('id','desc')->get();
        foreach ($bookings as $key => $value) {
          $provider_user = PlaceProvider::where('id',$value->places_provider_id)->where('status','1')->first();
          $provider_category = Place::where('id',$provider_user['cat_id'])->first();
          $attachment = Attachment::where('places_provider_id',$value->things_provider_id )->first();

          $data_place[$i]['id'] = $value['id'];
          $data_place[$i]['provider_id'] = $provider_user['id'];
          $data_place[$i]['title'] = $provider_user['title'];
          $data_place[$i]['category'] = $provider_category['name'];
          $data_place[$i]['average_ratings'] = $provider_user['ratings'];
          $data_place[$i]['date'] = $value['check_in'];
          $data_place[$i]['amount'] = $value['total_amount'];
          $data_place[$i]['location'] = $provider_user['address'];
          $data_place[$i]['image'] = URL::to('/').'/attachments/'.$attachment['filenames'];
          $i++;
        }      
      }
        $view = view('frontend.booking_upcomingprovider',compact('data_place','filter','','typebooking'))->render();
         return response()->json(['html'=>$view,'filter'=>$filter,'typebooking'=>$typebooking]);
    }

    else if($request->type==3 && $request->filter==2 ){
      $filter = $request->filter; 
      $typebooking = $request->type;
      $i=0;
      $provider = ThingProvider::where('user_id',$user_id)->where('status','1')->get();
      foreach ($provider as $key1 => $value1) {
        $bookings = Booking::where('things_provider_id', $value1->id)->where('status','3')->orderby('id','desc')->get();
        foreach ($bookings as $key => $value) {
          $provider_user = ThingProvider::where('id',$value->things_provider_id)->where('status','1')->first();
           $provider_category = Thing::where('id',$provider_user['cat_id'])->first();
          $attachment = Attachment::where('things_provider_id',$value->things_provider_id )->first();

          $data_things[$i]['id'] = $value['id'];
          $data_things[$i]['provider_id'] = $provider_user['id'];
          $data_things[$i]['title'] = $provider_user['title'];
          $data_things[$i]['average_ratings'] = $provider_user['ratings'];
          $data_things[$i]['category'] = $provider_category['name'];
          $data_things[$i]['date'] = $value['check_in'];
          $data_things[$i]['location'] = $provider_user['address'];
          $data_things[$i]['amount'] = $value['total_amount'];
          $data_things[$i]['image'] = URL::to('/').'/attachments/'.$attachment['filenames'];
          $i++;
        }      
      }             
      $view = view('frontend.booking_upcomingprovider',compact('data_things','filter','typebooking'))->render();
      return response()->json(['html'=>$view,'filter'=>$filter,'typebooking'=>$typebooking]);
    }
    else if($request->type==3 && $request->filter==3){
      $filter = $request->filter;
      $typebooking = $request->type;
      $i=0;
      $provider = PeopleProvider::where('user_id',$user_id)->where('status','1')->get();
      foreach ($provider as $key1 => $value1) {
        $bookings = Booking::where('people_provider_id', $value1->id)->where('status','3')->orderby('id','desc')->get();
        foreach ($bookings as $key => $value) {
          $provider_user = PeopleProvider::where('id',$value->people_provider_id)->where('status','1')->first();
          $provider_category = People::where('id',$provider_user['cat_id'])->first();
          $attachment = User::where('id',$provider_user->user_id )->first();

          $data_people[$i]['id'] = $value['id'];
          $data_people[$i]['provider_id'] = $provider_user['id'];
          $data_people[$i]['title'] = $provider_user['title'];
          $data_people[$i]['average_ratings'] = $provider_user['ratings'];
          $data_people[$i]['category'] = $provider_category['name'];
          $data_people[$i]['date'] = $value['check_in'];
          $data_people[$i]['amount'] = $value['total_amount'];
          $data_people[$i]['location'] = $provider_user['address'];
          $data_people[$i]['image'] = URL::to('/').'/profile/'.$attachment['image'];
          $i++;
        }
      }    
      $view = view('frontend.booking_upcomingprovider',compact('data_people','filter','typebooking'))->render();
      return response()->json(['html'=>$view,'filter'=>$filter,'typebooking'=>$typebooking]);
    }
  }
  else
  {
    $bookings = Booking::where('status','1')->where('provider_user_id',$user_id)->get();


    foreach ($bookings as $key => $value) {       
      if($value->people_provider_id != ""){
        $provider_user = PeopleProvider::where('id',$value->people_provider_id)->first();          
        $provider_category = People::where('id',$provider_user['cat_id'])->first();
        $attachment = User::where('id',$provider_user->user_id )->first();
        $image = URL::to('/').'/profile/'.$attachment->image;
        $booking_id = $value['id'];
        $date = $value['check_in'];
        $provider_id = $provider_user['id'];
        $average_ratings = $provider_user['ratings'];
        $provider_category = $provider_category['name'];
        $title = $provider_user['title'];
        $provider_type = '1';
      }elseif($value->things_provider_id != ""){
        $provider_user = ThingProvider::where('id',$value->things_provider_id )->first(); 
        $provider_category = Thing::where('id',$provider_user['cat_id'])->first();
        $attachment = Attachment::where('things_provider_id',$value->things_provider_id )->first();
        $image = URL::to('/').'/attachments/'.$attachment->filenames;
        $booking_id = $value['id'];
        $date = $value['check_in'];
        $provider_id = $provider_user['id'];
        $average_ratings = $provider_user['ratings'];
        $provider_category = $provider_category['name'];
        $title = $provider_user['title'];
        $provider_type = '2';
      }elseif($value->places_provider_id != ""){
        $provider_user = PlaceProvider::where('id',$value->places_provider_id )->first();

        $provider_category = Place::where('id',$provider_user['cat_id'])->first();

        $attachment = Attachment::where('places_provider_id',$value->places_provider_id )->first();
        $image = URL::to('/').'/attachments/'.$attachment->filenames;
        $booking_id = $value->id;
        $date = $value->check_in;
        $provider_id = $provider_user['id'];
        $average_ratings = $provider_user['ratings'];
        $provider_category = $provider_category['name'];
        $title = $provider_user['title'];
        $provider_type = '3';
      }
      $data[$key]['id'] = $booking_id;
      $data[$key]['provider_id'] = $provider_id;
      $data[$key]['date'] = $date;
      $data[$key]['category'] = $provider_category;
      $data[$key]['average_ratings'] = $average_ratings;
      $data[$key]['amount'] = $value->total_amount;
      $data[$key]['location'] = $provider_user['address'];
      $data[$key]['title'] = $title;
      $data[$key]['image'] = $image;
      $data[$key]['place'] = $place;
      $data[$key]['location'] = $provider_user['address'];

    }
    $filter=0;
    return view('frontend.myrequests')->with(compact('data','filter','typebooking'));
  }
}
  

public function booking_historydetail(Request $request, $id = Null)
  {


    $id = base64_decode($id);


    $bookings = Booking::where('id', $id)->first();
    
     $user_id = Auth::id();

    $status = $bookings['status'];
   
    if($status == '1'){
            
          $bookings = Booking::where('id', $id)->where('status', '1')->first();
          $coupon = Coupon::where('id',$bookings->coupon_id)->first();
          if($coupon){
            $coupon_data =  $coupon->discount;

          }else{
            $coupon_data =  "";
          }
          $reviews = Review::where('booking_id', $request->get('booking_id'))->first();
          if($reviews){
            $ratings = $reviews->ratings;
            $reviews = $reviews->reviews;
          }else{
            $ratings = '';
             $reviews = '';
          }
          $data= array();

          if($bookings){
            if($bookings->people_provider_id == '' &&  $bookings->things_provider_id == ''){
            $provider_user = PlaceProvider::where('id',$bookings->places_provider_id )->first();
            $reviews_count = Review::where('places_provider_id', $provider_user->id)->count();
            $attachment = Attachment::where('places_provider_id',$bookings->places_provider_id )->first();
            $image = URL::to('/').'/attachments/'.$attachment->filenames;

            $data['status'] = 1;
            $data['data']['booking_id'] = $bookings->id;
            $data['data']['status'] = $bookings->status;
            $data['data']['check_in'] = $bookings->check_in;
            $data['data']['check_out'] = $bookings->check_out;
            $data['data']['time_in'] = $bookings->time_in;
            $data['data']['time_out'] = $bookings->time_out;
            $data['data']['total_amount'] = $bookings->total_amount;
            $data['data']['title'] = $provider_user->title;
            $data['data']['address'] = $provider_user->address;
            $data['data']['latitude'] = $provider_user->latitude;
            $data['data']['longitude'] = $provider_user->longitude;
            $data['data']['guests'] = $provider_user->total_guests;
            $data['data']['average_rating'] = $provider_user->ratings;
            $data['data']['ratings'] = $ratings;
            $data['data']['reviews'] = $reviews;
            $data['data']['reviews_count'] = $reviews_count;
            $data['data']['coupon'] = $coupon_data;
            $data['data']['price_per_night'] = $provider_user->price_per_night;
            $data['data']['image'] = $image;
            $data['data']['hostname'] = $provider_user->host_name;
            $data['data']['hostphone'] = $provider_user->host_phone;
            $data['data']['encodedid'] = $provider_user->encodedid;
             $data['data']['couponid'] = $bookings->coupon_id;
            $data['provider_type'] = '';

            if($bookings->coupon_id !="")
            {
              $dis = Coupon::where('id',$bookings->coupon_id)->value('discount');
              $data['data']['discount'] = $bookings->total_amount*$dis/100;                 
            }
            else
            {
              $data['data']['discount'] = "";
            }

          }elseif($bookings->people_provider_id == '' &&  $bookings->places_provider_id == ''){

              $provider_user = ThingProvider::where('id',$bookings->things_provider_id )->first();
              $reviews_count = Review::where('things_provider_id', $provider_user->id)->count();
              $attachment = Attachment::where('things_provider_id',$bookings->things_provider_id )->first();
              $image = URL::to('/').'/attachments/'.$attachment->filenames;

               $data['status'] = 1;
              $data['data']['booking_id'] = $bookings->id;
               $data['data']['status'] = $bookings->status;
              $data['data']['check_in'] = $bookings->check_in;
              $data['data']['check_out'] = $bookings->check_out;
              $data['data']['time_in'] = $bookings->time_in;
              $data['data']['time_out'] = $bookings->time_out;
              $data['data']['total_amount'] = $bookings->total_amount;
              $data['data']['title'] = $provider_user->title;
              $data['data']['address'] = $provider_user->address;
              $data['data']['latitude'] = $provider_user->latitude;
            $data['data']['longitude'] = $provider_user->longitude;
            $data['data']['average_rating'] = $provider_user->ratings;
            $data['data']['ratings'] = $ratings;
            $data['data']['reviews'] = $reviews;
             $data['data']['reviews_count'] = $reviews_count;
             $data['data']['coupon'] = $coupon_data;
              $data['data']['price_per_night'] = $provider_user->price_per_night;
               $data['data']['encodedid'] = $provider_user->encodedid;
              $data['data']['image'] = $image;
              $data['provider_type'] = '2';
              $data['data']['couponid'] = $bookings->coupon_id;
            if($bookings->coupon_id !="")            {
              $dis = Coupon::where('id',$bookings->coupon_id)->value('discount');
              $data['data']['discount'] = $bookings->total_amount*$dis/100;                 
            }
            else
            {
              $data['data']['discount'] = "";
            }
          }elseif($bookings->places_provider_id == '' &&  $bookings->things_provider_id == ''){

                $provider_user = PeopleProvider::where('id',$bookings->people_provider_id )->first();
                 $reviews_count = Review::where('people_provider_id', $provider_user->id)->count();
              $attachment = User::where('id',$provider_user->user_id )->first();
              $image = URL::to('/').'/profile/'.$attachment->image;

               $data['status'] = 1;
              $data['data']['booking_id'] = $bookings->id;
               $data['data']['status'] = $bookings->status;
              $data['data']['check_in'] = $bookings->check_in;
              $data['data']['check_out'] = $bookings->check_out;
              $data['data']['time_in'] = $bookings->time_in;
              $data['data']['time_out'] = $bookings->time_out;
              $data['data']['total_amount'] = $bookings->total_amount;
              $data['data']['title'] = $provider_user->title;
              $data['data']['address'] = $provider_user->address;
              $data['data']['latitude'] = $provider_user->latitude;
              $data['data']['longitude'] = $provider_user->longitude;
              $data['data']['average_rating'] = $provider_user->ratings;
              $data['data']['ratings'] = $ratings;
              $data['data']['reviews'] = $reviews;
              $data['data']['reviews_count'] = $reviews_count;
              $data['data']['coupon'] = $coupon_data;
              $data['data']['reviews'] = $reviews;
              $data['data']['price_per_night'] = $provider_user->price_per_night;
               $data['data']['encodedid'] = $provider_user->encodedid;
              $data['data']['image'] = $image;
              $data['provider_type'] = '1';
              $data['data']['couponid'] = $bookings->coupon_id;
            if($bookings->coupon_id !="")            {
              $dis = Coupon::where('id',$bookings->coupon_id)->value('discount');
              $data['data']['discount'] = $bookings->total_amount*$dis/100;                 
            }
            else
            {
              $data['data']['discount'] = "";
            }
          }

          }
        }elseif($status == '2'){
          $bookings = Booking::where('id', $id)->where('status', '2')->first();
          if($user_id == $bookings->cancelled_by){
            $bookings_cancelled_me = true;
          }else{
            $bookings_cancelled_me = false;
          }
          $bookings_cancelled = User::where('id', $bookings->cancelled_by)->first();
            $coupon = Coupon::where('id',$bookings->coupon_id)->first();
          if($coupon){
            $coupon_data =  $coupon->discount;

          }else{
            $coupon_data =  "";
          }
          $reviews = Review::where('booking_id', $request->get('booking_id'))->first();
          if($reviews){
            $ratings = $reviews->ratings;
            $reviews = $reviews->reviews;
          }else{
            $ratings = '';
            $reviews = '';
          }
          if($bookings){


          if($bookings->people_provider_id == '' &&  $bookings->things_provider_id == ''){
            $provider_user = PlaceProvider::where('id',$bookings->places_provider_id )->first();
             $reviews_count = Review::where('places_provider_id', $provider_user->id)->count();
            $attachment = Attachment::where('places_provider_id',$bookings->places_provider_id )->first();
            $image = URL::to('/').'/attachments/'.$attachment->filenames;

             $data['status'] = 1;
            $data['data']['booking_id'] = $bookings->id;
             $data['data']['status'] = $bookings->status;
            $data['data']['check_in'] = $bookings->check_in;
            $data['data']['check_out'] = $bookings->check_out;
            $data['data']['time_in'] = $bookings->time_in;
            $data['data']['time_out'] = $bookings->time_out;
            $data['data']['total_amount'] = $bookings->total_amount;
            $data['data']['cancelled_by'] = $bookings_cancelled->name;
            $data['data']['cancelled_by_id'] = $bookings->cancelled_by;
            $data['data']['bookings_cancelled_by_me'] = $bookings_cancelled_me;
            $data['data']['title'] = $provider_user->title;
            $data['data']['address'] = $provider_user->address;
            $data['data']['latitude'] = $provider_user->latitude;
            $data['data']['longitude'] = $provider_user->longitude;
            $data['data']['guests'] = $provider_user->total_guests;
            $data['data']['average_rating'] = $provider_user->ratings;
            $data['data']['ratings'] =  $ratings;
            $data['data']['reviews'] = $reviews;
            $data['data']['reviews_count'] = $reviews_count;
            $data['data']['coupon'] = $coupon_data;
            $data['data']['price_per_night'] = $provider_user->price_per_night;
            $data['data']['image'] = $image;
            $data['data']['hostname'] = $provider_user->host_name;
            $data['data']['hostphone'] = $provider_user->host_phone;
             $data['data']['encodedid'] = $provider_user->encodedid;
            $data['provider_type'] = '';
             $data['data']['couponid'] = $bookings->coupon_id;
            if($bookings->coupon_id !="")            {
              $dis = Coupon::where('id',$bookings->coupon_id)->value('discount');
              $data['data']['discount'] = $bookings->total_amount*$dis/100;                 
            }
            else
            {
              $data['data']['discount'] = "";
            }
                  // $provider_type = '3';

            //echo "<pre>"; print_r($data); die;

          }elseif($bookings->people_provider_id == '' &&  $bookings->places_provider_id == ''){

              $provider_user = ThingProvider::where('id',$bookings->things_provider_id )->first();
              $reviews_count = Review::where('things_provider_id', $provider_user->id)->count();
              $attachment = Attachment::where('things_provider_id',$bookings->things_provider_id )->first();
              $image = URL::to('/').'/attachments/'.$attachment->filenames;

               $data['status'] = 1;
              $data['data']['booking_id'] = $bookings->id;
               $data['data']['status'] = $bookings->status;
              $data['data']['check_in'] = $bookings->check_in;
              $data['data']['check_out'] = $bookings->check_out;
              $data['data']['time_in'] = $bookings->time_in;
              $data['data']['time_out'] = $bookings->time_out;
              $data['data']['total_amount'] = $bookings->total_amount;
              $data['data']['cancelled_by'] = $bookings_cancelled->name;
              $data['data']['cancelled_by_id'] = $bookings->cancelled_by;
               $data['data']['bookings_cancelled_by_me'] = $bookings_cancelled_me;
              $data['data']['title'] = $provider_user->title;
              $data['data']['address'] = $provider_user->address;
              $data['data']['latitude'] = $provider_user->latitude;
              $data['data']['longitude'] = $provider_user->longitude;
              $data['data']['average_rating'] = $provider_user->ratings;
              $data['data']['ratings'] = $ratings;
              $data['data']['reviews'] = $reviews;
              $data['data']['reviews_count'] = $reviews_count;
              $data['data']['coupon'] = $coupon_data;
              $data['data']['price_per_night'] = $provider_user->price_per_night;
               $data['data']['encodedid'] = $provider_user->encodedid;
              $data['data']['image'] = $image;
              $data['provider_type'] = '2';
              $data['data']['couponid'] = $bookings->coupon_id;
            if($bookings->coupon_id !="")            {
              $dis = Coupon::where('id',$bookings->coupon_id)->value('discount');
              $data['data']['discount'] = $bookings->total_amount*$dis/100;                 
            }
            else
            {
              $data['data']['discount'] = "";
            }

          }elseif($bookings->places_provider_id == '' &&  $bookings->things_provider_id == ''){

                $provider_user = PeopleProvider::where('id',$bookings->people_provider_id )->first();
                 $reviews_count = Review::where('people_provider_id', $provider_user->id)->count();
              $attachment = User::where('id',$provider_user->user_id )->first();
              $image = URL::to('/').'/profile/'.$attachment->image;

               $data['status'] = 1;
              $data['data']['booking_id'] = $bookings->id;
              $data['data']['status'] = $bookings->status;
              $data['data']['check_in'] = $bookings->check_in;
              $data['data']['check_out'] = $bookings->check_out;
              $data['data']['time_in'] = $bookings->time_in;
              $data['data']['time_out'] = $bookings->time_out;
              $data['data']['total_amount'] = $bookings->total_amount;
              $data['data']['cancelled_by'] = $bookings_cancelled->name;
              $data['data']['cancelled_by_id'] = $bookings->cancelled_by;
               $data['data']['bookings_cancelled_by_me'] = $bookings_cancelled_me;
              $data['data']['title'] = $provider_user->title;
              $data['data']['address'] = $provider_user->address;
              $data['data']['latitude'] = $provider_user->latitude;
              $data['data']['longitude'] = $provider_user->longitude;
              $data['data']['average_rating'] = $provider_user->ratings;
              $data['data']['ratings'] = $ratings;
              $data['data']['reviews'] = $reviews;
               $data['data']['reviews_count'] = $reviews_count;
               $data['data']['coupon'] = $coupon_data;
              $data['data']['price_per_night'] = $provider_user->price_per_night;
               $data['data']['encodedid'] = $provider_user->encodedid;
              $data['data']['image'] = $image;
              $data['provider_type'] = '1';
              $data['data']['couponid'] = $bookings->coupon_id;
            if($bookings->coupon_id !="")            {
              $dis = Coupon::where('id',$bookings->coupon_id)->value('discount');
              $data['data']['discount'] = $bookings->total_amount*$dis/100;                 
            }
            else
            {
              $data['data']['discount'] = "";
            }

          }
        }
          
        }elseif($status == '3'){

          $bookings = Booking::where('id', $id)->where('status', '3')->first();
          $coupon = Coupon::where('id',$bookings->coupon_id)->first();
          if($coupon){
            $coupon_data =  $coupon->discount;

          }else{
            $coupon_data =  "";
          }

           $reviews = Review::where('booking_id', $id)->first();
          if($reviews){
            $ratings = $reviews->ratings;
            $reviews = $reviews->reviews;
          }else{
            $ratings = '';
            $reviews = '';
          }
          if($bookings){
          if($bookings->people_provider_id == '' &&  $bookings->things_provider_id == ''){
            $provider_user = PlaceProvider::where('id',$bookings->places_provider_id )->first();
             $reviews_count = Review::where('places_provider_id', $provider_user->id)->count();
            $attachment = Attachment::where('places_provider_id',$bookings->places_provider_id )->first();
            $image = URL::to('/').'/attachments/'.$attachment->filenames;

             $data['status'] = 1;
            $data['data']['booking_id'] = $bookings->id;
             $data['data']['status'] = $bookings->status;
            $data['data']['check_in'] = $bookings->check_in;
            $data['data']['check_out'] = $bookings->check_out;
            $data['data']['time_in'] = $bookings->time_in;
            $data['data']['time_out'] = $bookings->time_out;
            $data['data']['total_amount'] = $bookings->total_amount;
            $data['data']['title'] = $provider_user->title;
            $data['data']['address'] = $provider_user->address;
            $data['data']['latitude'] = $provider_user->latitude;
            $data['data']['longitude'] = $provider_user->longitude;
            $data['data']['guests'] = $provider_user->total_guests;
            $data['data']['average_rating'] = $provider_user->ratings;
            $data['data']['ratings'] = $ratings;
            $data['data']['reviews'] = $reviews;
            $data['data']['coupon'] = $coupon_data;
             $data['data']['reviews_count'] = $reviews_count;
            $data['data']['price_per_night'] = $provider_user->price_per_night;
            $data['data']['image'] = $image;
            $data['data']['hostname'] = $provider_user->host_name;
            $data['data']['hostphone'] = $provider_user->host_phone;
             $data['data']['encodedid'] = $provider_user->encodedid;
            $data['provider_type'] = '';
             $data['data']['couponid'] = $bookings->coupon_id;
            if($bookings->coupon_id !="")            {
              $dis = Coupon::where('id',$bookings->coupon_id)->value('discount');
              $data['data']['discount'] = $bookings->total_amount*$dis/100;                 
            }
            else
            {
              $data['data']['discount'] = "";
            }
                  // $provider_type = '3';

          }elseif($bookings->people_provider_id == '' &&  $bookings->places_provider_id == ''){

              $provider_user = ThingProvider::where('id',$bookings->things_provider_id )->first();
               $reviews_count = Review::where('things_provider_id', $provider_user->id)->count();
              $attachment = Attachment::where('things_provider_id',$bookings->things_provider_id )->first();
              $image = URL::to('/').'/attachments/'.$attachment->filenames;

               $data['status'] = 1;
              $data['data']['booking_id'] = $bookings->id;
               $data['data']['status'] = $bookings->status;
              $data['data']['check_in'] = $bookings->check_in;
              $data['data']['check_out'] = $bookings->check_out;
              $data['data']['time_in'] = $bookings->time_in;
              $data['data']['time_out'] = $bookings->time_out;
              $data['data']['total_amount'] = $bookings->total_amount;
              $data['data']['title'] = $provider_user->title;
              $data['data']['address'] = $provider_user->address;
              $data['data']['latitude'] = $provider_user->latitude;
              $data['data']['longitude'] = $provider_user->longitude;
              $data['data']['average_rating'] = $provider_user->ratings;
              $data['data']['ratings'] = $ratings;
              $data['data']['reviews'] = $reviews;
               $data['data']['reviews_count'] = $reviews_count;
               $data['data']['coupon'] = $coupon_data;
              $data['data']['price_per_night'] = $provider_user->price_per_night;
               $data['data']['encodedid'] = $provider_user->encodedid;
              $data['data']['image'] = $image;
              $data['provider_type'] = '2';
              $data['data']['couponid'] = $bookings->coupon_id;
            if($bookings->coupon_id !="")            {
              $dis = Coupon::where('id',$bookings->coupon_id)->value('discount');
              $data['data']['discount'] = $bookings->total_amount*$dis/100;                 
            }
            else
            {
              $data['data']['discount'] = "";
            }

          }elseif($bookings->places_provider_id == '' &&  $bookings->things_provider_id == ''){
              $provider_user = PeopleProvider::where('id',$bookings->people_provider_id )->first();
              $reviews_count = Review::where('people_provider_id', $provider_user->id)->count();
              $attachment = User::where('id',$provider_user->user_id )->first();
              $image = URL::to('/').'/profile/'.$attachment->image;
              $data['status'] = 1;
              $data['data']['booking_id'] = $bookings->id;
               $data['data']['status'] = $bookings->status;
              $data['data']['check_in'] = $bookings->check_in;
              $data['data']['check_out'] = $bookings->check_out;
              $data['data']['time_in'] = $bookings->time_in;
              $data['data']['time_out'] = $bookings->time_out;
              $data['data']['total_amount'] = $bookings->total_amount;
              $data['data']['title'] = $provider_user->title;
              $data['data']['address'] = $provider_user->address;
              $data['data']['latitude'] = $provider_user->latitude;
              $data['data']['longitude'] = $provider_user->longitude;
              $data['data']['price_per_night'] = $provider_user->price_per_night;
              $data['data']['average_rating'] = $provider_user->ratings;
              $data['data']['ratings'] = $ratings;
              $data['data']['reviews'] = $reviews;
              $data['data']['reviews_count'] = $reviews_count;
              $data['data']['coupon'] = $coupon_data;
               $data['data']['encodedid'] = $provider_user->encodedid;
              $data['data']['image'] = $image;
              $data['provider_type'] = '1';
               $data['data']['couponid'] = $bookings->coupon_id;
            if($bookings->coupon_id !="")            {
              $dis = Coupon::where('id',$bookings->coupon_id)->value('discount');
              $data['data']['discount'] = $bookings->total_amount*$dis/100;                 
            }
            else
            {
              $data['data']['discount'] = "";
            }
          }
        }          
      }

   
   
    return view('frontend.booking-historydetail')->with(compact('data'));
  }

  public function cancel_booking(Request $request)
  {

    $booking_data = Booking::where('id',$request->get('bookingid'))->first();
    $username = User::where('id',$request->userid)->value('name');
    if( $request->userid == $booking_data->provider_user_id){
        $reciever = $booking_data->user_id;
        $msg = "Booking cancelled.User will be refunded for the same.";
        
    }else{
        $reciever = $booking_data->provider_user_id;
        $msg = "Booking cancelled.Refund in progress.";
    }   
    $booking = Booking::where('id',$request->get('bookingid'))->update([
    'status' => '2','cancelled_by' => $request->userid
    ]);
    if($booking){

      
        $notification = new Notification;
        $notification->user_id = $request->userid;
        $notification->message = 'Booking Cancelled by '.$username;
        $notification->sender = $request->userid;
        $notification->reciever = $reciever;
        $notification->booking_id = $request->get('bookingid');
        $notification->type = 2;
        $notification->save();
       
        return response()->json(['msg'=> $msg,'success'=>1]);
    }
    else
      return response()->json(['msg'=> $msg,'success'=>0]);
  }

  public function provider_reviews(Request $request)
    { 
    if(!Auth::check()){
        return redirect()->route('home1')->with( ['show_modal' =>1]);
        $show_modal = 1;
    }
    else
    {
      $show_modal = 0;
    }   
    $user_id = Auth::id();
    $review_place = array();
    $review_things = array();
    $review_people = array();
    $review = array();
    $reviews1 = Review::where('provider_user_id',$user_id)->where('people_provider_id','<>','')->where('reviews','<>','')->paginate(2);
    if($reviews1){    
      foreach($reviews1 as $key => $value){
        $provider = PeopleProvider::where('id',$value->people_provider_id)->first();
        $user = User::where('id',$value->user_id)->first();
        $review_people[$key]['reviews'] = $value->reviews; 
        $review_people[$key]['title'] = $provider->title;       
        $review_people[$key]['user'] = $user->name; 
        $review_people[$key]['datemonth'] = date('F',strtotime($value->created_at));
        $review_people[$key]['dateyear'] = date('Y',strtotime($value->created_at));
        $review_people[$key]['image'] = URL::to('/').'/profile/'.$user->image; 
        $review_people[$key]['ratings'] = $value->ratings; 
      }
    }
    $reviews2 = Review::where('provider_user_id',$user_id)->where('things_provider_id','<>','')->where('reviews','<>','')->paginate(2);
    if($reviews2){
      foreach($reviews2 as $key => $value){
        $provider = ThingProvider::where('id',$value->things_provider_id)->first();
        $user = User::where('id',$value->user_id)->first();
        $review_things[$key]['reviews'] = $value->reviews; 
        $review_things[$key]['title'] = $provider->title;
        $review_things[$key]['datemonth'] = date('F',strtotime($value->created_at));
        $review_things[$key]['dateyear'] = date('Y',strtotime($value->created_at));
        $review_things[$key]['user'] = $user->name; 
        $review_things[$key]['image'] = URL::to('/').'/profile/'.$user->image; 
        $review_things[$key]['ratings'] = $value->ratings; 
      }
    }
    $reviews3 = Review::where('provider_user_id',$user_id)->where('places_provider_id','<>','')->where('reviews','<>','')->paginate(2);

    if($reviews3){    
      foreach($reviews3 as $key => $value){
        $provider = PlaceProvider::where('id',$value->places_provider_id)->first();

        $user = User::where('id',$value->user_id)->first();
        $review_place[$key]['reviews'] = $value->reviews; 
        $review_place[$key]['datemonth'] = date('F',strtotime($value->created_at));
        $review_place[$key]['dateyear'] = date('Y',strtotime($value->created_at)); 
        $review_place[$key]['title'] = $provider->title;
        $review_place[$key]['user'] = $user->name; 
        $review_place[$key]['image'] = URL::to('/').'/profile/'.$user->image; 
        $review_place[$key]['ratings'] = $value->ratings; 
      }    
    }
    $reviewsall = Review::where('provider_user_id',$user_id)->where('reviews','<>','')->paginate(2);

      if($reviewsall){
      foreach($reviewsall as $key => $value){
          if($value->people_provider_id != ""){
        $provider = PeopleProvider::where('id',$value->people_provider_id)->first();
        $title = $provider->title;
        }elseif ($value->places_provider_id != "") {
           $provider = PlaceProvider::where('id',$value->places_provider_id)->first();        
          $title = $provider->title;
        }elseif ($value->things_provider_id != "") {
          $provider = ThingProvider::where('id',$value->things_provider_id)->first();               
          $title = $provider->title;          }
        $user = User::where('id',$value->user_id)->first();
        $review[$key]['reviews'] = $value->reviews;
        $review[$key]['title'] = $title ;
        $review[$key]['user'] = $user->name; 
        $review[$key]['datemonth'] = date('F',strtotime($value->created_at));
        $review[$key]['dateyear'] = date('Y',strtotime($value->created_at)); 
        $review[$key]['date'] = date('Y-m-d',strtotime($value->created_at)); 
        $review[$key]['image'] = URL::to('/').'/profile/'.$user->image; 
        $review[$key]['ratings'] = $value->ratings; 
      }

    }
      $reviews = Review::where('provider_user_id',$user_id)->where('reviews','<>','')->count();
          $ratings_total = Review::where('provider_user_id',$user_id)->get()->sum('ratings');
          $ratings_count = Review::where('provider_user_id',$user_id)->count();
           if($ratings_total){

            $aveage_rating = number_format((float)($ratings_total/$ratings_count), 1, '.', '');
          }else{
            $aveage_rating = "";
          }
          
           if($request->ajax())
          {
            $type = $request->type;

            return view('frontend.providerreviewsview')->with(compact('review_place','review_things','review_people','aveage_rating','review','reviews1','reviews2','reviews3','reviewsall','type'));
           
          }
          
    return view('frontend.providerreviews')->with(compact('review_place','review_things','review_people','aveage_rating','review','reviews1','reviews2','reviews3','reviewsall'));
  }


  public function check_balance(Request $request)
  {   
      $user = Auth::user();
       if(!Auth::check()){
        return redirect()->route('home1')->with( ['show_modal' =>1]);
        $show_modal = 1;
      }
    
    else
    {
      $show_modal = 0;
    }
      if($user){

          if($user->user_vault_total == ''){
            $user_vault_total = 0;
          }else{
            $user_vault_total = $user->user_vault_total;
          }
     
      }
      return view('frontend.wallet_balance')->with(compact('user_vault_total'));
  }
  public function my_progress(Request $request)
  {

    $user_id = Auth::id();
    if(!Auth::check()){
        return redirect()->route('home1')->with( ['show_modal' =>1]);
        $show_modal = 1;
      }
    
    else
    {
      $show_modal = 0;
    }
      $review_count = Review::where('provider_user_id',$user_id)->where('reviews','<>','')->count();
      $ratings_total = Review::where('provider_user_id',$user_id)->get()->sum('ratings');
      $ratings_count = Review::where('provider_user_id',$user_id)->count();
     $total_bookings =  Booking::where('provider_user_id',$user_id)->count();

       $overall_earnings =  WalletTransaction::where('provider_user_id',$user_id)->where('transaction_amount_status','0')->get()->sum("transaction_amount");
       if($ratings_total){
        $aveage_rating = round(($ratings_total/$ratings_count),1);
      }else{
        $aveage_rating = "";
      }
      return view('frontend.myprogress')->with(compact('overall_earnings','review_count','total_bookings','aveage_rating'));
  }

    public function addReview(Request $request){
      $loggedInUser = Auth::user();               
      $check_review = Review::where('booking_id',$request->get('booking_id'))->first();
      if($check_review){
         if($request->get('reviews') != ""){
         $reviews = $request->get('reviews');
      }else{
         $reviews = "";
      }
      if($request->get('provider_type') == '1'){
        $review_update = Review::where('booking_id',$request->get('booking_id'))->update([
          'user_id' => $loggedInUser->id,
          'booking_id' => $request->get('booking_id'),
          'provider_user_id' => $request->get('provider_user_id'),
          'people_provider_id' => $request->get('provider_id'),
          'reviews' => $reviews,
          'ratings' => $request->get('ratings'),
      ]);

       }elseif($request->get('provider_type') == '2'){
        $review_update = Review::where('booking_id',$request->get('booking_id'))->update([
              'user_id' => $loggedInUser->id,
              'booking_id' => $request->get('booking_id'),
              'provider_user_id' => $request->get('provider_user_id'),
              'things_provider_id' => $request->get('provider_id'),
              'reviews' => $reviews,
              'ratings' => $request->get('ratings'),
            ]);

       }elseif($request->get('provider_type') == '3'){
        $review_update = Review::where('booking_id',$request->get('booking_id'))->update([
              'user_id' => $loggedInUser->id,
              'booking_id' => $request->get('booking_id'),
              'provider_user_id' => $request->get('provider_user_id'),
              'places_provider_id' => $request->get('provider_id'),
              'reviews' => $reviews,
              'ratings' => $request->get('ratings'),
            ]);
       }
        $review_update_data =  Review::where('id',$review_update->id)->first();
           if($review_update_data){

            return response()->json([
            "status" => 1,
            "message" => "Review Upadted successfully!!!",
            'data' => $review_update_data,
            
             ], 200);

          }else{

            return response()->json([
            "status" => 0,
            "message" => "Something went wrong!",
                 
             ], 422);

          }


      }else{
         if($request->get('reviews') != ""){
         $reviews = $request->get('reviews');
      }else{
         $reviews = "";
      } 

       $review = new Review;
       if($request->get('provider_type') == '1'){

         $provider_id = $request->get('provider_id');
         $review->people_provider_id = $provider_id;

       }elseif($request->get('provider_type') == '2'){

         $provider_id = $request->get('provider_id');
         $review->things_provider_id = $provider_id;
        
       }elseif($request->get('provider_type') == '3'){

         $provider_id = $request->get('provider_id');
         $review->places_provider_id = $provider_id;
       }

        $review->user_id = $loggedInUser->id;
        $review->booking_id = $request->get('booking_id');
        $review->provider_user_id = $request->get('provider_user_id');
        $review->ratings = $request->get('ratings');
        $review->reviews = $reviews;
        $review->save();
        $review_data =  Review::where('id',$review->id)->first();
           if($review_data){

            return response()->json([
            "status" => 1,
            "message" => "Review Added successfully!!!",
            'data' => $review_data,
            
             ], 200);

          }else{

            return response()->json([
            "status" => 0,
            "message" => "Something went wrong!",
                 
             ], 422);

          }

      }       

   }

  public function favourites(Request $request){
    $LoggedInUser = Auth::user();
     if(!Auth::check())
    {
      return response()->json([
        "data" => 2
      ]);
    }
    else
    {      
      if($request->get('type') == '1'){
       $favourite =   Favourite::where('people_provider_id',$request->get('provider_id'))->where('user_id', $LoggedInUser->id)->first();
         if($favourite){
          $favourite =   Favourite::where('people_provider_id',$request->get('provider_id'))->where('user_id', $LoggedInUser->id)->value('favourite');

            if($favourite==1) {
              $status = 0 ; 
              $msg = "Removed from Favourites";
            }
            else{ 
              $status =1;
               $msg = "Added to Favourites";
            }
            $favourite =   Favourite::where('people_provider_id',$request->get('provider_id'))->where('user_id', $LoggedInUser->id)->update([
              'favourite' => $status,
            ]);
         }else{
          $favourite = new Favourite;
          $favourite->user_id = $LoggedInUser->id;
          $favourite->favourite = $request->get('favourite');
          $favourite->people_provider_id = $request->get('provider_id');
          $msg = "Added to  Favourites";
          $favourite->save();        
         }
          $favourite =   Favourite::where('people_provider_id',$request->provider_id)->where('user_id', $LoggedInUser->id)->value('favourite');
            return response()->json([
          "message" => $msg,
          "fav_status" => $favourite,
          "data"=>1
           ]);
      }elseif($request->get('type') == '2'){
         $favourite =   Favourite::where('things_provider_id',$request->get('provider_id'))->where('user_id', $LoggedInUser->id)->first();
         if($favourite){
          $favourite =   Favourite::where('things_provider_id',$request->get('provider_id'))->where('user_id', $LoggedInUser->id)->value('favourite');;
            if($favourite==1) {
              $status = 0 ; 
              $msg = "Removed from Favourites";
            }
            else{ 
              $status =1;
               $msg = "Added to Favourites";
            }
            $favourite =   Favourite::where('things_provider_id',$request->get('provider_id'))->where('user_id', $LoggedInUser->id)->update([
              'favourite' => $status,
            ]);
         }else{
          $favourite = new Favourite;
          $favourite->user_id = $LoggedInUser->id;
          $favourite->favourite = $request->get('favourite');
          $favourite->things_provider_id = $request->get('provider_id');
          $msg = "Added to  Favourites";
          $favourite->save();
         }
         $favourite =   Favourite::where('things_provider_id',$request->get('provider_id'))->where('user_id', $LoggedInUser->id)->value('favourite');
            return response()->json([
          "message" => $msg,
          "fav_status" => $favourite,
          "data"=>1
           ]);
      }elseif($request->get('type') == '3'){
          $provider =   PlaceProvider::where('id',$request->get('provider_id'))->first();
          if($provider){
             $favourite =   Favourite::where('places_provider_id',$request->get('provider_id'))->where('user_id', $LoggedInUser->id)->first();

         if($favourite){
          
          $favourite =   Favourite::where('places_provider_id',$request->get('provider_id'))->where('user_id', $LoggedInUser->id)->value('favourite');
          if($favourite==1) {
            $status = 0 ; 
            $msg = "Removed from Favourites";
          }
          else{ 
            $status =1;
             $msg = "Added to Favourites";
          }
            $favourite =   Favourite::where('places_provider_id',$request->get('provider_id'))->where('user_id', $LoggedInUser->id)->update([
              'favourite' => $status,
            ]);
           
         }else{
          $favourite = new Favourite;
          $favourite->user_id = $LoggedInUser->id;
          $favourite->favourite = $request->get('favourite');
          $favourite->places_provider_id = $request->get('provider_id');
          $msg = "Added to  Favourites";
          $favourite->save();
         }
         $favourite =   Favourite::where('places_provider_id',$request->get('provider_id'))->where('user_id', $LoggedInUser->id)->value('favourite');
          return response()->json([
        "message" => $msg,
        "fav_status" => $favourite,
        "data"=>1
         ]);
        }
      }
    }
  }

  public function Host_transaction_history(Request $request){
    if(!Auth::check()){
      return redirect()->route('home1')->with( ['show_modal' =>1]);
      $show_modal = 1;
    }
    
    else
    {
      $show_modal = 0;
    }

    $user = Auth::user();
    $data_rcd = array();
    $data_all = array();
    $data_progress = array();
    $data_withdraw = array();
    $data_rcd = array();
    $data = array();
    $overall_earnings =  WalletTransaction::where('provider_user_id',$user->id)->where('transaction_amount_status','0')->get()->sum("transaction_amount");

     if($request->get('filterprovider-history') == '1'){


      $filter = $request->get('filterprovider-history');
      $transactionsrcd =  WalletTransaction::where('provider_user_id',$user->id)->where('transaction_amount_status','0')->orderBy('date', 'DESC')->paginate(4);

      $transactions =  WalletTransaction::where('provider_user_id',$user->id)->where('transaction_amount_status','0')->orderBy('date', 'DESC')->get();
      foreach ($transactions as $key => $value) {
       if($value->people_provider_id != ""){
         $provider = PeopleProvider::where('id',$value->people_provider_id)->first();
         $people =   People::where('id',$provider->cat_id)->first();
         $provider_id = $value->people_provider_id;
         $category = $people->name;
        }elseif ($value->places_provider_id != "") {
         $provider = PlaceProvider::where('id',$value->places_provider_id)->first();
          $place =   Place::where('id',$provider->cat_id)->first();
          $category = $place->name;
        $provider_id = $value->places_provider_id;
        }elseif ($value->things_provider_id != "") {
        $provider = ThingProvider::where('id',$value->things_provider_id)->first();
        $thing =   Thing::where('id',$provider->cat_id)->first();
        $category = $thing->name;
        $provider_id = $value->things_provider_id;
        }
        $data_rcd[$key]['date'] = date('Y-m-d H:i:s',strtotime($value->updated_at));
        $data_rcd[$key]['category'] = $category;
        $data_rcd[$key]['transaction_amount_status'] = $value->transaction_amount_status;
        $data_rcd[$key]['provider_id'] = $provider_id;
        $data_rcd[$key]['provider_title'] = $provider->title;
        $data_rcd[$key]['amount'] = $value->transaction_amount;

     }
     $type = 1;

    }
    elseif($request->get('filterprovider-history') == '2'){

      $filter = $request->get('filterprovider-history');
      $transactionsprogress =  WalletTransaction::where('provider_user_id',$user->id)->where('transaction_amount_status','1')->orderBy('date', 'DESC')->paginate(5);

       $transactions =  WalletTransaction::where('provider_user_id',$user->id)->where('transaction_amount_status','1')->orderBy('date', 'DESC')->paginate(5);

      foreach ($transactionsprogress as $key => $value) {
      $provider_id  = ''; 
      $category = ''; 
      $title = '';
      if($value->people_provider_id != ""){
       $provider = PeopleProvider::where('id',$value->people_provider_id)->first();
       $people =   People::where('id',$provider->cat_id)->first();
       $provider_id = $value->people_provider_id;
       $category = $people->name;
       $title = $provider->title;
        }elseif ($value->places_provider_id != "") {
          $provider = PlaceProvider::where('id',$value->places_provider_id)->first();
          $place =   Place::where('id',$provider->cat_id)->first();
          $category = $place->name;
          $provider_id = $value->places_provider_id;
          $title = $provider->title;
        }elseif ($value->things_provider_id != "") {
          $provider = ThingProvider::where('id',$value->things_provider_id)->first();
          $thing =   Thing::where('id',$provider->cat_id)->first();
          $category = $thing->name;
          $provider_id = $value->things_provider_id;
          $title = $provider->title;
        }
      
        $data_progress[$key]['date'] = date('Y-m-d H:i:s', strtotime($value->updated_at));
        $data_progress[$key]['category'] = $category; 
        $data_progress[$key]['transaction_amount_status'] = $value->transaction_amount_status;
        $data_progress[$key]['provider_id'] = $provider_id;
        $data_progress[$key]['provider_title'] = $title;
        $data_progress[$key]['amount'] = $value->transaction_amount;    
     }
     $type = 2;
     
    }elseif($request->get('filterprovider-history') == '3'){
      $filter = $request->get('filterprovider-history');
      $transactionswithdraw =  WalletTransaction::where('provider_user_id',$user->id)->where('transaction_amount_status','2')->orderBy('date', 'DESC')->paginate(5);
      $transactions =  WalletTransaction::where('provider_user_id',$user->id)->where('transaction_amount_status','2')->orderBy('date', 'DESC')->paginate(5);
     foreach ($transactionswithdraw as $key => $value) {
       $provider_id  = ''; 
        $category = '';
        $title = ""; 
        if($value->people_provider_id != ""){
          $provider = PeopleProvider::where('id',$value->people_provider_id)->first();
         $people =   People::where('id',$provider->cat_id)->first();
         $provider_id = $value->people_provider_id;
         $category = $people->name;
         $title = $provider->title;
        }elseif ($value->places_provider_id != "") {
         $provider = PlaceProvider::where('id',$value->places_provider_id)->first();
          $place =   Place::where('id',$provider->cat_id)->first();
          $category = $place->name;
          $provider_id = $value->places_provider_id;
          $title = $provider->title;
        }elseif ($value->things_provider_id != "") {
          $provider = ThingProvider::where('id',$value->things_provider_id)->first();
          $thing =   Thing::where('id',$provider->cat_id)->first();
          $category = $thing->name;
          $provider_id = $value->things_provider_id;
          $title = $provider->title;
        }

        $data_withdraw[$key]['date'] = date('Y-m-d H:i:s',strtotime($value->updated_at));
        $data_withdraw[$key]['category'] = $category;
        $data_withdraw[$key]['transaction_amount_status'] = $value->transaction_amount_status;
        $data_withdraw[$key]['provider_id'] = $provider_id;
        $data_withdraw[$key]['provider_title'] = $title;
        $data_withdraw[$key]['amount'] = $value->transaction_amount;    
        }
        $type = 3;
       
    }elseif($request->get('type') == '0'){
        $filter = $request->get('filterprovider-history');
        $transactionsall =  WalletTransaction::where('provider_user_id',$user->id)->orderBy('date', 'DESC')->paginate(5);;
        $transactions =  WalletTransaction::where('provider_user_id',$user->id)->orderBy('date', 'DESC')->paginate(5);;
       foreach ($transactionsall as $key => $value) {
        $category = "";
        $provider_id = "";
        $title = "";
        if($value->people_provider_id != ""){
         $provider = PeopleProvider::where('id',$value->people_provider_id)->first();
         $people =   People::where('id',$provider->cat_id)->first();
         $provider_id = $value->people_provider_id;
         $category = $people->name;
         $title = $provider->title;
        }elseif ($value->places_provider_id != "") {
          $provider = PlaceProvider::where('id',$value->places_provider_id)->first();
          $place =   Place::where('id',$provider->cat_id)->first();
          $category = $place->name;
          $provider_id = $value->places_provider_id;
          $title = $provider->title;
        }elseif ($value->things_provider_id != "") {
          $provider = ThingProvider::where('id',$value->things_provider_id)->first();
          $thing =   Thing::where('id',$provider->cat_id)->first();
          $category = $thing->name;
          $provider_id = $value->things_provider_id;
          $title = $provider->title;
        }
        $data_all[$key]['date'] = date('Y-m-d H:i:s',strtotime($value->updated_at));
        $data_all[$key]['category'] = $category;
        $data_all[$key]['transaction_amount_status'] = $value->transaction_amount_status;
        $data_all[$key]['provider_id'] = $provider_id;
        $data_all[$key]['provider_title'] = $title;
        $data_all[$key]['amount'] = $value->transaction_amount;    
       }
       $type = 0;
      
     }
     else{


        $transactions =  WalletTransaction::where('provider_user_id',$user->id)->orderBy('date', 'DESC')->paginate(5);
        $filter = $request->get('filterprovider-history');
       foreach ($transactions as $key => $value) {
        $category = "";
        $provider_id = "";
        $title = "";
        if($value->people_provider_id != ""){
         $provider = PeopleProvider::where('id',$value->people_provider_id)->first();
         $people =   People::where('id',$provider->cat_id)->first();
         $provider_id = $value->people_provider_id;
         $category = $people->name;
         $title = $provider->title;
        }elseif ($value->places_provider_id != "") {
          $provider = PlaceProvider::where('id',$value->places_provider_id)->first();
          $place =   Place::where('id',$provider->cat_id)->first();
          $category = $place->name;
          $provider_id = $value->places_provider_id;
          $title = $provider->title;
        }elseif ($value->things_provider_id != "") {
          $provider = ThingProvider::where('id',$value->things_provider_id)->first();
          $thing =   Thing::where('id',$provider->cat_id)->first();
          $category = $thing->name;
          $provider_id = $value->things_provider_id;
          $title = $provider->title;
        }
        $data[$key]['date'] = date('Y-m-d H:i:s',strtotime($value->updated_at));
         $data[$key]['category'] = $category;
        $data[$key]['transaction_amount_status'] = $value->transaction_amount_status;
        $data[$key]['provider_id'] = $provider_id;
        $data[$key]['provider_title'] = $title;
        $data[$key]['amount'] = $value->transaction_amount;    
       }
       $type = $request->typedata;
     }
     if($request->ajax())
          {
            $type = 1;
           


          return view('frontend.transactionhistoryview')->with(compact('data_all','overall_earnings','filter','transactionsall','transactionswithdraw','transactionsrcd','transactionsprogress','type','data_progress','data_rcd','data_withdraw'));
           
    }

    return view('frontend.transaction_history')->with(compact('data_all','overall_earnings','filter','transactionsall','transactionswithdraw','transactionsrcd','transactionsprogress','type','data_progress','data_rcd','data_withdraw','data','transactions'));
    
  }

  public function about_us(Request $request)
  {
    $data = Privacy::where('title','About Us')->first();
     if($data){
      $desc =  ($data->description); 
      }else{
        $desc = 'Sorry!! Will soon update content here'; 
      }
     return view('frontend.information.aboutus')->with(compact('desc'));;
  }

  public function terms_and_conditions(Request $request)
  {
    $data = Privacy::where('title','Terms and Conditions')->first();
    if($data){
      $desc =  $data->description; 
    }else{
      $desc = 'Sorry!! Will soon update content here'; 
    }
    return view('frontend.information.terms_conditions')->with(compact('desc'));
  }

   public function faqs(Request $request)
  {
    $faq = Faq::all();
    $data = array();
    if($faq){
      foreach ($faq as $key => $value) {
        $data[$key]['id'] = $value->id;
        $data[$key]['question'] = $value->question;
        $data[$key]['answer'] = $value->answer;              
    }
  }
    return view('frontend.information.faq')->with(compact('data'));
  }

   public function privacy_policy(Request $request)
  {
    $data = Privacy::where('title','Privacy Policy')->first();
    if($data){
      $desc =  ($data->description); 
    }else{
      $desc = 'Sorry!! Will soon update content here'; 
    }
    return view('frontend.information.privacy_policy')->with(compact('desc'));
  }


   public function howitworks(Request $request)
  {
    $data = Privacy::where('title','How it works')->first();
    if($data){
      $desc =  ($data->description); 
    }else{
      $desc = 'Sorry!! Will soon update content here'; 
    }
    return view('frontend.information.howitworks')->with(compact('desc'));
  }


   public function onlinesupport(Request $request)
  {
    $data = Privacy::where('title','Online Support')->first();
    if($data){
      $desc =  ($data->description); 
    }else{
      $desc = 'Sorry!! Will soon update content here'; 
    }
    return view('frontend.information.onlinesupport')->with(compact('desc'));
  }

   public function trustandsafety(Request $request)
  {
    $data = Privacy::where('title','Trust & Safety')->first();
    if($data){
      $desc =  ($data->description); 
    }else{
      $desc = 'Sorry!! Will soon update content here'; 
    }
    return view('frontend.information.trustandsafety')->with(compact('desc'));
  }

    public function help(Request $request)
  {
    $data = Privacy::where('title','HELP')->first();
    if($data){
      $desc =  ($data->description); 
    }else{
      $desc = 'Sorry!! Will soon update content here'; 
    }
    return view('frontend.information.help')->with(compact('desc'));
  }

  public function searchdata(Request $request,$category=Null,$typecat=Null,$lat=null, $lng=null)
  {    

    if(Auth::check() && Auth::user()->userheaderstatus==1)
    {
      return Redirect::back()->withInput()->with("booking_modal", 1);     
    }

    if(Auth::check())
      $userid = Auth::user()->id;
    else
      $userid = "";
     $placeids = array();
   
    if($request->catdropdown=="all" || $category=="all"){     
      if($request->typecat1 !="" || $request->typecat2 !="" ||  $request->typecat3 !="") {
        if($request->typecat1=="home") 
          $catval  = "place";        
        if($request->typecat2=="menu1") 
          $catval  = "thing";
        if($request->typecat3=="menu2") 
          $catval  = "people";
      }
      else
      {

        if($typecat=="home") 
          $catval  = "place";        
        if($typecat=="menu1") 
          $catval  = "thing";
        if($typecat=="menu2") 
          $catval  = "people";      
      }
    }
  
     else{
        if($request->catdropdown !="")
         $cattype = explode("-",$request->catdropdown);         
        else
        {
          $cattype = explode("-",$category); 
        }
        $cat = $cattype[0];
        $catval = $cattype[1];
        

        if($request->typecat1 !="" || $request->typecat2 !="" ||  $request->typecat3 !="") {
       if($request->typecat1=="home") 
          $placecat_id = $cat;      
        if($request->typecat2=="menu1") 
           $thing_id = $cat;
        if($request->typecat3=="menu2") 
          $people_id = $cat;
      }
      else
      {
        if($typecat=="home") 
           $placecat_id = $cat;       
        if($typecat=="menu1") 
         $thing_id = $cat;
        if($typecat=="menu2") 
          $people_id = $cat;
      }
        
    }
   

  
    if($catval =="place"){     
      if(($request->get('latitude1') != '' && $request->get('longitude1') != '') || ($lat!="" && $lng!="")){

        if($request->get('latitude1') != '' && $request->get('longitude1'))
          {
            $latitude = $request->get('latitude1');
            $longitude = $request->get('longitude1');
          }
          else
          {
            $latitude = $lat;
            $longitude = $lng;
          }
        if( $request->catdropdown == 'all' ||  $category=="all"){  
           $provider = PlaceProvider::select(DB::raw("*, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS($latitude) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS($latitude)) * COS( RADIANS( `longitude` ) - RADIANS($longitude)) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS($latitude) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS($latitude)) * COS( RADIANS( `longitude` ) - RADIANS($longitude)) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->orderBy(DB::raw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS($latitude) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS($latitude)) * COS( RADIANS( `longitude` ) - RADIANS($longitude)) ) * 6371 "), 'DESC')->paginate(2);

        }else{          
            $provider  = PlaceProvider::select(DB::raw("*,ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS($latitude) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS($latitude)) * COS( RADIANS( `longitude` ) - RADIANS($longitude)) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS($latitude) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS($latitude)) * COS( RADIANS( `longitude` ) - RADIANS($longitude)) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->where('cat_id',$placecat_id)->orderBy(DB::raw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS($latitude) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS($latitude)) * COS( RADIANS( `longitude` ) - RADIANS($longitude)) ) * 6371 "), 'DESC')->paginate(2);   
        } 
        $providerall = PlaceProvider::select(DB::raw("*, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS($latitude) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS($latitude)) * COS( RADIANS( `longitude` ) - RADIANS($longitude)) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS($latitude) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS($latitude)) * COS( RADIANS( `longitude` ) - RADIANS($longitude)) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->orderBy(DB::raw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS($latitude) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS($latitude)) * COS( RADIANS( `longitude` ) - RADIANS($longitude)) ) * 6371 "), 'DESC')->get();
      }
      else
      {

        $location = GeoIP::getLocation();
        $latitude = $location['lat'];
        $longitude = $location['lon']; 
        if( $request->catdropdown == 'all' || $category =="all"){  
       
         $provider  = PlaceProvider::where('status','1')->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->paginate(2);

        }else{ 
         ;
         $provider  = PlaceProvider::where('status','1')->where('cat_id',$placecat_id)->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15"), 'DESC')->paginate(2);
      

        }
       $providerall  = PlaceProvider::where('status','1')->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->get(); 
      }
        

      $filter = 0;   
       $place  = Place::orderBy('name')->get();
       $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','places')->get();
       $placecategories = array();
       $placedata = array();
       $attachments = array();
       $coupondata = array();
       $peoplecategories[] = 'All';
       foreach ($place as $key => $value) {
           //$placecategories[]=  $value->name;
          $placecategories[$key]['name'] = $value->name;
           $placecategories[$key]['id'] = $value->id;
        }     
      
        foreach ($coupon as $key1 => $value) {
        $day = date('Y-m-d',strtotime($value['created_at']));
        $date1 =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days"));
        $date_now = date('Y-m-d');
        
        if(strtotime($date1) >= strtotime($date_now)){
        //  $i++;
          $coupondata[$key1] = $value;
          $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value['background_image'];
          $coupondata[$key1]['valid_till'] =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days")); 
        }      
           
       }
       $arr = array_values($coupondata); 
      foreach ($provider as $key => $value) {
       $name = User::select('name','image')->where('id',$value->user_id)->first();
       $images = Attachment::where('places_provider_id',$value->id)->get();
       foreach ($images as $key1 => $value1) {
          $attachments[$key1] = $value1->filenames;
       } 
        if (strpos($name->image, 'http') !== false) {
                $image =  $name->image;
        }else{
               $image = URL::to('/').'/profile/'.$name->image;
        }
         if($value->ratings  == ""){
          $ratings = '5';
        }else{
          $ratings = $value->ratings;
        }
        $placedata[$key]['id'] = $value->id;
        $placedata[$key]['name'] = $name->name;
        $placedata[$key]['title'] = $value->title;
        $placedata[$key]['description'] = $value->description;
        $placedata[$key]['total_guests'] = $value->total_guests;
        $placedata[$key]['amenities_offered'] =$value->amenities_offered;
        $placedata[$key]['latitude'] = $value->latitude;
        $placedata[$key]['longitude'] = $value->longitude;
        $placedata[$key]['ratings'] = $ratings;
        $placedata[$key]['attachments'] = $attachments;
        $placedata[$key]['address'] = $value->address;
        $placedata[$key]['price_per_night'] = $value->price_per_night;
        $placedata[$key]['encodedid'] = $value->encodedid;            
      }  
      $location = array();
      $loc= array();
      $i = 0;
      $j= 0;
      foreach ($providerall as $key => $value) {
        for($i=0;$i<=2;$i++)
        {
          if($i==0)
           $loc[$i] = $value->address;
         if($i==1)
           $loc[$i] = $value->latitude;
         if($i==2)
           $loc[$i] = $value->longitude;
        }
        $location[$j] = $loc;
        $j++;               
      }    
      
      $result['categories'] = $placecategories;
      $result['data'] = $placedata;
      $result['coupons'] = $arr;
      $type = "place";
      $page = 'search';
      $test = array();
      $test = $placedata;
      echo  view('frontend.booking_place')->with(compact('result','provider','location','id','filter','placecat_id','placeids','page','test'));
      die;
    }
   
    else if($catval =="thing"){

      if($request->get('latitude2') != '' && $request->get('longitude2') != '' || ($lat!="" && $lng!="")){

         if($request->get('latitude2') != '' && $request->get('longitude2'))
          {
            $latitude = $request->get('latitude2');
            $longitude = $request->get('longitude2');
          }
          else
          {
            $latitude = $lat;
            $longitude = $lng;
          }
       if( $request->catdropdown == 'all' ||  $category=="all"){  
         $provider = ThingProvider::select(DB::raw("*, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS($latitude) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS($latitude)) * COS( RADIANS( `longitude` ) - RADIANS( $longitude )) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS($latitude) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS($latitude)) * COS( RADIANS( `longitude` ) - RADIANS( $longitude )) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->orderBy(DB::raw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS($latitude) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS($latitude)) * COS( RADIANS( `longitude` ) - RADIANS( $longitude )) ) * 6371 "), 'DESC')->paginate(2);

        }else{   

           $provider  = ThingProvider::select(DB::raw("*,ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS($latitude) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS($latitude)) * COS( RADIANS( `longitude` ) - RADIANS($longitude)) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS($latitude) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS($latitude)) * COS( RADIANS( `longitude` ) - RADIANS($longitude)) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->where('cat_id',$thing_id)->orderBy(DB::raw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS($latitude) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS($latitude)) * COS( RADIANS( `longitude` ) - RADIANS($longitude)) ) * 6371 "), 'DESC')->paginate(2); 
          
          }
            $providerall = ThingProvider::select(DB::raw("*, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS($latitude) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS($latitude)) * COS( RADIANS( `longitude` ) - RADIANS($longitude)) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS($latitude) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS($latitude)) * COS( RADIANS( `longitude` ) - RADIANS($longitude)) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->orderBy(DB::raw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS($latitude) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS($latitude)) * COS( RADIANS( `longitude` ) - RADIANS($longitude)) ) * 6371 "), 'DESC')->get(); 
        }     
       else{
        $location = GeoIP::getLocation();
        $latitude = $location['lat'];
        $longitude = $location['lon']; 


        if( $request->catdropdown == 'all' || $category== "all"){ 

            $provider  = ThingProvider::where('status','1')->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->paginate(2);


        }else{             
         $provider  = ThingProvider::where('status','1')->where('cat_id',$thing_id)->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15"), 'DESC')->paginate(2);

        }

        $filter = 0;
        /*$provider  = ThingProvider::where('status','1')->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->get();*/ 
       $providerall  = ThingProvider::where('status','1')->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->get();



      }
       $filter = 0;
      //$provider = DB::select(DB::raw($query));
      $people  = Thing::orderBy('name')->get();
      $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','things')->get();
     $peoplecategories = array();
     $thingdata = array();
     $attachments = array();
     $coupondata = array();
     $thingcategories= array();
      foreach ($people as $key => $value) {
       
        $thingcategories[$key]['name'] = $value->name;
         $thingcategories[$key]['id'] = $value->id;
      }  
       foreach ($coupon as $key1 => $value) {
        $day = date('Y-m-d',strtotime($value['created_at']));
        $date1 =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days"));
        $date_now = date('Y-m-d');
        
        if(strtotime($date1) >= strtotime($date_now)){
        //  $i++;
          $coupondata[$key1] = $value;
          $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value['background_image'];
          $coupondata[$key1]['valid_till'] =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days")); 
        }      
           
       }
       $arr = array_values($coupondata);
      
      foreach ($provider as $key => $value) {
        $name = User::select('name','image')->where('id',$value->user_id)->first();
        $images = Attachment::where('things_provider_id',$value->id)->get();
       foreach ($images as $key1 => $value1) {
          $attachments[$key1] = URL::to('/').'/attachments/'.$value1->filenames;
        }
          if (strpos($name->image, 'http') !== false) {
                  $image =  $name->image;
          }else{
                 $image = URL::to('/').'/profile/'.$name->image;
          }
           if($value->ratings  == ""){
            $ratings = '5';
          }else{
            $ratings = $value->ratings;
          }
        $thingdata[$key]['id'] = $value->id;
        $thingdata[$key]['name'] = $value->title;
        $thingdata[$key]['owned_by'] = $name->name;
        $thingdata[$key]['latitude'] = $value->latitude;
        $thingdata[$key]['longitude'] = $value->longitude;
        $thingdata[$key]['ratings'] = $ratings;
        $thingdata[$key]['attachments'] = $attachments;
        $thingdata[$key]['description'] = $value->description;
        $thingdata[$key]['address'] = $value->address;
        $thingdata[$key]['price_per_night'] = $value->price_per_night; 
        $thingdata[$key]['encodedid'] = $value->encodedid;             
      } 
      $j = 0;
      $location =array();
      foreach ($providerall as $key => $value) {
        for($i=0;$i<=2;$i++)
        {
          if($i==0)
           $loc[$i] = $value->address;
         if($i==1)
           $loc[$i] = $value->latitude;
         if($i==2)
           $loc[$i] = $value->longitude;
        }
        $location[$j] = $loc;
        $j++;               
      }  

      
      $result['status'] = 1;
      $result['categories'] = $thingcategories;
      $result['data'] = $thingdata;
      $result['coupons'] = $arr;
     
      echo  view('frontend.booking_thing')->with(compact('result','provider','id','filter','location','thing_id','placeids')); 
       die;
    }
    else if($catval =="people"){   

      if($request->get('latitude3') != '' && $request->get('longitude3') != '' || ($lat!="" && $lng!="")){

         if($request->get('latitude3') != '' && $request->get('longitude3'))
          {
            $latitude = $request->get('latitude3');
            $longitude = $request->get('longitude3');
          }
          else
          {
            $latitude = $lat;
            $longitude = $lng;
          }
        if( $request->catdropdown == 'all' ||  $category=="all"){     
         $provider = PeopleProvider::select(DB::raw("*, ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS($latitude) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS($latitude)) * COS( RADIANS( `longitude` ) - RADIANS($longitude)) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS($latitude) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS($latitude)) * COS( RADIANS( `longitude` ) - RADIANS($longitude)) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->orderBy(DB::raw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS($latitude) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS($latitude)) * COS( RADIANS( `longitude` ) - RADIANS($longitude)) ) * 6371 "), 'DESC')->paginate(2);
          }else{    

             $provider  = PeopleProvider::select(DB::raw("*,ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS($latitude) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS($latitude)) * COS( RADIANS( `longitude` ) - RADIANS($longitude )) ) * 6371"))->whereRaw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS($latitude) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS($latitude)) * COS( RADIANS( `longitude` ) - RADIANS($longitude )) ) * 6371 < 15")->where('status','1')->where('user_id','<>', $userid)->where('cat_id',$people_id)->orderBy(DB::raw("ACOS( SIN( RADIANS( `latitude` ) ) * SIN( RADIANS($latitude) ) + COS( RADIANS( `latitude` ) ) * COS( RADIANS($latitude)) * COS( RADIANS( `longitude` ) - RADIANS($longitude )) ) * 6371 "), 'DESC')->paginate(2);  

            
          }

           $providerall  = PeopleProvider::where('status','1')->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->get(); 
        }
        else
        {

          $location = GeoIP::getLocation();
          $latitude = $location['lat'];
          $longitude = $location['lon']; 
          if( $request->catdropdown == 'all' || $category =="all"){   
          
           $provider = PeopleProvider::where('status','1')->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->paginate(2);



         
            }else{
              $provider  = PeopleProvider::where('status','1')->where('cat_id',$people_id)->where('user_id','<>',$userid)->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15"), 'DESC')->paginate(2);
              

          
          }  
          $providerall  = PeopleProvider::where('status','1')->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->get();          
        }

      
        $filter = 0;
        /*$provider  = PeopleProvider::where('status','1')->orderBy(DB::raw("acos( cos( radians({$latitude}) ) * cos( radians( latitude ) ) * cos( radians( longitude ) - radians(-{$longitude}) ) + sin( radians({$latitude}) ) * sin(radians(latitude)) ) * 6371 < 15 "), 'DESC')->get(); */
        $people  = People::orderBy('name')->get();
        $coupon  = Coupon::where('applicable_on','all')->orwhere('applicable_on','people')->get();
       $peoplecategories = array();
       $peopledata = array();
       $coupondata = array();
       $peoplecategories=array();
       foreach ($people as $key => $value) {
          $peoplecategories[$key]['name'] = $value->name;
          $peoplecategories[$key]['id'] = $value->id;
        } 
          foreach ($coupon as $key1 => $value) {
        $day = date('Y-m-d',strtotime($value['created_at']));
        $date1 =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days"));
        $date_now = date('Y-m-d');
        
        if(strtotime($date1) >= strtotime($date_now)){
        //  $i++;
          $coupondata[$key1] = $value;
          $coupondata[$key1]['background_image'] = URL::to('/').'/coupons/'.$value['background_image'];
          $coupondata[$key1]['valid_till'] =  date('Y-m-d', strtotime($day . " +".$value['valid_for']." days")); 
        }      
           
       }
       $arr = array_values($coupondata); 
        foreach ($provider as $key => $value) {
          $name = User::select('name','image')->where('id',$value->user_id)->first();
            if (strpos($name->image, 'http') !== false) {
              $image =  $name->image;
            }else{
                $image = URL::to('/').'/profile/'.$name->image;
            }
             if($value->ratings  == ""){
              $ratings = '5';
            }else{
              $ratings = $value->ratings;
            }
          $peopledata[$key]['id'] = $value->id;
         /* $peopledata[$key]['name'] = $value->name;*/
          $peopledata[$key]['title'] = $value->title;
          $peopledata[$key]['description'] = $name->description;
          $peopledata[$key]['latitude'] = $value->latitude;
          $peopledata[$key]['longitude'] = $value->longitude;
          $peopledata[$key]['ratings'] = $ratings;
          $peopledata[$key]['image'] = $image;
          $peopledata[$key]['description'] = $value->description;
          $peopledata[$key]['address'] = $value->address;
          $peopledata[$key]['hourly_price'] = $value->hourly_price;  
          $peopledata[$key]['price_per_night'] = $value->price_per_night; 
          $peopledata[$key]['encodedid'] = $value->encodedid;           
        }
        $j = 0;
         $location = array();
        foreach ($providerall as $key => $value) {
          for($i=0;$i<=2;$i++)
          {
            if($i==0)
             $loc[$i] = $value->address;
           if($i==1)
             $loc[$i] = $value->latitude;
           if($i==2)
             $loc[$i] = $value->longitude;
          }
          $location[$j] = $loc;
          $j++;               
        } 

        $result['categories'] = $peoplecategories;
        $result['data'] = $peopledata;
        $result['coupons'] = $arr;

        echo  view('frontend.booking_people')->with(compact('result','provider','id','filter','location','people_id','placeids')); 
        die;      
      }  
  }

  public function add_reviews(Request $request)
  {
    $userid = Auth::user()->id;
     if ($request->isMethod('post')) {
       $review = new Review;
       if($request->get('servicetype') == '1'){

         $provider_id = $request->get('providerid');
         $review->people_provider_id = $provider_id;

       }elseif($request->get('servicetype') == '2'){

         $provider_id = $request->get('providerid');
         $review->things_provider_id = $provider_id;
        
       }elseif($request->get('servicetype') == '3'){

         $provider_id = $request->get('providerid');
         $review->places_provider_id = $provider_id;
       }

        $review->user_id = $userid;
        $review->booking_id = $request->get('bookingid');
        $review->provider_user_id = $request->get('provideruserid');
        $review->ratings = $request->get('rating');
        $review->reviews =$request->get('reviewdata');
        $review->save();
      return Redirect::back()->with("success", "added");     
     }

     $reviews =  Review::pluck('booking_id');
    $bookings = Booking::where('user_id',$userid)->where('status','3')->whereNotIn('id',$reviews)->get();
    $bookingscount= Booking::where('user_id',$userid)->where('status','3')->whereNotIn('id',$reviews)->count();
    $data = array();

       if($bookings != ""){
         foreach ($bookings as $key => $value) {
           if($value->people_provider_id != ""){
          $provider = PeopleProvider::where('id', $value->people_provider_id)->first();
          $attachment = User::where('id',$provider->user_id)->first();
          $image = URL::to('/').'/profile/'.$attachment->image;
          $data[$key]['provider_id'] = $value->people_provider_id;
          $data[$key]['provider_user_id'] = $provider->user_id;
          $data[$key]['title'] = $provider->title;
          $data[$key]['attachment'] = $image;
          $data[$key]['booking_id'] = $value->id;
          $data[$key]['provider_type'] = '1';

          }elseif($value->places_provider_id != ""){
             $provider = PlaceProvider::where('id', $value->places_provider_id)->first();
             $attachment = Attachment::where('places_provider_id',$value->places_provider_id)->first();
             $image = URL::to('/').'/attachments/'.$attachment->filenames;
             $data[$key]['provider_id'] = $value->places_provider_id;
             $data[$key]['provider_user_id'] = $provider->user_id;
             $data[$key]['title'] = $provider->title;
             $data[$key]['attachment'] = $image;
             $data[$key]['booking_id'] = $value->id;
             $data[$key]['provider_type'] = '3';
            }elseif($value->things_provider_id != ""){
                $provider = ThingProvider::where('id', $value->things_provider_id)->first();
               $attachment = Attachment::where('things_provider_id',$value->things_provider_id)->first();
               $image = URL::to('/').'/attachments/'.$attachment->filenames;
               $data[$key]['provider_id'] = $value->things_provider_id;
               $data[$key]['provider_user_id'] = $provider->user_id;
               $data[$key]['title'] = $provider->title;
               $data[$key]['attachment'] = $image;
               $data[$key]['booking_id'] = $value->id;
               $data[$key]['provider_type'] = '2';

            }
             $data[$key]['review'] = 0;  
         }
       }      
    return  view('frontend.addreviews')->with(compact('data','bookingscount'));
  }


  public function serviceproviderinformation(Request $request){  

    $user = Auth::user();
    $data = array();
    $attachment = array();
    $provider = PeopleProvider::where('user_id', $user->id)->where('status', '1')->get();

    if($provider !=  ''){
      foreach ($provider as $key => $value) {
      $Category = People::where('id',$value->cat_id)->first();
      $SubCategory = People_Subcat::where('id',$value->subcat_id)->first();
      $attachment = array();
     $attachments =  Attachment::where('people_provider_id',$value->id)->get();
       foreach ($attachments as $key1 => $value1) {
        $attachment[$key1] = URL::to('/').'/attachments/'.$value1->filenames;
       }
      $data[$key]['title'] =  $value->title;
      $data[$key]['description'] =  $value->description;
      $data[$key]['category'] =  $Category->name;
      $data[$key]['subcategory'] =  $SubCategory->name;
      $data[$key]['category_image'] =  URL::to('/').'/peoples/'.$Category->image;
      $data[$key]['price_per_night'] =  $value->price_per_night;        
    }

    $userdata = User::where('id',$user->id)->first();
       
    $image = URL::to('/').'/profile/'.$user->image; 
    $user_name = $userdata->name;
        
    
    /*$documents = array();
    foreach ($provider as $key => $value) {

      $attachment = array();
     $attachments =  Attachment::where('people_provider_id',$value->id)->get();

       foreach ($attachments as $key1 => $value1) {
        $attachment[$key1] = URL::to('/').'/attachments/'.$value1->filenames;
       }
        $documents[$key] =  $attachment;
    }
    $document =  call_user_func_array("array_merge", $documents);
    return response()->json([
      "status" => 1,
      'data' => $data,
      'attachments' => $document,
      'user_name' => $user->name,
      'image' => URL::to('/').'/profile/'.$user->image,              
       ], 200);*/
      
    $type = 1;
    return  view('frontend.serviceproviderinfo')->with(compact('data','image','user_name','attachment','type'));
  }
  else{
    $type = "Please Become service provider To provide your services.";
    return  view('frontend.serviceproviderinfo')->with(compact('type','attachment'));

  }
     
   
}

  public function balancecheck(Request $request)
  {
    $userid = Auth::id();
    $amt = User::where('id',$userid)->value('user_vault_total');
    $req_amt = $request->amount;
    if($amt>= $req_amt)
    {  
      return response()->json(['amountreq'=>$req_amt,'success'=>1]);      
    }
    else
    {
      return response()->json(['success'=>0]);

    }
  }

  public function addbankdetails(Request $request)
  {

    if(Auth::check())
    {
     
    $userid = Auth::user()->id;     

    if ($request->isMethod('post')) {
      $rules = [                
        
        'accout_holder_name' => 'required',
        'account_number' => 'required',
        'bank_name' => 'required',
        'iban' => 'required',
        'sort_code' => 'required',
      ];
      $validator = Validator::make($request->all(), $rules);
        if($validator->fails())
        {
           return redirect()->route('addbankdetails')->with( ['error' => "Please fill in all the details"] );       
      }

      $amt = User::where('id',$userid)->value('user_vault_total');
      $req_amt = $request->user_vault_total;
      $balance_amt = $amt- $req_amt;
      $wallettransaction = new WalletTransaction;
      $wallettransaction->provider_user_id = $userid;              
      $wallettransaction->transaction_amount  = $request->get('user_vault_total');
      $wallettransaction->account_holder  = $request->get('accout_holder_name');
      $wallettransaction->account_number  = $request->get('account_number');
      $wallettransaction->bank_name  = $request->get('bank_name');
      $wallettransaction->iban  = $request->get('iban');
      $wallettransaction->sort_code  = $request->get('sort_code');
      $wallettransaction->date = date('Y-m-d H:i:s');
      $wallettransaction->transaction_amount_status = '1';
      if($wallettransaction->save()){
        $balupdate = User::where('id',$userid)->update([
          'user_vault_total' =>$balance_amt
        ]);

        return redirect::back()->with('success', "Transaction under processing for admin approval");
         
      }      
    }
     $amt = User::where('id',$userid)->value('user_vault_total');

    return  view('frontend.addbankdetails')->with(compact('amt'));
   }
   else
   {
    return redirect()->route('home1')->with( ['show_modal' =>1]);
   }
  }

  

  public function getallissues(Request $request){
    if(!Auth::check())
    {
      return Redirect::back()->withInput()->with("show_modal", 1);     
    }   
    $loggedInUser = Auth::user();
    $issue_types = Support_IssueType::all();
   if ($request->isMethod('post')) {
      $Support = new Support;
      $Support->issue_type = $request->get('issue_type');   
      $Support->description = $request->get('description');
      $Support->user_name = $loggedInUser->name;          
      $Support->user_contact = $loggedInUser->phone_number;
      if($Support->save())
      {
        $data= array("issue_type"=>$request->get('issue_type'),'description'=>$request->get('description'),'type'=>2);
        $email = "sonilsood1@gmail.com";
        $title = "Reserve and Rent";
        Mail::send("emails.shareemail",["title"=>$title,"data" => $data], function ($message) use ($email,$title) {
        $message->from('testrvtechnologies1@gmail.com', 'rnr');
        $message->to($email);
        $message->subject($title);

        });        
        return redirect::back()->with('success', "Issue reported successfully");
      }   
    }
   return  view('frontend.contactus')->with(compact('issue_types'));  
  }

  public function mylistings(Request $request){
    $user_id = Auth::id();
    $things_data = array();
    $places_data = array();
    $people_data = array();
    $type= 0;

    $provider =   PeopleProvider::where('user_id',$user_id)->where('cat_id','<>','')->get();
   
    if($provider){
      foreach ($provider as $key => $value) {
        $unavailable_dates_booking = array();
        $date_new = array();
        $booking_data = Booking::where('people_provider_id',$value->id)->where('status','1')->get();
       if($booking_data){
         foreach ($booking_data as $key => $value2) {
        if(date("Y-m-d", strtotime($value2->check_in)) == date("Y-m-d",strtotime($value2->check_out))){
         $date_new[] =  $this->getDatesFromRange(date("Y-m-d", strtotime($value2->check_in)), date("Y-m-d",strtotime($value2->check_out)));
        }else{
          $date_new[] =  $this->getDatesFromRange(date("Y-m-d", strtotime($value2->check_in)), date("Y-m-d",strtotime('-1 day',strtotime($value2->check_out))));
          }
         } 
        } 
       $attachments = array();
       $amenities_offered = array();
       $user =  User::where('id',$value->user_id)->first();
       $people =   People::where('id',$value->cat_id)->first();
       $people_subcat = People_Subcat::where('id',$value->subcat_id)->first();
       $attachments_all =  Attachment::where('people_provider_id',$value->id)->get();
       foreach ($attachments_all as $key1 => $value1){
        $attachments[] = $value1->filenames;
      }
        if($value->status == "0"){
          $status = "Not Approved by admin";
        }else{
          $status = "Approved by admin";
        }
        if($value->percent_status == "2"){
           $percent_status = 75;
        }elseif($value->percent_status == "3"){
           $percent_status = 100;
        }
        $people_data[$key]['id'] = $value->id;
        $people_data[$key]['title'] = $value->title;
        $people_data[$key]['date'] = date('Y-m-d H:i:s',strtotime($value->updated_at));
        $people_data[$key]['Category'] = $people->name;
        $people_data[$key]['complete_status'] = $value->complete_status;
        $people_data[$key]['percent_status'] = $percent_status;
        $people_data[$key]['status'] = $status;
        $people_data[$key]['encodedid'] = $value->encodedid;
          if($user->image != ""){
         $people_data[$key]['image'] = URL::to('/').'/profile/'.$user->image;
        }else{
          $people_data[$key]['image'] = '';
        }
        $people_data[$key]['detail'] = $value;
         $newdates = array();
        if($value->available_dates == ""){
            $unavailable_dates = array();

          }else{
          $newdates[] =  $value->available_dates;              
          if(empty($date_new)){
            $final_bookingdateslist = array(); 
          }else{

          $final_bookingdateslist = call_user_func_array("array_merge", $date_new); 
          $newdates[] = implode(',', $final_bookingdateslist);
          }
            $final_unavailable_dates = implode(',', $newdates);
            $List = explode(',', $final_unavailable_dates);
            
              $unavailable_dates = $List;
                                         
          }
          $people_data[$key]['detail']['available_dates'] = $unavailable_dates;
          $people_data[$key]['detail']['amenities_offered'] = $amenities_offered;
           $people_data[$key]['detail']['unavailable_dates'] = $unavailable_dates;
           $people_data[$key]['detail']['attachments'] = $attachments;
            if($value->price_per_night == ""){
              $people_data[$key]['detail']['price_per_night'] = 0;
           }
           $people_data[$key]['detail']['subcat_name'] = $people_subcat->name;
       /* $data[$key]['image'] = URL::to('/').'/profile/'.$user->image;*/


      }
       $type = 1;

        }
   

     $provider =  ThingProvider::where('user_id',$user_id)->where('cat_id','<>','')->get();

      if($provider){

       foreach ($provider as $key => $value) {

         $unavailable_dates_booking = array();
        $date_new = array();
        $booking_data = Booking::where('things_provider_id',$value->id)->where('status','1')->get();
       
       if($booking_data){

         foreach ($booking_data as $key => $value2) {

        if(date("Y-m-d", strtotime($value2->check_in)) == date("Y-m-d",strtotime($value2->check_out))){

         $date_new[] =  $this->getDatesFromRange(date("Y-m-d", strtotime($value2->check_in)), date("Y-m-d",strtotime($value2->check_out)));
        }else{

          $date_new[] =  $this->getDatesFromRange(date("Y-m-d", strtotime($value2->check_in)), date("Y-m-d",strtotime('-1 day',strtotime($value2->check_out))));
          }

         }       
        
        }
         $thing =   Thing::where('id',$value->cat_id)->first();
         $things_subcat = Thing_Subcat::where('id',$value->subcat_id)->first();
        $attachment =  Attachment::where('things_provider_id',$value->id)->first();
        $attachments = array();
        $amenities_offered = array();
        $attachments_all =  Attachment::where('things_provider_id',$value->id)->get();
         foreach ($attachments_all as $key1 => $value1){
           $attachments[] = $value1->filenames;
        }
        if($value->status == "0"){
          $status = "Not Approved by admin";
        }else{
          $status = "Approved by admin";
        }
            if($value->status == "0"){
          $status = "Not Approved by admin";
        }else{
          $status = "Approved by admin";
        }
        
        if($value->percent_status == "3"){
           $percent_status = 75;
        }elseif($value->percent_status == "4"){
           $percent_status = 100;
        }
        $things_data[$key]['id'] = $value->id;
        $things_data[$key]['title'] = $value->title;
        $things_data[$key]['date'] = date('Y-m-d H:i:s',strtotime($value->updated_at));
        $things_data[$key]['Category'] = $thing->name;
        $things_data[$key]['complete_status'] = $value->complete_status;
        $things_data[$key]['percent_status'] = $percent_status;
        $things_data[$key]['status'] = $status;
        $things_data[$key]['encodedid'] = $value->encodedid;
         if($attachment != ""){
         $things_data[$key]['image'] = URL::to('/').'/attachments/'.$attachment->filenames;
        }else{
          $things_data[$key]['image'] = '';
        }
        $things_data[$key]['detail'] = $value;
            $newdates = array();
        if($value->unavailable_dates == ""){
            $unavailable_dates = array();

          }else{
          $newdates[] =  $value->unavailable_dates;              
          if(empty($date_new)){
            $final_bookingdateslist = array(); 
          }else{

          $final_bookingdateslist = call_user_func_array("array_merge", $date_new); 
          $newdates[] = implode(',', $final_bookingdateslist);
          }
            $final_unavailable_dates = implode(',', $newdates);
            $List = explode(',', $final_unavailable_dates);
            
              $unavailable_dates = $List;
                                         
          }
           $things_data[$key]['detail']['unavailable_dates'] = $unavailable_dates;
           $things_data[$key]['detail']['amenities_offered'] = $amenities_offered;
           $things_data[$key]['detail']['attachments'] = $attachments;
            if($value->price_per_night == ""){
              $things_data[$key]['detail']['price_per_night'] = 0;
           }
            $things_data[$key]['detail']['subcat_name'] = $things_subcat->name;
      }
      $type = 2;
     
        }

  

     $provider =  PlaceProvider::where('user_id',$user_id)->where('cat_id','<>','')->get();
     if($provider){
       foreach ($provider as $key => $value2) {
         $unavailable_dates_booking = array();
        $date_new = array();
        $booking_data = Booking::where('places_provider_id',$value2->id)->where('status','1')->get();

       if($booking_data){

         foreach ($booking_data as $key => $value) {

        if(date("Y-m-d", strtotime($value->check_in)) == date("Y-m-d",strtotime($value->check_out))){

         $date_new[] =  $this->getDatesFromRange(date("Y-m-d", strtotime($value->check_in)), date("Y-m-d",strtotime($value->check_out)));
        }else{

          $date_new[] =  $this->getDatesFromRange(date("Y-m-d", strtotime($value->check_in)), date("Y-m-d",strtotime('-1 day',strtotime($value->check_out))));
          }
         }  
        }
        $attachments = array();
        $attachment =  Attachment::where('places_provider_id',$value2->id)->first();
        $attachments_all =  Attachment::where('places_provider_id',$value2->id)->get();
        $place =   Place::where('id',$value2->cat_id)->first();
        $places_subcat = Place_Subcat::where('id',$value2->subcat_id)->first();
        foreach ($attachments_all as $key1 => $value1){
           $attachments[] = $value1->filenames;
        }
        if($value2->status == "0"){
          $status = "Not Approved by admin";
        }else{
          $status = "Approved by admin";
        }
       if($value2->percent_status == "3"){
           $percent_status = 75;
        }elseif($value2->percent_status == "4"){
           $percent_status = 100;
        }
         $places_data[$key]['id'] = $value2->id;
        $places_data[$key]['title'] = $value2->title;
           $places_data[$key]['date'] = date('Y-m-d H:i:s',strtotime($value2->updated_at));
        $places_data[$key]['Category'] = $place->name;
        $places_data[$key]['complete_status'] = $value2->complete_status;
        $places_data[$key]['percent_status'] = $percent_status;
        $places_data[$key]['status'] = $status;
        $places_data[$key]['encodedid'] = $value2->encodedid;
        if($attachment != ""){
         $places_data[$key]['image'] = URL::to('/').'/attachments/'.$attachment->filenames;
        }else{
          $places_data[$key]['image'] = '';
        }
        $places_data[$key]['detail'] = $value2;
        if($value2->unavailable_dates == ""){
            $unavailable_dates = array();

          }else{
          $newdates[] =  $value2->unavailable_dates;              
          if(empty($date_new)){
            $final_bookingdateslist = array(); 
          }else{
          $final_bookingdateslist = call_user_func_array("array_merge", $date_new); 
          $newdates[] = implode(',', $final_bookingdateslist);
          }
            $final_unavailable_dates = implode(',', $newdates);
            $List = explode(',', $final_unavailable_dates);            
            $unavailable_dates = $List;                                         
          }
          if($value2->amenities_offered == ""){
            $amenities_offered = array();
          }else{          
            $List = explode(',', $value2->amenities_offered);
            $amenities_offered = $List;                                          
          }
          $places_data[$key]['detail']['amenities_offered'] = $amenities_offered;
           $places_data[$key]['detail']['unavailable_dates'] = $unavailable_dates;
           $places_data[$key]['detail']['attachments'] = $attachments;
          if($value2->price_per_night == ""){
              $places_data[$key]['detail']['price_per_night'] = 0;
           }
          $places_data[$key]['detail']['subcat_name'] = $places_subcat->name;
          if($value2->pet_allowance == ""){
            $places_data[$key]['detail']['pet_allowance'] = false;
          }else{
            if($value2->pet_allowance == "true"){
              $places_data[$key]['detail']['pet_allowance'] = true;
            }else{
               $places_data[$key]['detail']['pet_allowance'] = false;
            }
          }
          if($value2->host_facility == ""){
            $places_data[$key]['detail']['host_facility'] = false;
          }else{
              if($value2->host_facility == "true"){
              $places_data[$key]['detail']['host_facility'] = true;
            }else{
               $places_data[$key]['detail']['host_facility'] = false;
            }
          }
          if($value2->host_name == ""){
            $places_data[$key]['detail']['host_name'] = '';
          }
          if($value2->host_phone == ""){
            $places_data[$key]['detail']['host_phone'] = '';
          }
        }
        $type = 3;
      }
    
    //echo "<pre>" ;print_r($places_data);die;
    return view('frontend.mylistings')->with(compact('people_data','things_data','places_data','provider','type'));

  }
  public function getDatesFromRange($start, $end, $format = 'Y-m-d') { 
 
    $array = array(); 
    $interval = new DateInterval('P1D'); 
    $realEnd = new DateTime($end); 
    $realEnd->add($interval); 
    $period = new DatePeriod(new DateTime($start), $interval, $realEnd); 
    foreach($period as $date) {                  
        $array[] = $date->format($format);  
    } 
    return $array; 
  } 

  public function editplaceprovider(Request $request,$id=Null)
  {

    if ($request->isMethod('post')) 
        {         
          $loggedInUser = Auth::user();
          $provider = PlaceProvider::find($request->providerid);
          $arramenities = implode(",",$request->amenities);

          $provider->amenities_offered = $arramenities;
          $provider->host_name = $request->host_name;
          $provider->host_phone = $request->host_phone;
          if($request->dates !="")
          {
            $provider->unavailable_dates = $request->dates.','.$request->datesbooked;
          }
          else{            
          $provider->unavailable_dates = $request->datesbooked;
          }
          if($request->pet_allow!="")
          $provider->pet_allowance = "true";
          else
          $provider->pet_allowance = "false";
          if($request->host_facility!=""){
           $provider->host_facility = "true";
           $provider->host_name = $request->host_name;
           $provider->host_phone = $request->host_phone;
          }

          else{
          $provider->host_facility = "false";
           $provider->host_name = "";
           $provider->host_phone = "";
         }
         $provider->time_in = $request->timepicker_in;
         $provider->time_out = $request->timepicker_out;
         $provider->price_per_night = $request->pricingpernight;
        
        $provider->save();
         
         if($files=$request->file('uploadfile')){
        foreach($files as $file){
           $pics = new Attachment;
           $pics->places_provider_id = $provider->id;
          $name=$file->getClientOriginalName();
          if (!file_exists( public_path('/attachments'))) {
            mkdir(public_path('/attachments'), 0777, true);
          }
          $path =public_path('/attachments/');
         
          $input['imagename'] = time().rand(10,10000).'.'.$file->getClientOriginalExtension();
          $destinationPath = public_path('/attachments');
         $file->move($destinationPath, $input['imagename']);
         $pics->filenames  =  $input['imagename'];
         $pics->save();
        }
      }    
      $attachments = Attachment::select('filenames')->where('places_provider_id',$provider->id)->get();  

      $allimages = array();
      foreach ($attachments as $key => $value) {
        $allimages[$key]= URL::to('/').'/attachments/'.$value['filenames'];
      }
      $placedetails = PlaceProvider::where('id',$request->providerid)->first(); 
      $providerid =  $request->providerid;
      $pics = $attachments;
      $placedetails = $placedetails;

      $allimages1 = $allimages;
      $pid = base64_encode($providerid);

      if($placedetails['percent_status']!=4)
        {
          return redirect()->route('confirmplacedetails',$pid)->with(compact('providerid','pics','placedetails','allimages1')); }   
      else
      return redirect()->route('mylistings')->with(['success'=>"Details Edited successfully"]);  
      }
        $provider_id = base64_decode($id);
        $provider_data = PlaceProvider::where('id',$provider_id)->first();  

        $amenties = PlaceProvider::where('id',$provider_id)->value('amenities_offered');
        $attachments_all = Attachment::where('places_provider_id',$provider_id)->get();
         $attachments = array();
        foreach ($attachments_all as $key1 => $value1){
          $attachments[$key1]['url'] = URL::to('/').'/attachments/'.$value1->filenames;
          $attachments[$key1]['id'] =$value1->id;
        }
        $checkin_time = $provider_data['time_in'];
        $checkout_time = $provider_data['time_out'];
        $host_facility = $provider_data['host_facility'];
        $pet_allowance = $provider_data['pet_allowance'];
        $host_name = $provider_data['host_name'];
        $host_phone= $provider_data['host_phone'];
        $pricing_per_night = $provider_data['price_per_night'];

        $amenitiesall = explode(",",$amenties);

        $unavailable_dates_booking = array();
            $date_new = array();
            $booking_data = Booking::where('places_provider_id',$provider_id)->where('status','1')->get();
           if($booking_data){
               foreach ($booking_data as $key => $value) {
                if(date("Y-m-d", strtotime($value->check_in)) == date("Y-m-d",strtotime($value->check_out))){
               $date_new[] =  $this->getDatesFromRange(date("Y-m-d", strtotime($value->check_in)), date("Y-m-d",strtotime($value->check_out)));
               }else{
                $date_new[] =  $this->getDatesFromRange(date("Y-m-d", strtotime($value->check_in)), date("Y-m-d",strtotime('-1 day',strtotime($value->check_out))));
                }
              }
               if($provider_data['unavailable_dates'] == ""){
                  $unavailable_dates ="";;
                }else{
                $newdates[] =  $provider_data['unavailable_dates'];              
                if(empty($date_new)){
                  $final_bookingdateslist = array(); 
                }else{
                $final_bookingdateslist = call_user_func_array("array_merge", $date_new); 
                $newdates[] = implode(',', $final_bookingdateslist);
                }
                  $final_unavailable_dates = implode(',', $newdates);
                  $unavailable_dates = $final_unavailable_dates;                                         
                }
            }
            $original_dates = $provider_data['unavailable_dates'];
            $providercompletion_status = PlaceProvider::where('id',$provider_id)->value('percent_status');


          return view('frontend.editplaceprovider')->with(compact('amenitiesall','attachments','checkin_time','checkout_time','host_facility','pet_allowance','host_name','host_phone','pricing_per_night','unavailable_dates','provider_id','original_dates','providercompletion_status'));
       
  }

  public function editthingprovider(Request $request,$id=Null)
  {

    if ($request->isMethod('post')) 
        {
          
          $provider = ThingProvider::find($request->providerid);
           if($request->dates !="")
          {
            $provider->unavailable_dates = $request->dates.','.$request->datesbooked;
          }
          else{            
          $provider->unavailable_dates = $request->datesbooked;
          }
          $provider->time_in = $request->timepicker_in;
          $provider->time_out = $request->timepicker_out;
          $provider->price_per_night = $request->pricingpernight;
          $provider->condition = $request->condition;
          $provider->save();
         
         if($files=$request->file('uploadfile')){
        foreach($files as $file){
           $pics = new Attachment;
           $pics->things_provider_id = $provider->id;
          $name=$file->getClientOriginalName();
          if (!file_exists( public_path('/attachments'))) {
            mkdir(public_path('/attachments'), 0777, true);
          }
          $path =public_path('/attachments/');
         
          $input['imagename'] = time().rand(10,10000).'.'.$file->getClientOriginalExtension();
          $destinationPath = public_path('/attachments');
         $file->move($destinationPath, $input['imagename']);
         $pics->filenames  =  $input['imagename'];
         $pics->save();
        }
      }    
       $attachments = Attachment::select('filenames')->where('places_provider_id',$provider->id)->get();  

      $allimages = array();
      foreach ($attachments as $key => $value) {
        $allimages[$key]= URL::to('/').'/attachments/'.$value['filenames'];
      }
      $thingsdetails = ThingProvider::where('id',$request->providerid)->first(); 
      $providerid =  $request->providerid;
      $pics = $attachments;
      $thingsdetails = $thingsdetails;
      $allimages1 = $allimages;
      $pid = base64_encode($providerid);
      if($thingsdetails['percent_status']!=4)
        {
        return redirect()->route('confirmthingdetails',$pid)->with(compact('providerid','pics','thingsdetails','allimages1')); }   
      else
      return redirect()->route('mylistings')->with(['success'=>"Details Edited successfully"]);        
      }
        $provider_id = base64_decode($id);
        $provider_data = ThingProvider::where('id',$provider_id)->first(); 
        $attachments_all = Attachment::where('things_provider_id',$provider_id)->get();
         $attachments = array();
        foreach ($attachments_all as $key1 => $value1){
          $attachments[$key1]['url'] = URL::to('/').'/attachments/'.$value1->filenames;
          $attachments[$key1]['id'] =$value1->id;
        }
        $checkin_time = $provider_data['time_in'];
        $checkout_time = $provider_data['time_out'];
        $pricing_per_night = $provider_data['price_per_night'];

        $unavailable_dates_booking = array();
            $date_new = array();
            $booking_data = Booking::where('things_provider_id',$provider_id)->where('status','1')->get();
           if($booking_data){
               foreach ($booking_data as $key => $value) {
                if(date("Y-m-d", strtotime($value->check_in)) == date("Y-m-d",strtotime($value->check_out))){
               $date_new[] =  $this->getDatesFromRange(date("Y-m-d", strtotime($value->check_in)), date("Y-m-d",strtotime($value->check_out)));
               }else{
                $date_new[] =  $this->getDatesFromRange(date("Y-m-d", strtotime($value->check_in)), date("Y-m-d",strtotime('-1 day',strtotime($value->check_out))));
                }
              }
               if($provider_data['unavailable_dates'] == ""){
                  $unavailable_dates ="";;
                }else{
                $newdates[] =  $provider_data['unavailable_dates'];              
                if(empty($date_new)){
                  $final_bookingdateslist = array(); 
                }else{
                $final_bookingdateslist = call_user_func_array("array_merge", $date_new); 
                $newdates[] = implode(',', $final_bookingdateslist);
                }
                  $final_unavailable_dates = implode(',', $newdates);
                  $unavailable_dates = $final_unavailable_dates;                                         
                }
            }
            $original_dates = $provider_data['unavailable_dates'];
            $providercompletion_status = ThingProvider::where('id',$provider_id)->value('percent_status');
             $condition = $provider_data['condition'];
          return view('frontend.editthingprovider')->with(compact('attachments','checkin_time','checkout_time','pricing_per_night','unavailable_dates','provider_id','original_dates','providercompletion_status','condition'));
   
  }

  public function editpeopleprovider(Request $request,$id=null)
  {
        
       if ($request->isMethod('post')) 
        {
          $loggedInUser = Auth::user();

         
          $provider =  PeopleProvider::find($request->providerid);

           if($request->dates !="")
          {
            $provider->available_dates = $request->dates.','.$request->datesbooked;
          }
          else{            
          $provider->available_dates = $request->datesbooked;
          }
         $provider->time_in = $request->timepicker_in;
         $provider->time_out = $request->timepicker_out;
         $provider->price_per_night = $request->pricingpernight;
        
         $provider->save();
         
         if($files=$request->file('uploadfile')){
        foreach($files as $file){
           $pics = new Attachment;
           $pics->people_provider_id = $provider->id;
          $name=$file->getClientOriginalName();
          if (!file_exists( public_path('/attachments'))) {
            mkdir(public_path('/attachments'), 0777, true);
          }
          $path =public_path('/attachments/');
         
          $input['imagename'] = time().rand(10,10000).'.'.$file->getClientOriginalExtension();
          $destinationPath = public_path('/attachments');
         $file->move($destinationPath, $input['imagename']);
         $pics->filenames  =  $input['imagename'];
         $pics->save();
        }
      }    
      $attachments = Attachment::select('filenames')->where('people_provider_id',$provider->id)->get();  
      $peopledetails = PeopleProvider::where('id',$provider->id)->first();
       $pid = base64_encode($provider->id);  

     if($peopledetails['percent_status']!=3)
        {
        return redirect()->route('confirmpeopledetails',$pid)->with(compact('providerid','peopledetails')); }   
      else
      return redirect()->route('mylistings')->with(['success'=>"Details Edited successfully"]); 
      }       

      $provider_id = base64_decode($id);
      $provider_data = PeopleProvider::where('id',$provider_id)->first(); 
      $attachments_all = Attachment::where('people_provider_id',$provider_id)->get();

      $attachments = array();
      foreach ($attachments_all as $key1 => $value1){
        $attachments[$key1]['url'] = URL::to('/').'/attachments/'.$value1->filenames;
        $attachments[$key1]['id'] =$value1->id;
      }
      $checkin_time = $provider_data['time_in'];
      $checkout_time = $provider_data['time_out'];
      $pricing_per_night = $provider_data['price_per_night'];

    $unavailable_dates_booking = array();
      $date_new = array();
      $booking_data = Booking::where('people_provider_id',$provider_id)->where('status','1')->get();
     if($booking_data){
         foreach ($booking_data as $key => $value) {
          if(date("Y-m-d", strtotime($value->check_in)) == date("Y-m-d",strtotime($value->check_out))){
         $date_new[] =  $this->getDatesFromRange(date("Y-m-d", strtotime($value->check_in)), date("Y-m-d",strtotime($value->check_out)));
         }else{
          $date_new[] =  $this->getDatesFromRange(date("Y-m-d", strtotime($value->check_in)), date("Y-m-d",strtotime('-1 day',strtotime($value->check_out))));
          }
        }
         if($provider_data['available_dates'] == ""){
            $unavailable_dates ="";;
          }else{
          $newdates[] =  $provider_data['available_dates'];              
          if(empty($date_new)){
            $final_bookingdateslist = array(); 
          }else{
          $final_bookingdateslist = call_user_func_array("array_merge", $date_new); 
          $newdates[] = implode(',', $final_bookingdateslist);
          }
            $final_unavailable_dates = implode(',', $newdates);
            $unavailable_dates = $final_unavailable_dates;                                         
          }
      }
      $original_dates = $provider_data['available_dates'];

      $providercompletion_status = ThingProvider::where('id',$provider_id)->value('percent_status');
    return view('frontend.editpeopleprovider')->with(compact('attachments','checkin_time','checkout_time','pricing_per_night','unavailable_dates','provider_id','original_dates','providercompletion_status','condition'));
  }


    public function updateuserstatus(Request $request)
  {
    $id = Auth::user()->id;
    $update = User::where(["id" => $id])->update([ 
      'userheaderstatus' => $request->status]);
  }

 
  public function invite_share(Request $request)
  {
    return view('frontend.invite_share');
  }

  public function deleteattachment(Request $request)
  {
    Attachment::where('id',$request->attachid)->delete();
  }

  public function notifications()
  {
    $user = Auth::user();
    $test= array();

    $notification = Notification::where('reciever', $user->id)->orderby('id','desc')->paginate(10);
    $data = array();

    if($notification){
      foreach ($notification as $key => $value) {
       
       
        $sender_user = User::where('id',$value->sender)->first();
        $data[$key]['message'] = $value->message;
        $data[$key]['image'] = URL::to('/').'/profile/'.$sender_user->image;
        $data[$key]['name'] = $sender_user->name;
        $data[$key]['time'] = date('d F Y h:i:s',strtotime($value->updated_at));       
        $data[$key]['id'] =  base64_encode($value->booking_id);
        $data[$key]['type'] =  $value->type; 
        $data[$key]['notifyid'] =  $value->id; 
        $data[$key]['readstatus'] =  $value->readstatus; 
        
      }
    }
    //return $data;
    return view('frontend.notifications')->with(compact('data','notification'));
  }

  public function updatenotifystatus(Request $request)
  {
   $done =  Notification::where('id',$request->id)->update(['readstatus'=>1]);
   return 1;

  }

  public function share_email(Request $request)
  {

    $data= array("description" => "Provide your services or avail them by just signup in our website",'type'=>1);
     $email = $request->emailval;
     $title = "Reserve and Rent";
    Mail::send("emails.shareemail",["title"=>$title,"data" => $data], function ($message) use ($email,$title) {
    $message->from('testrvtechnologies1@gmail.com', 'rnr');
    $message->to($email);
    $message->subject($title);

    });
     if (Mail::failures()) {
      return response()->json(['msg'=>"Email could not be sent successfully",'status'=>0]);
    }
    else
    {
      return response()->json(['msg'=>"Invited on email successfully",'status'=>1]);
    }

  }

  public function share_url(Request $request)
  {
   $email = $request->email;
   $title = "Reserve and Rent Services";
   $url = $request->url;
    $data = array("description" => "Shared the link.Click below to book this service",'urldata'=>$url,'type'=>0);
    Mail::send("emails.shareemail",["title"=>$title,"data" => $data], function ($message) use ($email,$title) {
    $message->from('testrvtechnologies1@gmail.com', 'rnr');
    $message->to($email);
    $message->subject($title);

    });
    if (Mail::failures()) {
      return response()->json(['msg'=>"Email could not be sent successfully",'status'=>0]);
    }
    else
    {
      return response()->json(['msg'=>"Link shared on the email successfully",'status'=>1]);
    }
  }
  public function allfavourites(Request $request)
  {
    $user_id = Auth::id(); 
    $data_people = array();  
    $data_place = array(); 
    $data_thing = array();   
    $favourite = Favourite::where('user_id',$user_id)->where('favourite', '1')->where('people_provider_id','<>', "")->get();
    if(count($favourite) != 0){
      foreach ($favourite as $key => $value) {
      $provider = PeopleProvider::where('id',$value->people_provider_id )->first();

      $category = People_Subcat::where('people_cat_id',$provider->cat_id)->value('name');
      $attachment = User::where('id',$provider->user_id )->first();
      $image = URL::to('/').'/profile/'.$attachment->image;
      $data_people[$key]['provider_id'] = $value->people_provider_id; 
      $data_people[$key]['title'] = $provider->title; 
      $data_people[$key]['ratings'] = $provider->ratings; 
      $data_people[$key]['address'] = $provider->address;
      $data_people[$key]['image'] = $image;
      $data_people[$key]['price_per_night'] = $provider->price_per_night;
      $data_people[$key]['category'] = $category;
      $data_people[$key]['encodedid'] = $provider->encodedid;

      }
      }else{ 
        
      }
      $favourite = Favourite::where('user_id',$user_id)->where('favourite', '1')->where('things_provider_id','<>', "")->get();
       if(count($favourite) != 0){
        foreach ($favourite as $key => $value) {
         $provider = ThingProvider::where('id',$value->things_provider_id )->first();
         $category=Thing_Subcat::where('things_cat_id',$provider->cat_id)->value('name');
         $attachment = Attachment::where('things_provider_id',$provider->id )->first();
          
          $image = URL::to('/').'/attachments/'.$attachment->filenames;
          $data_thing[$key]['provider_id'] = $value->things_provider_id; 
          $data_thing[$key]['title'] = $provider->title; 
          $data_thing[$key]['ratings'] = $provider->ratings; 
          $data_thing[$key]['address'] = $provider->address;
          $data_thing[$key]['image'] = $image;
          $data_thing[$key]['price_per_night'] = $provider->price_per_night;
          $data_thing[$key]['category'] = $category;
          $data_thing[$key]['encodedid'] = $provider->encodedid;

      }
      }else{        
        
      }
      $test= array();
      
      $favourite = Favourite::where('user_id',$user_id)->where('favourite', '1')->where('places_provider_id','<>', "")->get();
       if(count($favourite) != 0){ 

        foreach ($favourite as $key => $value) {
        $provider = PlaceProvider::where('id',$value->places_provider_id )->first();
        $category = Place_Subcat::where('places_cat_id',  $provider->cat_id)->value('name'); 
        $attachment = Attachment::where('places_provider_id',$provider->id )->first();
        $image = URL::to('/').'/attachments/'.$attachment->filenames;
       $data_place[$key]['provider_id'] = $value->places_provider_id; 
        $data_place[$key]['title'] = $provider->title; 
        $data_place[$key]['ratings'] = $provider->ratings; 
        $data_place[$key]['address'] = $provider->address;
         $data_place[$key]['image'] = $image;
        $data_place[$key]['price_per_night'] = $provider->price_per_night;
         $data_place[$key]['category'] = $category;
        $data_place[$key]['encodedid'] = $provider->encodedid;
      }
    
      }else{
                
      }
     
      //$data_placenew = array_shift($data_place);

     return view('frontend.favouriteslist')->with(compact('data_thing','data_place','data_people'));
  }
}


	

