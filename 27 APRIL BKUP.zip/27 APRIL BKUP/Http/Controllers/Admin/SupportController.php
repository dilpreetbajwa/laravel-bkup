<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Validator;
use Redirect;
use App\Support_IssueType;
use App\Support;

class SupportController extends Controller
{
    public function index()
    {
    	 $data = Support_IssueType::all();
    	return view('admin.Support.add_supportissue_types')->with(compact('data'));;
    }

    public function delete_supportissue_type(Request $request){
      $deleteissueTypes =   Support_IssueType::where('id',$request->id)->delete();

      if($deleteissueTypes){

        return response()->json([
                      "status" => 1,
                       "message" => "Issue Type deleted successfully",
                       
                   ], 200); 

      }else{

           return response()->json([
                      "status" => 0,
                       "message" => "Something went wrong",
                       
                   ], 422); 
      }

    }

    public function add_issueType(Request $request){

    	try{

    		$rules = [                
              'issue_type' => 'required',
            ];

            	$validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {

                return Redirect::back()->withErrors($validator); 
                                 
                }

                $Checkissue_type = Support_IssueType::where('issue_type',$request->get('issue_type'))->first();

                if($Checkissue_type){

                }else{

                $IssueType = new Support_IssueType;
                $IssueType->issue_type = $request->get('issue_type');         
                $IssueType->save();

                $data = Support_IssueType::all();
                
               return Redirect::back()->with('message', 'Issue Type added successfully')->with(compact('data'));  ;   
                	

                }



             }catch(Exception $e){

             	return response()->json([
                  		"status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
             }

    }

    public function Issue_ListView(Request $request){

    	$data = Support::where('status','0')->get();
    	return view('admin.Support.supportissue_listview')->with(compact('data'));;
    }

    public function delete_issue(Request $request){

      $changesupportstatus = Support::where('id',$request->id)->update([
        'status' => '1',
      ]);
     $data = Support::where('status','0')->get();
     if($changesupportstatus){

      return response()->json([
                      "status" => 1,
                       "message" => "Issue deleted successfully",
                       
                   ], 200); 

     }else{

      return response()->json([
                      "status" => 0,
                        "message" => "Something went wrong!",
                      
                   ], 422); 

     }
      return view('admin.Support.supportissue_listview')->with(compact('data'));;
    }
    
}
