<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Validator;
use Redirect;
use App\Privacy;
use App\WalletTransaction;
use App\Booking;
use App\PeopleProvider;
use App\People;
use App\PlaceProvider;
use App\Place;
use App\ThingProvider;
use App\Attachment;
use App\Notification;
use App\User;
use App\Thing;
use URL;
use Auth;
use App\Menu;

class TransactionController extends Controller
{


   public function transaction_history(Request $request){
     $user_menu = Auth::user();
       $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();
   	$transactions =  WalletTransaction::orderBy('date', 'DESC')->get();
   	 $data = array();
   		if($transactions != ""){

   			foreach ($transactions as $key => $value) {
              $category = "";
              $provider_id = "";
              $title = "";

              /*   if($value->people_provider_id != ""){
                   $provider = PeopleProvider::where('id',$value->people_provider_id)->first();            
                   $people =   People::where('id',$provider->cat_id)->first();
                   $provider_id = $value->people_provider_id;
                   $category = $people->name;
                   $title = $provider->title;
                }elseif ($value->places_provider_id != "") {
                   $provider = PlaceProvider::where('id',$value->places_provider_id)->first();
                    $place =   Place::where('id',$provider->cat_id)->first();
                    $category = $place->name;
                  $provider_id = $value->places_provider_id;
                  $title = $provider->title;
                }elseif ($value->things_provider_id != "") {
                    $provider = ThingProvider::where('id',$value->things_provider_id)->first();
                    $thing =   Thing::where('id',$provider->cat_id)->first();
                    $category = $thing->name;
                    $provider_id = $value->things_provider_id;
                    $title = $provider->title;
                }*/
              
              $data[$key]['date'] = date('Y-m-d H:i:s',strtotime($value->updated_at));
              $data[$key]['id'] = $value->id;
              $data[$key]['category'] = $category;
              $data[$key]['transaction_amount_status'] = $value->transaction_amount_status;
              $data[$key]['provider_id'] = $provider_id;
              $data[$key]['provider_title'] = $title;
              $data[$key]['amount'] = $value->transaction_amount;    
             
             }

            return view('admin.Transaction.transaction_history')->with(compact('data','menu'));
   		}else{

   			return view('admin.Transaction.transaction_history')->with(compact('data','menu'));
   		}
        


   	
   }

   public function vault_transansation(Request $request){

   	$transactions =  WalletTransaction::where('transaction_amount_status','<>','0')->orderBy('date', 'DESC')->get();
   	 $data = array();
   		if($transactions != ""){

   			foreach ($transactions as $key => $value) {
              $category = "";
              $provider_id = "";
              $title = "";

                 if($value->people_provider_id != ""){
                   $provider = PeopleProvider::where('id',$value->people_provider_id)->first();            
                   $people =   People::where('id',$provider->cat_id)->first();
                   $provider_id = $value->people_provider_id;
                   $category = $people->name;
                   $title = $provider->title;
                }elseif ($value->places_provider_id != "") {
                   $provider = PlaceProvider::where('id',$value->places_provider_id)->first();
                    $place =   Place::where('id',$provider->cat_id)->first();
                    $category = $place->name;
                  $provider_id = $value->places_provider_id;
                  $title = $provider->title;
                }elseif ($value->things_provider_id != "") {
                    $provider = ThingProvider::where('id',$value->things_provider_id)->first();
                    $thing =   Thing::where('id',$provider->cat_id)->first();
                    $category = $thing->name;
                    $provider_id = $value->things_provider_id;
                    $title = $provider->title;
                }
              
              $data[$key]['date'] = date('Y-m-d H:i:s',strtotime($value->updated_at));
              $data[$key]['category'] = $category;
              $data[$key]['id'] = $value->id;
              $data[$key]['transaction_amount_status'] = $value->transaction_amount_status;
              $data[$key]['provider_id'] = $provider_id;
              $data[$key]['provider_title'] = $title;
              $data[$key]['amount'] = $value->transaction_amount;    
             
             }

            return view('admin.Transaction.vault_transaction')->with(compact('data'.'menu'));
   		}else{

   			return view('admin.Transaction.vault_transaction')->with(compact('data','menu'));
   		}

   }
   
   public function TransactionDetails($id){
     $user_menu = Auth::user();
       $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();

    $data =  WalletTransaction::where('id',$id)->first();
    $provider_user =  User::where('id',$data->provider_user_id)->first();
    return view('admin.Transaction.vault_transactiondetails')->with(compact('data','provider_user','menu'));

   }

   public function RecievedTransactionDetails($id){
     $user_menu = Auth::user();
       $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();
    $data =  WalletTransaction::where('id',$id)->where('transaction_amount_status', '0')->first();
    $attachments = array();
    if($data->people_provider_id != ''){
      $provider = PeopleProvider::where('id',$data->people_provider_id)->first();
      $attachments = array();
      $category = People::where('id',$provider->cat_id)->first();
      $category_image = URL::to('/').'/peoples/'.$category->image;
    }elseif($data->places_provider_id != ''){
        $provider = PlaceProvider::where('id',$data->places_provider_id)->first();
        $images = Attachment::where('places_provider_id',$data->places_provider_id)->get();
        
        foreach ($images as $key1 => $value1) {
          $attachments[$key1] = URL::to('/').'/attachments/'.$value1->filenames;
       } 
        $category = Place::where('id',$provider->cat_id)->first();
        $category_image = URL::to('/').'/places/'.$category->image;
    }elseif($data->things_provider_id != ''){
       $provider = ThingProvider::where('id',$data->places_provider_id)->first();
       $images = Attachment::where('things_provider_id',$data->things_provider_id)->get();
        foreach ($images as $key1 => $value1) {
          $attachments[$key1] = URL::to('/').'/attachments/'.$value1->filenames;
       } 
       $category = Thing::where('id',$provider->cat_id)->first();
       $category_image = URL::to('/').'/things/'.$category->image;
    }
    $provider_user =  User::where('id',$data->provider_user_id)->first();
    $user_data =  User::where('id',$data->user_id)->first();
    $booking =  Booking::where('id',$data->booking_id)->first();

    return view('admin.Transaction.recieved_transactiondetails')->with(compact('data','user_data','provider','provider_user','category','booking','category_image','attachments','menu'));

   }
   

    public function approve_transaction_complete(Request $request){

   	$transactions =  WalletTransaction::where('id',$request->get('id'))->update([
   			'transaction_amount_status' => '2',

   	     ]);
    $transactions_data =  WalletTransaction::where('id',$request->get('id'))->first();
    $user = User::where('id',$transactions_data->provider_user_id)->first();
   		if($transactions != ""){

        $serverkey = 'AAAAEmcRsng:APA91bEGt33nTosoGVa_kb1vOLnxXFvrjjja3DR8M_hT7rkYpdKmEmbtM1sqMqsgsGi8EkoVRvfiD802zRlKawB-ornIV6EKTfcCbR0dl7M2kHmPmF9H57mAiyaSmUmCPHQP22fnJmSW';
           $url = 'https://fcm.googleapis.com/fcm/send';
           
           $fields = array(

             'to' => $user->device_token,
             'data' => array('title' => 'Transaction withdrawn', 'body' =>  'Transaction Widthdrawn Complete' )           
           );
           $headers = array(
             'Authorization: key=' . $serverkey,
             'Content-Type: application/json'
           );
           $ch = curl_init();
           curl_setopt($ch, CURLOPT_URL, $url);
           curl_setopt($ch, CURLOPT_POST, true);
           curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
           curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
           curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
           curl_exec($ch);
           curl_close($ch);
           
           $notification = new Notification;
           $notification->user_id = '1';
           $notification->message = 'Transaction Widthdrawn Complete';
           $notification->sender = '1';
           $notification->reciever = $user->id;
           $notification->save();


   			return response()->json([
                  "status" => 1,
                  "message" => "Transaction updated successfully!",

                   ], 200); 
        
   		}else{

   			   return response()->json([
                  "status" => 0,
                  "message" => "Something went wrong!",
                   ], 422); 
   		}

   }
}
