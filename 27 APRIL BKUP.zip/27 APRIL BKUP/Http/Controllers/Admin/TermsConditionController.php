<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Validator;
use Redirect;
use App\Privacy;
use App\Menu;
use Auth;

class TermsConditionController extends Controller
{
    public function index(){
         $user_menu = Auth::user();
       $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();
    	$data = Privacy::where('title','Terms and Conditions')->first();
    	return view('admin.TermsAndCondition.add')->with(compact('data','menu'));
    }
     public function add(Request $request){

    	try{

    		$rules = [                
              'title' => 'required',
              'description' => 'required',
            ];

            	$validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {

                return Redirect::back()->withErrors($validator); 
                                 
                }
                 $user_menu = Auth::user();
                 $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();
                $terms_and_condition = Privacy::where('title','Terms and Conditions')->first();

                if($terms_and_condition){

                     Privacy::where('title','Terms and Conditions')->update([
                     	'description' => $request->get('description'),
                     ]);

                     $data = Privacy::where('title','Terms and Conditions')->first();
	                $request->session()->flash('alert-success', 'Terms and Conditions updated successfully!');
	               return Redirect::back()->with(compact('data','menu'));

                }else{

	                $terms = new Privacy;
	                $terms->title = $request->get('title');
	                $terms->description = $request->get('description');    
	                $terms->save();

	                $data = Privacy::where('title','Terms and Conditions')->first();
	                $request->session()->flash('alert-success', 'Terms and Conditions added successfully!');
	               return Redirect::back()->with(compact('data','menu'));

                }
                          

                  
                	

             }catch(Exception $e){

             	return response()->json([
                  		"status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
             }

    }
}
