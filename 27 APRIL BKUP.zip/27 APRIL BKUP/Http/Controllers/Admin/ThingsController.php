<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Thing;
use Auth;
use App\Menu;

class ThingsController extends Controller
{
		public function index()
    	{
    		$data = Thing::all();
             $user_menu = Auth::user();
       $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();
    	    return view('admin.Things.add_things')->with(compact('data','menu'));
		}
		public function subcategory()
    	{
    		$things = Thing::all();
             $user_menu = Auth::user();
       $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();
    	    return view('admin.Things.add_things_subcat')->with(compact('things','menu'));
		}
}
