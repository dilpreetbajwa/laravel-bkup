<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Validator;
use Redirect;
use Auth;
use App\Faq;
use App\Menu;

class FAQController extends Controller
{
    public function index(){
       $user_menu = Auth::user();
       $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();
    	return view('admin.FAQ.add')->with(compact('menu'));
    }

    public function add_faq(Request $request){

    	try{

    		$rules = [                
              'question' => 'required',
              'answer' => 'required',
            ];

            	$validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {

                return Redirect::back()->withErrors($validator); 
                                 
                }
                 $user_menu = Auth::user();
                 $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();
            
                $faq = new Faq;
                $faq->question = $request->get('question');
                $faq->answer = $request->get('answer');             
                $faq->save();

                $data = Faq::all();
                $request->session()->flash('alert-success', 'Faq added successfully!');
               return Redirect::back()->with(compact('data','menu'));  ;   
                	

             }catch(Exception $e){

             	return response()->json([
                  		"status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
             }

    }

     public function faq_list(Request $request){
       $user_menu = Auth::user();
       $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();

    	$data = Faq::all();
    	return view('admin.FAQ.view')->with(compact('data','menu'));
    }
    public function edit_faq_view($id){
       $user_menu = Auth::user();
       $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();

    	$data = Faq::where('id',$id)->first();
    	return view('admin.FAQ.edit')->with(compact('data','menu'));
    }
    public function edit_faq(Request $request){
       $user_menu = Auth::user();
       $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();

    	try{
 
    		$rules = [                
              'question' => 'required',
              'answer' => 'required',
            ];



            	$validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {

                return Redirect::back()->withErrors($validator); 
                                 
                }


            $update = Faq::where('id',$request->get('id'))->update([
            	'question' => $request->get('question'),
            	'answer' => $request->get('answer'),

            ]);
			
            if($update){

            $data = Faq::where('id',$request->get('id'))->first();

            $request->session()->flash('alert-success', 'Faq updated successfully!');
            return Redirect::back()->with(compact('data','menu')); 

            }else{

            $request->session()->flash('alert-danger', 'Something went wrong!');
            $data = Faq::where('id',$request->get('id'))->first();
            return Redirect::back()->with(compact('data','menu'));

            }
    		
            }catch(Exception $e){

             	return response()->json([
                  		"status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
             }



    	
    }

    public function delete_faq(Request $request){

    	try{
 
    		$rules = [                
              'id' => 'required',
            ];



            	$validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {

                return Redirect::back()->withErrors($validator); 
                                 
                }


            $delete = Faq::where('id',$request->get('id'))->delete();
			
            if($delete){ 
            return response()->json([
                  "status" => 1,
                  "message" => "Coupon deleted successfully!",

                   ], 200); 

            }else{

            $data = Faq::all();
            return response()->json([
                  "status" => 0,
                  "message" => "Something went wrong!",
                   ], 422); 

            }
    		
            }catch(Exception $e){

             	return response()->json([
                  		"status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
             }



    	
    }
    
}
