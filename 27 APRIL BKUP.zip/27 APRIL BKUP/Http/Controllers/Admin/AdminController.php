<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use App\Place;
use App\Thing;
use App\Thing_Subcat;
use App\PeopleProvider;
use App\PlaceProvider;
use App\ThingProvider;
use App\Place_Subcat;
use App\People_Subcat;
use App\Notification;
use App\People;
use Auth;
use App\Coupon;
use App\Booking;
use App\Support_IssueType;
use App\Menu;
use Validator;
use Redirect;

class AdminController extends Controller
{

  
  
  
  public function users() {
        $user_menu = Auth::user();
        $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray(); 
        $data['data'] = User::where('role', '<>' ,'1')->orderBy('created_at', 'DESC')->get();
        
        $data['page_title'] = "User List";
        return view('admin.user_list')->with(compact('data','menu'));
    }

    public function my_profile() {
       $user_menu = Auth::user();
       $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();
        return view('admin.Profile.my_profile')->with(compact('menu'));;
    }
      public function edit_my_profile(Request $request) {
        $user_menu = Auth::user();
        $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();

        $user = User::where('role','1')->first();

          if( $request->file('new_image')!= ""){
                if (!file_exists( public_path('/profile'))) {
                    mkdir(public_path('/profile'), 0777, true);
                }
                $path =public_path('/profile/');
                $image = $request->file('new_image');
                $ProfileImage = time().'.'.$image->getClientOriginalExtension();
                $destinationPath = public_path('/profile');
                $image->move($destinationPath, $ProfileImage);
            }else{
                $ProfileImage = $user->image;  
            }


            if($request->get('name') == ""){
              $name = $user->name;
            }else{
              $name = $request->get('name');
            }

            if($request->get('email') == ""){
              $email = $user->email;
            }else{
              $email = $request->get('email');
            }
            if($request->get('new_password') == ""){
              $password = $user->password;
            }else{
              $password = bcrypt($request->get('new_password'));
            }

            $provider  = User::where('role','1')->update([
              'name' => $name,
              'email' => $email,
              'password' => $password,
              'image' => $ProfileImage,

            ]);
        $data = User::where('role','1')->first();
        $request->session()->flash('alert-success', 'Profile Update successfully');
         return Redirect::back()->with(compact('data','menu'));

    }
    

    public function deleteUser(Request $request, $delete_id = NULL) {
        $result = User::where('id', $delete_id)->delete();
        $user_menu = Auth::user();
       $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();

        if ($result) {
            return redirect('/users')->with('success', 'User has been deleted successfully');
        } else {
            return redirect('/users')->with('error', 'Oops! error occured while deleting user, please try again');
        }
    }

    public function AddPlaces(Request $request){
        $result = Place::where('name', $request->name)->first();
        $data = Place::all();
        if($result){

            return redirect('/place')->with('message', 'Place already added')->with(compact('data'));  
        }else{

                if( $request->file('image')!= ""){
                if (!file_exists( public_path('/places'))) {
                    mkdir(public_path('/places'), 0777, true);
                }
                $path =public_path('/places/');
                $image = $request->file('image');
                $SubcategoryImage = time().'.'.$image->getClientOriginalExtension();
                $destinationPath = public_path('/places');
                $image->move($destinationPath, $SubcategoryImage);
            }else{
                $SubcategoryImage = "";  
            }

                $categories = new Place;
                $categories->name = $request->get('name');
                $categories->image = $SubcategoryImage;
                $categories->color = $request->get('color');;
                $categories->save();
               return redirect('/place')->with('message', 'Place added successfully')->with(compact('data'));  ;   
        }
    }

    public function EditPlaces($id){
        $data = Place::where('id', $id)->first();
        $user_menu = Auth::user();
       $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();
       
        if($data){
          return view('admin.Places.edit_places')->with(compact('data','menu'));
        }
    }

    public function DeletePlaces(Request $request){
      $chk_provider = PlaceProvider::where('cat_id',$request->id)->first();
      if($chk_provider){

        return response()->json([
                "status" => 1,
                "message" => "Provider with this category exists!",

        ], 200); 

      }else{
        $data = Place::where('id', $request->id)->delete();
       
        if($data){
        return response()->json([
                "status" => 1,
                "message" => "Category deleted Successfully!",

        ], 200); 
        }else{
          return response()->json([
                "status" => 0,
                "message" => "Something went wrong!",

        ], 422); 
        }

      }
        
    }

     public function EditPlacesData(Request $request){

       $user_menu = Auth::user();
       $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();

       $result_check = Place::where('name', $request->name)->first();
       if($result_check){

         $data = Place::where('id', $request->id)->first();
         $request->session()->flash('alert-danger', 'Category Name already exists');
        return redirect()->back()->with(compact('data','menu')); 

       }else{ 


         $result = Place::where('id', $request->id)->first();
       if($request->name == ""){
         $name = $result->name;
       }else{
         $name = $request->name;
       }
        if($request->file('image') == ""){
         $image1 = $result->image;
       }else{

      if( $request->file('image')!= ""){
                if (!file_exists( public_path('/places'))) {
                    mkdir(public_path('/places'), 0777, true);
                }
                $path =public_path('/places/');
                $image = $request->file('image');
                $SubcategoryImage = time().'.'.$image->getClientOriginalExtension();
                $destinationPath = public_path('/places');
                $image->move($destinationPath, $SubcategoryImage);
            
         $image1 = $SubcategoryImage;
       }
     }
     if($request->color == ""){
       $color = $result->color;
     }else{
       $color = $request->color;
     }


     $update = Place::where('id', $request->id)->update([
        'name' => $name,
        'image' => $image1,
        'color' => $color,
     ]);

       if($update){

        $data = Place::where('id', $request->id)->first();
         $request->session()->flash('alert-success', 'Place edit successfully');
        return redirect()->back()->with(compact('data','menu'));  

       }else{

         $data = Place::where('id', $request->id)->first();
         $request->session()->flash('alert-danger', 'Something went wrong');
        return redirect()->back()->with(compact('data','menu')); 
       }

       }
      
      
       
    }
    
  

    public function AddThings(Request $request){

    	try{

    		$rules = [                
              'name' => 'required',
              'image' => 'required',
              'color' => 'required', 

            ];

            $validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {

                return Redirect::back()->withErrors($validator); 
                                 
                }
         $user_menu = Auth::user();
       $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();

        $result = Thing::where('name', $request->name)->first();
        if($result){

            return redirect('/thing')->with('message', 'Thing already added');  
        }else{

                if( $request->file('image')!= ""){
                if (!file_exists( public_path('/things'))) {
                    mkdir(public_path('/things'), 0777, true);
                }
                $path =public_path('/things/');
                $image = $request->file('image');
                $SubcategoryImage = time().'.'.$image->getClientOriginalExtension();
                $destinationPath = public_path('/things');
                $image->move($destinationPath, $SubcategoryImage);
            }else{
                $SubcategoryImage = "";  
            } 

                $categories = new Thing;
                $categories->name = $request->get('name');
                $categories->image = $SubcategoryImage;
                $categories->color = $request->get('color');
                $categories->save();
               return redirect('/thing')->with('message', 'Place added successfully');   
        }

         }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }


    }

     public function EditThings($id){
        $data = Thing::where('id', $id)->first();
         $user_menu = Auth::user();
       $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();

       
        if($data){
          return view('admin.Things.edit_things')->with(compact('data','menu'));
        }
    }

    public function DeleteThings(Request $request){
      $chk_provider = ThingProvider::where('cat_id',$request->id)->first();
      if($chk_provider){
        return response()->json([
                "status" => 1,
                "message" => "Provider with this category exists!",

        ], 200); 
        
      }else{
        $data = Thing::where('id', $request->id)->delete();
       
        if($data){
        return response()->json([
                "status" => 1,
                "message" => "Category deleted Successfully!",

        ], 200); 
        }else{
          return response()->json([
                "status" => 0,
                "message" => "Something went wrong!",

        ], 422); 
        }

      }
        
    }

     public function EditThingsData(Request $request){
       $result_check = Thing::where('name', $request->name)->first();
        $user_menu = Auth::user();
       $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();
       if($result_check){

         $data = Thing::where('id', $request->id)->first();
         $request->session()->flash('alert-danger', 'Category Name already exists');
        return redirect()->back()->with(compact('data','menu')); 

       }else{ 

         $result = Thing::where('id', $request->id)->first();
       if($request->name == ""){
         $name = $result->name;
       }else{
         $name = $request->name;
       }
        if($request->file('image') == ""){
         $image1 = $result->image;
       }else{

          if( $request->file('image')!= ""){
                    if (!file_exists( public_path('/things'))) {
                        mkdir(public_path('/things'), 0777, true);
                    }
                    $path =public_path('/things/');
                    $image = $request->file('image');
                    $SubcategoryImage = time().'.'.$image->getClientOriginalExtension();
                    $destinationPath = public_path('/things');
                    $image->move($destinationPath, $SubcategoryImage);
                
             $image1 = $SubcategoryImage;
           }
         }
         if($request->color == ""){
           $color = $result->color;
         }else{
           $color = $request->color;
         }

         $update = Thing::where('id', $request->id)->update([
            'name' => $name,
            'image' => $image1,
            'color' => $color,
         ]);

         if($update){

          $data = Thing::where('id', $request->id)->first();
           $request->session()->flash('alert-success', 'Thing edit successfully');
          return redirect()->back()->with(compact('data','menu'));  

         }else{

           $data = Thing::where('id', $request->id)->first();
            $request->session()->flash('alert-danger', 'Something went wrong');
          return redirect()->back()->with(compact('data','menu')); 
         }

       }
      
      
       
    }
 
        public function AddPeople(Request $request){
    
        $result = People::where('name', $request->name)->first();
        if($result){

            return redirect('/people')->with('message', 'Thing already added');  
        }else{

                if( $request->file('image')!= ""){
                if (!file_exists( public_path('/peoples'))) {
                    mkdir(public_path('/peoples'), 0777, true);
                }
                $path =public_path('/peoples/');
                $image = $request->file('image');
                $SubcategoryImage = time().'.'.$image->getClientOriginalExtension();
                $destinationPath = public_path('/peoples');
                $image->move($destinationPath, $SubcategoryImage);
            }else{
                $SubcategoryImage = "";  
            }

                $categories = new People;
                $categories->name = $request->get('name');
                $categories->image = $SubcategoryImage;
                $categories->color = $request->get('color');
                $categories->save();
               return redirect('/people')->with('message', 'People added successfully');   
        }


    }

    public function EditPeople($id){
        $data = People::where('id', $id)->first();
         $user_menu = Auth::user();
       $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();
       
        if($data){
          return view('admin.Peoples.edit_people')->with(compact('data','menu'));
        }
    }

    public function DeletePeople(Request $request){

      $chk_provider = PeopleProvider::where('cat_id',$request->id)->first();
      if($chk_provider){

        return response()->json([
                  "status" => 1,
                  "message" => "Provider with this category exists!",

                   ], 200);
        }else{
        $data = People::where('id', $request->id)->delete(); 
        if($data){
        return response()->json([
                "status" => 1,
                "message" => "Category deleted Successfully!",

        ], 200); 
        }else{
          return response()->json([
                "status" => 0,
                "message" => "Something went wrong!",

        ], 422); 
        }

      }
        
    } 

  

     public function EditPeopleData(Request $request){
       $user_menu = Auth::user();
       $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();

      $result_check = People::where('name', $request->name)->first();
       if($result_check){

         $data = People::where('id', $request->id)->first();
         $request->session()->flash('alert-danger', 'Category Name already exists');
        return redirect()->back()->with(compact('data')); 

       }else{ 

        $result = People::where('id', $request->id)->first();
         if($request->name == ""){
           $name = $result->name;
         }else{
           $name = $request->name;
         }
          if($request->file('image') == ""){
           $image1 = $result->image;
         }else{

          if( $request->file('image')!= ""){
                  if (!file_exists( public_path('/peoples'))) {
                      mkdir(public_path('/peoples'), 0777, true);
                  }
                  $path =public_path('/peoples/');
                  $image = $request->file('image');
                  $SubcategoryImage = time().'.'.$image->getClientOriginalExtension();
                  $destinationPath = public_path('/peoples');
                  $image->move($destinationPath, $SubcategoryImage);
              
           $image1 = $SubcategoryImage;
         }
       }
         if($request->color == ""){
           $color = $result->color;
         }else{
           $color = $request->color;
         }

         $update = People::where('id', $request->id)->update([
            'name' => $name,
            'image' => $image1,
            'color' => $color,
         ]);

         if($update){

          $data = People::where('id', $request->id)->first();
           $request->session()->flash('alert-success', 'People edit successfully');
          return redirect()->back()->with(compact('data','menu'));  

         }else{

           $data = People::where('id', $request->id)->first();
            $request->session()->flash('alert-danger', 'Something went wrong');
          return redirect()->back()->with(compact('data','menu')); 
         }

       }

       
      
       
    }

    public function AddThingsSubcategory(Request $request){
        $user = Auth::user();
         
        $result = Thing_Subcat::where('name', $request->name)->where('user_id',$user->id)->first(); 

        if($result){

            return redirect('/thing_subcat')->with('error', 'Thing already added');  
        }else{


                $categories = new Thing_Subcat;
                $categories->name = $request->get('name');
                $categories->things_cat_id = $request->get('things_cat');
                $categories->user_id = $user->id;
                $categories->save();
               return redirect('/thing_subcat')->with('success', 'Th added successfully');   
        }


    }

    public function AddPeopleSubcategory(Request $request){
        $user = Auth::user();
         
        $result = People_Subcat::where('name', $request->name)->where('user_id',$user->id)->first(); 

        if($result){

            return redirect('/people_subcat')->with('error', 'People subcategory already added');  
        }else{


                $categories = new People_Subcat;
                $categories->name = $request->get('name');
                $categories->people_cat_id = $request->get('people_cat');
                $categories->user_id = $user->id;
                $categories->save();
               return redirect('/people_subcat')->with('success', 'People subcategory added successfully');   
        }


    }
    public function AddPlacesSubcategory(Request $request){
        $user = Auth::user();
         
        $result = Place_Subcat::where('name', $request->name)->where('user_id',$user->id)->first(); 

        if($result){

            return redirect('/place_subcat')->with('error', 'Places subcategory already added');  
        }else{


                $categories = new Place_Subcat;
                $categories->name = $request->get('name');
                $categories->places_cat_id = $request->get('places_cat');
                $categories->user_id = $user->id;
                $categories->save();
               return redirect('/place_subcat')->with('success', 'Places subcategory added successfully');   
        }


    }

    public function ProviderList(Request $request){
      try{
        $user_menu = Auth::user();
       $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();
      $provider  = PeopleProvider::where('complete_status', '1')->get(); 
       $data = array(); 
       foreach($provider as $key => $value){

        $user_name =  User::select('name')->where('id',$value->user_id)->first();
        if($user_name){
           $name = $user_name->name;
        }else{
           $name = ''; 
        }
        $subcategory_name =  People_Subcat::select('name')->where('id',$value->subcat_id)->first();
        $category_name =   People::select('name')->where('id',$value->cat_id)->first();
        $data[$key]['id'] = $value->id;
        $data[$key]['user_id'] = $value->user_id;
        $data[$key]['status'] = $value->status;
        $data[$key]['name'] = $name;
        $data[$key]['category'] = $category_name->name;
        $data[$key]['subcategory'] = $subcategory_name->name;
    
       }
       if($provider){
           return view('admin.Peoples.provider_list')->with(compact('data','menu')); 
       }else{
        return response()->json([
                  "status" => 0,
                  "message" => "No Provider found",
                    ], 422); 

       }

       }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }

    }

        public function PlaceProviderList(Request $request){
        try{
           $user_menu = Auth::user();
       $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();
        $data = array();
        $provider  = PlaceProvider::where('complete_status', '1')->get();  
        foreach($provider as $key => $value){
        $user_name =  User::select('name')->where('id',$value->user_id)->first();
        $subcategory_name =  Place_Subcat::select('name')->where('id',$value->subcat_id)->first();
        $category_name =   Place::select('name')->where('id',$value->cat_id)->first();
        if($user_name){
             $user_name = $user_name->name;
        }else{
             $user_name = '';
        }
        $data[$key]['id'] = $value->id;
        $data[$key]['user_id'] = $value->user_id;
        $data[$key]['status'] = $value->status;
        $data[$key]['name'] = $user_name;
        $data[$key]['category'] = $category_name['name'];
        $data[$key]['subcategory'] = $subcategory_name['name'];
        $data[$key]['title'] = $value->title;

        }
        if($provider){
           return view('admin.Places.placeprovider_list')->with(compact('data','menu')); 
       }else{
        return response()->json([
                  "status" => 0,
                  "message" => "No Provider found",
                    ], 422); 

       }

       }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }

    }
      public function ThingProviderList(Request $request){
      try{
         $user_menu = Auth::user();
       $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();
        $data = array();
        $provider  = ThingProvider::where('complete_status', '1')->get();
        foreach($provider as $key => $value){
        $user_name =  User::select('name')->where('id',$value->user_id)->first();
        $subcategory_name =  Thing_Subcat::select('name')->where('id',$value->subcat_id)->first();
        $category_name =   Thing::select('name')->where('id',$value->cat_id)->first();

        $data[$key]['id'] = $value->id;
        $data[$key]['user_id'] = $value->user_id;
        $data[$key]['status'] = $value->status;
        $data[$key]['name'] = $user_name->name;
        $data[$key]['category'] = $category_name->name;
        $data[$key]['subcategory'] = $subcategory_name->name;

      }
          if($provider){
           return view('admin.Things.thingprovider_list')->with(compact('data','menu')); 
       }else{
        return response()->json([
                  "status" => 0,
                  "message" => "No Provider found",
                    ], 422); 

       }

       }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }

    }

    public function ApproveProvider(Request $request){
      
        try{
           $user_menu = Auth::user();
       $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();
			$provider  = PeopleProvider::where('id',$request->get('id'))->first();
	    if($provider->status == '1'){
        $chkbooking = Booking::where('people_provider_id',$request->get('id'))->first();
        if($chkbooking){

          return response()->json([
                    "status" => 2,
                    "message" => $provider->title."Can not be unapproved!",

                     ], 200); 

        }else{

          $user =   User::where('id',$provider->user_id)->first();
          $provider  = PeopleProvider::where('id',$request->get('id'))->update(['status' => '0']);

          $serverkey = 'AAAAEmcRsng:APA91bEGt33nTosoGVa_kb1vOLnxXFvrjjja3DR8M_hT7rkYpdKmEmbtM1sqMqsgsGi8EkoVRvfiD802zRlKawB-ornIV6EKTfcCbR0dl7M2kHmPmF9H57mAiyaSmUmCPHQP22fnJmSW';
             $url = 'https://fcm.googleapis.com/fcm/send';
             
             $fields = array(

               'to' => $user->device_token,
               'data' => array('title' => 'UnApproved Provider', 'body' =>  $provider->title.' is UnApproved by Admin','type' => '4' ),          
             );
             $headers = array(
               'Authorization: key=' . $serverkey,
               'Content-Type: application/json'
             );
             $ch = curl_init();
             curl_setopt($ch, CURLOPT_URL, $url);
             curl_setopt($ch, CURLOPT_POST, true);
             curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
             curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
             curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
             curl_exec($ch);
             curl_close($ch);

             $notification = new Notification;
             $notification->user_id = '1';
             $notification->message = $provider->title.' is UnApproved by Admin';
             $notification->sender = '1';
             $notification->reciever =  $user->id;
             $notification->save();

        return response()->json([
                    "status" => 2,
                    "message" => $provider->title." unapproved successfully!",

                     ], 200); 

        }
	 	   
	 	   }else{
	 	   	 $provider  = PeopleProvider::where('id',$request->get('id'))->update(['status' => '1']);
	 	   }
 
       $provider  = PeopleProvider::where('id',$request->get('id'))->update(['status' => '1']);
       $people_provider = PeopleProvider::where('id',$request->get('id'))->first();
       $user = 	User::where('id',$people_provider->user_id)->first();
        if($people_provider->status == '1'){
            User::where('id',$people_provider->user_id)->update(['role' => '3']);

            $serverkey = 'AAAAEmcRsng:APA91bEGt33nTosoGVa_kb1vOLnxXFvrjjja3DR8M_hT7rkYpdKmEmbtM1sqMqsgsGi8EkoVRvfiD802zRlKawB-ornIV6EKTfcCbR0dl7M2kHmPmF9H57mAiyaSmUmCPHQP22fnJmSW';
           $url = 'https://fcm.googleapis.com/fcm/send';
           
           $fields = array(

             'to' => $user->device_token,
             'data' => array('title' => 'Approved Provider', 'body' =>  $people_provider->title.' is approved by Admin','type' => '4' )           
           );
           $headers = array(
             'Authorization: key=' . $serverkey,
             'Content-Type: application/json'
           );
           $ch = curl_init();
           curl_setopt($ch, CURLOPT_URL, $url);
           curl_setopt($ch, CURLOPT_POST, true);
           curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
           curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
           curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
           curl_exec($ch);
           curl_close($ch);
           
           $notification = new Notification;
           $notification->user_id = '1';
           $notification->message = $people_provider->title.' is approved by Admin';
           $notification->sender = '1';
           $notification->reciever =  $user->id;
           $notification->save();

               return response()->json([
                  "status" => 1,
                  "message" => $people_provider->title." approved successfully!",

                   ], 200); 
            //return redirect('/provider_list')->with('success', 'Provider approved successfully!');  

        }else{

        	return response()->json([
                  "status" => 0,
                  "message" => "Something went wrong!",
                   ], 422); 

            //return redirect('/provider_list')->with('error', 'Something went wrong!'); 

       } 

       }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }

    }

      public function ApprovePlaceProvider(Request $request){
      
        try{
        
 	   $provider  = PlaceProvider::where('id',$request->get('id'))->first();
 	   if($provider->status == '1'){

      $chkbooking = Booking::where('places_provider_id',$request->get('id'))->first();
        if($chkbooking){

          return response()->json([
                    "status" => 2,
                    "message" => $provider->title." Can not be unapproved!",

                     ], 200); 

        }else{
 	   $user = 	User::where('id',$provider->user_id)->first();
 	   $provider  = PlaceProvider::where('id',$request->get('id'))->update(['status' => '0']);
     $providerdata  = PlaceProvider::where('id',$request->get('id'))->first();

 	   	$serverkey = 'AAAAEmcRsng:APA91bEGt33nTosoGVa_kb1vOLnxXFvrjjja3DR8M_hT7rkYpdKmEmbtM1sqMqsgsGi8EkoVRvfiD802zRlKawB-ornIV6EKTfcCbR0dl7M2kHmPmF9H57mAiyaSmUmCPHQP22fnJmSW';
           $url = 'https://fcm.googleapis.com/fcm/send';
           
           $fields = array(

             'to' => $user->device_token,
             'data' => array('title' => 'UnApproved Provider', 'body' =>  $providerdata->title.' is UnApproved by Admin','type' => '4'  ),          
           );
           $headers = array(
             'Authorization: key=' . $serverkey,
             'Content-Type: application/json'
           );
           $ch = curl_init();
           curl_setopt($ch, CURLOPT_URL, $url);
           curl_setopt($ch, CURLOPT_POST, true);
           curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
           curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
           curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
           curl_exec($ch);
           curl_close($ch);

           $notification = new Notification;
           $notification->user_id = '1';
           $notification->message = $providerdata->title.' is UnApproved by Admin';
           $notification->sender = '1';
           $notification->reciever =  $user->id;
           $notification->save();

 	   	 return response()->json([
                  "status" => 2,
                  "message" => $providerdata->title." unapproved successfully!",

                   ], 200); 
      }
 	   }else{
 	   	 $provider  = PlaceProvider::where('id',$request->get('id'))->update(['status' => '1']);
 	   }
       
       $people_provider = PlaceProvider::where('id',$request->get('id'))->first();
       $user = 	User::where('id',$people_provider->user_id)->first();
        if($people_provider->status == 1){

            User::where('id',$people_provider->user_id)->update(['role' => '3']);

           $serverkey = 'AAAAEmcRsng:APA91bEGt33nTosoGVa_kb1vOLnxXFvrjjja3DR8M_hT7rkYpdKmEmbtM1sqMqsgsGi8EkoVRvfiD802zRlKawB-ornIV6EKTfcCbR0dl7M2kHmPmF9H57mAiyaSmUmCPHQP22fnJmSW';
           $url = 'https://fcm.googleapis.com/fcm/send';
           
           $fields = array(

             'to' => $user->device_token,
             'data' => array('title' => 'Approved Provider', 'body' =>  $people_provider->title.' is approved by Admin','type' => '4'  )           
           );
           $headers = array(
             'Authorization: key=' . $serverkey,
             'Content-Type: application/json'
           );
           $ch = curl_init();
           curl_setopt($ch, CURLOPT_URL, $url);
           curl_setopt($ch, CURLOPT_POST, true);
           curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
           curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
           curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
           curl_exec($ch);
           curl_close($ch);
           
           $notification = new Notification;
           $notification->user_id = '1';
           $notification->message = $people_provider->title.' is approved by Admin';
           $notification->sender = '1';
           $notification->reciever =  $user->id;
           $notification->save();

            return response()->json([
                  "status" => 1,
                  "message" => $people_provider->title." approved successfully!",

                   ], 200); 
            //return redirect('/place_provider_list')->with('success', 'Provider approved successfully!');  

        }else{

        	return response()->json([
                  "status" => 0,
                  "message" => "Something went wrong!",
                   ], 422); 
           // return redirect('/place_provider_list')->with('error', 'Something went wrong!'); 

       } 

       }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }

    }

    public function ApproveThingProvider(Request $request){
      
        try{
 	    $provider  = ThingProvider::where('id',$request->get('id'))->first();
	    if($provider->status == '1'){

      $chkbooking = Booking::where('things_provider_id',$request->get('id'))->first();
      if($chkbooking){

          return response()->json([
                    "status" => 2,
                    "message" => $provider->title." Can not be unapproved!",

                     ], 200); 

        }else{
	 	   $user = 	User::where('id',$provider->user_id)->first();
	 	   	 $provider  = ThingProvider::where('id',$request->get('id'))->update(['status' => '0']);
         $providerdata  = ThingProvider::where('id',$request->get('id'))->first();

	 	   	  $serverkey = 'AAAAEmcRsng:APA91bEGt33nTosoGVa_kb1vOLnxXFvrjjja3DR8M_hT7rkYpdKmEmbtM1sqMqsgsGi8EkoVRvfiD802zRlKawB-ornIV6EKTfcCbR0dl7M2kHmPmF9H57mAiyaSmUmCPHQP22fnJmSW';
	           $url = 'https://fcm.googleapis.com/fcm/send';
	           
	           $fields = array(

	             'to' => $user->device_token,
	             'data' => array('title' => 'UnApproved Provider', 'body' =>  $providerdata->title.' is UnApproved by Admin','type' => '4'  ),          
	           );
	           $headers = array(
	             'Authorization: key=' . $serverkey,
	             'Content-Type: application/json'
	           );
	           $ch = curl_init();
	           curl_setopt($ch, CURLOPT_URL, $url);
	           curl_setopt($ch, CURLOPT_POST, true);
	           curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	           curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	           curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
	           curl_exec($ch);
	           curl_close($ch);

	           $notification = new Notification;
	           $notification->user_id = '1';
	           $notification->message = $providerdata->title.' is UnApproved by Admin';
             $notification->sender = '1';
             $notification->reciever =  $user->id;
	           $notification->save();

	 	   	return response()->json([
	                  "status" => 2,
	                  "message" => $providerdata->title." unapproved successfully!",

	                   ], 200); 
       }
	 	   }else{
	 	   	 $provider  = ThingProvider::where('id',$request->get('id'))->update(['status' => '1']);
	 	   }
 
       $provider  = ThingProvider::where('id',$request->get('id'))->update(['status' => '1']);
       $people_provider = ThingProvider::where('id',$request->get('id'))->first();
       $user = 	User::where('id',$people_provider->user_id)->first();
        if($people_provider->status == '1'){
            User::where('id',$people_provider->user_id)->update(['role' => '3']);

            $serverkey = 'AAAAEmcRsng:APA91bEGt33nTosoGVa_kb1vOLnxXFvrjjja3DR8M_hT7rkYpdKmEmbtM1sqMqsgsGi8EkoVRvfiD802zRlKawB-ornIV6EKTfcCbR0dl7M2kHmPmF9H57mAiyaSmUmCPHQP22fnJmSW';
           $url = 'https://fcm.googleapis.com/fcm/send';
           
           $fields = array(

             'to' => $user->device_token,
             'data' => array('title' => 'Approved Provider', 'body' =>  $people_provider->title.' is approved by Admin','type' => '4' )           
           );
           $headers = array(
             'Authorization: key=' . $serverkey,
             'Content-Type: application/json'
           );
           $ch = curl_init();
           curl_setopt($ch, CURLOPT_URL, $url);
           curl_setopt($ch, CURLOPT_POST, true);
           curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
           curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
           curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
           curl_exec($ch);
           curl_close($ch);
           
           $notification = new Notification;
           $notification->user_id = '1';
           $notification->message = $people_provider->title.' is approved by Admin';
           $notification->sender = '1';
             $notification->reciever =  $user->id;
           $notification->save();

               return response()->json([
                  "status" => 1,
                  "message" => $people_provider->title." approved successfully!",

                   ], 200); 
      
           //return redirect('/thing_provider_list')->with('success', 'Provider approved successfully!');  

        }else{

        	return response()->json([
                  "status" => 0,
                  "message" => "Something went wrong!",
                   ], 422); 
            //return redirect('/thing_provider_list')->with('error', 'Something went wrong!'); 

       } 

       }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }

    }

    public function Coupons(Request $request){

            try{
       
      $coupons  = Coupon::all(); 
       $user_menu = Auth::user();
       $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();
       if($coupons){
           return view('admin.Coupons.coupon_listview')->with(compact('coupons','menu')); 
       }else{
        
        return view('admin.Coupons.coupon_listview')->with('error', 'Something went wrong!'); 

       }

       }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }

    }

    public function AddCoupons(Request $request){

       try{
         $user_menu = Auth::user();
       $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();
       
      $coupons  = Coupon::where('coupon_code', $request->get('coupon_code'))->first(); 
       if( $request->file('background_image')!= ""){
                if (!file_exists( public_path('/coupons'))) {
                    mkdir(public_path('/coupons'), 0777, true);
                }
                $path =public_path('/coupons/');
                $image = $request->file('background_image');
                $BackgroundImage = time().'.'.$image->getClientOriginalExtension();
                $destinationPath = public_path('/coupons');
                $image->move($destinationPath, $BackgroundImage);
            }else{
                $BackgroundImage = "";  
            }

       if($coupons){

                 $updateCoupon = Coupon::where('coupon_code' , $request->get('coupon_code'))->update([
                  'coupon_code' => $request->get('coupon_code'),
                  'discount' => $request->get('discount'),
                  'rules' => $request->get('rules'),
                  'amount' => $request->get('amount'),
                  'applicable_on' => $request->get('applicable_on'),
                  'valid_for' => $request->get('valid_for'),
                  'background_image' => $BackgroundImage,             
                  ]);
          
          $coupons  = Coupon::where('coupon_code', $request->get('coupon_code'))->first(); 
          return redirect('/coupon')->with(compact('coupons','menu')); 
           
       }else{

        $coupon = new Coupon; 
        $coupon->coupon_code = $request->get('coupon_code');
        $coupon->discount = $request->get('discount');
        $coupon->rules = $request->get('rules');
        $coupon->amount = $request->get('amount');
        $coupon->applicable_on = $request->get('applicable_on');
        $coupon->valid_for = $request->get('valid_for');
        $coupon->background_image = $BackgroundImage;
        $coupon->save();

        $coupons  = Coupon::where('coupon_code', $request->get('coupon_code'))->first();
        return redirect('/coupon')->with(compact('coupons','menu'));

       }

       }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
            
        }

    }

    public function DeleteCoupon(Request $request){
             try{
       
      $coupons  = Coupon::where('id',  $request->get('id'))->delete(); 
       if($coupons){  

            return response()->json([
                  "status" => 1,
                  "message" => "Coupon deleted successfully!",
                   ], 200);     

         
           
       }else{

        return redirect('/coupon')->with('error', 'Something went wrong!');  
       }

       }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
             
        }

    }


    public function Booking($status){

      try{
         $user_menu = Auth::user();
       $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();

        if($status == 'all'){

            $status_data = "all";

          $bookings = Booking::all();
       $data = array();
       foreach ($bookings as $key => $value) {
        if($value->status == '1'){
          $status = 'Upcoming';
        }elseif($value->status == '2'){
          $status = 'Cancelled';
        }elseif($value->status == '3'){
          $status = 'Completed';
        }

        if($value->people_provider_id == "" && $value->places_provider_id == ""){
          $provider_user = ThingProvider::where('id',$value->things_provider_id)->first();
        }elseif($value->people_provider_id == "" && $value->things_provider_id == ""){
          $provider_user = PlaceProvider::where('id',$value->places_provider_id)->first();
          
        }elseif($value->places_provider_id == "" && $value->things_provider_id == ""){
          $provider_user = PeopleProvider::where('id',$value->people_provider_id)->first();
          
        }

        $user = User::where('id',$value->user_id)->first();
        if($user){
          $name =  $user->name;
        }else{
        $name = '';
        }

        $data[$key]['id'] = $value->id;
        $data[$key]['user'] = $name;
        $data[$key]['provider_title'] = $provider_user->title;
        $data[$key]['check_in'] = $value->check_in;
        $data[$key]['check_out'] = $value->check_out;
        $data[$key]['total_amount'] = $value->total_amount;
        $data[$key]['time_in'] = $value->time_in;
        $data[$key]['time_out'] = $value->time_out;
        $data[$key]['status'] =  $status;
       


         # code...
       }

       return view('admin.Bookings.booking_listview')->with(compact('data','status_data','menu'));

        }elseif($status == 'upcoming'){

            $status_data = "upcoming";

           $bookings = Booking::where('status','1')->get();
           $data = array();
           foreach ($bookings as $key => $value) {
            if($value->status == '1'){
              $status = 'Upcoming';
            }elseif($value->status == '2'){
              $status = 'Cancelled';
            }elseif($value->status == '3'){
              $status = 'Completed';
            }

            if($value->people_provider_id == "" && $value->places_provider_id == ""){
              $provider_user = ThingProvider::where('id',$value->things_provider_id)->first();
            }elseif($value->people_provider_id == "" && $value->things_provider_id == ""){
              $provider_user = PlaceProvider::where('id',$value->places_provider_id)->first();
              
            }elseif($value->places_provider_id == "" && $value->things_provider_id == ""){
              $provider_user = PeopleProvider::where('id',$value->people_provider_id)->first();
              
            }

            $user = User::where('id',$value->user_id)->first();
            if($user){
              $name =  $user->name;
            }else{
            $name = '';
            }

            $data[$key]['id'] = $value->id;
            $data[$key]['user'] = $name;
            $data[$key]['provider_title'] = $provider_user->title;
            $data[$key]['check_in'] = $value->check_in;
            $data[$key]['check_out'] = $value->check_out;
            $data[$key]['total_amount'] = $value->total_amount;
            $data[$key]['time_in'] = $value->time_in;
            $data[$key]['time_out'] = $value->time_out;
            $data[$key]['status'] =  $status;
           


             # code...
           }
           return view('admin.Bookings.booking_listview')->with(compact('data','status_data','menu'));

        }elseif($status == 'cancelled'){

            $status_data = "cancelled";

           $bookings = Booking::where('status','2')->get();
           $data = array();
           foreach ($bookings as $key => $value) {
            if($value->status == '1'){
              $status = 'Upcoming';
            }elseif($value->status == '2'){
              $status = 'Cancelled';
            }elseif($value->status == '3'){
              $status = 'Completed';
            }

            if($value->people_provider_id == "" && $value->places_provider_id == ""){
              $provider_user = ThingProvider::where('id',$value->things_provider_id)->first();
            }elseif($value->people_provider_id == "" && $value->things_provider_id == ""){
              $provider_user = PlaceProvider::where('id',$value->places_provider_id)->first();
              
            }elseif($value->places_provider_id == "" && $value->things_provider_id == ""){
              $provider_user = PeopleProvider::where('id',$value->people_provider_id)->first();
              
            }

            $user = User::where('id',$value->user_id)->first();
            if($user){
              $name =  $user->name;
            }else{
            $name = '';
            }

            $data[$key]['id'] = $value->id;
            $data[$key]['user'] = $name;
            $data[$key]['provider_title'] = $provider_user->title;
            $data[$key]['check_in'] = $value->check_in;
            $data[$key]['check_out'] = $value->check_out;
            $data[$key]['total_amount'] = $value->total_amount;
            $data[$key]['time_in'] = $value->time_in;
            $data[$key]['time_out'] = $value->time_out;
            $data[$key]['status'] =  $status;
           


             # code...
           }
           return view('admin.Bookings.booking_listview')->with(compact('data','status_data','menu'));

        }elseif($status == 'completed'){

            $status_data = "completed";

           $bookings = Booking::where('status','3')->get();
           $data = array();
           foreach ($bookings as $key => $value) {
            if($value->status == '1'){
              $status = 'Upcoming';
            }elseif($value->status == '2'){
              $status = 'Cancelled';
            }elseif($value->status == '3'){
              $status = 'Completed';
            }

            if($value->people_provider_id == "" && $value->places_provider_id == ""){
              $provider_user = ThingProvider::where('id',$value->things_provider_id)->first();
            }elseif($value->people_provider_id == "" && $value->things_provider_id == ""){
              $provider_user = PlaceProvider::where('id',$value->places_provider_id)->first();
              
            }elseif($value->places_provider_id == "" && $value->things_provider_id == ""){
              $provider_user = PeopleProvider::where('id',$value->people_provider_id)->first();
              
            }

            $user = User::where('id',$value->user_id)->first();
            if($user){
              $name =  $user->name;
            }else{
            $name = '';
            }

            $data[$key]['id'] = $value->id;
            $data[$key]['user'] = $name;
            $data[$key]['provider_title'] = $provider_user->title;
            $data[$key]['check_in'] = $value->check_in;
            $data[$key]['check_out'] = $value->check_out;
            $data[$key]['total_amount'] = $value->total_amount;
            $data[$key]['time_in'] = $value->time_in;
            $data[$key]['time_out'] = $value->time_out;
            $data[$key]['status'] =  $status;
           


             # code...
           }
           return view('admin.Bookings.booking_listview')->with(compact('data','status_data','menu'));

        }

       

      

       }catch(Exception $e){

             return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
             
        }


    }




}
