<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use App\Menu;
use App\User;

class SubAdminController extends Controller
{

	public function addsubadmin(Request $request){
    $user_menu = Auth::user();
        $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();
         return view('admin.SubAdmins.add')->with(compact('menu'));
  }
  	public function subadminlist(Request $request){
        $user_menu = Auth::user();
        $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();
        $users = User::where('role', '4')->get()->toArray();
        
         return view('admin.SubAdmins.list')->with(compact('menu','users'));
  }
  	public function editsubadmin($id){
        $user_menu = Auth::user();
        $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();
        $users = User::where('id', $id)->first();
        $menu_user = Menu::where('user_id', $id)->pluck('menu_name')->toArray();
        
         return view('admin.SubAdmins.edit')->with(compact('menu','users','menu_user'));
  }
  	public function deletesubadmin(Request $request){
        $user_menu = Auth::user();
        $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();
        $usersdelete = User::where('id', $request->id)->delete();
        $menu_user = Menu::where('user_id', $request->id)->delete();
        if($usersdelete){
          return response()->json([
                  "status" => 1,
                   "message" => "Sub Admin deleted Successfully",
                      
                   ], 200); 
        }else{
            return response()->json([
                  "status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
        }
  }

  	public function editsavesubadmin(Request $request){

        $user_menu = Auth::user();
        $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();
        
        $userDATA = User::where('id', $request->id)->first();
        if($request->password == ''){
          $pass = $userDATA->password;
        }else{
          $pass = bcrypt($request->password);
        }
        $user_update = User::where('id', $request->id)->update([
        	'name' => $request->name,
        	'email' => $request->email, 
          'password' => $pass
        ]);
        
    	if($user_update){
    		$menu = Menu::where('user_id', $request->id)->delete();
    		foreach ($request->permissions as $key => $permission) {
    			$menu = new Menu;
    			$menu->user_id = $request->id;
    			$menu->role = '4';
    			$menu->menu_name = $permission; 
    			$menu->save();
    		} 
    		$users = User::where('id', $request->id)->where('role', '4')->get()->toArray();
    		$request->session()->flash('alert-success', 'Sub Admin Successfully Updated');
    		return redirect()->back()->with('message', 'Sub Admin Successfully Updated.');
        }else{
           $request->session()->flash('alert-danger', 'Something went wrong');
           return redirect()->back()->with('message', 'Something went wrong.');       
        }
        
  }

  
  
  

    public function addnewsubadmin(Request $request){
    		
    	$user = new User;
    	$user->name = $request->name;
    	$user->email = $request->email;
    	$user->password = bcrypt($request->password);
    	$user->role = '4';
    	if($user->save()){

    		foreach ($request->permissions as $key => $permission) {
    			$menu = new Menu;
    			$menu->user_id = $user->id;
    			$menu->role = '4';
    			$menu->menu_name = $permission; 
    			$menu->save();
    		} 
    		$request->session()->flash('alert-success', 'Sub Admin Successfully Added');
    		return redirect('/subadminlist')->with('message', 'Sub Admin Successfully Added.');
        }else{
           $request->session()->flash('alert-danger', 'Something went wrong');
           return redirect()->back()->with('message', 'Something went wrong.');       
        }
    }
    
}
