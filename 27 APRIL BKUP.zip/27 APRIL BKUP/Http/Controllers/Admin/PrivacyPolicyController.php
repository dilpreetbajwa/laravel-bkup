<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Validator;
use Redirect;
use App\Privacy;
use App\Menu;
use Auth;
class PrivacyPolicyController extends Controller
{
     public function index(){
         $user_menu = Auth::user();
       $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();
    	$data = Privacy::where('title','Privacy Policy')->first();
    	return view('admin.PrivacyPolicy.add')->with(compact('data','menu'));
    }
     public function add(Request $request){

    	try{

    		$rules = [                
              'title' => 'required',
              'description' => 'required',
            ];

            	$validator = Validator::make($request->all(), $rules);

                if($validator->fails())
                {

                return Redirect::back()->withErrors($validator); 
                                 
                }
                 $user_menu = Auth::user();
                 $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();

                $terms_and_condition = Privacy::where('title','Privacy Policy')->first();

                if($terms_and_condition){

                     Privacy::where('title','Privacy Policy')->update([
                     	'description' => $request->get('description'),
                     ]);

                     $data = Privacy::where('title','Privacy Policy')->first();
	                $request->session()->flash('alert-success', 'Privacy Policy updated successfully!');
	               return Redirect::back()->with(compact('data','menu'));

                }else{

	                $terms = new Privacy;
	                $terms->title = $request->get('title');
	                $terms->description = $request->get('description');    
	                $terms->save();

	                $data = Privacy::where('title','Privacy Policy')->first();
	                $request->session()->flash('alert-success', 'Privacy Policy added successfully!');
	               return Redirect::back()->with(compact('data','menu'));

                }
                          

                  
                	

             }catch(Exception $e){

             	return response()->json([
                  		"status" => 0,
                        "message" => "Something went wrong!",
                       'errors' => $validator->errors()->toArray(),
                   ], 422); 
             }

    }
}
