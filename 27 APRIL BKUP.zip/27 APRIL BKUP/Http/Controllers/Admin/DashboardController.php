<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Booking;
use App\Menu;
class DashboardController extends Controller
{
     public function index(){

     	$user = Auth::user();

     	$total_users = User::count();
     	$total_users_providers = User::where('role','3')->count();
     	$total_bookings = Booking::count();
     	$menu = Menu::where('user_id', $user->id)->pluck('name');
     	return $menu;
     	die();
     	$total_bookings_earnings = Booking::where('status' ,'!=','2')->sum('total_amount');
       
    	return view('admin.dashboard')->with(compact('total_users','total_bookings','total_users_providers','total_bookings_earnings'));
    }
     public function getUsers(){
       
    	return view('admin.user_list');
    }
}
