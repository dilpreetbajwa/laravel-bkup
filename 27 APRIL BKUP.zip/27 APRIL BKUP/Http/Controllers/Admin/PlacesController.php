<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Place;
use Auth;
use App\Menu;
class PlacesController extends Controller
{
    public function index()
    {
    	$data = Place::all();
         $user_menu = Auth::user();
       $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();
    	return view('admin.Places.add_places')->with(compact('data','menu'));;
    }
    public function subcategory()
    	{
    		$place = Place::all();
             $user_menu = Auth::user();
       $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();
    	    return view('admin.Places.add_places_subcat')->with(compact('place','menu'));
		}
}
