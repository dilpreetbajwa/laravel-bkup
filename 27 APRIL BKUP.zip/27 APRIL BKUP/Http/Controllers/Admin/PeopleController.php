<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\People;
use App\Menu;
use Auth;
class PeopleController extends Controller
{
   public function index()
    	{
    		$data = People::all();
             $user_menu = Auth::user();
       $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();
    	    return view('admin.Peoples.add_peoples')->with(compact('data','menu'));
		}

		public function subcategory()
    	{
             $user_menu = Auth::user();
       $menu = Menu::where('user_id', $user_menu->id)->pluck('menu_name')->toArray();
    		$people = People::all();
    	    return view('admin.Peoples.add_people_subcat')->with(compact('people','menu'));
		}
}
