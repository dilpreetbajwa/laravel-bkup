<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();

});

Route::group(['namespace' => 'Api'], function() {
      Route::post('/signup', 'UserController@signup');
      Route::post('/social_login', 'UserController@SoialLogin');
      Route::post('/login', 'UserController@login');
  	  Route::post('/forgot-password', 'UserController@forgotPassword');
      Route::group(['middleware'=>['auth:api']], function(){
        
      Route::post('/changepassword', 'UserController@changepassword');
      Route::post('/update-devicetoken', 'UserController@update_deviceToken');
  		Route::post('/update-profile', 'UserController@updateprofile');
  		Route::post('/get-profile', 'UserController@getProfile');
      Route::post('/serviceprovider', 'PlacesController@BecomeProvider');
      Route::post('/placeprovider', 'PlacesController@PlaceProvider');
      Route::post('/thingprovider', 'PlacesController@ThingProvider');
      Route::post('/deleteprovider', 'PlacesController@delete_provider');
      Route::post('/workdetails', 'PlacesController@Workdetails');
      Route::post('/thingsworkdetails', 'PlacesController@ThingsWorkdetails');
      Route::post('/placesworkdetails', 'PlacesController@PlacesWorkdetails');
      Route::post('/reviews', 'PlacesController@AllReviews');
      Route::post('/favourites', 'PlacesController@favourites');
      Route::post('/createpaymentcard', 'PlacesController@createpaymentcard');
      Route::post('/getallcreditcards', 'PlacesController@getallcreditcards');
      Route::post('/deletecreditcards', 'PlacesController@deletecreditcards');
      Route::post('/payment', 'PlacesController@payment');
      Route::post('/createtoken', 'PlacesController@createtoken'); 
      Route::post('/applycoupon', 'PlacesController@applycoupon'); 
      Route::post('/booking_list', 'PlacesController@booking_list'); 
      Route::post('/favourites_savedlist', 'PlacesController@favourites_savedlist');
      Route::post('/slots', 'PlacesController@slots');
      Route::post('/bookingListDetail', 'PlacesController@bookingListDetail');
      Route::post('/cancelbooking', 'PlacesController@CancelBooking');
      Route::post('/booking_requestlist', 'PlacesController@booking_requestlist');
      Route::post('/provider_progress', 'PlacesController@my_progress');
      Route::get('/home', 'PlacesController@getPlaces');
      Route::post('/get_places', 'PlacesController@getPlaces');
      Route::post('/addReview', 'PlacesController@addReview');
      Route::post('/host_transaction_history', 'PlacesController@Host_transaction_history'); 
      Route::post('/provider_reviews', 'PlacesController@provider_reviews');
      Route::post('/listings', 'PlacesController@listings');
      Route::post('/check_balance', 'PlacesController@check_balance');   
      Route::post('/vault_withdraw', 'PlacesController@vault_withdraw'); 
      Route::post('/provider_details', 'PlacesController@provider_details');
      Route::post('/get_provider_details', 'PlacesController@get_provider_details');
      Route::post('/delete_attachments', 'PlacesController@delete_attachments');
      Route::post('/edit_provider_detail', 'PlacesController@edit_provider_detail');
      Route::post('/specific_users_chat', 'PlacesController@SpecificUsersChat');
      Route::post('/show_lastmessage', 'PlacesController@Show_lastmessage');
      Route::post('/deletechat', 'ChatController@deleteChat');
      Route::post('/upload-image', 'UserController@uploadImage');
      Route::post('/getissue_types', 'SupportController@GetIssueTypes');
      Route::post('/addsupport_issue', 'SupportController@AddSupportIssues');
      Route::get('/notifications', 'NotificationController@notifications');
            Route::post('/get_peopledetail', 'PlacesController@getPeopleDetail'); 
      Route::post('/get_thingsdetail', 'PlacesController@getThingsDetail'); 
      Route::post('/get_placesdetail', 'PlacesController@getPlaceDetail'); 
      Route::post('/get_categorydetail', 'PlacesController@CategoryDetaildata');
    
        
           
      
});  
    Route::post('/verifyphone_no', 'UserController@VerifyPhone_no');  
    Route::get('/faq', 'ManagementController@faq');
    Route::get('/about_us', 'ManagementController@about_us');
    Route::get('/privacy_policy', 'ManagementController@privacy_policy');
    Route::get('/terms_and_condition', 'ManagementController@terms_and_condition');
    Route::get('/nonDiscrimination', 'ManagementController@nonDiscrimination');
    Route::get('/paymentTermOfService', 'ManagementController@paymentTermOfService');
    
    Route::post('/get_things', 'PlacesController@getthings');	
  	Route::post('/get_people', 'PlacesController@getPeople');
    Route::post('/get_people_subcat', 'PlacesController@getPeoplesubcat');
    Route::post('/get_places_subcat', 'PlacesController@getPlacessubcat');
    Route::post('/get_things_subcat', 'PlacesController@getThingsSubcat');
     
});