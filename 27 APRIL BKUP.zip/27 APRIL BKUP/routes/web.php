<?php
use App\Place;
use App\Thing;
use App\People;
use App\PlaceProvider;
use App\PeopleProvider;
use App\ThingProvider;
use App\Booking;
use App\Review;
use App\User;
use App\Attachment;
use Illuminate\Http\Request;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function (Request $request) {
   $today =  date('Y-m-d');
	$allcategories = Place::orderBy('name')->get();
	$alltopratedplaces = PlaceProvider::with('getimage')->orderBy('ratings','DESC')->take(10)->get();
	$allplacecat =  Place::orderBy('name')->get();
    $allthingscat = Thing::orderBy('name')->get();
    $allpeoplecat =  People::orderBy('name')->get();
    if(Auth::check())
    {

    	Booking::where('user_id',Auth::user()->id)->where('status','1')->whereDate('check_out', '<', $today)->update([
                    'status' => '3',
                   ]);
          $reviews =  Review::pluck('booking_id');
          $bookings = Booking::where('user_id',Auth::user()->id)->where('status','3')->whereNotIn('id',$reviews)->get();
         
          if(count($bookings)>0){

          	$request->session()->put('reviews',1);
            return view('frontend.index')->with(compact('allcategories','alltopratedplaces','allplacecat','allthingscat','allpeoplecat'));
           }
           else{
           $request->session()->forget('reviews');
       	}

    }
	
   return view('frontend.index')->with(compact('allcategories','alltopratedplaces','allplacecat','allthingscat','allpeoplecat'));
    
})->name('home1');


Route::get('/bookings', function () {
	if(Auth::check() && Auth::user()->userheaderstatus==1)
    {
      return Redirect::back()->withInput()->with("booking_modal", 1);     
    }
	return view('frontend.booking_place');
});

Route::get('/confirmplacedetails/{pid?}', function (Request $request,$pid=Null) {
	$pics = session()->get( 'pics' );
	$providerid = base64_decode($pid);

	$placedetails = PlaceProvider::where('id',$providerid)->first();

	$allimages = array();
	$attachments = Attachment::select('filenames')->where('places_provider_id',$providerid)->get(); 
      foreach ($attachments as $key => $value) {
        $allimages[$key]= URL::to('/').'/attachments/'.$value['filenames'];
      }
       $allimages1 = $allimages;

	return view('frontend.confirmplacedetails')->with(compact('pics','placedetails','allimages1'));
})->name('confirmplacedetails');


Route::get('/confirmthingdetails/{pid?}', function (Request $request,$pid=Null) {
	$pics = session()->get( 'pics' );
	$providerid = base64_decode($pid);
	$thingsdetails = ThingProvider::where('id',$providerid)->first();
	$allimages = array();
	$attachments = Attachment::select('filenames')->where('things_provider_id',$providerid)->get(); 

      foreach ($attachments as $key => $value) {
        $allimages[$key]= URL::to('/').'/attachments/'.$value['filenames'];
      }
       $allimages1 = $allimages;
	return view('frontend.confirmthingdetails')->with(compact('pics','thingsdetails','allimages1'));
})->name('confirmthingdetails');

Route::get('/confirmservicedetails/{pid?}', function (Request $request,$pid=Null) {
	
	$providerid = base64_decode($pid);
	$peopledetails = PeopleProvider::where('id',$providerid)->first();
	$pics = User::where('id',$peopledetails['user_id'])->value('image');
	$allimages1 = array();
	return view('frontend.confirmservicedetails')->with(compact('pics','peopledetails'));
})->name('confirmservicedetails');


Route::group(['namespace'=>'Web'], function(){
	Route::group(['middleware'=>['auth','checkrole']], function(){	
		// Route::match (['get','post'],'/bookings-history', 'HomeController@bookings_history')->name('bookings_history');

	});	
	Route::match (['get','post'],'/test', 'HomeController@test')->name('test');	
	Route::match (['get','post'],'/addthingdetails', 'HomeController@addthingdetails')->name('addthingdetails');	
	Route::match (['get','post'],'/addservicedetails', 'HomeController@addservicedetails')->name('addservicedetails');	
	Route::match (['get','post'],'/addplacesdetails', 'HomeController@addplacesdetails')->name('addplacesdetails');	
		
	Route::post('/user-login', 'HomeController@user_login')->name('user_login');
    Route::post('/check-email', 'HomeController@check_email')->name('check_email');
    Route::post('/check-phoneno', 'HomeController@check_phone')->name('check_phone');
    Route::post('/check-password', 'HomeController@check_password')->name('check_password');
    Route::post('/sign-up', 'HomeController@sign_up')->name('sign_up');
    Route::post('/send-otp', 'HomeController@send_otp')->name('send-otp');
    Route::get('login/facebook', 'HomeController@redirectSiteFb');
	Route::get('login/facebook/callback', 'HomeController@handleFacebookCallback');
	Route::get('login/google', 'HomeController@redirectSitegoogle');
	Route::get('login/google/callback', 'HomeController@handleGoogleCallback');
	Route::post('/forgot-password', 'HomeController@forgotpassword');
	Route::match(['get','post'],'logout1', 'HomeController@logout');
	Route::get( '/instagram/','HomeController@instagramLogin' );
	Route::get ('/instagram/callback/', 'HomeController@instagramCallback' );
	Route::match (['get','post'],'/bookings', 'HomeController@bookingpagedata')->name('bookingpagedata');
	Route::match (['get','post'],'/getplacelistings/{id?}', 'HomeController@getplacelistings')->name('placelisting');
	Route::match (['get','post'],'/getthingslistings/{id?}', 'HomeController@getthingslistings')->name('thingslisting');
	Route::match (['get','post'],'/getpeoplelistings/{id?}', 'HomeController@getpeoplelistings')->name('peoplelisting');	
	Route::match (['get','post'],'/booking-placedetails/{id?}', 'HomeController@bookingplacedetail')->name('bookingplacedetail');	
	Route::match (['get','post'],'/booking-thingdetails/{id?}', 'HomeController@bookingthingdetail')->name('bookingthingdetail');	
	Route::match (['get','post'],'/booking-peopledetails/{id?}', 'HomeController@bookingpeopledetail')->name('bookingpeopledetail');	
	Route::match (['get','post'],'/booking-placeavailability/{id?}', 'HomeController@bookingplaceavailability')->name('bookingplaceavailability');	
	Route::match (['get','post'],'/booking-thingavailability/{id?}', 'HomeController@bookingthingavailability')->name('bookingthingavailability');	
	Route::match (['get','post'],'/booking-peopleavailability/{id?}', 'HomeController@bookingpeopleavailability')->name('bookingpeopleavailability');
	Route::match (['get','post'],'/paymentservices/{id?}/{checkindate?}/{checkoutdate?}', 'HomeController@paymentservices')->name('paymentservices');
	Route::match (['get','post'],'/paymentplaces/{id?}/{guest?}/{checkindate?}/{checkoutdate?}', 'HomeController@paymentplaces')->name('paymentplaces');
	Route::match (['get','post'],'/paymentthings/{id?}/{checkindate?}/{checkoutdate?}', 'HomeController@paymentthings')->name('paymentthings');	
	Route::get ('/user-profile', 'HomeController@userprofile');

	Route::post ('/update-profile', 'HomeController@updateprofile');
	Route::post ('/get-subcatplaces', 'HomeController@getsubcategoriesplaces');
	Route::post ('/get-subcatthings', 'HomeController@getsubcategoriesthings');
	Route::post ('/get-subcatpeople', 'HomeController@getsubcategoriespeople');
	Route::match (['get','post'],'/confirmplaces', 'HomeController@confirmplaces')->name('confirmplaces');	
	Route::match (['get','post'],'/confirmthings', 'HomeController@confirmthings')->name('confirmthings');	
	Route::match (['get','post'],'/confirmpeople', 'HomeController@confirmpeople')->name('confirmpeople');
	Route::match (['get','post'],'/token', 'HomeController@createtoken')->name('token');
	Route::match (['get','post'],'/payment', 'HomeController@payment')->name('payment');
	Route::match (['get','post'],'/applycoupon', 'HomeController@applycoupon')->name('applycoupon');
	Route::match (['get','post'],'/bookings-history', 'HomeController@bookings_history')->name('bookings_history');
	Route::match (['get','post'],'/request_bookinglist', 'HomeController@request_bookinglist')->name('request_bookinglist');
	Route::match (['get','post'],'/booking-historydetail/{id?}', 'HomeController@booking_historydetail')->name('booking_historydetail');
	Route::match (['get','post'],'/cancel-booking', 'HomeController@cancel_booking')->name('cancel_booking');
	Route::match (['get','post'],'/provider-reviews', 'HomeController@provider_reviews')->name('provider-reviews');
	Route::match (['get','post'],'/check-balance', 'HomeController@check_balance')->name('check-balance');
	Route::match (['get','post'],'/my-progress', 'HomeController@my_progress')->name('my-progress');
	Route::match (['get','post'],'/favourites', 'HomeController@favourites')->name('favourites');
	Route::match (['get','post'],'/addReview', 'HomeController@addReview')->name('addReview');
	Route::match (['get','post'],'/transaction-history', 'HomeController@Host_transaction_history')->name('transaction-history');
	Route::match (['get','post'],'/my-requests', 'HomeController@my_requests')->name('my_requests');
	Route::match (['get','post'],'/show-categories', 'HomeController@show_categories')->name('show-categories');
	Route::match (['get','post'],'/about-us', 'HomeController@about_us')->name('about-us');
	Route::match (['get','post'],'/terms-and-conditions', 'HomeController@terms_and_conditions')->name('terms-and-conditions');
	Route::match (['get','post'],'/faqs', 'HomeController@faqs')->name('faqs');
	Route::match (['get','post'],'/privacy-policy', 'HomeController@privacy_policy')->name('privacy-policy');
	Route::match (['get','post'],'/search-data/{cat?}/{type?}/{lat?}/{lng?}', 'HomeController@searchdata')->name('search-data');
	Route::match (['get','post'],'/add-reviews', 'HomeController@add_reviews')->name('add-reviews');
	Route::match (['get','post'],'/serviceproviderinformation', 'HomeController@serviceproviderinformation')->name('serviceproviderinformation');
	Route::match (['get','post'],'/addbankdetails', 'HomeController@addbankdetails')->name('addbankdetails');
	Route::match (['get','post'],'/balance-check', 'HomeController@balancecheck')->name('balancecheck');
	Route::match (['get','post'],'/mylistings', 'HomeController@mylistings')->name('mylistings');
	Route::match (['get','post'],'/contact-us', 'HomeController@getallissues')->name('getallissues');
	Route::match (['get','post'],'/editplaceprovider/{id?}', 'HomeController@editplaceprovider')->name('editplaceprovider');
	Route::match (['get','post'],'/editthingprovider/{id?}', 'HomeController@editthingprovider')->name('editthingprovider');
	Route::match (['get','post'],'/editpeopleprovider/{id?}', 'HomeController@editpeopleprovider')->name('editpeopleprovider');
	Route::match (['get','post'],'/updateuserstatus', 
		'HomeController@updateuserstatus')->name('updateuserstatus');
	Route::match (['get','post'],'/notifications', 
		'HomeController@notifications')->name('notifications');
	Route::match (['get','post'],'/invite-share', 
		'HomeController@invite_share')->name('invite-share');
	Route::match (['get','post'],'/deleteattachment', 
		'HomeController@deleteattachment')->name('deleteattachment');
	Route::match (['get','post'],'/notifications', 
		'HomeController@notifications')->name('notifications');
	Route::match (['get','post'],'share_email', 
		'HomeController@share_email')->name('share_email');
	Route::match (['get','post'],'share_url', 
		'HomeController@share_url')->name('share_url');
	Route::match (['get','post'],'allfavourites', 
		'HomeController@allfavourites')->name('allfavourites');
	Route::match (['get','post'],'howitworks', 
		'HomeController@howitworks')->name('howitworks');	
	Route::match (['get','post'],'onlinesupport', 
		'HomeController@onlinesupport')->name('onlinesupport');
	Route::match (['get','post'],'trustandsafety', 
		'HomeController@trustandsafety')->name('trustandsafety');
	Route::match (['get','post'],'help', 
		'HomeController@help')->name('help');
	Route::match (['get','post'],'backtologin', 
		'HomeController@backtologin')->name('backtologin');
	Route::match (['get','post'],'updatenotifystatus', 
		'HomeController@updatenotifystatus')->name('updatenotifystatus');
	
	
	


	Route::get('/editconfirmplace/{pid?}', function (Request $request,$pid=Null) {	
	$providerid = base64_decode($pid);
	$placedetails = PlaceProvider::where('id',$providerid)->first();
	$allimages = array();
    $attachments = Attachment::select('filenames')->where('places_provider_id',$providerid)->get(); 

      foreach ($attachments as $key => $value) {
        $allimages[$key]= URL::to('/').'/attachments/'.$value['filenames'];
      }
       $allimages1 = $allimages;
	return view('frontend.editconfirmplace')->with(compact('placedetails','allimages1'));
})->name('editconfirmplace');

Route::get('/confirmthingdetails/{pid?}', function (Request $request,$pid=Null) {	
	$providerid = base64_decode($pid);
	$thingsdetails = ThingProvider::where('id',$providerid)->first();
	$allimages = array();
    $attachments = Attachment::select('filenames')->where('things_provider_id',$providerid)->get(); 

      foreach ($attachments as $key => $value) {
        $allimages[$key]= URL::to('/').'/attachments/'.$value['filenames'];
      }
       $allimages1 = $allimages;
	return view('frontend.editconfirmthing')->with(compact('thingsdetails','allimages1'));
})->name('confirmthingdetails');


Route::get('/confirmpeopledetails/{pid?}', function (Request $request,$pid=Null) {	
	$providerid = base64_decode($pid);
	$peopledetails = PeopleProvider::where('id',$providerid)->first();
	 $attachments = Attachment::select('filenames')->where('people_provider_id',$providerid)->get(); 

      foreach ($attachments as $key => $value) {
        $allimages[$key]= URL::to('/').'/attachments/'.$value['filenames'];
      }
       $allimages1 = $allimages;
	
	return view('frontend.editconfirmpeople')->with(compact('peopledetails','allimages1'));
})->name('confirmpeopledetails');


	
	
});
Auth::routes();
Route::group(['middleware'=>['auth']], function(){
Route::get('/home', 'DashboardController@index')->name('home');
});
Route::get('logout', '\App\Http\Controllers\Auth\LoginController@logout');


Route::group(['namespace' => 'Admin'], function() {

	Route::get('/addsubadmin', 'SubAdminController@addsubadmin')->name('addsubadmin');
	Route::get('/subadminlist', 'SubAdminController@subadminlist')->name('subadminlist');
	Route::post('/addnewsubadmin', 'SubAdminController@addnewsubadmin')->name('addnewsubadmin');
	Route::get('/edit-subadmin/{id}', 'SubAdminController@editsubadmin')->name('editsubadmin');
	Route::post('/editsavesubadmin', 'SubAdminController@editsavesubadmin')->name('editsavesubadmin');
	Route::post('/delete-subadmin', 'SubAdminController@deletesubadmin')->name('delete-subadmin');
	
	
	
	Route::get('/users', 'AdminController@users')->name('users');
	Route::get('/my_profile', 'AdminController@my_profile')->name('my_profile');
	Route::post('/edit_my_profile', 'AdminController@edit_my_profile')->name('edit_my_profile');
	
	Route::get('/delete-user/{id}', 'AdminController@deleteUser');
	Route::get('place', 'PlacesController@index')->name('place');
	Route::get('place_subcat', 'PlacesController@subcategory')->name('place_subcat');

	Route::get('thing', 'ThingsController@index')->name('thing');
	Route::get('thing_subcat', 'ThingsController@subcategory')->name('thing_subcat');

	Route::get('people', 'PeopleController@index')->name('people');
	Route::get('people_subcat', 'PeopleController@subcategory')->name('people_subcat');
	Route::post('add_places', 'AdminController@AddPlaces')->name('add_places');
	Route::get('edit-places/{id}', 'AdminController@EditPlaces');
	Route::post('delete-people/', 'AdminController@DeletePeople')->name('delete-people');
	Route::post('delete-places/', 'AdminController@DeletePlaces')->name('delete-places');
	Route::post('delete-things/', 'AdminController@DeleteThings')->name('delete-things');
	Route::post('edit_place_data', 'AdminController@EditPlacesData')->name('edit_place_data');
	Route::post('add_places_subcategory', 'AdminController@AddPlacesSubcategory')->name('add_places_subcategory');

	Route::post('add_things', 'AdminController@AddThings')->name('add_things');
	Route::get('edit-things/{id}', 'AdminController@EditThings');
	Route::post('edit_things_data', 'AdminController@EditThingsData')->name('edit_things_data');
	Route::post('add_things_subcategory', 'AdminController@AddThingsSubcategory')->name('add_things_subcategory');

	Route::post('add_peoples', 'AdminController@AddPeople')->name('add_peoples');
	Route::get('edit-people/{id}', 'AdminController@EditPeople');
	Route::post('edit_people_data', 'AdminController@EditPeopleData')->name('edit_people_data');
	Route::post('add_people_subcategory', 'AdminController@AddPeopleSubcategory')->name('add_people_subcategory');

	Route::get('provider_list', 'AdminController@ProviderList')->name('provider_list');
	Route::get('thing_provider_list', 'AdminController@ThingProviderList')->name('thing_provider_list');
	Route::get('place_provider_list', 'AdminController@PlaceProviderList')->name('place_provider_list');

	Route::post('approve_provider', 'AdminController@ApproveProvider')->name('approve_provider');
	Route::post('approve_placeprovider', 'AdminController@ApprovePlaceProvider')->name('approve_placeprovider');
	Route::post('approve_thingprovider/', 'AdminController@ApproveThingProvider')->name('approve_thingprovider');
	Route::post('get_things', 'AdminController@GetThings')->name('get_things');

	Route::get('coupon', 'AdminController@Coupons')->name('coupon');
	Route::post('add_coupon', 'AdminController@AddCoupons')->name('add_coupon');
	Route::post('delete-coupon', 'AdminController@DeleteCoupon')->name('delete-coupon');
	Route::get('booking_list/{status}', 'AdminController@Booking')->name('booking_list');

	Route::get('supportIssue_type', 'SupportController@index')->name('supportIssue_type');
	Route::post('delete-support', 'SupportController@delete_issue')->name('delete-support'); 
	Route::post('delete_supportissue_type', 'SupportController@delete_supportissue_type')->name('delete_supportissue_type');  
	
	Route::post('add_issue_type', 'SupportController@add_issueType')->name('add_issue_type'); 
	
	Route::get('issue_listview', 'SupportController@Issue_ListView')->name('issue_listview'); 

	Route::match (['get','post'],'/faq', 'FAQController@index')->name('faq');
	Route::match (['get','post'],'/add_faq', 'FAQController@add_faq')->name('add_faq');
	Route::match (['get','post'],'/faq_list', 'FAQController@faq_list')->name('faq_list');
	Route::match (['get','post'],'/edit-faq/{id}', 'FAQController@edit_faq_view')->name('edit-faq'); 
	Route::match (['get','post'],'/editfaq', 'FAQController@edit_faq')->name('editfaq');
	Route::match (['get','post'],'/delete-faq', 'FAQController@delete_faq')->name('delete-faq');

	Route::match (['get','post'],'/terms_and_condition', 'TermsConditionController@index')->name('terms_and_condition');
	Route::match (['get','post'],'/add_terms_and_condition', 'TermsConditionController@add')->name('add_terms_and_condition');

	Route::match (['get','post'],'/privacy_policy', 'PrivacyPolicyController@index')->name('privacy_policy');
	Route::match (['get','post'],'/add_privacy_policy', 'PrivacyPolicyController@add')->name('add_privacy_policy');

	Route::match (['get','post'],'/transaction_history', 'TransactionController@transaction_history')->name('transaction_history');
	Route::match (['get','post'],'/vault_transactions', 'TransactionController@vault_transansation')->name('vault_transactions');
	Route::get ('/transactiondetails/{id}', 'TransactionController@TransactionDetails')->name('transactiondetails');
	Route::get ('/recieved_transactiondetails/{id}', 'TransactionController@RecievedTransactionDetails')->name('recieved_transactiondetails');
	
	Route::match (['get','post'],'/approve_transaction_complete', 'TransactionController@approve_transaction_complete')->name('approve_transaction_complete');
	

	Route::match (['get','post'],'/about_us', 'AboutUsController@index')->name('about_us');
	Route::match (['get','post'],'/add_about_us', 'AboutUsController@add')->name('add_about_us');

	Route::match (['get','post'],'/online_support', 'PaymentServicesController@index')->name('online_support');
	Route::match (['get','post'],'/add_online_support', 'PaymentServicesController@add')->name('add_online_support');
	Route::match (['get','post'],'/trust_and_safety', 'PaymentServicesController@trust_and_safety')->name('trust_and_safety');
	Route::match (['get','post'],'/add_trust_and_safety', 'PaymentServicesController@add_trust_and_safety')->name('add_trust_and_safety');
	
	

	Route::match (['get','post'],'/nondescrimination', 'NonDescriminationController@index')->name('nondescrimination');
	Route::match (['get','post'],'/add_non_descrimination', 'NonDescriminationController@add')->name('add_non_descrimination');

	

}); 
